# Deployment Guide

Complete instructions for setting up, running, and reproducing results from the **Overlap-Aware FiLM Conditioning** project.

---

## Table of Contents

1. [Data Acquisition](#1-data-acquisition)
2. [Software & Hardware Requirements](#2-software--hardware-requirements)
3. [Code Architecture](#3-code-architecture)
4. [How to Run](#4-how-to-run)
5. [How to Check Results](#5-how-to-check-results)
6. [Figure Generation](#6-figure-generation)
7. [Troubleshooting](#7-troubleshooting)

---

## 1. Data Acquisition

The project uses permafrost thermal and deformation data from open-access repositories. There are **two paths**: real data (requires download) or synthetic data (always available, no download needed).

### 1.1 Real Datasets

| ID | Dataset | Source | DOI / URL | Format |
|:---|:---|:---|:---|:---|
| D1 | Qinghai-Tibet Corridor 2D Deformation (2017–2022) | TPDC | `10.11888/cryos.tpdc.300400` | GeoTIFF |
| D2 | GTN-P CALM Active Layer Thickness | PANGAEA | `10.1594/PANGAEA.972777` | CSV |
| A1 | Chaimu Railway Deformation + Damage | TPDC | `f7be4a1d-2506` | Mixed |
| A5 | Northeast China Permafrost Engineering Stability | NCDC | `70c33bc7` | Mixed |
| A8 | Yeniugou Permafrost Deformation + ALT | TPDC | `dd24266c` | Mixed |

**Download methods:**

```bash
# Option A: Automated download (handles TPDC FTP and HTTP sources)
python download_datasets.py --config configs/autodl_gpu.yaml

# Option B: Manual download
# Visit the DOI URLs above in a browser, download to:
#   <project_root>/datasets/raw/
# or any path specified by --data-root
```

> **Note on TPDC FTP access:** The TPDC (Tibetan Plateau Data Center) provides FTP access for large datasets. The script `data/ftp_download_tpdc.py` handles FTP connections, but TPDC sometimes requires registration. If FTP fails, download manually from the web portal and place files in `datasets/raw/`.

### 1.2 Synthetic Data (Fallback)

If real data is unavailable, the framework automatically generates **physics-based synthetic data** using the Stefan equation and thermodynamic models. This requires no download and always works:

```bash
python run_main.py --config configs/simulation_fallback.yaml
```

The synthetic generator (`data/synthetic_generator.py`) produces physically plausible permafrost thermal fields with known ground-truth, suitable for framework validation and debugging.

---

## 2. Software & Hardware Requirements

### 2.1 Software

| Component | Version | Notes |
|:---|:---|:---|
| Python | 3.12+ | Tested on 3.12.4 |
| PyTorch | 2.4+ (CUDA 12.4) | `pip install torch --index-url https://download.pytorch.org/whl/cu124` |
| NumPy | ≥1.26 | Core array operations |
| Pandas | ≥2.2 | Data I/O |
| Scikit-learn | ≥1.5 | Baseline models (RF, XGBoost) |
| Matplotlib | ≥3.9 | Figure generation |
| PyYAML | ≥6.0 | Configuration parsing |
| rasterio | ≥1.3 | GeoTIFF reading (real data only) |
| xarray | ≥2024.1 | NetCDF handling (real data only) |

**Install all at once:**

```bash
pip install -r requirements.txt
```

### 2.2 Hardware

| Configuration | Minimum | Recommended |
|:---|:---|:---|
| GPU | NVIDIA GTX 1080 (8 GB) | NVIDIA RTX 4090 (24 GB) |
| RAM | 16 GB | 32 GB+ |
| Storage | 10 GB free | 50 GB+ (for real datasets) |
| CUDA | 12.0+ | 12.4+ |

> **Cloud GPU note:** We tested on [AutoDL](https://www.autodl.com/) with RTX 4090 instances. The setup script `setup_autodl.sh` automates the full environment configuration on AutoDL.

### 2.3 AutoDL Quick Setup

```bash
# SSH into your AutoDL instance, then:
git clone <repo-url> && cd overlap-aware-film-permafrost
bash setup_autodl.sh
```

The script installs all Python dependencies, verifies CUDA availability, and sets `DATA_ROOT` to the AutoDL data disk (`/root/autodl-tmp`).

---

## 3. Code Architecture

```
overlap-aware-film-permafrost/
├── run_main.py                  # 🚀 Main entry point (single-command training)
├── download_datasets.py         # Automated data download
├── setup_autodl.sh              # AutoDL cloud GPU setup script
├── requirements.txt             # Python dependencies
├── LICENSE                      # Academic use license
│
├── models/                      # Neural network implementations
│   ├── geo_film_st_gat.py       #   ★ Core: Geo-FiLM ST-GAT (zero-init FiLM generator)
│   ├── st_gat.py                #   Standard ST-GAT (ablation baseline)
│   ├── stgcn.py                 #   ST-GCN baseline
│   ├── dcrnn.py                 #   DCRNN baseline
│   ├── pinn_permafrost.py       #   PINN-Permafrost baseline
│   ├── stefan_model.py          #   Pure Stefan-equation baseline
│   └── _utils.py                #   Shared model utilities
│
├── trainers/                    # Training infrastructure
│   └── trainer.py               #   Training loop, loss computation, early stopping
│
├── data/                        # Data pipeline
│   ├── download_data.py         #   Download + graceful fallback to synthetic
│   ├── ftp_download_tpdc.py     #   TPDC FTP client
│   ├── preprocess.py            #   Feature engineering + graph construction
│   ├── preprocess_real_magt.py  #   Real MAGT-specific preprocessing
│   └── synthetic_generator.py   #   Stefan-equation-based synthetic data
│
├── evaluation/                  # Metrics & physics checks
│   ├── metrics.py               #   RMSE, MAE, R², etc.
│   └── physical_constraint.py   #   Stefan constraint violation rate
│
├── experiments/                 # Standalone experiment scripts
│   ├── run_fair_film_experiment.py     # ★ Fair FiLM ablation (parameter-matched)
│   ├── run_fair_mult_film.py           #   Full vs. multiplicative FiLM comparison
│   ├── run_real_magt_experiment.py     # ★ Real MAGT retrospective prediction
│   ├── run_multi_seed.py              #   Multi-seed statistical validation
│   ├── run_no_geo_input.py            #   No-geological-prior ablation
│   ├── validate_alt_magt.py           #   ALT–MAGT cross-validation
│   ├── visualize_geo_bias.py          #   Geo-bias visualization
│   └── synthetic_generator_v2.py      #   Extended synthetic generator
│
├── baselines/                   # Non-GNN baselines
│   ├── gbrt_baseline.py         #   XGBoost (gradient boosted trees)
│   └── rf_baseline.py           #   Random Forest
│
├── figures/                     # Figure generation
│   ├── generate_paper_figures.py        # ★ Real-data figures (Fig 7–10, Morandi palette)
│   ├── generate_synthetic_figures.py    #   Synthetic-data figures (Fig 1–6)
│   └── *.png                    #   Generated figure outputs
│
└── configs/                     # YAML experiment configurations
    ├── autodl_gpu.yaml          #   GPU training (real MAGT data)
    ├── simulation_fallback.yaml #   Synthetic data (no download needed)
    ├── qaidam_inSAR.yaml        #   Qaidam Basin InSAR deformation
    ├── chaimu_railway.yaml      #   Chaimu Railway corridor
    ├── northeast_frost.yaml     #   Northeast China permafrost
    └── yeniugou_alt.yaml        #   Yeniugou ALT validation
```

### Core Model: Geo-FiLM ST-GAT

The central innovation lives in `models/geo_film_st_gat.py`:

- **FiLMGenerator**: An MLP that maps geological features `g_i = [ALT_i, k_{s,i}, I_{t,i}]` to FiLM parameters `(γ, β)`. The final layer is **zero-initialized**, so conditioning starts as identity and degrades gracefully to the unconditioned baseline.
- **Soft-clamp design**: `β = β_raw / (1 + |β_raw| / β_max)` — bounded but never saturates (gradient always flows), replacing the v6 tanh clamp that caused gradient vanishing.
- **Overlap-aware FiLM**: When spatial overlap ρ > 0.5, additive geo-bias `h + σ(α)·β` suffices; when ρ < 0.3, full FiLM `γ·h + β` is needed.

---

## 4. How to Run

### 4.1 Basic Training (Single Command)

```bash
# Synthetic data — always works, no data download needed
python run_main.py --config configs/simulation_fallback.yaml

# Real MAGT data — requires TPDC dataset download
python run_main.py --config configs/autodl_gpu.yaml

# Specify custom data root (useful for cloud GPU with separate data disk)
python run_main.py --config configs/autodl_gpu.yaml --data-root /root/autodl-tmp
```

### 4.2 Key Experiment Scripts

```bash
# Fair FiLM Ablation (the central experiment, 5 seeds, parameter-matched)
cd experiments && python run_fair_film_experiment.py --seeds 5

# Real MAGT Retrospective Prediction (5 seeds)
cd experiments && python run_real_magt_experiment.py --seeds 5

# ALT–MAGT Cross-Validation (correlation shift analysis)
cd experiments && python validate_alt_magt.py

# Multi-seed statistical validation
cd experiments && python run_multi_seed.py --seeds 5 --config ../configs/autodl_gpu.yaml

# No-geological-prior ablation
cd experiments && python run_no_geo_input.py
```

### 4.3 Configuration

All hyperparameters are in YAML files under `configs/`. Key parameters in `autodl_gpu.yaml`:

| Parameter | Default | Description |
|:---|:---|:---|
| `hidden_dim` | 128 | Hidden dimension of ST-GAT |
| `num_heads` | 4 | Number of GAT attention heads |
| `num_gat_layers` | 2 | Number of spatial GAT layers |
| `lr` | 0.001 | Learning rate |
| `lambda_phys` | 0.3 | Physics constraint loss weight |
| `alpha_raw_init` | -2.2 | Initial value of FiLM gate (σ(α) ≈ 0.10) |
| `beta_max` | 5.0 | Soft-clamp bound for FiLM bias |
| `epochs` | 200 | Maximum training epochs |
| `patience` | 20 | Early stopping patience |

> **Important:** `input_dim` is **not** read from the config — it is dynamically determined from `X_train.shape[2]` at runtime. This prevents dimension mismatch errors when switching datasets.

### 4.4 Long-Running Jobs

For SSH sessions that may disconnect (e.g., laptop sleep during commute), use `tmux` or `nohup`:

```bash
# Using tmux (recommended — can reattach)
tmux new -s experiment
python run_main.py --config configs/autodl_gpu.yaml
# Detach: Ctrl+B then D
# Reattach: tmux attach -t experiment

# Using nohup
nohup python run_main.py --config configs/autodl_gpu.yaml > train.log 2>&1 &
```

---

## 5. How to Check Results

### 5.1 Console Output

During training, the following metrics are printed per epoch:

```
Epoch 45/200 | Train Loss: 0.0312 | Val RMSE: 1.716°C | Val R²: 0.9644 | PhysViol: 99.0%
```

### 5.2 Output Directory

After training completes, results are saved under `outputs/`:

```
outputs/
├── <experiment_name>/
│   ├── model_best.pt              # Best model checkpoint (lowest val RMSE)
│   ├── training_log.csv           # Per-epoch loss/RMSE/R² history
│   ├── predictions.npz            # Predictions vs. ground truth
│   └── config_used.yaml           # Snapshot of config at run time
```

### 5.3 Multi-Seed Summary

When running with `--seeds N`, a summary file is generated:

```
outputs/<experiment_name>/summary.json
{
  "rmse_mean": 1.594,
  "rmse_std": 0.034,
  "r2_mean": 0.9693,
  "r2_std": 0.0028,
  "n_seeds": 5,
  "seeds": [42, 123, 456, 789, 1024]
}
```

---

## 6. Figure Generation

Two scripts generate all paper figures. Each produces publication-ready PNGs at 300 DPI.

### 6.1 Real-Data Figures (Fig 7–10)

```bash
cd figures && python generate_paper_figures.py
```

**Output files** (in `figures/`):

| File | Paper Figure | Content |
|:---|:---|:---|
| `Fig7.RealMAGT.png` | Fig. 7 | Retrospective MAGT RMSE/R² comparison (Geo-FiLM vs. Standard ST-GAT) |
| `Fig8.PerZone.png` | Fig. 8 | Per-zone RMSE by permafrost type (cold/warm/seasonal) |
| `Fig9.FairFiLM.png` | Fig. 9 | Fair FiLM ablation — Full vs. γ-only vs. β-only vs. Standard wider |
| `Fig9.AltMagt.png` | Fig. 10 | ALT–MAGT correlation shift (historical vs. future) |

**Style**: Morandi color palette, Times New Roman / DejaVu Serif fonts, font size ≥ 12pt, clean axis design (no top/right spines).

### 6.2 Synthetic-Data Figures (Fig 1–6)

```bash
cd figures && python generate_synthetic_figures.py
```

**Output files** (in `figures/` or `/sandbox/workspace/paper_figures/`):

| File | Paper Figure | Content |
|:---|:---|:---|
| `fig1_architecture.png` | Fig. 1 | Geo-FiLM ST-GAT architecture schematic |
| `fig2_rmse_comparison.png` | Fig. 2 | 8-model RMSE comparison |
| `fig3_r2_comparison.png` | Fig. 3 | 8-model R² comparison |
| `fig4_film_iteration.png` | Fig. 4 | FiLM architectural iteration history |
| `fig5_physviol.png` | Fig. 5 | Stefan constraint violation rate |
| `fig6_film_comparison.png` | Fig. 6 | Multiplicative vs. additive FiLM feature impact |

**Style**: Color-coded model categories (Traditional ML / Standard ST-GAT / Geo-FiLM / Other GNN / PINN / Pure Physics).

### 6.3 Customization

To change output directory or style, edit the variables at the top of each script:

```python
# In generate_paper_figures.py
outdir = '/sandbox/workspace/outputs/figures'  # Change output path

# In generate_synthetic_figures.py
output_dir = '/sandbox/workspace/paper_figures'  # Change output path
```

---

## 7. Troubleshooting

| Issue | Cause | Fix |
|:---|:---|:---|
| `CUDA out of memory` | Graph too large for GPU | Reduce `hidden_dim` in config (e.g., 128→64) |
| `input_dim mismatch` | Config hardcoded but data differs | **Do not** set `input_dim` in config; it's auto-detected from data |
| `TypeError: must be real, not str` | YAML parsed `1e-5` as string | Code has defensive `float()` conversion; update to latest version |
| `KeyError: 'final_metrics'` | Failed experiment has no metrics | Summary script checks for key existence; skip failed seeds |
| `FTP download timeout` | TPDC FTP server slow/unreachable | Download manually from browser, place in `datasets/raw/` |
| `Stefan constraint = 0%` | Pure physics baseline has no violations by definition | Normal — this is expected behavior |

---

## Citation

```bibtex
@article{fan2026overlap,
  title={Overlap-Aware {FiLM} Conditioning for Spatio-Temporal Graph Networks with Overlapping Geological Priors: A Permafrost Thermal Prediction Study},
  author={Fan, Xiaohu},
  journal={PeerJ Computer Science},
  year={2026},
  note={Under review}
}
```
