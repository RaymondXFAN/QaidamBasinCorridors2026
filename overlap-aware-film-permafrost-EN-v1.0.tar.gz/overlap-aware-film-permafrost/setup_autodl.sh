#!/bin/bash
# ============================================================
# AutoDL Cloud Deployment Script
# Permafrost-Infrastructure Settlement Prediction Experiment Project
# ============================================================
# Usage: run "bash setup_autodl.sh" in the AutoDL terminal
# ============================================================
# Environment info:
#   GPU: RTX4090 (24GB VRAM)
#   CUDA Driver: 13.0 | PyTorch CUDA Runtime: 12.4 (cu24)
#   Python: 3.12 | PyTorch: 2.4+
#   Data disk: /root/autodl-tmp (/dev/md0, large capacity)
# ============================================================

set -e  # Stop immediately on error

# ============================================================
# DATA_ROOT — root directory for data storage (key setting)
# ============================================================
# AutoDL data disk path /root/autodl-tmp
# All datasets and outputs are stored here (the system disk /root has limited capacity)
export DATA_ROOT="/root/autodl-tmp"
echo ""
echo "  ★ DATA_ROOT = $DATA_ROOT (data disk, /dev/md0 mount point)"
echo "  ★ Data directory: $DATA_ROOT/datasets/"
echo "  ★ Output directory: $DATA_ROOT/outputs/"
echo ""

# Ensure the data disk directories exist
mkdir -p "$DATA_ROOT/datasets/raw"
mkdir -p "$DATA_ROOT/datasets/processed"
mkdir -p "$DATA_ROOT/outputs"

echo "============================================================"
echo "  Permafrost-Infrastructure Settlement Prediction Experiment - AutoDL Environment Setup"
echo "  Environment: RTX4090 | CUDA 13.0(driver)/12.4(runtime) | Py3.12"
echo "============================================================"

# ============================================================
# 1. Print system information
# ============================================================
echo ""
echo "[Step 1] System information check"
echo "------------------------------------------------------------"

# GPU model
if command -v nvidia-smi &> /dev/null; then
    echo "GPU info:"
    nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader
    echo ""
else
    echo "[WARNING] nvidia-smi not found; there may be no GPU"
fi

# CUDA version
if [ -x "$(command -v nvcc)" ]; then
    echo "CUDA Runtime version: $(nvcc --version | tail -1 | cut -d' ' -f5 | cut -d',' -f1)"
else
    echo "[WARNING] nvcc not found; CUDA Runtime may not be installed"
fi

echo "CUDA Driver version: $(nvidia-smi | grep 'CUDA Version' | head -1 | awk '{print $NF}')"

# Python version
echo "Python version: $(python3 --version 2>&1 || python --version 2>&1)"

# PyTorch version and CUDA support
python3 -c "
import torch
print(f'PyTorch version: {torch.__version__}')
print(f'CUDA available: {torch.cuda.is_available()}')
if torch.cuda.is_available():
    print(f'CUDA Runtime version: {torch.version.cuda}')
    print(f'CUDA device count: {torch.cuda.device_count()}')
    print(f'Current GPU: {torch.cuda.get_device_name(0)}')
    print(f'GPU memory: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB')
else:
    print('[WARNING] CUDA not available; will use CPU for training (slower)')
" 2>&1 || echo "[WARNING] PyTorch not installed"

# Data disk capacity check
echo ""
echo "Data disk /root/autodl-tmp info:"
df -h /root/autodl-tmp 2>/dev/null || echo "[INFO] /root/autodl-tmp is not mounted or does not exist"
echo "System disk /root info:"
df -h /root 2>/dev/null | head -2

echo "------------------------------------------------------------"

# ============================================================
# 2. Install Python dependencies
# ============================================================
echo ""
echo "[Step 2] Install Python dependencies"
echo "------------------------------------------------------------"

# AutoDL usually has torch pre-installed, no need to reinstall
echo "Checking installed packages..."

# Use requirements.txt for pinned versions
if [ -f "requirements.txt" ]; then
    echo "Installing dependencies using requirements.txt..."
    pip install -r requirements.txt -q 2>&1 || echo "[WARNING] Some packages may have failed to install"
else
    # Detect and install missing packages
    PACKAGES="numpy pandas scikit-learn matplotlib pyyaml xgboost scipy"
    
    for pkg in $PACKAGES; do
        # The sklearn package name is scikit-learn, but the import name is sklearn
        import_name=$pkg
        if [ "$pkg" = "scikit-learn" ]; then
            import_name="sklearn"
        fi
        
        if python3 -c "import $import_name" 2>/dev/null; then
            echo "  ✓ $pkg installed"
        else
            echo "  ✗ $pkg not installed, installing..."
            pip install $pkg -q
        fi
    done
fi

# Special check for PyTorch
if python3 -c "import torch" 2>/dev/null; then
    TORCH_CUDA=$(python3 -c "import torch; print(torch.version.cuda)" 2>/dev/null)
    echo "  ✓ torch installed (pre-installed by AutoDL, not reinstalling)"
    echo "  ✓ torch CUDA runtime: $TORCH_CUDA"
else
    echo "  ✗ torch not installed, installing CUDA 12.4 version..."
    pip install torch --index-url https://download.pytorch.org/whl/cu124 -q
fi

# CUDA compatibility check
echo ""
echo "CUDA compatibility check:"
python3 -c "
import torch
driver_cuda = float('13.0')  # CUDA version shown by NVIDIA-SMI
runtime_cuda = torch.version.cuda
print(f'  Driver CUDA: {driver_cuda} (nvidia-smi)')
print(f'  PyTorch CUDA Runtime: {runtime_cuda}')
print(f'  Compatible: ✓ (Driver >= Runtime, backward compatible)')
print(f'  torch.cuda.is_available(): {torch.cuda.is_available()}')
" 2>&1 || echo "[WARNING] CUDA compatibility check failed"

# Do not install torch_geometric (all GNN models are hand-written to reduce dependency conflicts)
echo "  ⊘ torch_geometric not installed (all GNN models are hand-written)"

echo "Dependency installation complete!"
echo "------------------------------------------------------------"

# ============================================================
# 3. Data download and preprocessing (data stored on the data disk)
# ============================================================
echo ""
echo "[Step 3] Data download and preprocessing (DATA_ROOT=$DATA_ROOT)"
echo "------------------------------------------------------------"

echo "Running data download script (data stored in $DATA_ROOT/datasets/)..."
python3 download_datasets.py 2>&1 || {
    echo "[WARNING] Data download script failed; falling back to synthetic data"
    echo "You can run it manually later: python3 download_datasets.py"
}

echo "Checking download status..."
STATUS_FILE="$DATA_ROOT/datasets/download_status.txt"
if [ -f "$STATUS_FILE" ]; then
    echo "Download status report:"
    cat "$STATUS_FILE"
else
    echo "[INFO] Download status report not generated"
fi

echo "Checking processed data..."
python3 -c "
import os
import numpy as np

# Check the datasets/processed/ directory on the data disk
data_dir = '$DATA_ROOT/datasets/processed'
if os.path.exists(data_dir):
    npz_files = [f for f in os.listdir(data_dir) if f.endswith('.npz')]
    if npz_files:
        print(f'Processed data files ({len(npz_files)}):')
        for f in npz_files:
            path = os.path.join(data_dir, f)
            data = np.load(path, allow_pickle=True)
            print(f'  {f}: keys={data.files[:5]}')
    else:
        print('[INFO] No .npz files in datasets/processed/ (will fall back to synthetic data)')
else:
    print('[INFO] datasets/processed/ directory does not exist')

# Check the datasets/raw/ directory on the data disk
raw_dir = '$DATA_ROOT/datasets/raw'
if os.path.exists(raw_dir):
    raw_files = os.listdir(raw_dir)
    if raw_files:
        print(f'Raw data files ({len(raw_files)}):')
        for f in raw_files:
            print(f'  {f}')
    else:
        print('[INFO] No files in datasets/raw/')
else:
    print('[INFO] datasets/raw/ directory does not exist')
" 2>&1

echo "------------------------------------------------------------"

# ============================================================
# 4. Run the experiment (outputs stored on the data disk)
# ============================================================
echo ""
echo "[Step 4] Run experiment (DATA_ROOT=$DATA_ROOT)"
echo "------------------------------------------------------------"

# First check the synthetic fallback configuration
CONFIG_FILE="configs/simulation_fallback.yaml"

# Verbose flag options:
# --quiet   : LEVEL 0 (minimal output)
# --verbose : LEVEL 1 (key progress, default)
# --debug   : LEVEL 2 (detailed debug info)

VERBOSE_FLAG=""
echo "Verbose options: --quiet (LEVEL 0) | --verbose (LEVEL 1, default) | --debug (LEVEL 2)"
echo "Log file is saved to $DATA_ROOT/outputs/run_log.txt by default (no manual argument needed)"
echo "Use --no-log to disable the log file"
echo ""

if [ -f "$CONFIG_FILE" ]; then
    echo "Using configuration file: $CONFIG_FILE"
    echo "Run command: python3 run_main.py --config $CONFIG_FILE --data-root $DATA_ROOT $VERBOSE_FLAG"
    echo ""
    python3 run_main.py --config "$CONFIG_FILE" --data-root "$DATA_ROOT" $VERBOSE_FLAG 2>&1 || {
        echo "[ERROR] Experiment run failed! Please check the error message."
        echo "Common causes:"
        echo "  1. Data dimension mismatch → check the F_features setting in configs/"
        echo "  2. Insufficient GPU memory → reduce batch_size or hidden_dim"
        echo "  3. Wrong configuration file path → make sure the configs/ directory exists"
        echo "  4. Data disk not writable → check whether /root/autodl-tmp is mounted"
        echo ""
        echo "Debug options:"
        echo "  python3 run_main.py --config $CONFIG_FILE --data-root $DATA_ROOT --debug  # detailed debug"
        echo "  python3 run_main.py --config $CONFIG_FILE --data-root $DATA_ROOT --no-log  # do not save log"
        exit 1
    }
else
    echo "[WARNING] Configuration file $CONFIG_FILE does not exist!"
    echo "Please create a configuration file first; refer to the templates in the configs/ directory."
    echo "Or run manually: python3 run_main.py --data-root $DATA_ROOT"
fi

echo "------------------------------------------------------------"

# ============================================================
# 5. Print result summary (results are on the data disk)
# ============================================================
echo ""
echo "[Step 5] Result summary (DATA_ROOT=$DATA_ROOT)"
echo "------------------------------------------------------------"

OUTPUT_DIR="$DATA_ROOT/outputs"

# Check outputs directory on data disk
if [ -f "$OUTPUT_DIR/experiment_results.txt" ]; then
    echo "Result files generated (on the data disk $OUTPUT_DIR/):"
    echo "  - experiment_results.txt (plain text table)"
    echo "  - experiment_results.csv (CSV format)"
    echo "  - diagnostics.txt (detailed per-model info)"
    echo ""
    cat "$OUTPUT_DIR/experiment_results.txt"
elif [ -f "$OUTPUT_DIR/experiment_results.csv" ]; then
    echo "Result files generated (on the data disk $OUTPUT_DIR/):"
    echo "  - experiment_results.csv"
    echo ""
    cat "$OUTPUT_DIR/experiment_results.csv"
else
    echo "[WARNING] No result files in $OUTPUT_DIR/; the experiment may not have completed."
fi

echo "------------------------------------------------------------"
echo ""
echo "============================================================"
echo "  Experiment complete! Results are saved in the data disk directory $DATA_ROOT/outputs/."
echo "============================================================"
echo ""
echo "Next steps:"
echo "  1. View the text result table: cat $OUTPUT_DIR/experiment_results.txt"
echo "  2. View detailed CSV results: cat $OUTPUT_DIR/experiment_results.csv"
echo "  3. View diagnostic info: cat $OUTPUT_DIR/diagnostics.txt"
echo "  4. Copy the results and send them to the assistant: cat $OUTPUT_DIR/experiment_results.txt"
echo "  5. Fill the results into Table X of the paper"
echo ""
echo "Important reminders:"
echo "  ★ Data and results are on the data disk /root/autodl-tmp/ (will not use system disk space)"
echo "  ★ The system disk /root has limited capacity (~50GB); do not put data on the system disk"
echo "  ★ If you need to re-download data: python3 download_datasets.py --data-root $DATA_ROOT"
echo ""
