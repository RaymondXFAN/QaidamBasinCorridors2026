"""Data download module - permafrost-infrastructure settlement prediction experiment

Attempts to download public datasets (TPDC/PANGAEA); on failure, gracefully degrades to synthetic data.

Supported dataset IDs:
- D1: Qinghai-Tibet Corridor InSAR deformation (TPDC)
- D2: CALM ALT (PANGAEA)
- A1: Chaimu Railway (TPDC)
- A5: Northeast China permafrost (NCDC)
- A8: Yeniugou (TPDC)

Path strategy:
- AutoDL environment: data is stored at /root/autodl-tmp/datasets/raw/ (data disk)
- Local development: stored at project_root/datasets/raw/
- Specified via the DATA_ROOT environment variable or config['data_root']
"""

import os
import numpy as np
from pathlib import Path
from typing import Dict, Optional

# Default path of the AutoDL data disk
AUTODL_DATA_DISK = '/root/autodl-tmp'


def _resolve_data_root(config: dict) -> str:
    """Resolve data root from config, env, or auto-detect.
    
    Priority:
      1. config['data_root'] (from CLI --data-root or YAML)
      2. Environment variable DATA_ROOT
      3. Auto-detect /root/autodl-tmp (AutoDL data disk)
      4. Current working directory (fallback)
    """
    # 1. Config override
    if config.get('data_root'):
        return config['data_root']
    
    # 2. Environment variable
    env_root = os.environ.get('DATA_ROOT')
    if env_root:
        return env_root
    
    # 3. Auto-detect AutoDL data disk
    if os.path.exists(AUTODL_DATA_DISK) and os.path.isdir(AUTODL_DATA_DISK):
        return AUTODL_DATA_DISK
    
    # 4. Fallback: current working directory
    return os.getcwd()

# Dataset metadata
DATASET_REGISTRY = {
    "D1": {
        "name": "Qinghai-Tibet Corridor 2D Deformation (2017-2022)",
        "source": "TPDC",
        "url": "https://data.tpdc.ac.cn/zh-hans/data/10.11888/cryos.tpdc.300400",
        "doi": "10.11888/cryos.tpdc.300400",
        "format": "geotiff",
        "description": "Qinghai-Tibet Engineering Corridor 2D deformation dataset",
    },
    "D2": {
        "name": "GTN-P CALM Active Layer Thickness",
        "source": "PANGAEA",
        "url": "https://doi.pangaea.de/10.1594/PANGAEA.972777",
        "doi": "10.1594/PANGAEA.972777",
        "format": "csv",
        "description": "Circumpolar Active Layer Monitoring (CALM) ALT data",
    },
    "A1": {
        "name": "Chaimu Railway Deformation + Damage",
        "source": "TPDC",
        "url": "https://data.tpdc.ac.cn/zh-hans/data/f7be4a1d-2506",
        "doi": "f7be4a1d-2506",
        "format": "mixed",
        "description": "Qilian Mountains Chaimu Railway deformation + damage data",
    },
    "A5": {
        "name": "Northeast China Permafrost Engineering Stability",
        "source": "NCDC",
        "url": "https://data.ncdc.ac.cn/zh-hans/data/70c33bc7",
        "doi": "70c33bc7",
        "format": "mixed",
        "description": "Northeast China permafrost engineering foundation stability data",
    },
    "A8": {
        "name": "Yeniugou Permafrost Deformation + ALT",
        "source": "TPDC",
        "url": "https://data.tpdc.ac.cn/zh-hans/data/dd24266c",
        "doi": "dd24266c",
        "format": "mixed",
        "description": "Yeniugou permafrost deformation + ALT data",
    },
}


def download_dataset(config: dict) -> Optional[str]:
    """Attempt to download a public dataset according to data_source in config

    Args:
        config: YAML config dictionary (including data_root and other info)

    Returns:
        data_path: returns the data path on success, None on failure
    """
    data_source = config.get("data_source", "simulation")
    dataset_name = config.get("dataset_name", "qaidam_inSAR")

    # If data_source is simulation, degrade directly
    if data_source == "simulation":
        print(f"[Download] data_source='simulation', skipping download, using synthetic data")
        return None

    # Look up the dataset ID
    dataset_id = None
    for key, info in DATASET_REGISTRY.items():
        if info["url"] == data_source or info["doi"] == data_source:
            dataset_id = key
            break

    if dataset_id is None:
        # Try using the URL directly
        print(f"[Download] Unknown data source: {data_source}")
        print(f"[Download] Attempting direct download...")
        dataset_id = "CUSTOM"

    print(f"[Download] Attempting to download dataset: {dataset_id}")
    print(f"  Dataset: {DATASET_REGISTRY.get(dataset_id, {}).get('name', data_source)}")

    # Download to DATA_ROOT/datasets/raw/ (data disk on AutoDL)
    data_root = _resolve_data_root(config)
    download_dir = Path(data_root) / "datasets" / "raw"
    download_dir.mkdir(parents=True, exist_ok=True)
    target_path = download_dir / f"{dataset_name}_raw"

    try:
        _attempt_download(data_source, str(target_path))
        print(f"[Download] ✓ Download succeeded: {target_path}")
        return str(target_path)
    except Exception as e:
        print(f"[Download] ✗ Download failed: {e}")
        print(f"[Download] Degrading to synthetic data...")
        return None


def _attempt_download(url: str, target_path: str) -> None:
    """Attempt to download data from a URL

    The actual download requires network access and authentication; here we only make an attempt.
    In a networked environment it will actually download.

    Args:
        url: data download URL
        target_path: local save path
    """
    import urllib.request
    import socket

    # Set timeout
    socket.setdefaulttimeout(30)

    try:
        # Try a simple HTTP download
        urllib.request.urlretrieve(url, target_path)
    except (urllib.error.URLError, urllib.error.HTTPError, socket.timeout) as e:
        raise RuntimeError(f"Network download failed: {e}")
    except Exception as e:
        raise RuntimeError(f"Download exception: {e}")


def handle_download_failure(config: dict) -> str:
    """Automatically call synthetic_generator to produce fallback data when download fails

    Args:
        config: YAML config dictionary

    Returns:
        save_path: path where the synthetic data is saved
    """
    from .synthetic_generator import generate_and_save_synthetic

    print(f"[Download] ===== Degrading to synthetic data (fallback) =====")
    print(f"[Download] Reason: public data download failed or is unavailable")
    print(f"[Download] Note: synthetic data is based on the Stefan equation + thermodynamic model, physically realistic")

    # Mark data_source in config
    config["data_source"] = "simulation"
    config["metadata_note"] = "Synthetic fallback data, for framework validation only"

    save_path = generate_and_save_synthetic(config)

    print(f"[Download] Synthetic data generated: {save_path}")
    print(f"[Download] Synthetic data is only for verifying that the experimental framework runs; it does not represent real results")

    return save_path


def get_dataset_info(dataset_id: str) -> dict:
    """Get dataset information

    Args:
        dataset_id: dataset ID (D1, D2, A1, A5, A8)

    Returns:
        info: dataset metadata dictionary
    """
    if dataset_id in DATASET_REGISTRY:
        return DATASET_REGISTRY[dataset_id]
    else:
        return {"name": "Unknown", "source": "Unknown", "url": "", "doi": ""}


def list_available_datasets() -> Dict[str, dict]:
    """List all available datasets

    Returns:
        registry: dataset registry
    """
    print("[Download] Available dataset list:")
    for id_, info in DATASET_REGISTRY.items():
        print(f"  {id_}: {info['name']} ({info['source']})")
    return DATASET_REGISTRY
