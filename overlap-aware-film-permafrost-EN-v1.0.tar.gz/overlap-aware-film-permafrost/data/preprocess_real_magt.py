#!/usr/bin/env python3
"""
Real data preprocessing: MAGT time series -> Geo-FiLM ST-GAT input format
Convert TPDC's MAGT GeoTIFF into (N, T, F) + (N, geo_dim) numpy arrays

Task: retrospective MAGT prediction
- Input: MAGT 1981-2010 (30 years)
- Target: MAGT 2016-2018 (3 years)
- Geo features: spatial mean MAGT, linear trend, standard deviation
"""

import os
import numpy as np
import rasterio
from rasterio.warp import reproject, Resampling
import argparse
from pathlib import Path


def read_magt_tif(tif_path, nodata_val=-3.4028234663852886e+38, magt_range=(-50, 50)):
    """Read a MAGT GeoTIFF and return a properly filtered float32 array"""
    with rasterio.open(tif_path) as ds:
        arr = ds.read(1).astype(np.float32)
        # Triple filter: not nodata + finite values + physically plausible range
        valid = (arr != nodata_val) & np.isfinite(arr) & (arr >= magt_range[0]) & (arr <= magt_range[1])
        result = np.where(valid, arr, np.nan)
    return result


def load_all_magt(magt_dir, years=range(1981, 2019)):
    """Load all MAGT year data and return a (T, H, W) array"""
    tif_files = sorted(Path(magt_dir).glob('MAGT_*.tif'))
    if not tif_files:
        raise FileNotFoundError(f"No MAGT_*.tif found in {magt_dir}")
    
    # Read the first file to get the shape
    sample = read_magt_tif(str(tif_files[0]))
    H, W = sample.shape
    T = len(years)
    
    magt_all = np.full((T, H, W), np.nan, dtype=np.float32)
    year_to_idx = {y: i for i, y in enumerate(years)}
    
    for tif_path in tif_files:
        # Extract the year from the file name
        fname = tif_path.stem  # e.g., MAGT_2018
        year = int(fname.split('_')[1])
        if year in year_to_idx:
            magt_all[year_to_idx[year]] = read_magt_tif(str(tif_path))
    
    print(f"Loaded MAGT: {T} years × {H}×{W} = {magt_all.shape}")
    return magt_all, years


def compute_geo_features(magt_all, train_years_idx):
    """Compute geo features from the MAGT time series
    Args:
        magt_all: (T, H, W) data for all years
        train_years_idx: training-period year indices (e.g., 0:30 for 1981-2010)
    Returns:
        geo_features: (H, W, 3) [mean_MAGT, trend, std]
    """
    T, H, W = magt_all.shape
    train_data = magt_all[train_years_idx]  # (T_train, H, W)
    T_train = len(train_years_idx)
    
    geo_mean = np.nanmean(train_data, axis=0)  # (H, W)
    geo_std = np.nanstd(train_data, axis=0)    # (H, W)
    
    # Linear trend: MAGT rate of change per pixel (°C/yr)
    geo_trend = np.full((H, W), np.nan, dtype=np.float32)
    years_arr = np.arange(T_train, dtype=np.float32)
    
    # Vectorized trend computation (valid pixels only)
    valid_mask = np.sum(~np.isnan(train_data), axis=0) >= 20  # at least 20 valid years
    rows, cols = np.where(valid_mask)
    
    for i in range(len(rows)):
        r, c = rows[i], cols[i]
        ts = train_data[:, r, c]
        valid_idx = ~np.isnan(ts)
        if valid_idx.sum() >= 20:
            coeffs = np.polyfit(years_arr[valid_idx], ts[valid_idx], 1)
            geo_trend[r, c] = coeffs[0]
    
    geo_features = np.stack([geo_mean, geo_trend, geo_std], axis=-1)  # (H, W, 3)
    print(f"Geo features computed: mean=[{np.nanmin(geo_mean):.2f}, {np.nanmax(geo_mean):.2f}], "
          f"trend=[{np.nanmin(geo_trend):.4f}, {np.nanmax(geo_trend):.4f}], "
          f"std=[{np.nanmin(geo_std):.2f}, {np.nanmax(geo_std):.2f}]")
    
    return geo_features


def find_valid_pixels(magt_all, min_valid_years=30, magt_range_filter=None):
    """Find pixel locations that are valid in all years
    Args:
        magt_all: (T, H, W)
        min_valid_years: minimum number of valid years required
        magt_range_filter: optional; keep only pixels whose MAGT is within a range (e.g. (-15, 0) keeps only permafrost)
    Returns:
        pixel_indices: (N, 2) array of [row, col]
    """
    valid_per_pixel = np.sum(~np.isnan(magt_all), axis=0)
    mask = valid_per_pixel >= min_valid_years
    
    if magt_range_filter is not None:
        mean_magt = np.nanmean(magt_all, axis=0)
        mask &= (mean_magt >= magt_range_filter[0]) & (mean_magt <= magt_range_filter[1])
    
    rows, cols = np.where(mask)
    pixel_indices = np.stack([rows, cols], axis=1)  # (N, 2)
    print(f"Valid pixels (>= {min_valid_years} years): {len(pixel_indices)}")
    return pixel_indices


def spatial_stratified_sample(pixel_indices, magt_mean, n_samples, n_bins=10, seed=42):
    """Spatial stratified sampling: stratify by mean MAGT to ensure each temperature range is represented"""
    rng = np.random.RandomState(seed)
    
    magt_vals = magt_mean[pixel_indices[:, 0], pixel_indices[:, 1]]
    bins = np.linspace(np.nanmin(magt_vals), np.nanmax(magt_vals), n_bins + 1)
    bin_indices = np.digitize(magt_vals, bins) - 1
    bin_indices = np.clip(bin_indices, 0, n_bins - 1)
    
    samples_per_bin = n_samples // n_bins
    selected = []
    
    for b in range(n_bins):
        bin_mask = bin_indices == b
        bin_pixels = pixel_indices[bin_mask]
        if len(bin_pixels) == 0:
            continue
        n_select = min(samples_per_bin, len(bin_pixels))
        idx = rng.choice(len(bin_pixels), n_select, replace=False)
        selected.append(bin_pixels[idx])
    
    selected = np.concatenate(selected, axis=0)
    rng.shuffle(selected)
    print(f"Spatial stratified sample: {len(selected)} pixels from {len(pixel_indices)} total")
    return selected


def build_graph_edges(pixel_indices, magt_transform, k=8):
    """Build a K-nearest-neighbor spatial graph
    Args:
        pixel_indices: (N, 2) [row, col]
        magt_transform: rasterio transform for coordinate conversion
        k: number of neighbors per node
    Returns:
        edge_index: (2, E) edge index
        edge_weight: (E,) edge weights (distance-based)
    """
    from scipy.spatial import cKDTree
    
    N = len(pixel_indices)
    rows, cols = pixel_indices[:, 0], pixel_indices[:, 1]
    
    # Convert to geographic coordinates
    lons = magt_transform.c + (cols + 0.5) * magt_transform.a
    lats = magt_transform.f + (rows + 0.5) * magt_transform.e
    coords = np.stack([lons, lats], axis=1)  # (N, 2) in projected coords
    
    tree = cKDTree(coords)
    distances, indices = tree.query(coords, k=k + 1)  # +1 because self is included
    
    # Build edges (excluding self-loops)
    src_list, dst_list, weight_list = [], [], []
    for i in range(N):
        for j_idx in range(1, k + 1):  # skip self (j_idx=0)
            j = indices[i, j_idx]
            d = distances[i, j_idx]
            if d > 0:
                src_list.append(i)
                dst_list.append(j)
                weight_list.append(1.0 / (d + 1e-8))  # inverse distance weight
    
    edge_index = np.array([src_list, dst_list], dtype=np.int64)
    edge_weight = np.array(weight_list, dtype=np.float32)
    
    print(f"Graph: {N} nodes, {edge_index.shape[1]} edges, k={k}")
    return edge_index, edge_weight


def preprocess_real_data(magt_dir, output_dir, n_samples=50000, k_neighbors=8, seed=42):
    """Full preprocessing pipeline"""
    os.makedirs(output_dir, exist_ok=True)
    
    # 1. Load all MAGT data
    magt_all, years = load_all_magt(magt_dir)
    T, H, W = magt_all.shape
    
    # 2. Split into periods
    train_idx = list(range(0, 30))   # 1981-2010
    val_idx = list(range(30, 35))     # 2011-2015
    test_idx = list(range(35, 38))    # 2016-2018
    
    # 3. Compute geo features (using the training period only)
    geo_features = compute_geo_features(magt_all, train_idx)
    
    # 4. Find valid pixels
    pixel_indices = find_valid_pixels(magt_all, min_valid_years=30)
    
    # 5. Spatial stratified sampling
    magt_mean = np.nanmean(magt_all, axis=0)
    selected_pixels = spatial_stratified_sample(pixel_indices, magt_mean, n_samples, seed=seed)
    
    # 6. Extract time series data
    N = len(selected_pixels)
    rows, cols = selected_pixels[:, 0], selected_pixels[:, 1]
    
    # Input: 1981-2010 (30 years)
    X_train_ts = magt_all[train_idx][:, rows, cols].T  # (N, 30)
    X_val_ts = magt_all[train_idx][:, rows, cols].T    # (N, 30) same input for val
    X_test_ts = magt_all[train_idx][:, rows, cols].T   # (N, 30) same input for test
    
    # Target: 2016-2018 (3 years) for test, 2011-2015 for val
    y_val = magt_all[val_idx][:, rows, cols].T   # (N, 5)
    y_test = magt_all[test_idx][:, rows, cols].T  # (N, 3)
    
    # Geo features
    geo = geo_features[rows, cols]  # (N, 3)
    
    # 7. Build the spatial graph
    with rasterio.open(os.path.join(magt_dir, 'MAGT_2018.tif')) as ds:
        magt_transform = ds.transform
    
    edge_index, edge_weight = build_graph_edges(selected_pixels, magt_transform, k=k_neighbors)
    
    # 8. Normalization (using training-period statistics)
    # Time series data: normalize by global statistics
    train_flat = X_train_ts[~np.isnan(X_train_ts)]
    ts_mean, ts_std = train_flat.mean(), train_flat.std()
    
    def normalize(arr, mean, std):
        return (arr - mean) / (std + 1e-8)
    
    def denormalize(arr, mean, std):
        return arr * (std + 1e-8) + mean
    
    X_train_norm = normalize(X_train_ts, ts_mean, ts_std)
    X_val_norm = normalize(X_val_ts, ts_mean, ts_std)
    X_test_norm = normalize(X_test_ts, ts_mean, ts_std)
    y_val_norm = normalize(y_val, ts_mean, ts_std)
    y_test_norm = normalize(y_test, ts_mean, ts_std)
    
    # Geo features: normalize each dimension independently
    geo_mean = np.nanmean(geo, axis=0)  # (3,)
    geo_std = np.nanstd(geo, axis=0)    # (3,)
    geo_norm = normalize(geo, geo_mean, geo_std)
    
    # 9. Save
    np.savez_compressed(
        os.path.join(output_dir, 'real_magt_data.npz'),
        # Time series input (N, T, F) - add the feature dimension
        X_train=X_train_norm.reshape(N, 30, 1).astype(np.float32),
        X_val=X_val_norm.reshape(N, 30, 1).astype(np.float32),
        X_test=X_test_norm.reshape(N, 30, 1).astype(np.float32),
        # Target (N, T')
        y_train=y_val_norm.reshape(N, 5, 1).astype(np.float32),  # use val for early stopping
        y_val=y_val_norm.reshape(N, 5, 1).astype(np.float32),
        y_test=y_test_norm.reshape(N, 3, 1).astype(np.float32),
        # Geo features (N, 3)
        geo_features=geo_norm.astype(np.float32),
        # Graph structure
        edge_index=edge_index,
        edge_weight=edge_weight,
        # Raw data (not normalized, for evaluation)
        X_train_raw=X_train_ts.astype(np.float32),
        y_val_raw=y_val.astype(np.float32),
        y_test_raw=y_test.astype(np.float32),
        geo_raw=geo.astype(np.float32),
        # Normalization parameters
        ts_mean=ts_mean, ts_std=ts_std,
        geo_mean=geo_mean, geo_std=geo_std,
        # Metadata
        pixel_indices=selected_pixels,
        years=np.array(list(years)),
    )
    
    # 10. Data quality report
    print(f"\n{'='*50}")
    print(f"Dataset saved to: {output_dir}/real_magt_data.npz")
    print(f"{'='*50}")
    print(f"Number of pixels N = {N}")
    print(f"Training period: 1981-2010 (30 years)")
    print(f"Validation period: 2011-2015 (5 years)")
    print(f"Test period: 2016-2018 (3 years)")
    print(f"Geo features: MAGT mean, linear trend (°C/yr), standard deviation")
    print(f"Graph: {N} nodes, {edge_index.shape[1]} edges, k={k_neighbors}")
    print(f"\nMAGT statistics (raw values):")
    print(f"  Training period: mean={ts_mean:.2f}°C, std={ts_std:.2f}°C")
    print(f"  Test target: mean={y_test.mean():.2f}°C, std={y_test.std():.2f}°C")
    print(f"\nGeo features distribution (raw values):")
    for i, name in enumerate(['MAGT mean (°C)', 'trend (°C/yr)', 'std (°C)']):
        print(f"  {name}: [{geo[:, i].min():.3f}, {geo[:, i].max():.3f}], "
              f"mean={geo[:, i].mean():.3f}")
    
    # Statistics by permafrost type
    cold_permafrost = (geo[:, 0] < -2).sum()
    warm_permafrost = ((geo[:, 0] >= -2) & (geo[:, 0] < 0)).sum()
    seasonal = (geo[:, 0] >= 0).sum()
    print(f"\nPermafrost type distribution:")
    print(f"  Cold permafrost (MAGT<-2°C): {cold_permafrost} ({cold_permafrost/N*100:.1f}%)")
    print(f"  Warm permafrost (-2≤MAGT<0°C): {warm_permafrost} ({warm_permafrost/N*100:.1f}%)")
    print(f"  Seasonally frozen ground (MAGT≥0°C): {seasonal} ({seasonal/N*100:.1f}%)")
    
    return output_dir


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Preprocess TPDC MAGT data for Geo-FiLM ST-GAT')
    parser.add_argument('--magt_dir', type=str, 
                        default='/root/autodl-tmp/datasets/raw/qtp_MAGT_raw',
                        help='Directory containing MAGT_YYYY.tif files')
    parser.add_argument('--output_dir', type=str,
                        default='/root/autodl-tmp/datasets/processed/real_magt',
                        help='Output directory')
    parser.add_argument('--n_samples', type=int, default=50000,
                        help='Number of pixels to sample (spatial stratified)')
    parser.add_argument('--k_neighbors', type=int, default=8,
                        help='K-nearest neighbors for spatial graph')
    parser.add_argument('--seed', type=int, default=42)
    args = parser.parse_args()
    
    preprocess_real_data(
        magt_dir=args.magt_dir,
        output_dir=args.output_dir,
        n_samples=args.n_samples,
        k_neighbors=args.k_neighbors,
        seed=args.seed,
    )
