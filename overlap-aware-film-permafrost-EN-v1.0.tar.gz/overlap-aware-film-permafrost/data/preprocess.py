"""Data preprocessing module - permafrost-infrastructure settlement prediction experiment

Functions:
- load_config(): read YAML config (type-safe conversion)
- load_npz(path): load already-preprocessed npz data
- normalize_features(X, method): feature standardization
- build_adjacency_matrix(coords, threshold_km): build a spatial adjacency matrix from coordinates
- split_time_series(data, train_ratio): time split
- validate_data(X, y, adj, geo): dimension check and validation
- save_processed(data_dict, path): save npz
"""

import os
import yaml
import numpy as np
from pathlib import Path
from typing import Dict, Optional, Tuple


def load_config(yaml_path: str) -> dict:
    """Read a YAML config file and apply type-safe conversion to all numeric keys

    Key fix: YAML may parse 1e-5 as a string; this bug occurred during AutoDL deployment.

    Args:
        yaml_path: path to the YAML file

    Returns:
        cfg: type-safe config dictionary
    """
    with open(yaml_path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    if cfg is None:
        raise ValueError(f"YAML config file is empty or malformed: {yaml_path}")

    def sanitize(d):
        """Recursively apply type-safe conversion to a dictionary"""
        result = {}
        for k, v in d.items():
            if isinstance(v, str):
                # Try converting to int, then to float
                try:
                    v = int(v)
                except ValueError:
                    try:
                        v = float(v)
                    except ValueError:
                        pass  # keep as string
            elif isinstance(v, dict):
                v = sanitize(v)
            elif isinstance(v, list):
                # Convert elements within lists as well
                v = [_sanitize_value(item) for item in v]
            result[k] = v
        return result

    def _sanitize_value(v):
        """Apply type-safe conversion to a single value"""
        if isinstance(v, str):
            try:
                return int(v)
            except ValueError:
                try:
                    return float(v)
                except ValueError:
                    return v
        elif isinstance(v, dict):
            return sanitize(v)
        return v

    cfg = sanitize(cfg)
    print(f"[Preprocess] Loading config: {yaml_path}")
    print(f"  dataset_name: {cfg.get('dataset_name', 'N/A')}")
    print(f"  N_nodes: {cfg.get('N_nodes', 'N/A')}, T_steps: {cfg.get('T_steps', 'N/A')}")

    return cfg


def load_npz(path: str) -> dict:
    """Load an already-preprocessed npz data file

    Args:
        path: path to the npz file

    Returns:
        data_dict: dictionary containing X, y, adj_matrix, geo_features, etc.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Data file does not exist: {path}")

    raw = np.load(str(path), allow_pickle=True)

    data_dict = {}
    for key in raw.files:
        data_dict[key] = raw[key]

    # Restore metadata (if present)
    if "metadata_keys" in data_dict and "metadata_vals" in data_dict:
        keys = data_dict["metadata_keys"]
        vals = data_dict["metadata_vals"]
        metadata = {}
        for k, v in zip(keys, vals):
            # Try type conversion
            try:
                metadata[str(k)] = int(v)
            except (ValueError, TypeError):
                try:
                    metadata[str(k)] = float(v)
                except (ValueError, TypeError):
                    metadata[str(k)] = str(v)
        data_dict["metadata"] = metadata

    # Restore feature_names (if present)
    if "feature_names" in data_dict:
        data_dict["feature_names"] = list(data_dict["feature_names"])

    # Print dimension info
    print(f"[Preprocess] Loading npz data: {path}")
    if "X" in data_dict:
        print(f"  X.shape = {data_dict['X'].shape}")
    if "y" in data_dict:
        print(f"  y.shape = {data_dict['y'].shape}")
    if "adj_matrix" in data_dict:
        print(f"  adj_matrix.shape = {data_dict['adj_matrix'].shape}")
    if "geo_features" in data_dict:
        print(f"  geo_features.shape = {data_dict['geo_features'].shape}")

    return data_dict


def normalize_features(X: np.ndarray, method: str = "zscore",
                       feature_range: Optional[Tuple] = None) -> Tuple[np.ndarray, dict]:
    """Feature standardization

    Args:
        X: (N, T, F) or (N, F) feature matrix
        method: standardization method
            - 'zscore': mean-variance standardization (x - μ) / σ
            - 'minmax': min-max standardization (x - min) / (max - min)
            - 'robust': Robust standardization (x - median) / IQR
        feature_range: target range for minmax, default (0, 1)

    Returns:
        X_norm: standardized features
        norm_params: standardization parameters (for inverse transform)
    """
    if feature_range is None:
        feature_range = (0, 1)

    original_shape = X.shape
    # Flatten to 2D for processing
    if X.ndim == 3:
        N, T, F = X.shape
        X_flat = X.reshape(-1, F)  # (N*T, F)
    elif X.ndim == 2:
        X_flat = X.copy()
        F = X.shape[1]
    else:
        raise ValueError(f"Unsupported X dimension: {X.shape}, expected 2D or 3D")

    norm_params = {}

    if method == "zscore":
        mean = X_flat.mean(axis=0)
        std = X_flat.std(axis=0)
        std = np.where(std < 1e-8, 1.0, std)  # prevent division by zero
        X_flat = (X_flat - mean) / std
        norm_params = {"method": "zscore", "mean": mean, "std": std}

    elif method == "minmax":
        min_val = X_flat.min(axis=0)
        max_val = X_flat.max(axis=0)
        range_val = max_val - min_val
        range_val = np.where(range_val < 1e-8, 1.0, range_val)
        X_flat = (X_flat - min_val) / range_val
        # Map to the target range
        if feature_range != (0, 1):
            X_flat = X_flat * (feature_range[1] - feature_range[0]) + feature_range[0]
        norm_params = {
            "method": "minmax", "min": min_val, "max": max_val,
            "feature_range": feature_range,
        }

    elif method == "robust":
        median = np.median(X_flat, axis=0)
        q25 = np.percentile(X_flat, 25, axis=0)
        q75 = np.percentile(X_flat, 75, axis=0)
        iqr = q75 - q25
        iqr = np.where(iqr < 1e-8, 1.0, iqr)
        X_flat = (X_flat - median) / iqr
        norm_params = {"method": "robust", "median": median, "iqr": iqr}

    else:
        raise ValueError(f"Unknown standardization method: {method}")

    # Restore the original shape
    if X.ndim == 3:
        X_norm = X_flat.reshape(original_shape)
    else:
        X_norm = X_flat

    print(f"[Preprocess] Feature standardization: method={method}, shape {original_shape} -> {X_norm.shape}")

    return X_norm, norm_params


def build_adjacency_matrix(coords: np.ndarray, threshold_km: float = 50.0) -> np.ndarray:
    """Build a spatial adjacency matrix from coordinates

    Args:
        coords: (N, 2) latitude/longitude coordinates [lon, lat]
        threshold_km: edge distance threshold (km)

    Returns:
        adj_matrix: (N, N) adjacency matrix (symmetric, with self-loops)
    """
    N = coords.shape[0]
    adj = np.zeros((N, N), dtype=np.float32)

    for i in range(N):
        for j in range(i + 1, N):
            dlat = coords[i, 1] - coords[j, 1]
            dlon = coords[i, 0] - coords[j, 0]
            # Approximate latitude/longitude -> km conversion
            dist_km = np.sqrt(
                (dlat * 111.0) ** 2 +
                (dlon * 111.0 * np.cos(np.radians(np.mean([coords[i, 1], coords[j, 1]])))) ** 2
            )
            if dist_km <= threshold_km:
                adj[i, j] = 1.0
                adj[j, i] = 1.0

    # Self-loops
    np.fill_diagonal(adj, 1.0)

    num_edges = int((adj.sum() - N) / 2)
    avg_degree = 2 * num_edges / N if N > 0 else 0
    print(f"[Preprocess] Adjacency matrix: {N} nodes, {num_edges} edges, "
          f"avg degree={avg_degree:.1f}, threshold={threshold_km}km")

    return adj


def split_time_series(data: dict, train_ratio: float = 0.8) -> dict:
    """Time series split: train (first 80%) / test (last 20%)

    Sliding-window expansion:
    - input window of T_in months -> predict settlement for T_out months
    - number of samples = T - T_in - T_out + 1 (per node)

    Args:
        data: raw data dictionary (containing X, y, adj_matrix, geo_features)
        train_ratio: train split ratio

    Returns:
        split_data: containing X_train, y_train, X_test, y_test, adj_matrix, geo_features
    """
    X = data["X"]        # (N, T, F)
    y = data["y"]        # (N, T) full settlement time series
    adj = data["adj_matrix"]   # (N, N)
    geo = data["geo_features"] # (N, G)

    N, T, F = X.shape
    T_in = data.get("T_in", 24) if isinstance(data.get("T_in"), int) else 24
    T_out = data.get("T_out", 1) if isinstance(data.get("T_out"), int) else 1

    # Check whether enough windows can be constructed
    num_windows = T - T_in - T_out + 1
    if num_windows <= 0:
        raise ValueError(f"Time steps T={T} are insufficient to construct a window T_in={T_in}, T_out={T_out}")

    # Sliding-window expansion
    X_windows = np.zeros((N, num_windows, T_in, F))
    y_windows = np.zeros((N, num_windows, T_out))

    for n in range(N):
        for w in range(num_windows):
            start = w
            end = w + T_in
            X_windows[n, w] = X[n, start:end]
            # Predict settlement for the T_out steps after window end
            y_windows[n, w] = y[n, end:end + T_out]

    # Split by time (first 80% of time windows for training, last 20% for testing)
    split_w = int(num_windows * train_ratio)

    # ===== Graph Format (W, N, T_in, F) — used by GNN models =====
    # Each time window contains all N real nodes, and adj_matrix is N×N
    X_graph = X_windows.transpose(1, 0, 2, 3)  # (num_windows, N, T_in, F)
    y_graph = y_windows.transpose(1, 0, 2)       # (num_windows, N, T_out)

    X_train_graph = X_graph[:split_w]   # (W_train, N, T_in, F)
    y_train_graph = y_graph[:split_w]   # (W_train, N, T_out)
    X_test_graph  = X_graph[split_w:]   # (W_test, N, T_in, F)
    y_test_graph  = y_graph[split_w:]   # (W_test, N, T_out)

    # ===== Flat Format (N*W, T_in, F) — used by ML models =====
    # Flatten the node dimension: (N, num_windows, ...) -> (N*num_windows, ...)
    X_all = X_windows.reshape(N * num_windows, T_in, F)
    y_all = y_windows.reshape(N * num_windows, T_out)

    X_train = X_all[:N * split_w]
    y_train = y_all[:N * split_w]
    X_test = X_all[N * split_w:]
    y_test = y_all[N * split_w:]

    split_data = {
        # Flat format (for ML baselines: RF, XGBoost)
        "X_train": X_train,
        "X_test": X_test,
        "y_train": y_train,
        "y_test": y_test,
        # Graph format (for GNN models: Geo-FiLM ST-GAT, ST-GAT, ST-GCN, DCRNN)
        "X_train_graph": X_train_graph,
        "X_test_graph": X_test_graph,
        "y_train_graph": y_train_graph,
        "y_test_graph": y_test_graph,
        # Shared
        "adj_matrix": adj,
        "geo_features": geo,
        "feature_names": data.get("feature_names", []),
        "node_ids": data.get("node_ids", np.arange(N)),
        "metadata": data.get("metadata", {}),
        "num_windows": num_windows,
        "N_nodes": N,
        "split_window_idx": split_w,
    }

    print(f"[Preprocess] Time split: train_ratio={train_ratio}")
    print(f"  [Flat]  X_train.shape = {X_train.shape}  (N*W_train, T_in, F)")
    print(f"  [Flat]  y_train.shape = {y_train.shape}  (N*W_train, T_out)")
    print(f"  [Flat]  X_test.shape = {X_test.shape}   (N*W_test, T_in, F)")
    print(f"  [Flat]  y_test.shape = {y_test.shape}   (N*W_test, T_out)")
    print(f"  [Graph] X_train_graph.shape = {X_train_graph.shape}  (W_train, N, T_in, F)")
    print(f"  [Graph] y_train_graph.shape = {y_train_graph.shape}  (W_train, N, T_out)")
    print(f"  [Graph] X_test_graph.shape = {X_test_graph.shape}   (W_test, N, T_in, F)")
    print(f"  [Graph] y_test_graph.shape = {y_test_graph.shape}   (W_test, N, T_out)")
    print(f"  adj_matrix.shape = {adj.shape}")
    print(f"  geo_features.shape = {geo.shape}")
    print(f"  Total windows: {num_windows}, train windows: {split_w}, test windows: {num_windows - split_w}")

    return split_data


def validate_data(X: np.ndarray, y: np.ndarray, adj: np.ndarray,
                  geo: np.ndarray, F_expected: int = 12,
                  G_expected: int = 3) -> bool:
    """Data dimension check and validation

    Args:
        X: feature matrix (N, T, F) or (N_samples, T_in, F)
        y: labels (N, T) or (N_samples, T_out)
        adj: adjacency matrix (N_total, N_total)
        geo: geographic priors (N_total, G)
        F_expected: expected number of feature dimensions
        G_expected: expected number of geographic prior dimensions

    Returns:
        is_valid: whether validation passed
    """
    print("[Preprocess] Data validation:")
    is_valid = True
    errors = []

    # X dimension check
    print(f"  X.shape = {X.shape}")
    if X.ndim != 3:
        errors.append(f"X should be 3D (N, T, F), actual ndim={X.ndim}")
        is_valid = False
    else:
        F_actual = X.shape[2]
        if F_actual != F_expected:
            errors.append(f"X feature dimension F={F_actual}, expected F={F_expected}")
            is_valid = False

    # y dimension check
    print(f"  y.shape = {y.shape}")
    if y.ndim not in [1, 2]:
        errors.append(f"y should be 1D or 2D, actual ndim={y.ndim}")
        is_valid = False

    # adj dimension check
    print(f"  adj_matrix.shape = {adj.shape}")
    if adj.ndim != 2:
        errors.append(f"adj should be 2D (N, N), actual ndim={adj.ndim}")
        is_valid = False
    elif adj.shape[0] != adj.shape[1]:
        errors.append(f"adj should be square, actual shape={adj.shape}")
        is_valid = False

    # geo dimension check
    print(f"  geo_features.shape = {geo.shape}")
    if geo.ndim != 2:
        errors.append(f"geo should be 2D (N, G), actual ndim={geo.ndim}")
        is_valid = False
    elif geo.shape[1] != G_expected:
        errors.append(f"geo dimension G={geo.shape[1]}, expected G={G_expected}")
        is_valid = False

    # N consistency check
    N_nodes = adj.shape[0]
    if X.ndim == 3 and X.shape[0] != N_nodes:
        # After sliding-window expansion, N of X may != N of adj, which is normal
        print(f"  Note: X.shape[0]={X.shape[0]} != adj.shape[0]={N_nodes} "
              f"(may be the number of samples after sliding-window expansion)")
    if geo.shape[0] != N_nodes:
        errors.append(f"geo node count {geo.shape[0]} != adj node count {N_nodes}")
        is_valid = False

    if errors:
        print(f"  [ERROR] Data validation failed:")
        for err in errors:
            print(f"    - {err}")
    else:
        print(f"  [OK] Data validation passed ✓")

    return is_valid


def save_processed(data_dict: dict, path: str) -> str:
    """Save the processed data in npz format

    Args:
        data_dict: data dictionary
        path: save path

    Returns:
        save_path: actual save path
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    # Prepare the save dictionary (metadata needs special handling)
    save_dict = {}
    for key, value in data_dict.items():
        if key == "metadata" and isinstance(value, dict):
            # Save metadata as a string array
            save_dict["metadata_keys"] = np.array(list(value.keys()))
            save_dict["metadata_vals"] = np.array([str(v) for v in value.values()])
        elif key == "feature_names" and isinstance(value, list):
            save_dict["feature_names"] = np.array(value)
        elif isinstance(value, np.ndarray):
            save_dict[key] = value
        elif isinstance(value, (int, float, str)):
            save_dict[key] = np.array([value])
        # Ignore unsupported types

    np.savez(str(path), **save_dict)
    file_size = os.path.getsize(str(path)) / 1024
    print(f"[Preprocess] Data saved to: {path} ({file_size:.1f} KB)")

    return str(path)
