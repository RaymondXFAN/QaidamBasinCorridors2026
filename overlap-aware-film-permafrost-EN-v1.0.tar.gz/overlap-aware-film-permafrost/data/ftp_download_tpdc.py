#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TPDC FTP data download script — real data for the permafrost prediction experiment

Downloads two core datasets:
  D1: Qinghai-Tibet Engineering Corridor permafrost region surface 2D deformation dataset (2017-02—2022-03)
      DOI: 10.11888/Cryos.tpdc.300400
  D2: Qinghai-Tibet Plateau permafrost mean annual ground temperature (MAGT) 1km annual simulation data (1981-2018)
      DOI: 10.11888/Cryos.tpdc.300603

FTP server: ftp2.tpdc.ac.cn / ftp3.tpdc.ac.cn, port 6201
Note: the download credentials are temporary passwords that expire, so please download as soon as possible!

Usage:
  python3 ftp_download_tpdc.py --dataset all       # download everything
  python3 ftp_download_tpdc.py --dataset insar     # download only InSAR deformation
  python3 ftp_download_tpdc.py --dataset magt      # download only MAGT ground temperature
  python3 ftp_download_tpdc.py --dataset all --ftp-host ftp3.tpdc.ac.cn  # switch host
"""

import os
import sys
import argparse
import time
from pathlib import Path
from ftplib import FTP, error_perm


# ===== Download configuration =====
FTP_HOSTS = ["ftp2.tpdc.ac.cn", "ftp3.tpdc.ac.cn"]
FTP_PORT = 6201

# Dataset 1: InSAR deformation (Du et al., 2023)
# Credentials are read from environment variables (never hard-code them in the repo).
# The TPDC download usernames follow the format "download_<numeric_id>".
INSAR_CREDENTIALS = {
    "user": os.environ.get("TPDC_INSAR_USER", ""),
    "passwd": os.environ.get("TPDC_INSAR_PASS", ""),
}

# Dataset 2: MAGT ground temperature (Zhao et al., 2023)
MAGT_CREDENTIALS = {
    "user": os.environ.get("TPDC_MAGT_USER", ""),
    "passwd": os.environ.get("TPDC_MAGT_PASS", ""),
}

# Default path of the AutoDL data disk
AUTODL_DATA_DISK = "/root/autodl-tmp"
DEFAULT_OUTPUT_DIR = os.path.join(AUTODL_DATA_DISK, "datasets", "raw")


def ftp_connect(host: str, port: int, user: str, passwd: str) -> FTP:
    """Connect to the FTP server and log in"""
    print(f"[FTP] Connecting to {host}:{port} ...")
    ftp = FTP()
    ftp.encoding = 'utf-8'
    ftp.connect(host, port, timeout=60)
    print(f"[FTP] Connected, logging in (user={user}) ...")
    ftp.login(user, passwd)
    print(f"[FTP] ✅ Login succeeded!")
    return ftp


def ftp_list_dir(ftp: FTP, path: str = "") -> list:
    """List the contents of an FTP directory"""
    if path:
        try:
            ftp.cwd(path)
        except error_perm as e:
            print(f"[FTP] ⚠️ Cannot enter directory {path}: {e}")
            return []

    items = []
    def _callback(line):
        # Parse the FTP LIST output
        parts = line.split()
        if len(parts) >= 9:
            item_type = "dir" if parts[0].startswith("d") else "file"
            name = " ".join(parts[8:])  # file names may contain spaces
            size = int(parts[4]) if parts[4].isdigit() else 0
            items.append({"type": item_type, "name": name, "size": size})
        else:
            items.append({"type": "unknown", "name": line, "size": 0})

    try:
        ftp.retrlines("LIST", _callback)
    except Exception as e:
        print(f"[FTP] ⚠️ Failed to list directory: {e}")

    return items


def ftp_download_dir(ftp: FTP, remote_dir: str, local_dir: str, depth: int = 0):
    """Recursively download an FTP directory"""
    indent = "  " * depth
    os.makedirs(local_dir, exist_ok=True)

    # Enter the remote directory
    try:
        ftp.cwd(remote_dir)
    except error_perm:
        print(f"{indent}⚠️ Cannot enter {remote_dir}")
        return

    items = ftp_list_dir(ftp)
    print(f"{indent}📁 {remote_dir}/ ({len(items)} items)")

    for item in items:
        name = item["name"]
        local_path = os.path.join(local_dir, name)

        if item["type"] == "dir":
            # Recursively download subdirectories
            print(f"{indent}  📁 Entering subdirectory: {name}/")
            current_dir = ftp.pwd()
            ftp_download_dir(ftp, name, local_path, depth + 1)
            ftp.cwd(current_dir)  # go back up

        elif item["type"] == "file":
            size_mb = item["size"] / (1024 * 1024)
            print(f"{indent}  ⬇️  {name} ({size_mb:.1f} MB) ...", end="", flush=True)

            try:
                with open(local_path, "wb") as f:
                    def _write(data):
                        f.write(data)

                    ftp.retrbinary(f"RETR {name}", _write, blocksize=8192)

                # Verify the file size
                local_size = os.path.getsize(local_path)
                if item["size"] > 0 and local_size != item["size"]:
                    print(f" ⚠️ Size mismatch (expected {item['size']}, actual {local_size})")
                else:
                    print(f" ✅ ({local_size / (1024*1024):.1f} MB)")

            except Exception as e:
                print(f" ❌ Failed: {e}")
                # Delete the incomplete file
                if os.path.exists(local_path):
                    os.remove(local_path)
        else:
            print(f"{indent}  ❓ Unknown type: {name}")


def download_dataset(dataset_id: str, output_dir: str, ftp_host: str = None):
    """Download the specified dataset"""
    hosts = [ftp_host] if ftp_host else FTP_HOSTS

    if dataset_id == "insar":
        credentials = INSAR_CREDENTIALS
        dataset_name = "InSAR deformation (Du et al., 2023)"
        local_subdir = "qaidam_inSAR_raw"
    elif dataset_id == "magt":
        credentials = MAGT_CREDENTIALS
        dataset_name = "MAGT ground temperature (Zhao et al., 2023)"
        local_subdir = "qtp_MAGT_raw"
    else:
        print(f"❌ Unknown dataset: {dataset_id}")
        return False

    local_dir = os.path.join(output_dir, local_subdir)
    os.makedirs(local_dir, exist_ok=True)

    print(f"\n{'='*60}")
    print(f"📦 Downloading dataset: {dataset_name}")
    print(f"📂 Saving to: {local_dir}")
    print(f"{'='*60}")

    # Fail fast if credentials are missing
    if not credentials.get("user") or not credentials.get("passwd"):
        print("Please set TPDC_INSAR_USER / TPDC_INSAR_PASS (or TPDC_MAGT_*) environment variables before downloading.")
        return False

    # Try to connect to FTP (try the primary host first, switch to a backup host on failure)
    ftp = None
    for host in hosts:
        try:
            ftp = ftp_connect(host, FTP_PORT, credentials["user"], credentials["passwd"])
            break
        except Exception as e:
            print(f"[FTP] ❌ Failed to connect to {host}: {e}")
            if ftp:
                try:
                    ftp.quit()
                except:
                    pass
            ftp = None

    if ftp is None:
        print("[FTP] ❌ All hosts failed to connect!")
        return False

    try:
        # List the root directory
        print(f"\n[FTP] Current directory: {ftp.pwd()}")
        items = ftp_list_dir(ftp)
        if not items:
            print("[FTP] ⚠️ Root directory is empty, trying common paths...")
            # Some TPDC data is in subdirectories
            for subdir in ["data", "pub", "download", "dataset"]:
                try:
                    ftp.cwd(f"/{subdir}")
                    items = ftp_list_dir(ftp)
                    if items:
                        print(f"[FTP] ✅ Found data directory: /{subdir}")
                        break
                    ftp.cwd("/")
                except:
                    ftp.cwd("/")

        if items:
            print(f"\n[FTP] 📋 Found {len(items)} files/directories:")
            for item in items:
                icon = "📁" if item["type"] == "dir" else "📄"
                size_str = f" ({item['size']/(1024*1024):.1f} MB)" if item['size'] > 0 else ""
                print(f"  {icon} {item['name']}{size_str}")

            # Download all contents
            print(f"\n[FTP] 🚀 Starting download...")
            start_time = time.time()
            ftp_download_dir(ftp, ".", local_dir)
            elapsed = time.time() - start_time

            # Summarize the download results
            total_files = 0
            total_size = 0
            for root, dirs, files in os.walk(local_dir):
                for f in files:
                    fp = os.path.join(root, f)
                    total_files += 1
                    total_size += os.path.getsize(fp)

            print(f"\n[FTP] ✅ Download complete!")
            print(f"  📄 Files: {total_files}")
            print(f"  💾 Total size: {total_size / (1024*1024):.1f} MB")
            print(f"  ⏱️  Elapsed: {elapsed:.0f} s")
            return True
        else:
            print("[FTP] ⚠️ No files found. You may need to browse subdirectories.")
            print("[FTP] Please check the FTP contents manually; the data may be in a subdirectory.")
            return False

    except Exception as e:
        print(f"[FTP] ❌ Download error: {e}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        try:
            ftp.quit()
        except:
            pass


def main():
    parser = argparse.ArgumentParser(description="TPDC FTP data download")
    parser.add_argument("--dataset", choices=["all", "insar", "magt"],
                        default="all", help="dataset to download (all/insar/magt)")
    parser.add_argument("--output-dir", default=DEFAULT_OUTPUT_DIR,
                        help=f"output directory (default: {DEFAULT_OUTPUT_DIR})")
    parser.add_argument("--ftp-host", default=None,
                        help="specify the FTP host (default: automatically try ftp2/ftp3)")

    args = parser.parse_args()

    print("=" * 60)
    print("🏔️  TPDC permafrost data download tool")
    print("=" * 60)
    print(f"FTP server: {args.ftp_host or 'ftp2/ftp3.tpdc.ac.cn'}")
    print(f"Port: {FTP_PORT}")
    print(f"Output directory: {args.output_dir}")
    print()

    datasets = ["insar", "magt"] if args.dataset == "all" else [args.dataset]

    results = {}
    for ds in datasets:
        success = download_dataset(ds, args.output_dir, args.ftp_host)
        results[ds] = "✅ Success" if success else "❌ Failed"

    print("\n" + "=" * 60)
    print("📊 Download result summary:")
    print("=" * 60)
    for ds, status in results.items():
        ds_name = "InSAR deformation" if ds == "insar" else "MAGT ground temperature"
        print(f"  {ds_name}: {status}")

    # If everything succeeded, suggest the next step
    if all("✅" in v for v in results.values()):
        print(f"\n🎉 All downloads succeeded! Data saved at: {args.output_dir}")
        print("Next step: run the data preprocessing script to convert to model input format")
    else:
        print(f"\n⚠️ Some downloads failed; please check the network or FTP credentials")
        print("Tip: if the FTP connection times out, you can try:")
        print("  1. Switch host: --ftp-host ftp3.tpdc.ac.cn")
        print("  2. Download with FileZilla on your local machine, then upload to AutoDL")


if __name__ == "__main__":
    main()
