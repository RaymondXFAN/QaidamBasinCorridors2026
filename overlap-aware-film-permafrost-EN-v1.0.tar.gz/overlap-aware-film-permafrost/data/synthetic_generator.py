"""Synthetic data generator - fallback for the permafrost-infrastructure settlement prediction experiment

Generates realistic Qilian Mountains / Qaidam permafrost InSAR deformation + settlement data based on the Stefan equation + a thermodynamic model.

Data format:
    X:  (N, T, F) — N monitoring nodes, T time steps, F=12 features
    y:  (N, T_out) — settlement prediction labels
    adj_matrix: (N, N) — spatial proximity graph adjacency matrix
    geo_features: (N, G=3) — FiLM conditioning priors [ALT, k_s, I_t]

Physics-driven:
    ALT = sqrt(2 * k_thaw * I_t * 86400 / L)   (Stefan equation)
    settlement = k_s * ALT * seasonal_factor + noise
    deformation velocity = integral of dALT/dt
"""

import os
import numpy as np
from pathlib import Path


class SyntheticDataGenerator:
    """Synthetic data generator: based on the Stefan equation + a thermodynamic model"""

    # Stefan equation constants
    K_THAW_DEFAULT = 1.2      # W/m·K, thermal conductivity during the thaw period
    L_DEFAULT = 3.34e7        # J/m³, latent heat (water->ice)
    SEC_PER_DAY = 86400       # seconds/day

    # Climate parameters (typical values for the Qilian Mountains / Qaidam)
    MEAN_ANNUAL_TEMP = -3.0   # °C, mean annual ground temperature
    SUMMER_AMPLITUDE = 8.0    # °C, summer deviation from the mean
    WINTER_AMPLITUDE = -12.0  # °C, winter deviation from the mean
    SUMMER_PEAK_MONTH = 6     # thawing peak in June
    WINTER_TROUGH_MONTH = 1  # freezing trough in January

    # Geographic parameter ranges
    ELEVATION_RANGE = (2800, 4800)  # m, elevation range
    SLOPE_RANGE = (0, 30)           # °, slope range
    MOISTURE_RANGE = (15, 45)       # %, moisture content range

    # Feature name list (12 dimensions, strictly matching EXPERIMENT_DESIGN.md)
    FEATURE_NAMES = [
        "cumulative_deformation",   # 0: mm
        "deformation_velocity",     # 1: mm/year
        "coherence",                # 2: 0-1
        "ground_temp",              # 3: °C
        "thawing_index",            # 4: °C·day
        "freezing_index",           # 5: °C·day
        "moisture",                 # 6: %
        "elevation",                # 7: m
        "permafrost_type",          # 8: int (stored as slope_angle, see below)
        "infrastructure_type",      # 9: int
        "seasonal_amplitude",       # 10: mm  (corresponds to F idx 11)
    ]

    # Strict 12-dimension feature names
    FEATURE_NAMES_12 = [
        "cumulative_deformation",   # idx 0
        "deformation_velocity",     # idx 1
        "coherence",                # idx 2
        "ground_temp",              # idx 3
        "thawing_index",            # idx 4 (I_t)
        "freezing_index",           # idx 5
        "moisture",                 # idx 6
        "elevation",                # idx 7
        "slope_angle",              # idx 8
        "permafrost_type",          # idx 9
        "infrastructure_type",      # idx 10
        "seasonal_amplitude",       # idx 11
    ]

    # Permafrost type encoding
    PERMAFROST_TYPES = {
        "continuous": 0,
        "discontinuous": 1,
        "sporadic": 2,
        "isolated": 3,
    }

    # Infrastructure type encoding
    INFRASTRUCTURE_TYPES = {
        "railway": 0,
        "highway": 1,
        "pipeline": 2,
        "building": 3,
        "bridge": 4,
    }

    def __init__(self, config: dict):
        """Initialize the generator

        Args:
            config: YAML config dictionary (already type-safe converted)
        """
        self.config = config
        self.N = int(config.get("N_nodes", 47))
        self.T = int(config.get("T_steps", 120))
        self.F = int(config.get("F_features", 12))
        self.G = int(config.get("G_geo_features", 3))
        self.T_in = int(config.get("T_in", 24))
        self.T_out = int(config.get("T_out", 1))
        self.seed = int(config.get("seed", 42))
        self.noise_level = float(config.get("noise_level", 0.05))
        self.k_thaw = float(config.get("k_thaw", self.K_THAW_DEFAULT))
        self.L = float(config.get("L", self.L_DEFAULT))
        self.adj_threshold_km = float(config.get("adj_threshold_km", 50))
        self.region = config.get("region", "Qaidam Basin Corridor")
        self.dataset_name = config.get("dataset_name", "qaidam_inSAR")
        self.output_dir = config.get("output_dir", "results")

        # Set the random seed
        np.random.seed(self.seed)

    def _generate_node_coordinates(self) -> np.ndarray:
        """Generate geographic coordinates of N monitoring nodes (distributed along the corridor/railway)

        Returns:
            coords: (N, 2) — [longitude, latitude]
        """
        # Qilian Mountains corridor: distributed roughly from east to west
        # Longitude range ~96°E - 103°E, latitude range ~37°N - 39°N
        base_lon = np.random.uniform(96.0, 103.0, self.N)
        base_lat = np.random.uniform(37.0, 39.0, self.N)

        # Simulate distribution along the corridor: add a linear trend
        order = np.argsort(base_lon)
        base_lon[order] = np.linspace(96.0, 103.0, self.N) + np.random.normal(0, 0.3, self.N)
        base_lat[order] = np.linspace(37.5, 38.5, self.N) + np.random.normal(0, 0.2, self.N)

        coords = np.stack([base_lon, base_lat], axis=1)
        return coords

    def _generate_monthly_thawing_index(self, t: int) -> float:
        """Compute the thawing index I_t for month t (°C·day)

        Seasonal model: about 240°C·day/month in July, about 0 in January
        Fit the monthly variation with a sinusoidal model

        Args:
            t: time step index (0-based, monthly)

        Returns:
            I_t: thawing index for that month (°C·day)
        """
        month = t % 12  # 0=January, 1=February, ..., 5=June, 6=July
        # Sinusoidal thawing index model: peak in June-August, zero in January-February
        # Peak in June (month=5) and July (month=6)
        phase = (month - 5) / 12.0 * 2 * np.pi  # June is the peak
        I_t = max(0, 240.0 * np.cos(phase) * (1 if month >= 4 and month <= 9 else 0))
        # A more accurate model
        if month in [4, 5, 6, 7, 8, 9]:  # thawing occurs in May-October
            I_t = 240.0 * np.sin((month - 3) / 6.0 * np.pi)  # half-sine from April to October
        else:
            I_t = 0.0
        return I_t

    def _generate_monthly_freezing_index(self, t: int) -> float:
        """Compute the freezing index for month t (°C·day)

        Args:
            t: time step index

        Returns:
            freezing_index: °C·day
        """
        month = t % 12
        if month in [10, 11, 0, 1, 2, 3]:  # freezing occurs in November-April
            freezing_index = 200.0 * np.sin((month - 9) / 6.0 * np.pi)
        else:
            freezing_index = 0.0
        return max(0, freezing_index)

    def _compute_alt_stefan(self, I_t_annual: float) -> float:
        """Compute the active layer thickness (ALT) using the Stefan equation

        ALT = sqrt(2 * k_thaw * I_t * 86400 / L)

        Args:
            I_t_annual: annual cumulative thawing index (°C·day)

        Returns:
            ALT: active layer thickness (m)
        """
        if I_t_annual <= 0:
            return 0.01  # extremely thin active layer (fully frozen)
        alt = np.sqrt(2.0 * self.k_thaw * I_t_annual * self.SEC_PER_DAY / self.L)
        return alt

    def _compute_seasonal_factor(self, t: int) -> float:
        """Compute the seasonal factor (freeze-thaw cycle)

        Peak in June (thawing), trough in January (freezing)
        Sinusoidal model: factor = 1 + 0.5 * sin(2π*(t-5)/12)

        Args:
            t: time step index

        Returns:
            seasonal_factor: seasonal fluctuation factor
        """
        month = t % 12
        # June (month=5) is the peak, January (month=0) is the trough
        phase = 2 * np.pi * (month - 5) / 12.0
        factor = 1.0 + 0.5 * np.sin(phase)
        return factor

    def _compute_ground_temp(self, t: int, mean_temp: float) -> float:
        """Compute ground temperature

        Seasonal variation: +8°C in summer, -12°C in winter (based on a -3°C annual mean)

        Args:
            t: time step
            mean_temp: baseline mean annual ground temperature

        Returns:
            ground_temp: °C
        """
        month = t % 12
        phase = 2 * np.pi * (month - 5) / 12.0
        # Deviation of +8°C in summer and -12°C in winter, using asymmetric amplitudes
        if month >= 4 and month <= 9:  # summer half-year
            amplitude = self.SUMMER_AMPLITUDE
        else:  # winter half-year
            amplitude = self.WINTER_AMPLITUDE

        temp = mean_temp + amplitude * np.sin(phase)
        return temp

    def generate(self) -> dict:
        """Generate the complete synthetic dataset

        Returns:
            data_dict: dictionary containing X, y, adj_matrix, geo_features, coords, metadata
        """
        print(f"[SyntheticGenerator] Generating synthetic dataset: {self.dataset_name}")
        print(f"  Region: {self.region}")
        print(f"  N={self.N}, T={self.T}, F={self.F}, G={self.G}")
        print(f"  T_in={self.T_in}, T_out={self.T_out}, seed={self.seed}")

        np.random.seed(self.seed)

        # ===== Step 1: Generate monitoring node coordinates =====
        coords = self._generate_node_coordinates()

        # Static attributes of each node
        elevations = np.random.uniform(*self.ELEVATION_RANGE, self.N)
        slopes = np.random.uniform(*self.SLOPE_RANGE, self.N)
        moisture_base = np.random.uniform(*self.MOISTURE_RANGE, self.N)
        k_s_values = np.random.uniform(0.01, 0.05, self.N)  # soil-structure coefficient
        permafrost_types = np.random.choice(list(self.PERMAFROST_TYPES.values()), self.N)
        infrastructure_types = np.random.choice(list(self.INFRASTRUCTURE_TYPES.values()), self.N)

        # Each node has its own mean annual ground temperature (higher elevation is colder)
        mean_temps = self.MEAN_ANNUAL_TEMP - (elevations - 3500) / 1000.0 * 6.0  # about -6°C/km

        # ===== Step 2: Compute the ALT time series for each node =====
        # First compute the annual cumulative thawing index
        annual_I_t = np.zeros(self.N)
        for t_idx in range(12):  # one full year
            I_t_month = self._generate_monthly_thawing_index(t_idx)
            annual_I_t += I_t_month
        # Different nodes have different I_t (the higher the elevation, the lower I_t)
        node_I_t_annual = annual_I_t * (1.0 + np.random.normal(0, 0.2, self.N))
        node_I_t_annual = np.clip(node_I_t_annual, 200, 1800)

        # Compute ALT with the Stefan equation
        alt_values = np.array([self._compute_alt_stefan(it) for it in node_I_t_annual])
        alt_values = np.clip(alt_values, 0.5, 5.0)  # physically plausible range

        # ===== Step 3: Compute the settlement time series =====
        # settlement = k_s * ALT * seasonal_factor + noise
        # Cumulative settlement increases over time
        settlements = np.zeros((self.N, self.T))
        for n in range(self.N):
            cumulative = 0.0
            for t in range(self.T):
                seasonal = self._compute_seasonal_factor(t)
                # Annual ALT change (warming trend: ALT increases by about 2% per year)
                alt_year = alt_values[n] * (1.0 + 0.02 * (t // 12))
                settlement_increment = k_s_values[n] * alt_year * seasonal * 0.1  # mm/month
                settlement_increment += np.random.normal(0, self.noise_level * 10)  # noise
                cumulative += settlement_increment
                settlements[n, t] = cumulative

        # ===== Step 4: Generate InSAR cumulative deformation =====
        # cumulative_deformation = cumulative settlement + InSAR noise + unwrapping error
        cumulative_deformation = np.zeros((self.N, self.T))
        deformation_velocity = np.zeros((self.N, self.T))
        coherence = np.zeros((self.N, self.T))
        seasonal_amplitude = np.zeros((self.N, self.T))

        for n in range(self.N):
            for t in range(self.T):
                # Cumulative deformation = cumulative settlement + InSAR system noise
                cumulative_deformation[n, t] = settlements[n, t] + \
                    np.random.normal(0, self.noise_level * 5)
                # Deformation velocity = this month's settlement increment * 12 (converted to mm/year)
                if t > 0:
                    velocity = (settlements[n, t] - settlements[n, t - 1]) * 12.0
                else:
                    velocity = k_s_values[n] * alt_values[n] * 12.0 * 0.1
                deformation_velocity[n, t] = velocity + \
                    np.random.normal(0, self.noise_level * 2)

                # Coherence: high in winter (stable when frozen), low in summer (disturbed by thawing)
                month = t % 12
                base_coherence = 0.85
                if month >= 4 and month <= 9:
                    base_coherence = 0.65  # coherence decreases during the thaw period
                coherence[n, t] = base_coherence + np.random.normal(0, 0.05)
                coherence[n, t] = np.clip(coherence[n, t], 0.3, 0.95)

                # Seasonal amplitude
                seasonal_amplitude[n, t] = k_s_values[n] * alt_values[n] * 0.5

        # ===== Step 5: Generate other feature time series =====
        ground_temp_ts = np.zeros((self.N, self.T))
        thawing_index_ts = np.zeros((self.N, self.T))
        freezing_index_ts = np.zeros((self.N, self.T))
        moisture_ts = np.zeros((self.N, self.T))

        for n in range(self.N):
            for t in range(self.T):
                ground_temp_ts[n, t] = self._compute_ground_temp(t, mean_temps[n])
                thawing_index_ts[n, t] = self._generate_monthly_thawing_index(t) * \
                    (1.0 + np.random.normal(0, 0.1))  # small differences between nodes
                freezing_index_ts[n, t] = self._generate_monthly_freezing_index(t) * \
                    (1.0 + np.random.normal(0, 0.1))
                # Moisture content: high during the thaw period, low during the freezing period
                month = t % 12
                moisture_ts[n, t] = moisture_base[n] * \
                    (1.0 + 0.3 * np.sin(2 * np.pi * (month - 5) / 12.0))

        # ===== Step 6: Assemble the feature matrix X =====
        # X: (N, T, F=12)
        X = np.zeros((self.N, self.T, self.F))
        X[:, :, 0] = cumulative_deformation
        X[:, :, 1] = deformation_velocity
        X[:, :, 2] = coherence
        X[:, :, 3] = ground_temp_ts
        X[:, :, 4] = thawing_index_ts
        X[:, :, 5] = freezing_index_ts
        X[:, :, 6] = moisture_ts
        X[:, :, 7] = elevations[:, np.newaxis] * np.ones((1, self.T))  # static elevation
        X[:, :, 8] = slopes[:, np.newaxis] * np.ones((1, self.T))      # static slope
        X[:, :, 9] = permafrost_types[:, np.newaxis] * np.ones((1, self.T))
        X[:, :, 10] = infrastructure_types[:, np.newaxis] * np.ones((1, self.T))
        X[:, :, 11] = seasonal_amplitude

        # ===== Step 7: Assemble the labels y =====
        # y: (N, T_out) — settlement at each time step
        # For T_out=1, take the settlement value at each time step
        # Construct samples with a sliding window: (N, T) -> (N*T_in valid samples, T_out)
        # Simplified handling: y = the T_out-th step of settlements

        # Construct sliding-window samples
        num_windows = self.T - self.T_in - self.T_out + 1
        if num_windows <= 0:
            # If T is too small, adjust T_in
            self.T_in = max(1, self.T - self.T_out - 1)
            num_windows = self.T - self.T_in - self.T_out + 1

        # Each node produces num_windows samples
        # But to keep the (N, T_out) format, we take the prediction of the last window
        # In actual use, sliding-window expansion is performed again during training
        # Here y = the settlement values of all time steps, for later sliding-window splitting
        y = settlements  # (N, T) — full settlement time series

        # ===== Step 8: Build geographic priors geo_features =====
        # geo_features: (N, G=3) — [ALT, k_s, I_t]
        geo_features = np.zeros((self.N, self.G))
        geo_features[:, 0] = alt_values       # ALT (m)
        geo_features[:, 1] = k_s_values       # k_s (dimensionless)
        geo_features[:, 2] = node_I_t_annual  # I_t (°C·day)

        # ===== Step 9: Build the spatial adjacency matrix =====
        adj_matrix = self._build_adjacency_matrix(coords)

        # ===== Step 10: Time split =====
        train_ratio = float(self.config.get("train_ratio", 0.8))
        split_idx = int(self.T * train_ratio)

        # Build the output dictionary
        data_dict = {
            "X": X,
            "y": y,
            "adj_matrix": adj_matrix,
            "geo_features": geo_features,
            "coords": coords,
            "elevations": elevations,
            "settlements": settlements,
            "cumulative_deformation": cumulative_deformation,
            "alt_values": alt_values,
            "split_idx": split_idx,
            "feature_names": self.FEATURE_NAMES_12,
            "node_ids": np.arange(self.N),
            "metadata": {
                "dataset_name": self.dataset_name,
                "region": self.region,
                "N": self.N,
                "T": self.T,
                "F": self.F,
                "G": self.G,
                "T_in": self.T_in,
                "T_out": self.T_out,
                "seed": self.seed,
                "noise_level": self.noise_level,
                "k_thaw": self.k_thaw,
                "source": "simulation",
                "description": f"Synthetic data: {self.region}, driven by the Stefan equation",
            },
        }

        # Print dimension info
        print(f"[SyntheticGenerator] Data dimensions:")
        print(f"  X.shape = {X.shape}  (N, T, F)")
        print(f"  y.shape = {y.shape}  (N, T)")
        print(f"  adj_matrix.shape = {adj_matrix.shape}  (N, N)")
        print(f"  geo_features.shape = {geo_features.shape}  (N, G)")
        print(f"  coords.shape = {coords.shape}  (N, 2)")
        print(f"  split_idx = {split_idx}  (train: 0~{split_idx}, test: {split_idx}~{self.T})")

        # ALT statistics
        print(f"[SyntheticGenerator] ALT statistics:")
        print(f"  min ALT = {alt_values.min():.3f} m")
        print(f"  max ALT = {alt_values.max():.3f} m")
        print(f"  mean ALT = {alt_values.mean():.3f} m")

        return data_dict

    def _build_adjacency_matrix(self, coords: np.ndarray) -> np.ndarray:
        """Build a spatial adjacency matrix from coordinates

        Distance threshold: nodes within threshold_km are connected

        Args:
            coords: (N, 2) latitude/longitude coordinates

        Returns:
            adj_matrix: (N, N) adjacency matrix (0/1, symmetric)
        """
        N = coords.shape[0]
        adj = np.zeros((N, N), dtype=np.float32)

        # Approximate latitude/longitude distance (1° ≈ 111km)
        for i in range(N):
            for j in range(i + 1, N):
                dlat = coords[i, 1] - coords[j, 1]
                dlon = coords[i, 0] - coords[j, 0]
                # Simplified distance computation (°->km)
                dist_km = np.sqrt((dlat * 111) ** 2 + (dlon * 111 * np.cos(np.radians(coords[i, 1]))) ** 2)
                if dist_km <= self.adj_threshold_km:
                    adj[i, j] = 1.0
                    adj[j, i] = 1.0

        # Self-loops
        for i in range(N):
            adj[i, i] = 1.0

        # Print adjacency matrix statistics
        num_edges = (adj.sum() - N) / 2  # remove self-loops
        print(f"[SyntheticGenerator] Adjacency matrix: {num_edges:.0f} edges "
              f"(threshold={self.adj_threshold_km}km, avg degree={2*num_edges/N:.1f})")

        return adj

    def generate_and_save(self) -> str:
        """Generate data and save it in npz format

        Returns:
            save_path: save file path
        """
        data_dict = self.generate()

        # Build the save dictionary (npz-compatible format)
        save_dict = {
            "X": data_dict["X"],
            "y": data_dict["y"],
            "adj_matrix": data_dict["adj_matrix"],
            "geo_features": data_dict["geo_features"],
            "coords": data_dict["coords"],
            "feature_names": np.array(data_dict["feature_names"]),
            "node_ids": data_dict["node_ids"],
            "split_idx": data_dict["split_idx"],
            "alt_values": data_dict["alt_values"],
            "settlements": data_dict["settlements"],
        }

        # metadata cannot be stored directly in npz; convert to a string array
        meta = data_dict["metadata"]
        meta_keys = np.array(list(meta.keys()))
        meta_vals = np.array([str(v) for v in meta.values()])
        save_dict["metadata_keys"] = meta_keys
        save_dict["metadata_vals"] = meta_vals

        # Save path
        output_dir = Path(self.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        save_path = output_dir / f"{self.dataset_name}.npz"

        np.savez(save_path, **save_dict)
        print(f"[SyntheticGenerator] Data saved to: {save_path}")
        print(f"  File size: {os.path.getsize(save_path) / 1024:.1f} KB")

        return str(save_path)


def generate_synthetic_data(config: dict) -> dict:
    """Convenience function: generate synthetic data from config

    Args:
        config: YAML config dictionary

    Returns:
        data_dict: generated data dictionary
    """
    generator = SyntheticDataGenerator(config)
    return generator.generate()


def generate_and_save_synthetic(config: dict) -> str:
    """Convenience function: generate and save synthetic data from config

    Args:
        config: YAML config dictionary

    Returns:
        save_path: save file path
    """
    generator = SyntheticDataGenerator(config)
    return generator.generate_and_save()
