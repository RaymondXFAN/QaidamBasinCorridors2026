# Project Descriptions

## One-Sentence Description

An overlap-aware FiLM framework for spatio-temporal graph networks that selects additive, multiplicative, or full FiLM by geological-target overlap, validated on permafrost thermal prediction.

## Paragraph Description

This repository provides the complete implementation of "Overlap-Aware FiLM Conditioning for Spatio-Temporal Graph Networks with Overlapping Geological Priors: A Permafrost Thermal Prediction Study." It introduces an overlap-degree selection framework that determines the most effective form of Feature-wise Linear Modulation (FiLM) for injecting geological priors into graph neural networks: additive geo-bias (h + σ(α)·β) in high-overlap regimes and full FiLM (γ·h + β) in low-overlap regimes. In a fair, parameter-matched, five-seed ablation on real Mean Annual Ground Temperature (MAGT) data from the Qinghai–Tibet Plateau, Full FiLM achieves 1.594 °C RMSE (R² = 0.9693), a 38.8% reduction over the parameter-matched no-FiLM baseline. The codebase includes the Geo-FiLM ST-GAT model with zero-initialized FiLM generators, six comparison models (ST-GAT, ST-GCN, DCRNN, PINN-Permafrost, Stefan-only, Random Forest, and XGBoost), automated data acquisition from TPDC/PANGAEA/NCDC, and scripts to reproduce every figure and table in the paper. All code is licensed under MIT and documented in English; the pipeline runs on synthetic data out of the box and on real data with a single command.
