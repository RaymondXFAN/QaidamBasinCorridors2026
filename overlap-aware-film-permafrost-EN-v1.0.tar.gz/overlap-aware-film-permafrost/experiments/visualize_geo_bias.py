#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
visualize_geo_bias.py — Reviewer experiment 4: Geo-bias visualization

Reviewer question:
  "The paper contains no experiment or visualization proving that the geo-bias actually carries geological information
   and achieves 'node-level geological adaptation'— for example, it never compares whether 'nodes with different ALT
   receive different biases'. The claimed Contribution (2) lacks direct evidence."

This experiment:
  1. Train Geo-FiLM ST-GAT
  2. Extract the beta (geo-bias) output of the FiLMGenerator
  3. Visualize whether nodes with different ALT/k_s/I_t receive different beta
  4. Compute the correlation between beta and geo_features
  5. Output the figures to DATA_ROOT/outputs/figures/

Usage:
  python3 experiments/visualize_geo_bias.py --config configs/simulation_fallback.yaml
"""

import sys
import os
import argparse
import numpy as np
from datetime import datetime

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)

AUTODL_DATA_DISK = '/root/autodl-tmp'


def resolve_data_root(project_root, cli_data_root=None):
    if cli_data_root:
        return os.path.abspath(cli_data_root)
    if os.environ.get('DATA_ROOT'):
        return os.path.abspath(os.environ.get('DATA_ROOT'))
    if os.path.exists(AUTODL_DATA_DISK) and os.path.isdir(AUTODL_DATA_DISK):
        return AUTODL_DATA_DISK
    return project_root


def main():
    parser = argparse.ArgumentParser(description='Geo-bias visualization')
    parser.add_argument('--config', type=str, default='configs/simulation_fallback.yaml')
    parser.add_argument('--epochs', type=int, default=200)
    parser.add_argument('--device', type=str, default=None)
    parser.add_argument('--data-root', type=str, default=None)
    parser.add_argument('--seed', type=int, default=42)
    args = parser.parse_args()
    
    DATA_ROOT = resolve_data_root(PROJECT_ROOT, args.data_root)
    
    print("=" * 70)
    print("  🔬 Geo-Bias Visualization Experiment")
    print("  Proving that FiLM geo-bias carries geological information")
    print("=" * 70)
    
    import torch
    import torch.nn as nn
    import matplotlib
    matplotlib.use('Agg')  # Non-interactive backend for server
    import matplotlib.pyplot as plt
    
    from data import load_config, SyntheticDataGenerator, normalize_features, split_time_series
    from models import GeoFiLMSTGATWrapper
    
    config = load_config(os.path.join(PROJECT_ROOT, args.config))
    config['epochs'] = args.epochs
    config['seed'] = args.seed
    if args.device:
        config['device'] = args.device
    else:
        config['device'] = 'cuda' if torch.cuda.is_available() else 'cpu'
    config['verbose'] = 1
    
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    
    # Generate data
    generator = SyntheticDataGenerator(config)
    data_dict = generator.generate()
    # Preprocessing (note: normalize_features takes the X numpy array, not a dict)
    norm_method = config.get('normalization_method', 'zscore')
    X_norm, norm_params = normalize_features(data_dict['X'], method=norm_method)
    data_dict['X'] = X_norm
    data_dict['norm_params'] = norm_params
    data_dict['T_in'] = int(config.get('T_in', 24))
    data_dict['T_out'] = int(config.get('T_out', 1))
    train_ratio = float(config.get('train_ratio', 0.8))
    data_dict = split_time_series(data_dict, train_ratio=train_ratio)
    
    # Train Geo-FiLM
    print("\n[1/3] Training Geo-FiLM ST-GAT...")
    geo_model = GeoFiLMSTGATWrapper(config)
    geo_model.fit(
        X_train=data_dict['X_train_graph'],
        y_train=data_dict['y_train_graph'],
        adj_matrix=data_dict['adj_matrix'],
        geo_features=data_dict['geo_features'],
    )
    print("  Training complete.")
    
    # Extract geo-bias
    print("\n[2/3] Extracting geo-bias (beta) from FiLMGenerator...")
    
    # Get the FiLMGenerator
    model_net = geo_model.model if hasattr(geo_model, 'model') else geo_model
    
    # Traverse the modules to find the FiLMGenerator
    film_gen = None
    for name, module in model_net.named_modules():
        if 'film_generator' in name.lower() or 'filmgen' in name.lower():
            film_gen = module
            break
    
    if film_gen is None:
        print("  ⚠️ Could not find FiLMGenerator module, trying direct access...")
        if hasattr(model_net, 'film_generator'):
            film_gen = model_net.film_generator
        else:
            print("  ❌ FiLMGenerator not found. Cannot extract geo-bias.")
            return
    
    # Extract beta
    device = config['device']
    geo_features_np = data_dict['geo_features']  # (N, G)
    geo_tensor = torch.FloatTensor(geo_features_np).to(device)
    
    with torch.no_grad():
        gamma, beta = film_gen(geo_tensor)
        beta_np = beta.cpu().numpy()  # (N, hidden_dim)
        gamma_np = gamma.cpu().numpy()  # (N, hidden_dim)
    
    N, hidden_dim = beta_np.shape
    G = geo_features_np.shape[1]
    
    print(f"  Extracted beta: shape={beta_np.shape}")
    print(f"  geo_features: shape={geo_features_np.shape}")
    
    # ALT, k_s, I_t
    alt_values = geo_features_np[:, 0]
    ks_values = geo_features_np[:, 1]
    it_values = geo_features_np[:, 2]
    
    # beta statistics
    print(f"\n  Beta statistics:")
    print(f"    Mean:  {beta_np.mean():.6f}")
    print(f"    Std:   {beta_np.std():.6f}")
    print(f"    Min:   {beta_np.min():.6f}")
    print(f"    Max:   {beta_np.max():.6f}")
    print(f"    ||β|| per node: mean={np.linalg.norm(beta_np, axis=1).mean():.6f}, "
          f"std={np.linalg.norm(beta_np, axis=1).std():.6f}")
    
    # ===== Visualization =====
    print("\n[3/3] Generating visualizations...")
    
    fig_dir = os.path.join(DATA_ROOT, 'outputs', 'figures')
    os.makedirs(fig_dir, exist_ok=True)
    
    # Figure 1: Beta vs ALT scatter (mean beta magnitude per node)
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    
    beta_norms = np.linalg.norm(beta_np, axis=1)
    
    # Beta magnitude vs ALT
    axes[0].scatter(alt_values, beta_norms, alpha=0.7, c=alt_values, cmap='coolwarm', s=60)
    axes[0].set_xlabel('Active Layer Thickness (ALT, m)', fontsize=12)
    axes[0].set_ylabel('||β|| (geo-bias magnitude)', fontsize=12)
    axes[0].set_title('Geo-bias magnitude vs ALT', fontsize=14)
    # Correlation
    corr_alt = np.corrcoef(alt_values, beta_norms)[0, 1]
    axes[0].text(0.05, 0.95, f'r = {corr_alt:.3f}', transform=axes[0].transAxes,
                fontsize=12, verticalalignment='top',
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
    
    # Beta magnitude vs k_s
    axes[1].scatter(ks_values, beta_norms, alpha=0.7, c=ks_values, cmap='viridis', s=60)
    axes[1].set_xlabel('Soil-structure coefficient (k_s)', fontsize=12)
    axes[1].set_ylabel('||β|| (geo-bias magnitude)', fontsize=12)
    axes[1].set_title('Geo-bias magnitude vs k_s', fontsize=14)
    corr_ks = np.corrcoef(ks_values, beta_norms)[0, 1]
    axes[1].text(0.05, 0.95, f'r = {corr_ks:.3f}', transform=axes[1].transAxes,
                fontsize=12, verticalalignment='top',
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
    
    # Beta magnitude vs I_t
    axes[2].scatter(it_values, beta_norms, alpha=0.7, c=it_values, cmap='plasma', s=60)
    axes[2].set_xlabel('Thawing Index (I_t, °C·day)', fontsize=12)
    axes[2].set_ylabel('||β|| (geo-bias magnitude)', fontsize=12)
    axes[2].set_title('Geo-bias magnitude vs I_t', fontsize=14)
    corr_it = np.corrcoef(it_values, beta_norms)[0, 1]
    axes[2].text(0.05, 0.95, f'r = {corr_it:.3f}', transform=axes[2].transAxes,
                fontsize=12, verticalalignment='top',
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
    
    plt.tight_layout()
    fig1_path = os.path.join(fig_dir, 'geo_bias_vs_geo_features.png')
    plt.savefig(fig1_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  ✅ Saved: {fig1_path}")
    
    # Figure 2: Beta heatmap (nodes × hidden_dim), sorted by ALT
    fig, ax = plt.subplots(figsize=(12, 8))
    sorted_idx = np.argsort(alt_values)
    beta_sorted = beta_np[sorted_idx]
    
    im = ax.imshow(beta_sorted.T, aspect='auto', cmap='RdBu_r', 
                   vmin=-np.abs(beta_np).max(), vmax=np.abs(beta_np).max())
    ax.set_xlabel('Node (sorted by ALT)', fontsize=12)
    ax.set_ylabel('Hidden dimension', fontsize=12)
    ax.set_title('Geo-bias (β) across nodes sorted by ALT', fontsize=14)
    plt.colorbar(im, ax=ax, label='β value')
    
    fig2_path = os.path.join(fig_dir, 'geo_bias_heatmap.png')
    plt.savefig(fig2_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  ✅ Saved: {fig2_path}")
    
    # Figure 3: Per-dimension correlation with geo features
    fig, ax = plt.subplots(figsize=(14, 5))
    x_pos = np.arange(hidden_dim)
    width = 0.25
    
    corr_alt_per_dim = [np.corrcoef(alt_values, beta_np[:, d])[0, 1] for d in range(hidden_dim)]
    corr_ks_per_dim = [np.corrcoef(ks_values, beta_np[:, d])[0, 1] for d in range(hidden_dim)]
    corr_it_per_dim = [np.corrcoef(it_values, beta_np[:, d])[0, 1] for d in range(hidden_dim)]
    
    ax.bar(x_pos - width, corr_alt_per_dim, width, label='ALT', alpha=0.8, color='#e74c3c')
    ax.bar(x_pos, corr_ks_per_dim, width, label='k_s', alpha=0.8, color='#2ecc71')
    ax.bar(x_pos + width, corr_it_per_dim, width, label='I_t', alpha=0.8, color='#3498db')
    ax.set_xlabel('Hidden dimension', fontsize=12)
    ax.set_ylabel('Pearson correlation', fontsize=12)
    ax.set_title('Correlation between β dimensions and geological features', fontsize=14)
    ax.legend(fontsize=11)
    ax.axhline(y=0, color='gray', linestyle='--', linewidth=0.5)
    ax.set_ylim(-1, 1)
    
    fig3_path = os.path.join(fig_dir, 'geo_bias_correlation_per_dim.png')
    plt.savefig(fig3_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  ✅ Saved: {fig3_path}")
    
    # ===== Summary of key findings =====
    print(f"\n{'='*70}")
    print(f"  📊 Key Findings: Geo-Bias Analysis")
    print(f"{'='*70}")
    
    print(f"\n  Overall correlations (β magnitude vs geo features):")
    print(f"    ALT:  r = {corr_alt:+.3f}  {'✅ Significant geological adaptation!' if abs(corr_alt) > 0.3 else '⚠️ Weak correlation'}")
    print(f"    k_s:  r = {corr_ks:+.3f}  {'✅ Significant geological adaptation!' if abs(corr_ks) > 0.3 else '⚠️ Weak correlation'}")
    print(f"    I_t:  r = {corr_it:+.3f}  {'✅ Significant geological adaptation!' if abs(corr_it) > 0.3 else '⚠️ Weak correlation'}")
    
    # Check whether any dimension is significantly correlated with the geo features
    sig_dims = sum(1 for r in corr_alt_per_dim if abs(r) > 0.3)
    print(f"\n  Hidden dimensions with |r|>0.3 correlation with ALT: {sig_dims}/{hidden_dim}")
    
    if abs(corr_alt) > 0.3 or sig_dims > hidden_dim * 0.1:
        print(f"\n  🎉 KEY FINDING: Geo-bias carries geological information!")
        print(f"  Different ALT nodes receive DIFFERENT beta values,")
        print(f"  confirming node-level geological adaptation.")
    else:
        print(f"\n  ⚠️ Geo-bias does NOT show strong geological dependence.")
        print(f"  This suggests the FiLM generator may not be effectively")
        print(f"  learning geo-adaptive conditioning on this synthetic data.")
    
    # Save the text report
    output_dir = os.path.join(DATA_ROOT, 'outputs')
    report_path = os.path.join(output_dir, 'geo_bias_analysis.txt')
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(f"Geo-Bias Visualization Analysis\n")
        f.write(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Seed: {args.seed}\n\n")
        f.write(f"Beta statistics:\n")
        f.write(f"  Shape: {beta_np.shape}\n")
        f.write(f"  Mean: {beta_np.mean():.6f}\n")
        f.write(f"  Std: {beta_np.std():.6f}\n")
        f.write(f"  ||β|| per node: mean={beta_norms.mean():.6f}, std={beta_norms.std():.6f}\n\n")
        f.write(f"Correlations (β magnitude vs geo features):\n")
        f.write(f"  ALT:  r = {corr_alt:+.3f}\n")
        f.write(f"  k_s:  r = {corr_ks:+.3f}\n")
        f.write(f"  I_t:  r = {corr_it:+.3f}\n\n")
        f.write(f"Per-dimension correlations with ALT:\n")
        for d in range(hidden_dim):
            f.write(f"  dim {d}: r = {corr_alt_per_dim[d]:+.3f}\n")
        f.write(f"\nFigures saved:\n")
        f.write(f"  {fig1_path}\n")
        f.write(f"  {fig2_path}\n")
        f.write(f"  {fig3_path}\n")
    
    print(f"\n✅ Analysis saved to: {report_path}")
    print(f"✅ Figures saved to: {fig_dir}/")


if __name__ == '__main__':
    main()
