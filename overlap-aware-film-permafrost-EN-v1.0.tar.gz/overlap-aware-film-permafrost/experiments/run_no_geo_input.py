#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_no_geo_input.py — No-geo-input experiment (key reviewer response)
Remove thawing_index/freezing_index from input, test if FiLM provides value.
"""
import sys
import os
import argparse
import time
import numpy as np
from datetime import datetime

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)
AUTODL_DATA_DISK = '/root/autodl-tmp'


def resolve_data_root(project_root, cli_data_root=None):
    if cli_data_root:
        return os.path.abspath(cli_data_root)
    if os.environ.get('DATA_ROOT'):
        return os.path.abspath(os.environ.get('DATA_ROOT'))
    if os.path.exists(AUTODL_DATA_DISK) and os.path.isdir(AUTODL_DATA_DISK):
        return AUTODL_DATA_DISK
    return project_root


def remove_geo_features_from_input(X, feature_indices_to_remove):
    all_indices = list(range(X.shape[-1]))
    keep_indices = [i for i in all_indices if i not in feature_indices_to_remove]
    if X.ndim == 4:
        return X[..., keep_indices]
    elif X.ndim == 3:
        return X[:, :, keep_indices]
    else:
        raise ValueError(f"Unexpected X shape: {X.shape}")


def main():
    parser = argparse.ArgumentParser(description='No-geo-input experiment')
    parser.add_argument('--config', type=str, default='configs/simulation_fallback.yaml')
    parser.add_argument('--epochs', type=int, default=None)
    parser.add_argument('--device', type=str, default=None)
    parser.add_argument('--data-root', type=str, default=None)
    parser.add_argument('--seeds', type=int, default=5)
    parser.add_argument('--base-seed', type=int, default=100)
    args = parser.parse_args()

    DATA_ROOT = resolve_data_root(PROJECT_ROOT, args.data_root)

    # Features to remove from input (double-counting with geo_features)
    GEO_FEATURE_INDICES = [4, 5]  # thawing_index, freezing_index
    REMOVED_NAMES = ['thawing_index', 'freezing_index']

    print("=" * 70)
    print("  No-Geo-Input Experiment (Reviewer Response)")
    print(f"  Removed from input: {REMOVED_NAMES} (indices {GEO_FEATURE_INDICES})")
    print(f"  Seeds: {args.seeds}")
    print("=" * 70)

    import torch
    from data import load_config, SyntheticDataGenerator, normalize_features, split_time_series
    from models import GeoFiLMSTGATWrapper, StandardSTGATWrapper

    config = load_config(os.path.join(PROJECT_ROOT, args.config))
    if args.epochs:
        config['epochs'] = int(args.epochs)
    if args.device:
        config['device'] = args.device
    else:
        config['device'] = 'cuda' if torch.cuda.is_available() else 'cpu'
    config['verbose'] = 1

    seeds = list(range(args.base_seed, args.base_seed + args.seeds))
    results_full_input = {'Geo-FiLM': [], 'Standard': []}
    results_no_geo = {'Geo-FiLM': [], 'Standard': []}

    for seed in seeds:
        print(f"\n{'='*60}")
        print(f"  Seed {seeds.index(seed)+1}/{len(seeds)}: seed={seed}")
        print(f"{'='*60}")

        config['seed'] = seed
        np.random.seed(seed)
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed(seed)

        # Generate and preprocess data
        generator = SyntheticDataGenerator(config)
        data_dict = generator.generate()

        # Normalize: pass data_dict['X'] (numpy array), NOT data_dict (dict)
        norm_method = config.get('normalization_method', 'zscore')
        X_norm, norm_params = normalize_features(data_dict['X'], method=norm_method)
        data_dict['X'] = X_norm
        data_dict['norm_params'] = norm_params
        data_dict['T_in'] = int(config.get('T_in', 24))
        data_dict['T_out'] = int(config.get('T_out', 1))
        train_ratio = float(config.get('train_ratio', 0.8))
        data_dict = split_time_series(data_dict, train_ratio=train_ratio)

        # ===== Exp 1: Full input (F=12) =====
        print(f"\n  [1/2] Full input (F=12) - baseline")
        config_full = dict(config)
        config_full['input_dim'] = data_dict['X_train'].shape[-1]

        std_model = StandardSTGATWrapper(config_full)
        std_model.fit(
            X_train=data_dict['X_train_graph'], y_train=data_dict['y_train_graph'],
            adj_matrix=data_dict['adj_matrix'], geo_features=data_dict['geo_features'],
        )
        std_metrics_full = std_model.evaluate(
            X_test=data_dict['X_test_graph'], y_test=data_dict['y_test_graph'],
            adj_matrix=data_dict['adj_matrix'], geo_features=data_dict['geo_features'],
        )
        results_full_input['Standard'].append(std_metrics_full)

        geo_model = GeoFiLMSTGATWrapper(config_full)
        geo_model.fit(
            X_train=data_dict['X_train_graph'], y_train=data_dict['y_train_graph'],
            adj_matrix=data_dict['adj_matrix'], geo_features=data_dict['geo_features'],
        )
        geo_metrics_full = geo_model.evaluate(
            X_test=data_dict['X_test_graph'], y_test=data_dict['y_test_graph'],
            adj_matrix=data_dict['adj_matrix'], geo_features=data_dict['geo_features'],
        )
        results_full_input['Geo-FiLM'].append(geo_metrics_full)

        # ===== Exp 2: No-geo input (F=10) =====
        print(f"\n  [2/2] No-geo input (F=10, removed {REMOVED_NAMES})")

        data_no_geo = dict(data_dict)
        data_no_geo['X_train'] = remove_geo_features_from_input(
            data_dict['X_train'], GEO_FEATURE_INDICES)
        data_no_geo['X_test'] = remove_geo_features_from_input(
            data_dict['X_test'], GEO_FEATURE_INDICES)
        data_no_geo['X_train_graph'] = remove_geo_features_from_input(
            data_dict['X_train_graph'], GEO_FEATURE_INDICES)
        data_no_geo['X_test_graph'] = remove_geo_features_from_input(
            data_dict['X_test_graph'], GEO_FEATURE_INDICES)

        config_no_geo = dict(config)
        config_no_geo['input_dim'] = data_no_geo['X_train'].shape[-1]
        print(f"    Reduced F: {data_dict['X_train'].shape[-1]} -> {data_no_geo['X_train'].shape[-1]}")

        std_model_ng = StandardSTGATWrapper(config_no_geo)
        std_model_ng.fit(
            X_train=data_no_geo['X_train_graph'], y_train=data_no_geo['y_train_graph'],
            adj_matrix=data_dict['adj_matrix'], geo_features=data_dict['geo_features'],
        )
        std_metrics_ng = std_model_ng.evaluate(
            X_test=data_no_geo['X_test_graph'], y_test=data_no_geo['y_test_graph'],
            adj_matrix=data_dict['adj_matrix'], geo_features=data_dict['geo_features'],
        )
        results_no_geo['Standard'].append(std_metrics_ng)

        geo_model_ng = GeoFiLMSTGATWrapper(config_no_geo)
        geo_model_ng.fit(
            X_train=data_no_geo['X_train_graph'], y_train=data_no_geo['y_train_graph'],
            adj_matrix=data_dict['adj_matrix'], geo_features=data_dict['geo_features'],
        )
        geo_metrics_ng = geo_model_ng.evaluate(
            X_test=data_no_geo['X_test_graph'], y_test=data_no_geo['y_test_graph'],
            adj_matrix=data_dict['adj_matrix'], geo_features=data_dict['geo_features'],
        )
        results_no_geo['Geo-FiLM'].append(geo_metrics_ng)

        # Print this seed's results
        print(f"\n  Results (seed={seed}):")
        print(f"  {'Condition':<30} {'Geo-FiLM RMSE':>15} {'Standard RMSE':>15} {'FiLM Imp':>10}")
        print(f"  {'-'*70}")
        for condition, geo_m, std_m in [
            ('Full input (F=12)', geo_metrics_full, std_metrics_full),
            ('No geo input (F=10)', geo_metrics_ng, std_metrics_ng),
        ]:
            geo_rmse = geo_m.get('rmse', geo_m.get('test_rmse', 0))
            std_rmse = std_m.get('rmse', std_m.get('test_rmse', 0))
            film_imp = (std_rmse - geo_rmse) / std_rmse * 100 if std_rmse > 0 else 0
            marker = "OK" if film_imp > 0 else "NEG"
            print(f"  {condition:<30} {geo_rmse:>15.4f} {std_rmse:>15.4f} {film_imp:>+9.1f}% {marker}")

    # ===== Summary =====
    print(f"\n{'='*70}")
    print(f"  Summary: No-Geo-Input Experiment")
    print(f"{'='*70}")

    for condition, results_dict in [
        ('Full input (F=12)', results_full_input),
        ('No geo input (F=10)', results_no_geo),
    ]:
        geo_rmses = [m.get('rmse', m.get('test_rmse', 0)) for m in results_dict['Geo-FiLM']]
        std_rmses = [m.get('rmse', m.get('test_rmse', 0)) for m in results_dict['Standard']]
        if geo_rmses and std_rmses:
            film_imps = [(s - g) / s * 100 for g, s in zip(geo_rmses, std_rmses)]
            mean_imp = np.mean(film_imps)
            positive_count = sum(1 for imp in film_imps if imp > 0)
            print(f"\n  {condition}:")
            print(f"    Geo-FiLM RMSE:  {np.mean(geo_rmses):.4f} +/- {np.std(geo_rmses):.4f}")
            print(f"    Standard RMSE:  {np.mean(std_rmses):.4f} +/- {np.std(std_rmses):.4f}")
            print(f"    FiLM Imp:       {mean_imp:+.1f}% +/- {np.std(film_imps):.1f}%")
            print(f"    Positive runs:  {positive_count}/{len(film_imps)}")
            if condition == 'No geo input (F=10)' and mean_imp > 0:
                print(f"\n    >>> KEY FINDING: FiLM provides POSITIVE improvement ({mean_imp:+.1f}%)!")

    # Save results
    output_dir = os.path.join(DATA_ROOT, 'outputs')
    os.makedirs(output_dir, exist_ok=True)
    result_path = os.path.join(output_dir, 'no_geo_input_results.txt')
    with open(result_path, 'w') as f:
        f.write(f"No-Geo-Input Experiment Results\nDate: {datetime.now()}\n")
        f.write(f"Removed: {REMOVED_NAMES} (indices {GEO_FEATURE_INDICES})\nSeeds: {seeds}\n\n")
        for condition, results_dict in [
            ('Full input (F=12)', results_full_input),
            ('No geo input (F=10)', results_no_geo),
        ]:
            f.write(f"\n{condition}:\n")
            geo_rmses = [m.get('rmse', m.get('test_rmse', 0)) for m in results_dict['Geo-FiLM']]
            std_rmses = [m.get('rmse', m.get('test_rmse', 0)) for m in results_dict['Standard']]
            f.write(f"  Geo-FiLM RMSE: {geo_rmses}\n")
            f.write(f"  Standard RMSE: {std_rmses}\n")
            if geo_rmses and std_rmses:
                film_imps = [(s - g) / s * 100 for g, s in zip(geo_rmses, std_rmses)]
                f.write(f"  FiLM Imp: {film_imps}\n  Mean: {np.mean(film_imps):+.1f}%\n")
    print(f"\nResults saved to {result_path}")


if __name__ == '__main__':
    main()
