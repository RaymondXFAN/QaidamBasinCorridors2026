#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_fair_mult_film.py — Reviewer experiment 3: fair multiplicative FiLM control

Reviewer criticism:
  "R1 (Naive FiLM) injects FiLM at every GAT layer and every timestep (48 times per forward pass),
   violating the single-application recommendation of Perez et al.
   using a route that is admitted to be a design error and that diverges during training to infer that 'multiplicative FiLM causes 76.2% degradation',
   and presenting it as the headline selling point of the abstract and Contribution ① — this is typical selective reporting (cherry-picking)."

This experiment:
  Designs a **fair** multiplicative FiLM control:
  - Injects via SINGLE-APPLICATION only after spatial processing (1 time per forward pass, following Perez's recommendation)
  - Uses zero initialization (the same safe start as the additive version)
  - Compares with additive FiLM and Standard ST-GAT under exactly the same conditions
  
  Goal: to replace R1 with a fair control so that the mechanistic claim that "overlap causes degradation" is more convincing

Usage:
  python3 experiments/run_fair_mult_film.py --config configs/simulation_fallback.yaml
"""

import sys
import os
import argparse
import time
import numpy as np
from datetime import datetime

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)

import torch
import torch.nn as nn

AUTODL_DATA_DISK = '/root/autodl-tmp'


def resolve_data_root(project_root, cli_data_root=None):
    if cli_data_root:
        return os.path.abspath(cli_data_root)
    if os.environ.get('DATA_ROOT'):
        return os.path.abspath(os.environ.get('DATA_ROOT'))
    if os.path.exists(AUTODL_DATA_DISK) and os.path.isdir(AUTODL_DATA_DISK):
        return AUTODL_DATA_DISK
    return project_root


class FairMultiplicativeFiLMGenerator(nn.Module):
    """
    Fair multiplicative FiLM generator — follows the single-application principle of Perez et al.
    
    Differences from Naive FiLM (R1):
      - R1: each GAT layer × each timestep = 48 injections → over-modulation → divergence
      - this design: only 1 injection after spatial processing → follows Perez's recommendation
    
    Differences from Additive FiLM (v5):
      - v5: h' = h + film_scale * β  (additive only)
      - this design: h' = γ · h + β  (multiplicative + additive, but with a safe zero-initialized start)
    
    Zero-initialization guarantee:
      - γ = 1 + γ_raw, γ_raw init = 0 → γ init = 1 (identity scaling)
      - β = β_raw, β_raw init = 0 → β init = 0 (zero bias)
      → initial model behavior = Standard ST-GAT, learning only useful modulation
    """
    def __init__(self, geo_dim, hidden_dim, num_layers=2):
        super().__init__()
        layers = []
        in_dim = geo_dim
        for i in range(num_layers - 1):
            layers.append(nn.Linear(in_dim, hidden_dim))
            layers.append(nn.ReLU())
            in_dim = hidden_dim
        layers.append(nn.Linear(in_dim, 2 * hidden_dim))
        self.mlp = nn.Sequential(*layers)
        
        # ★ Zero initialization (same safe start as additive v5)
        nn.init.zeros_(self.mlp[-1].weight)
        nn.init.zeros_(self.mlp[-1].bias)
    
    def forward(self, geo_features):
        """
        Args:
            geo_features: (N, G) — geological priors
        Returns:
            gamma: (N, hidden_dim) — multiplicative scaling (1 + learned offset)
            beta: (N, hidden_dim) — additive bias
        """
        params = self.mlp(geo_features)
        gamma_raw, beta_raw = params.chunk(2, dim=-1)
        gamma = 1.0 + gamma_raw  # identity + learned offset
        beta = beta_raw           # additive bias
        return gamma, beta


class FairMultFiLMSTGAT(nn.Module):
    """
    Fair Multiplicative FiLM ST-GAT — a single-injection, zero-initialized multiplicative FiLM.
    
    The architecture is the same as Geo-FiLM ST-GAT v5, but FiLM is applied differently:
      - v5 (additive): h' = h + film_scale * β
      - this design (multiplicative): h' = γ · h + β
      - same injection position: after spatial processing and before temporal processing, only once
    """
    def __init__(self, config):
        super().__init__()
        cfg = {}
        for k, v in config.items():
            if isinstance(v, str):
                try: v = float(v)
                except ValueError: pass
            cfg[k] = v
        
        self.hidden_dim = int(cfg.get('hidden_dim', 64))
        self.num_heads = int(cfg.get('num_heads', 4))
        self.num_spatial_layers = int(cfg.get('num_spatial_layers', 2))
        self.dropout = float(cfg.get('dropout', 0.1))
        self.lambda_phys = float(cfg.get('lambda_phys', 0.3))
        self.use_phys_loss = bool(cfg.get('use_phys_loss', True))
        self.output_dim = 1
        self._built = False
    
    def _build_model(self, input_dim, geo_dim):
        self.input_dim = input_dim
        self.geo_dim = geo_dim
        
        self.input_proj = nn.Sequential(
            nn.Linear(input_dim, self.hidden_dim),
            nn.ReLU(),
            nn.Dropout(self.dropout)
        )
        
        # Fair multiplicative FiLM generator
        self.film_generator = FairMultiplicativeFiLMGenerator(
            geo_dim=geo_dim,
            hidden_dim=self.hidden_dim,
            num_layers=2
        )
        
        # Spatial GAT layers (same as v5 — pure attention, no in-layer FiLM)
        from models.geo_film_st_gat import GeoFiLMGATLayer
        self.spatial_layers = nn.ModuleList()
        for i in range(self.num_spatial_layers):
            self.spatial_layers.append(GeoFiLMGATLayer(
                in_dim=self.hidden_dim,
                out_dim=self.hidden_dim,
                num_heads=self.num_heads,
                dropout=self.dropout
            ))
        
        # Temporal GRU
        self.temporal_gru = nn.GRU(
            input_size=self.hidden_dim,
            hidden_size=self.hidden_dim,
            num_layers=1,
            batch_first=True
        )
        
        # Output head
        self.output_head = nn.Sequential(
            nn.Linear(self.hidden_dim, self.hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(self.dropout),
            nn.Linear(self.hidden_dim // 2, self.output_dim)
        )
        
        self._built = True
    
    def compute_stefan_alt(self, geo_features):
        I_t = geo_features[:, 2]
        I_t_sec = I_t * 86400.0
        k_thaw = 1.2
        L = 3.34e7
        alt = torch.sqrt(2.0 * k_thaw * I_t_sec / L + 1e-8)
        return alt
    
    def compute_physical_loss(self, y_pred, y_true, geo_features):
        if not self.use_phys_loss:
            return torch.tensor(0.0, device=y_pred.device)
        k_s = geo_features[:, 1].unsqueeze(0)
        alt = self.compute_stefan_alt(geo_features).unsqueeze(0)
        delta_z = torch.abs(y_pred.squeeze(-1))
        violation = delta_z - k_s * alt
        phys_loss = torch.relu(violation).mean()
        return phys_loss
    
    def forward(self, x, adj_matrix, geo_features):
        """
        Args:
            x: (batch, N, T_in, F) or (batch, T_in, N, F)
            adj_matrix: (N, N)
            geo_features: (N, G)
        """
        if not self._built:
            input_dim = x.shape[-1]
            geo_dim = geo_features.shape[-1]
            self._build_model(input_dim, geo_dim)
            self.to(x.device)
        
        # Handle time-first or batch-first format
        if x.shape[1] > x.shape[2] if x.dim() == 4 else False:
            # (batch, T, N, F) → (batch, N, T, F)
            x = x.permute(0, 2, 1, 3)
        
        batch_size, N, T_in, F = x.shape
        
        # Generate FiLM parameters (single application!)
        gamma, beta = self.film_generator(geo_features)  # (N, hidden_dim)
        
        # Process each timestep
        gru_input_list = []
        for t in range(T_in):
            h_t = x[:, :, t, :]  # (batch, N, F)
            h_t = self.input_proj(h_t)  # (batch, N, hidden_dim)
            
            # Spatial attention
            for layer in self.spatial_layers:
                h_t = layer(h_t, adj_matrix)
            
            # ★ FAIR MULTIPLICATIVE FiLM: single application after spatial processing
            # h' = γ · h + β  (multiplicative + additive, but zero-initialized safe start)
            gamma_expanded = gamma.unsqueeze(0)  # (1, N, hidden_dim)
            beta_expanded = beta.unsqueeze(0)    # (1, N, hidden_dim)
            h_t = gamma_expanded * h_t + beta_expanded  # ★ key difference: multiplicative modulation
            
            gru_input_list.append(h_t)
        
        # Temporal processing
        gru_input = torch.stack(gru_input_list, dim=1)  # (batch, T_in, N, hidden_dim)
        gru_input = gru_input.reshape(batch_size * N, T_in, self.hidden_dim)
        
        gru_out, _ = self.temporal_gru(gru_input)
        last_hidden = gru_out[:, -1, :]  # (batch*N, hidden_dim)
        
        y_pred = self.output_head(last_hidden)  # (batch*N, 1)
        y_pred = y_pred.reshape(batch_size, N, 1)
        
        return y_pred


class FairMultFiLMWrapper:
    """Wrapper for Fair Multiplicative FiLM ST-GAT (compatible with trainer)."""
    
    data_format = 'graph'
    
    def __init__(self, config):
        self.config = config
        self.model = FairMultFiLMSTGAT(config)
        self.name = "Fair-Mult-FiLM-ST-GAT"
    
    def get_name(self):
        return self.name
    
    def fit(self, X_train, y_train, adj_matrix=None, geo_features=None,
            X_val=None, y_val=None):
        import torch
        from torch.utils.data import DataLoader, TensorDataset
        
        device = self.config.get('device', 'cpu')
        self.model = self.model.to(device)
        
        # Convert to tensors
        X_t = torch.FloatTensor(np.array(X_train)).to(device)
        y_t = torch.FloatTensor(np.array(y_train)).to(device)
        adj_t = torch.FloatTensor(np.array(adj_matrix)).to(device)
        geo_t = torch.FloatTensor(np.array(geo_features)).to(device)
        
        optimizer = torch.optim.Adam(self.model.parameters(), 
                                      lr=float(self.config.get('lr', 0.001)))
        scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=50, gamma=0.5)
        
        epochs = int(self.config.get('epochs', 200))
        batch_size = int(self.config.get('batch_size', 32))
        lambda_phys = float(self.config.get('lambda_phys', 0.3))
        
        self.model.train()
        for epoch in range(epochs):
            total_loss = 0
            n_batches = 0
            
            # Mini-batch over windows
            W = X_t.shape[0]
            indices = torch.randperm(W)
            
            for start in range(0, W, batch_size):
                end = min(start + batch_size, W)
                batch_idx = indices[start:end]
                
                X_batch = X_t[batch_idx]
                y_batch = y_t[batch_idx]
                
                y_pred = self.model(X_batch, adj_t, geo_t)
                
                # MSE loss
                mse_loss = nn.MSELoss()(y_pred.squeeze(-1), y_batch.squeeze(-1))
                
                # Physical constraint loss
                phys_loss = self.model.compute_physical_loss(y_pred, y_batch, geo_t)
                
                loss = mse_loss + lambda_phys * phys_loss
                
                optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
                optimizer.step()
                
                total_loss += loss.item()
                n_batches += 1
            
            scheduler.step()
            
            if epoch % 20 == 0 and self.config.get('verbose', 1) >= 1:
                avg_loss = total_loss / max(n_batches, 1)
                print(f"    [{self.name}] Epoch {epoch}/{epochs}, Loss: {avg_loss:.6f}")
    
    def predict(self, X_test, adj_matrix=None, geo_features=None):
        import torch
        device = self.config.get('device', 'cpu')
        self.model.eval()
        
        with torch.no_grad():
            X_t = torch.FloatTensor(np.array(X_test)).to(device)
            adj_t = torch.FloatTensor(np.array(adj_matrix)).to(device)
            geo_t = torch.FloatTensor(np.array(geo_features)).to(device)
            
            y_pred = self.model(X_t, adj_t, geo_t)
            return y_pred.cpu().numpy().squeeze(-1)
    
    def evaluate(self, X_test, y_test, adj_matrix=None, geo_features=None):
        import torch
        from evaluation.metrics import compute_rmse, compute_mae, compute_r2
        
        y_pred = self.predict(X_test, adj_matrix, geo_features)
        y_true = np.array(y_test).squeeze()
        y_pred = y_pred.squeeze()
        
        # Align shapes
        min_len = min(len(y_true.flatten()), len(y_pred.flatten()))
        y_true_flat = y_true.flatten()[:min_len]
        y_pred_flat = y_pred.flatten()[:min_len]
        
        rmse = compute_rmse(y_true_flat, y_pred_flat)
        mae = compute_mae(y_true_flat, y_pred_flat)
        r2 = compute_r2(y_true_flat, y_pred_flat)
        
        # Physical constraint check
        geo_np = np.array(geo_features)
        from evaluation.physical_constraint import check_physical_constraints
        phys_report = check_physical_constraints(y_pred_flat, geo_np)
        
        return {
            'rmse': float(rmse),
            'mae': float(mae),
            'r2': float(r2),
            'phys_violation_rate': phys_report.get('violation_rate_pct', 0),
        }


def main():
    parser = argparse.ArgumentParser(description='Fair Multiplicative FiLM Experiment')
    parser.add_argument('--config', type=str, default='configs/simulation_fallback.yaml')
    parser.add_argument('--epochs', type=int, default=None)
    parser.add_argument('--device', type=str, default=None)
    parser.add_argument('--data-root', type=str, default=None)
    parser.add_argument('--seeds', type=int, default=3)
    parser.add_argument('--base-seed', type=int, default=200)
    args = parser.parse_args()
    
    DATA_ROOT = resolve_data_root(PROJECT_ROOT, args.data_root)
    
    print("=" * 70)
    print("  🔬 Fair Multiplicative FiLM Experiment (Replacing R1)")
    print("  Single-application, zero-initialized, same conditions as additive")
    print("=" * 70)
    
    from data import load_config, SyntheticDataGenerator, normalize_features, split_time_series
    from models import GeoFiLMSTGATWrapper, StandardSTGATWrapper
    
    config = load_config(os.path.join(PROJECT_ROOT, args.config))
    if args.epochs:
        config['epochs'] = int(args.epochs)
    if args.device:
        config['device'] = args.device
    else:
        config['device'] = 'cuda' if torch.cuda.is_available() else 'cpu'
    config['verbose'] = 1
    
    seeds = list(range(args.base_seed, args.base_seed + args.seeds))
    results = {
        'Standard ST-GAT': [],
        'Additive Geo-FiLM (v5)': [],
        'Fair Mult FiLM (this)': [],
    }
    
    for seed in seeds:
        print(f"\n{'='*60}")
        print(f"  Seed {seeds.index(seed)+1}/{len(seeds)}: seed={seed}")
        print(f"{'='*60}")
        
        config['seed'] = seed
        np.random.seed(seed)
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed(seed)
        
        generator = SyntheticDataGenerator(config)
        data_dict = generator.generate()
        # Preprocessing (note: normalize_features takes the X numpy array, not a dict)
        norm_method = config.get('normalization_method', 'zscore')
        X_norm, norm_params = normalize_features(data_dict['X'], method=norm_method)
        data_dict['X'] = X_norm
        data_dict['norm_params'] = norm_params
        data_dict['T_in'] = int(config.get('T_in', 24))
        data_dict['T_out'] = int(config.get('T_out', 1))
        train_ratio = float(config.get('train_ratio', 0.8))
        data_dict = split_time_series(data_dict, train_ratio=train_ratio)
        
        # Standard ST-GAT
        std_model = StandardSTGATWrapper(config)
        std_model.fit(
            X_train=data_dict['X_train_graph'],
            y_train=data_dict['y_train_graph'],
            adj_matrix=data_dict['adj_matrix'],
            geo_features=data_dict['geo_features'],
        )
        std_metrics = std_model.evaluate(
            X_test=data_dict['X_test_graph'],
            y_test=data_dict['y_test_graph'],
            adj_matrix=data_dict['adj_matrix'],
            geo_features=data_dict['geo_features'],
        )
        results['Standard ST-GAT'].append(std_metrics)
        
        # Additive Geo-FiLM (v5)
        geo_model = GeoFiLMSTGATWrapper(config)
        geo_model.fit(
            X_train=data_dict['X_train_graph'],
            y_train=data_dict['y_train_graph'],
            adj_matrix=data_dict['adj_matrix'],
            geo_features=data_dict['geo_features'],
        )
        geo_metrics = geo_model.evaluate(
            X_test=data_dict['X_test_graph'],
            y_test=data_dict['y_test_graph'],
            adj_matrix=data_dict['adj_matrix'],
            geo_features=data_dict['geo_features'],
        )
        results['Additive Geo-FiLM (v5)'].append(geo_metrics)
        
        # Fair Multiplicative FiLM (this experiment)
        mult_model = FairMultFiLMWrapper(config)
        mult_model.fit(
            X_train=data_dict['X_train_graph'],
            y_train=data_dict['y_train_graph'],
            adj_matrix=data_dict['adj_matrix'],
            geo_features=data_dict['geo_features'],
        )
        mult_metrics = mult_model.evaluate(
            X_test=data_dict['X_test_graph'],
            y_test=data_dict['y_test_graph'],
            adj_matrix=data_dict['adj_matrix'],
            geo_features=data_dict['geo_features'],
        )
        results['Fair Mult FiLM (this)'].append(mult_metrics)
        
        # Print this epoch
        std_rmse = std_metrics.get('rmse', 0)
        geo_rmse = geo_metrics.get('rmse', 0)
        mult_rmse = mult_metrics.get('rmse', 0)
        
        print(f"\n  Results (seed={seed}):")
        print(f"  {'Model':<30} {'RMSE':>10} {'vs Standard':>12}")
        for name, rmse in [('Standard ST-GAT', std_rmse),
                           ('Additive Geo-FiLM (v5)', geo_rmse),
                           ('Fair Mult FiLM (this)', mult_rmse)]:
            imp = (std_rmse - rmse) / std_rmse * 100
            marker = "✅" if imp > 0 else "❌"
            print(f"  {name:<30} {rmse:>10.4f} {imp:>+10.1f}% {marker}")
    
    # ===== Summary =====
    print(f"\n{'='*70}")
    print(f"  📊 Summary: Fair Multiplicative FiLM")
    print(f"{'='*70}")
    
    for model_name, metrics_list in results.items():
        rmses = [m.get('rmse', 0) for m in metrics_list]
        std_rmse_list = [m.get('rmse', 0) for m in results['Standard ST-GAT']]
        if rmses:
            print(f"  {model_name}:")
            print(f"    RMSE: {np.mean(rmses):.4f} ± {np.std(rmses):.4f}")
            if std_rmse_list and model_name != 'Standard ST-GAT':
                imps = [(s - g) / s * 100 for g, s in zip(rmses, std_rmse_list)]
                print(f"    FiLM Imp: {np.mean(imps):+.1f}% ± {np.std(imps):.1f}%")
    
    # Save
    output_dir = os.path.join(DATA_ROOT, 'outputs')
    os.makedirs(output_dir, exist_ok=True)
    
    result_path = os.path.join(output_dir, 'fair_mult_film_results.txt')
    with open(result_path, 'w', encoding='utf-8') as f:
        f.write(f"Fair Multiplicative FiLM Experiment Results\n")
        f.write(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Seeds: {seeds}\n\n")
        for model_name, metrics_list in results.items():
            rmses = [m.get('rmse', 0) for m in metrics_list]
            f.write(f"{model_name}: RMSE = {rmses}\n")
    
    print(f"\n✅ Results saved to: {result_path}")


if __name__ == '__main__':
    main()
