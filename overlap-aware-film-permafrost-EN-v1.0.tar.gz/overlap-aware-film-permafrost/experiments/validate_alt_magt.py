#!/usr/bin/env python3
"""
validate_alt_magt.py — ALT and MAGT cross-validation script

1. Read the 5 ALT TIF files (EPSG:4326, 0.01° resolution)
2. Read the MAGT npz data (EPSG:32646 UTM, 1 km resolution)
3. Reproject ALT onto the MAGT grid and extract ALT values over the overlap region
4. Analyze the relationship between ALT and the MAGT geo features
5. Optional: use ALT to replace/supplement the geo features and run the FiLM experiment
"""

import os
import numpy as np
import rasterio
from rasterio.warp import reproject, Resampling
from rasterio import Affine

# ============================================================
# 1. Read the ALT data
# ============================================================

def read_alt_tif(tif_path, nodata_val=None):
    """Read an ALT TIF file, filtering out NoData"""
    with rasterio.open(tif_path) as src:
        arr = src.read(1)
        crs = src.crs
        transform = src.transform
        nodata = src.nodata if nodata_val is None else nodata_val
        
        if nodata is not None and not np.isnan(nodata):
            valid = (arr != nodata) & np.isfinite(arr) & (arr >= 0)
        else:
            valid = np.isfinite(arr) & (arr >= 0)
        
        return arr, valid, crs, transform, nodata


def load_all_alt(alt_dir):
    """Load all ALT files and return a dictionary"""
    import glob
    files = sorted(glob.glob(os.path.join(alt_dir, 'ALT_*.tif')))
    alt_data = {}
    
    for f in files:
        name = os.path.basename(f).replace('.tif', '')
        arr, valid, crs, transform, nodata = read_alt_tif(f)
        
        # Special handling: the nodata=0 of ssp4530 is wrong, so use the mask from the other files
        if 'ssp4530' in name:
            arr_raw, _, _, _, _ = read_alt_tif(f, nodata_val=-3.4e38)
            valid = (arr_raw != -3.4e38) & np.isfinite(arr_raw) & (arr_raw > 0)
        
        alt_data[name] = {
            'arr': arr, 'valid': valid, 'crs': crs, 
            'transform': transform, 'nodata': nodata
        }
        
        if valid.sum() > 0:
            vals = arr[valid]
            print(f"  {name}: valid_pixels={valid.sum()}, ALT_range=[{vals.min():.2f}, {vals.max():.2f}]m, mean={vals.mean():.2f}m")
        else:
            print(f"  {name}: no valid data!")
    
    return alt_data


# ============================================================
# 2. Read the MAGT data & reproject ALT
# ============================================================

def load_magt_coords(npz_path):
    """Get the pixel coordinates and transform from the MAGT npz"""
    d = np.load(npz_path, allow_pickle=True)
    pixel_indices = d['pixel_indices']
    
    # UTM coordinates (derived from pixel_indices)
    transform = Affine(1000.0, 0.0, -1209454.88, 0.0, -1000.0, 4978562.96)
    rows, cols = pixel_indices[:, 0], pixel_indices[:, 1]
    lons_utm = transform.c + (cols + 0.5) * transform.a
    lats_utm = transform.f + (rows + 0.5) * transform.e
    
    return d, lons_utm, lats_utm, transform


def reproject_alt_to_magt_grid(alt_arr, alt_crs, alt_transform, 
                                 magt_crs, magt_transform, magt_shape):
    """Reproject ALT onto the MAGT grid"""
    dest = np.full(magt_shape, np.nan, dtype=np.float32)
    
    reproject(
        source=alt_arr,
        destination=dest,
        src_transform=alt_transform,
        src_crs=alt_crs,
        dst_transform=magt_transform,
        dst_crs=magt_crs,
        resampling=Resampling.nearest
    )
    
    return dest


def extract_alt_at_magt_pixels(alt_arr, alt_crs, alt_transform, 
                                magt_lons_utm, magt_lats_utm, magt_crs_str):
    """Sample values from ALT (WGS84) at the MAGT pixel locations"""
    from rasterio.warp import transform as warp_transform
    
    # Convert the MAGT UTM coordinates to WGS84
    magt_lons_wgs84, magt_lats_wgs84 = warp_transform(
        magt_crs_str, alt_crs, 
        magt_lons_utm.tolist(), magt_lats_utm.tolist()
    )
    
    # Sample from the ALT raster
    alt_values = np.full(len(magt_lons_wgs84), np.nan, dtype=np.float32)
    with rasterio.openEnv():  # ensure the rasterio environment
        pass
    
    # Manual sampling: convert the WGS84 coordinates to pixel indices
    inv_transform = ~alt_transform
    for i in range(len(magt_lons_wgs84)):
        col, row = inv_transform * (magt_lons_wgs84[i], magt_lats_wgs84[i])
        col, row = int(round(col)), int(round(row))
        if 0 <= row < alt_arr.shape[0] and 0 <= col < alt_arr.shape[1]:
            val = alt_arr[row, col]
            if np.isfinite(val) and val > 0:
                alt_values[i] = val
    
    return alt_values


# ============================================================
# 3. Main analysis
# ============================================================

if __name__ == '__main__':
    alt_dir = '/root/autodl-tmp/datasets/raw/qtp_ALT_raw/'
    npz_path = '/root/autodl-tmp/datasets/processed/real_magt/real_magt_data.npz'
    
    print("=" * 60)
    print("  ALT-MAGT cross-validation analysis")
    print("=" * 60)
    
    # Step 1: read ALT
    print("\n📁 Reading ALT data:")
    alt_data = load_all_alt(alt_dir)
    
    # Step 2: read MAGT
    print("\n📁 Reading MAGT data:")
    d, lons_utm, lats_utm, magt_transform = load_magt_coords(npz_path)
    geo_raw = d['geo_raw']
    magt_mean = geo_raw[:, 0]
    magt_trend = geo_raw[:, 1]
    magt_std = geo_raw[:, 2]
    N_pixels = len(magt_mean)
    print(f"  MAGT pixels: {N_pixels}")
    print(f"  MAGT mean range: [{magt_mean.min():.2f}, {magt_mean.max():.2f}]°C")
    
    # Step 3: sample ALT at the MAGT pixel locations
    magt_crs_str = 'EPSG:32646'
    
    print("\n🔄 Reprojecting ALT to the MAGT pixel locations:")
    for alt_name, alt_info in alt_data.items():
        alt_arr = alt_info['arr']
        alt_crs = alt_info['crs']
        alt_transform = alt_info['transform']
        alt_valid_mask = alt_info['valid']
        
        # Set NoData to NaN
        alt_arr_clean = np.where(alt_valid_mask, alt_arr, np.nan)
        
        alt_values = extract_alt_at_magt_pixels(
            alt_arr_clean, alt_crs, alt_transform,
            lons_utm, lats_utm, magt_crs_str
        )
        
        valid_mask = np.isfinite(alt_values) & (alt_values > 0)
        n_valid = valid_mask.sum()
        
        if n_valid > 0:
            print(f"\n  {alt_name}:")
            print(f"    Overlapping pixels: {n_valid}/{N_pixels} ({100*n_valid/N_pixels:.1f}%)")
            print(f"    ALT range: [{alt_values[valid_mask].min():.2f}, {alt_values[valid_mask].max():.2f}]m")
            print(f"    ALT mean: {alt_values[valid_mask].mean():.2f}m")
            
            # Analyze by permafrost type
            for zone_name, zone_cond in [
                ('Cold permafrost', magt_mean < -2),
                ('Warm permafrost', (magt_mean >= -2) & (magt_mean < 0)),
                ('Seasonally frozen', magt_mean >= 0)
            ]:
                zone_valid = valid_mask & zone_cond
                if zone_valid.sum() > 0:
                    z_alt = alt_values[zone_valid]
                    z_magt = magt_mean[zone_valid]
                    print(f"    {zone_name}(n={zone_valid.sum()}): ALT={z_alt.mean():.2f}±{z_alt.std():.2f}m, MAGT={z_magt.mean():.2f}°C")
            
            # ALT vs MAGT correlation
            if n_valid > 10:
                from scipy.stats import pearsonr, spearmanr
                r_p, p_p = pearsonr(magt_mean[valid_mask], alt_values[valid_mask])
                r_s, p_s = spearmanr(magt_mean[valid_mask], alt_values[valid_mask])
                print(f"    Pearson r={r_p:.3f} (p={p_p:.2e}), Spearman r={r_s:.3f} (p={p_s:.2e})")
            
            # Save ALT values for subsequent experiments
            alt_data[alt_name]['magt_alt_values'] = alt_values
            alt_data[alt_name]['magt_valid_mask'] = valid_mask
        else:
            print(f"  {alt_name}: no overlap!")
    
    # Step 4: summary analysis
    print("\n" + "=" * 60)
    print("  📊 Summary of the ALT-MAGT relationship")
    print("=" * 60)
    
    # Use ALT_2020 as the baseline and analyze the relationship between ALT and the geo features
    if 'ALT_2020' in alt_data and 'magt_alt_values' in alt_data['ALT_2020']:
        alt_2020 = alt_data['ALT_2020']['magt_alt_values']
        valid = alt_data['ALT_2020']['magt_valid_mask']
        
        print(f"\n  ALT_2020 vs Geo Features (overlap region):")
        for feat_name, feat_vals in [('MAGT mean', magt_mean), ('MAGT trend', magt_trend), ('MAGT std', magt_std)]:
            from scipy.stats import pearsonr
            r, p = pearsonr(feat_vals[valid], alt_2020[valid])
            print(f"    ALT vs {feat_name}: r={r:.3f}, p={p:.2e}")
    
    # Step 5: save ALT-enhanced geo features
    print("\n💾 Saving ALT-enhanced geo features:")
    if 'ALT_2020' in alt_data and 'magt_alt_values' in alt_data['ALT_2020']:
        alt_2020 = alt_data['ALT_2020']['magt_alt_values']
        valid = alt_data['ALT_2020']['magt_valid_mask']
        
        # Build the enhanced geo features: [MAGT mean, MAGT trend, MAGT std, ALT]
        geo_enhanced = np.column_stack([geo_raw, np.nan_to_num(alt_2020, nan=0.0)])
        # Mark which pixels have ALT data
        has_alt = valid.astype(np.float32)
        
        output_path = '/root/autodl-tmp/datasets/processed/real_magt/real_magt_alt_data.npz'
        # Re-save all the original data + the ALT enhancement
        np.savez(output_path,
                 X_train_raw=d['X_train_raw'],
                 y_val_raw=d['y_val_raw'],
                 y_test_raw=d['y_test_raw'],
                 geo_raw=geo_raw,
                 geo_raw_alt=geo_enhanced,
                 has_alt=has_alt,
                 alt_2020=alt_2020,
                 ts_mean=d['ts_mean'],
                 ts_std=d['ts_std'],
                 pixel_indices=d['pixel_indices'])
        print(f"  Saved to: {output_path}")
        print(f"  geo_raw_alt shape: {geo_enhanced.shape} (4 features: MAGT mean+trend+std+ALT)")
        print(f"  has_alt: {valid.sum()}/{len(valid)} pixels have ALT data")
    
    print("\n✅ Analysis complete!")
