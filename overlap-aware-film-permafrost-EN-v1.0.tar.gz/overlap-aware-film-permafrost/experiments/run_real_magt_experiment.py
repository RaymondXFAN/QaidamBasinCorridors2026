#!/usr/bin/env python3
"""
run_real_magt_experiment.py — Geo-FiLM ST-GAT validation experiment on real MAGT data

Directly addresses a reviewer comment: validating the FiLM advantage on real data

Key optimization: use a sparse GAT (only compute KNN edges, no full N×N attention)
N=500, K=8 → only 4000 edges are computed, instead of 250000 pairs
"""

import os
import sys
import time
import numpy as np

# Fix OMP_NUM_THREADS — must be done before importing torch
for key in ['OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS']:
    os.environ.pop(key, None)

import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.spatial import cKDTree

# ============================================================
# Data loading and windowing
# ============================================================

def load_real_data(npz_path):
    d = np.load(npz_path, allow_pickle=True)
    print(f"Loading data: {npz_path}")
    print(f"  num_pixels={d['X_train_raw'].shape[0]}, sequence_length={d['X_train_raw'].shape[1]}")
    return d


def create_sliding_windows(magt_ts, T_in=10, T_out_step=5):
    N, T_total = magt_ts.shape
    windows, targets, year_targets = [], [], []
    for start in range(T_total - T_in - T_out_step + 1):
        end = start + T_in
        target_idx = end + T_out_step - 1
        if target_idx >= T_total:
            break
        windows.append(magt_ts[:, start:end])
        targets.append(magt_ts[:, target_idx:target_idx+1])
        year_targets.append(1981 + target_idx)
    X = np.stack(windows, axis=0)[:, :, :, np.newaxis].astype(np.float32)
    y = np.stack(targets, axis=0).astype(np.float32)
    return X, y, year_targets


def subsample_pixels(N_total, n_sub, geo_raw, seed=42):
    rng = np.random.RandomState(seed)
    magt_mean = geo_raw[:, 0]
    n_bins = 10
    bins = np.linspace(magt_mean.min(), magt_mean.max(), n_bins + 1)
    bin_idx = np.clip(np.digitize(magt_mean, bins) - 1, 0, n_bins - 1)
    samples_per_bin = n_sub // n_bins
    selected = []
    for b in range(n_bins):
        pool = np.where(bin_idx == b)[0]
        if len(pool) == 0:
            continue
        n_sel = min(samples_per_bin, len(pool))
        idx = rng.choice(pool, n_sel, replace=False)
        selected.append(idx)
    selected = np.concatenate(selected)
    rng.shuffle(selected)
    return selected[:n_sub]


def build_edge_index(pixel_coords, k=8):
    """Build the KNN edge index (sparse graph)"""
    N = len(pixel_coords)
    tree = cKDTree(pixel_coords)
    distances, indices = tree.query(pixel_coords, k=k+1)
    
    src_list, dst_list = [], []
    for i in range(N):
        for j_idx in range(1, k+1):
            j = indices[i, j_idx]
            src_list.append(i)
            dst_list.append(j)
    
    edge_index = np.array([src_list, dst_list], dtype=np.int64)
    return edge_index  # (2, E)


# ============================================================
# Sparse GAT model (only computes attention over KNN edges, saves GPU memory)
# ============================================================

class SparseGATLayer(nn.Module):
    """Sparse graph attention layer: only computes the edges present in edge_index, with no full N×N expansion
    
    Memory comparison (N=500, batch=16, heads=4, head_dim=16):
    - Dense GAT: concat=(16,500,500,4,32) = 1.91 GB → OOM
    - Sparse GAT: edge_feat=(16,4000,4,32) = 0.03 MB → easily
    
    KNN K=8 → E=4000 edges vs N×N=250000 pairs, a 98.4% reduction
    """
    def __init__(self, in_dim, out_dim, num_heads=4, dropout=0.1):
        super().__init__()
        self.num_heads = num_heads
        self.out_dim = out_dim
        self.head_dim = out_dim // num_heads
        assert out_dim % num_heads == 0
        
        self.W_src = nn.Linear(in_dim, out_dim, bias=False)
        self.W_dst = nn.Linear(in_dim, out_dim, bias=False)
        self.attn = nn.Parameter(torch.zeros(1, num_heads, 2 * self.head_dim))
        self.dropout = nn.Dropout(dropout)
        self.leaky_relu = nn.LeakyReLU(0.2)
        self.out_proj = nn.Linear(out_dim, out_dim)
        nn.init.xavier_uniform_(self.attn)
    
    def forward(self, h, edge_index):
        """
        Args:
            h: (batch, N, in_dim)
            edge_index: (2, E) — src and dst node indices, E = number of KNN edges
        Returns:
            h_out: (batch, N, out_dim)
        """
        batch, N, _ = h.shape
        src_idx, dst_idx = edge_index[0], edge_index[1]  # each (E,)
        E = src_idx.shape[0]
        
        # Linear transform + multi-head reshape
        h_src = self.W_src(h).view(batch, N, self.num_heads, self.head_dim)
        h_dst = self.W_dst(h).view(batch, N, self.num_heads, self.head_dim)
        
        # Only gather features of KNN edge endpoints — key: no N×N expansion!
        src_feat = h_src[:, src_idx]  # (batch, E, num_heads, head_dim)
        dst_feat = h_dst[:, dst_idx]
        
        # Attention coefficients: e_ij = LeakyReLU(a^T [Wh_i || Wh_j])
        edge_feat = torch.cat([src_feat, dst_feat], dim=-1)  # (batch, E, num_heads, 2*head_dim)
        e = (edge_feat * self.attn.unsqueeze(0)).sum(-1)  # (batch, E, num_heads)
        e = self.leaky_relu(e)
        
        # Sparse softmax over all src neighbors of each dst node (numerically stable version)
        dst_expand = dst_idx.unsqueeze(0).unsqueeze(-1).expand(batch, -1, self.num_heads)
        
        # Step 1: group by dst node and take the max
        e_max = self._segment_max(e, dst_idx, batch, N)  # (batch, N, num_heads)
        e_shifted = e - e_max[:, dst_idx]
        e_exp = torch.exp(e_shifted)
        
        # Step 2: sum by dst node
        e_sum = torch.zeros(batch, N, self.num_heads, device=h.device, dtype=e.dtype)
        e_sum.scatter_add_(1, dst_expand, e_exp)
        alpha = e_exp / (e_sum[:, dst_idx] + 1e-8)
        alpha = self.dropout(alpha)
        
        # Weighted aggregation: h'_i = Σ_j alpha_ij * Wh_j
        weighted = (alpha.unsqueeze(-1) * src_feat).reshape(batch, E, self.out_dim)
        h_agg = torch.zeros(batch, N, self.out_dim, device=h.device, dtype=h.dtype)
        dst_expanded = dst_idx.unsqueeze(0).unsqueeze(-1).expand(batch, -1, self.out_dim)
        h_agg.scatter_add_(1, dst_expanded, weighted)
        
        return self.out_proj(h_agg)
    
    @staticmethod
    def _segment_max(e, dst_idx, batch, N):
        """Group by dst node and take the max, compatible with various PyTorch versions
        
        Strategy: first try scatter_reduce_('amax'); if the API is unsupported, fall back to
        scattering into a sorted buffer and then reducing
        """
        # e: (batch, E, num_heads), dst_idx: (E,)
        num_heads = e.shape[-1]
        dst_expand = dst_idx.unsqueeze(0).unsqueeze(-1).expand(batch, -1, num_heads)
        
        # Option 1: scatter_reduce_ (PyTorch >= 1.12, stable on 2.x)
        try:
            e_max = torch.full((batch, N, num_heads), -1e9, device=e.device, dtype=e.dtype)
            e_max.scatter_reduce_(1, dst_expand, e, reduce='amax', include_self=True)
            return e_max
        except (AttributeError, RuntimeError, TypeError):
            pass
        
        # Option 2: index_reduce_ (PyTorch >= 1.12)
        try:
            e_max = torch.full((batch, N, num_heads), -1e9, device=e.device, dtype=e.dtype)
            for b in range(batch):
                idx_1d = dst_expand[b]  # (E, num_heads)
                e_max[b].index_reduce_(0, idx_1d[:, 0], e[b], 'amax', include_self=True)
            return e_max
        except (AttributeError, RuntimeError, TypeError):
            pass
        
        # Option 3: implement with sparse matrices — build a sparse max operation
        # Create a one-hot matrix and aggregate via matrix multiplication
        # Using torch.sparse may actually be more complex; use the simplest approach
        e_max = torch.full((batch, N, num_heads), -1e9, device=e.device, dtype=e.dtype)
        # Sort by dst and then group-reduce
        sorted_idx = torch.argsort(dst_idx)
        sorted_dst = dst_idx[sorted_idx]
        unique_dst, counts = torch.unique_consecutive(sorted_dst, return_counts=True)
        offset = 0
        for i, (d, c) in enumerate(zip(unique_dst.tolist(), counts.tolist())):
            e_group = e[:, sorted_idx[offset:offset+c], :]  # (batch, c, num_heads)
            e_max[:, d, :] = e_group.max(dim=1).values
            offset += c
        return e_max


class FiLMGenerator(nn.Module):
    def __init__(self, geo_dim, hidden_dim, beta_max=5.0):
        super().__init__()
        self.beta_max = beta_max
        self.mlp = nn.Sequential(
            nn.Linear(geo_dim, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, 2 * hidden_dim)
        )
        nn.init.zeros_(self.mlp[-1].weight)
        nn.init.zeros_(self.mlp[-1].bias)
        self.film_scale_raw = nn.Parameter(torch.tensor(-1.5))
    
    def forward(self, geo_features):
        params = self.mlp(geo_features)
        gamma_raw, beta_raw = params.chunk(2, dim=-1)
        gamma = 1.0 + gamma_raw
        beta = beta_raw * self.beta_max / (self.beta_max + torch.abs(beta_raw) + 1e-8)
        return gamma, beta, torch.sigmoid(self.film_scale_raw)


class SparseSTGATModel(nn.Module):
    """Sparse ST-GAT with optional FiLM"""
    def __init__(self, input_dim=1, hidden_dim=64, geo_dim=3,
                 num_heads=4, num_spatial_layers=2, dropout=0.1,
                 use_film=True, beta_max=5.0):
        super().__init__()
        self.use_film = use_film
        self.hidden_dim = hidden_dim
        
        self.input_proj = nn.Sequential(
            nn.Linear(input_dim, hidden_dim), nn.ReLU(), nn.Dropout(dropout)
        )
        if use_film:
            self.film_gen = FiLMGenerator(geo_dim, hidden_dim, beta_max=beta_max)
        
        self.spatial_layers = nn.ModuleList([
            SparseGATLayer(hidden_dim, hidden_dim, num_heads, dropout)
            for _ in range(num_spatial_layers)
        ])
        
        self.temporal_gru = nn.GRU(hidden_dim, hidden_dim, num_layers=1, batch_first=True)
        self.output_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2), nn.ReLU(),
            nn.Dropout(dropout), nn.Linear(hidden_dim // 2, 1)
        )
    
    def forward(self, X, edge_index, geo_features):
        batch, N, T, F_dim = X.shape
        
        if self.use_film:
            gamma, beta, film_scale = self.film_gen(geo_features)
        
        temporal_outputs = []
        for t in range(T):
            x_t = X[:, :, t, :]
            h = self.input_proj(x_t)
            for gat in self.spatial_layers:
                h = gat(h, edge_index)
                h = F.relu(h)
            temporal_outputs.append(h)
        
        temporal_seq = torch.stack(temporal_outputs, dim=2)
        
        if self.use_film:
            geo_bias = beta.unsqueeze(0).unsqueeze(2)
            temporal_seq = temporal_seq + film_scale * geo_bias
        
        temporal_seq = temporal_seq.reshape(batch * N, T, self.hidden_dim)
        gru_out, _ = self.temporal_gru(temporal_seq)
        gru_last = gru_out[:, -1, :].reshape(batch, N, self.hidden_dim)
        
        return self.output_head(gru_last)


# ============================================================
# Training and evaluation
# ============================================================

def train_model(model, X_train, y_train, edge_index_t, geo_t,
                X_val=None, y_val=None,
                epochs=200, lr=0.001, batch_size=16, verbose=1):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    
    W_train = X_train.shape[0]
    best_loss = float('inf')
    best_state = None
    patience = 30
    no_improve = 0
    
    for epoch in range(epochs):
        model.train()
        perm = torch.randperm(W_train)
        epoch_loss = 0.0
        
        for start in range(0, W_train, batch_size):
            idx = perm[start:start+batch_size]
            X_b = X_train[idx]
            y_b = y_train[idx]
            
            optimizer.zero_grad()
            y_pred = model(X_b, edge_index_t, geo_t)
            loss = F.mse_loss(y_pred, y_b)
            loss.backward()
            optimizer.step()
            epoch_loss += loss.item() * len(idx)
        
        scheduler.step()
        avg_loss = epoch_loss / W_train
        
        val_loss = None
        if X_val is not None:
            model.eval()
            with torch.no_grad():
                y_pred = model(X_val, edge_index_t, geo_t)
                val_loss = F.mse_loss(y_pred, y_val).item()
        
        metric = val_loss if val_loss is not None else avg_loss
        if metric < best_loss:
            best_loss = metric
            best_state = {k: v.clone() for k, v in model.state_dict().items()}
            no_improve = 0
        else:
            no_improve += 1
        
        if no_improve >= patience:
            if verbose >= 1:
                print(f"  Early stop at epoch {epoch+1}, best_val={best_loss:.6f}")
            break
        
        if verbose >= 2 and (epoch + 1) % 20 == 0:
            v_str = f", val={val_loss:.6f}" if val_loss else ""
            print(f"  Epoch {epoch+1}: train={avg_loss:.6f}{v_str}")
    
    if best_state is not None:
        model.load_state_dict(best_state)
    return model


def evaluate_model(model, X_test, y_test, edge_index_t, geo_t, ts_mean, ts_std):
    model.eval()
    with torch.no_grad():
        y_pred = model(X_test, edge_index_t, geo_t)
    
    y_pred_np = y_pred.cpu().numpy().squeeze()
    y_true_np = y_test.cpu().numpy().squeeze()
    
    y_pred_orig = y_pred_np * ts_std + ts_mean
    y_true_orig = y_true_np * ts_std + ts_mean
    
    rmse = np.sqrt(np.mean((y_pred_orig - y_true_orig)**2))
    mae = np.mean(np.abs(y_pred_orig - y_true_orig))
    ss_res = np.sum((y_true_orig - y_pred_orig)**2)
    ss_tot = np.sum((y_true_orig - y_true_orig.mean())**2)
    r2 = 1 - ss_res / (ss_tot + 1e-8)
    
    return {'rmse': rmse, 'mae': mae, 'r2': r2}


# ============================================================
# Main experiment
# ============================================================

def run_single_experiment(npz_path, n_sub=500, seed=42, use_film=True,
                          T_in=10, T_out_step=5, epochs=200, verbose=1):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    d = np.load(npz_path, allow_pickle=True)
    magt_all_raw = np.concatenate([d['X_train_raw'], d['y_val_raw'], d['y_test_raw']], axis=1)
    geo_raw = d['geo_raw']
    ts_mean = float(d['ts_mean'])
    ts_std = float(d['ts_std'])
    
    N_total = magt_all_raw.shape[0]
    print(f"\n[Seed={seed}, FiLM={use_film}] N_total={N_total}, data_shape={magt_all_raw.shape}")
    
    selected = subsample_pixels(N_total, n_sub, geo_raw, seed=seed)
    magt_sub = magt_all_raw[selected]
    geo_sub = geo_raw[selected]
    
    pixel_indices = d['pixel_indices'][selected]
    from rasterio import Affine
    transform = Affine(1000.0, 0.0, -1209454.88, 0.0, -1000.0, 4978562.96)
    rows, cols = pixel_indices[:, 0], pixel_indices[:, 1]
    lons = transform.c + (cols + 0.5) * transform.a
    lats = transform.f + (rows + 0.5) * transform.e
    coords = np.stack([lons, lats], axis=1)
    
    edge_index = build_edge_index(coords, k=8)
    N = len(selected)
    print(f"  Subsampling: {N} pixels, num_edges={edge_index.shape[1]}")
    
    X_win, y_win, year_targets = create_sliding_windows(magt_sub, T_in=T_in, T_out_step=T_out_step)
    W = X_win.shape[0]
    print(f"  Sliding window: W={W}, T_in={T_in}, target_years={year_targets[0]}~{year_targets[-1]}")
    
    train_mask = np.array([y <= 2010 for y in year_targets])
    val_mask = np.array([2011 <= y <= 2014 for y in year_targets])
    test_mask = np.array([y >= 2015 for y in year_targets])
    
    X_train_np = X_win[train_mask]
    y_train_np = y_win[train_mask]
    X_val_np = X_win[val_mask]
    y_val_np = y_win[val_mask]
    X_test_np = X_win[test_mask]
    y_test_np = y_win[test_mask]
    print(f"  train_windows={train_mask.sum()}, val_windows={val_mask.sum()}, test_windows={test_mask.sum()}")
    
    train_flat = X_train_np.flatten()
    x_mean = float(np.mean(train_flat))
    x_std = float(np.std(train_flat))
    
    X_train_norm = (X_train_np - x_mean) / (x_std + 1e-8)
    X_val_norm = (X_val_np - x_mean) / (x_std + 1e-8)
    X_test_norm = (X_test_np - x_mean) / (x_std + 1e-8)
    y_train_norm = (y_train_np - x_mean) / (x_std + 1e-8)
    y_val_norm = (y_val_np - x_mean) / (x_std + 1e-8)
    y_test_norm = (y_test_np - x_mean) / (x_std + 1e-8)
    
    geo_mean = geo_sub.mean(axis=0)
    geo_std = geo_sub.std(axis=0)
    geo_norm = (geo_sub - geo_mean) / (geo_std + 1e-8)
    
    X_train_t = torch.FloatTensor(X_train_norm).to(device)
    y_train_t = torch.FloatTensor(y_train_norm).to(device)
    X_val_t = torch.FloatTensor(X_val_norm).to(device)
    y_val_t = torch.FloatTensor(y_val_norm).to(device)
    X_test_t = torch.FloatTensor(X_test_norm).to(device)
    y_test_t = torch.FloatTensor(y_test_norm).to(device)
    edge_index_t = torch.LongTensor(edge_index).to(device)
    geo_t = torch.FloatTensor(geo_norm.astype(np.float32)).to(device)
    
    model = SparseSTGATModel(
        input_dim=1, hidden_dim=64, geo_dim=3,
        num_heads=4, num_spatial_layers=2, dropout=0.1,
        use_film=use_film, beta_max=5.0
    ).to(device)
    
    t0 = time.time()
    model = train_model(model, X_train_t, y_train_t, edge_index_t, geo_t,
                        X_val_t, y_val_t,
                        epochs=epochs, lr=0.001, batch_size=16, verbose=verbose)
    train_time = time.time() - t0
    
    metrics = evaluate_model(model, X_test_t, y_test_t, edge_index_t, geo_t, x_mean, x_std)
    metrics['train_time'] = train_time
    
    film_tag = "Geo-FiLM" if use_film else "Standard"
    print(f"  {film_tag} ST-GAT: RMSE={metrics['rmse']:.3f}°C, MAE={metrics['mae']:.3f}°C, "
          f"R²={metrics['r2']:.4f}, time={train_time:.1f}s")
    
    # Evaluate by grouping according to permafrost type
    magt_mean_sub = geo_sub[:, 0]
    model.eval()
    with torch.no_grad():
        y_pred_all = model(X_test_t, edge_index_t, geo_t).cpu().numpy().squeeze()
    y_pred_orig = y_pred_all * x_std + x_mean
    y_true_orig = y_test_np.squeeze()
    
    for name, mask in [('Cold permafrost', magt_mean_sub < -2), 
                       ('Warm permafrost', (magt_mean_sub >= -2) & (magt_mean_sub < 0)),
                       ('Seasonally frozen', magt_mean_sub >= 0)]:
        if mask.sum() > 0:
            pred_sub = y_pred_orig[:, mask].flatten()
            true_sub = y_true_orig[:, mask].flatten()
            sub_rmse = np.sqrt(np.mean((pred_sub - true_sub)**2))
            sub_mae = np.mean(np.abs(pred_sub - true_sub))
            print(f"    {name}(n={mask.sum()}): RMSE={sub_rmse:.3f}°C, MAE={sub_mae:.3f}°C")
            metrics[f'{name}_rmse'] = sub_rmse
            metrics[f'{name}_mae'] = sub_mae
    
    # Free GPU memory
    del model, X_train_t, y_train_t, X_val_t, y_val_t, X_test_t, y_test_t
    torch.cuda.empty_cache()
    
    return metrics


def run_multi_seed_experiment(npz_path, n_seeds=5, n_sub=500, **kwargs):
    results_film = []
    results_standard = []
    
    for seed in range(n_seeds):
        print(f"\n{'='*50}")
        print(f"  Seed {seed+1}/{n_seeds}")
        print(f"{'='*50}")
        
        m_film = run_single_experiment(npz_path, n_sub=n_sub, seed=seed*100+42,
                                        use_film=True, **kwargs)
        m_std = run_single_experiment(npz_path, n_sub=n_sub, seed=seed*100+42,
                                       use_film=False, **kwargs)
        results_film.append(m_film)
        results_standard.append(m_std)
    
    print(f"\n{'='*60}")
    print(f"  📊 Real-data experiment results ({n_seeds}-seedstatistics)")
    print(f"{'='*60}")
    
    for name, results in [('Geo-FiLM ST-GAT', results_film), ('Standard ST-GAT', results_standard)]:
        rmse_vals = [r['rmse'] for r in results]
        mae_vals = [r['mae'] for r in results]
        r2_vals = [r['r2'] for r in results]
        print(f"\n  {name}:")
        print(f"    RMSE: {np.mean(rmse_vals):.3f} ± {np.std(rmse_vals):.3f} °C")
        print(f"    MAE:  {np.mean(mae_vals):.3f} ± {np.std(mae_vals):.3f} °C")
        print(f"    R²:   {np.mean(r2_vals):.4f} ± {np.std(r2_vals):.4f}")
    
    film_rmse = np.mean([r['rmse'] for r in results_film])
    std_rmse = np.mean([r['rmse'] for r in results_standard])
    improvement = (std_rmse - film_rmse) / std_rmse * 100
    
    print(f"\n  📈 Geo-FiLM improvement: RMSE reduced by {improvement:.1f}%")
    
    for zone in ['Cold permafrost', 'Warm permafrost', 'Seasonally frozen']:
        film_key = f'{zone}_rmse'
        if film_key in results_film[0]:
            f_vals = [r[film_key] for r in results_film if film_key in r]
            s_vals = [r[film_key] for r in results_standard if film_key in r]
            if f_vals and s_vals:
                f_mean, s_mean = np.mean(f_vals), np.mean(s_vals)
                imp = (s_mean - f_mean) / s_mean * 100
                print(f"    {zone}: Geo-FiLM={f_mean:.3f}, Standard={s_mean:.3f}, improvement={imp:+.1f}%")
    
    return results_film, results_standard


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--npz', type=str,
                        default='/root/autodl-tmp/datasets/processed/real_magt/real_magt_data.npz')
    parser.add_argument('--n_sub', type=int, default=500)
    parser.add_argument('--n_seeds', type=int, default=5)
    parser.add_argument('--epochs', type=int, default=200)
    parser.add_argument('--T_in', type=int, default=10)
    parser.add_argument('--T_out_step', type=int, default=5)
    parser.add_argument('--quick', action='store_true')
    args = parser.parse_args()
    
    # OMP is already cleaned up at the top of the file, so no need to handle it here
    
    if args.quick:
        print("🚀 Fast mode (1 seed, 50 epochs)")
        m_film = run_single_experiment(args.npz, n_sub=args.n_sub, seed=42,
                                        use_film=True, T_in=args.T_in,
                                        T_out_step=args.T_out_step, epochs=50, verbose=2)
        m_std = run_single_experiment(args.npz, n_sub=args.n_sub, seed=42,
                                       use_film=False, T_in=args.T_in,
                                       T_out_step=args.T_out_step, epochs=50, verbose=2)
        imp = (m_std['rmse'] - m_film['rmse']) / m_std['rmse'] * 100
        print(f"\n📊 FiLM improvement: {imp:+.1f}% (Geo-FiLM RMSE={m_film['rmse']:.3f} vs Standard={m_std['rmse']:.3f})")
    else:
        run_multi_seed_experiment(
            args.npz, n_seeds=args.n_seeds, n_sub=args.n_sub,
            T_in=args.T_in, T_out_step=args.T_out_step, epochs=args.epochs, verbose=1
        )
