#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_multi_seed.py — Multi-seed experiment with statistical tests
"""
import sys
import os
import argparse
import time
import json
import numpy as np
from datetime import datetime

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)
AUTODL_DATA_DISK = '/root/autodl-tmp'


def resolve_data_root(project_root, cli_data_root=None):
    if cli_data_root:
        return os.path.abspath(cli_data_root)
    if os.environ.get('DATA_ROOT'):
        return os.path.abspath(os.environ.get('DATA_ROOT'))
    if os.path.exists(AUTODL_DATA_DISK) and os.path.isdir(AUTODL_DATA_DISK):
        return AUTODL_DATA_DISK
    return project_root


def run_single_seed(config_path, seed, epochs_override=None, device=None, verbose=0):
    from data import load_config, SyntheticDataGenerator, normalize_features, split_time_series
    from trainers import run_all_experiments

    config = load_config(os.path.join(PROJECT_ROOT, config_path))
    config['seed'] = seed
    config['verbose'] = verbose

    if epochs_override:
        config['epochs'] = int(epochs_override)
    if device:
        config['device'] = device
    else:
        import torch
        config['device'] = 'cuda' if torch.cuda.is_available() else 'cpu'

    # Generate data (different per seed)
    generator = SyntheticDataGenerator(config)
    data_dict = generator.generate()

    # Normalize features: pass data_dict['X'] (numpy array), NOT data_dict (dict)
    norm_method = config.get('normalization_method', 'zscore')
    X_norm, norm_params = normalize_features(data_dict['X'], method=norm_method)
    data_dict['X'] = X_norm
    data_dict['norm_params'] = norm_params

    # Inject T_in/T_out for split_time_series
    data_dict['T_in'] = int(config.get('T_in', 24))
    data_dict['T_out'] = int(config.get('T_out', 1))
    train_ratio = float(config.get('train_ratio', 0.8))
    data_dict = split_time_series(data_dict, train_ratio=train_ratio)

    # Run all models
    results = run_all_experiments(config, data_dict)
    return results


def main():
    parser = argparse.ArgumentParser(description='Multi-seed experiment for reviewer response')
    parser.add_argument('--config', type=str, default='configs/simulation_fallback.yaml')
    parser.add_argument('--seeds', type=int, default=5, help='Number of random seeds')
    parser.add_argument('--epochs', type=int, default=None)
    parser.add_argument('--device', type=str, default=None)
    parser.add_argument('--data-root', type=str, default=None)
    parser.add_argument('--verbose', '-v', action='store_true')
    parser.add_argument('--debug', '-d', action='store_true')
    parser.add_argument('--base-seed', type=int, default=42)
    args = parser.parse_args()

    verbose = 2 if args.debug else (1 if args.verbose else 0)
    DATA_ROOT = resolve_data_root(PROJECT_ROOT, args.data_root)
    seeds = list(range(args.base_seed, args.base_seed + args.seeds))

    print("=" * 70)
    print("  Multi-Seed Experiment for Reviewer Response")
    print(f"  Seeds: {seeds}")
    print(f"  Config: {args.config}")
    print("=" * 70)

    all_results = {}
    total_start = time.time()

    for i, seed in enumerate(seeds):
        print(f"\n{'='*60}")
        print(f"  Seed {i+1}/{len(seeds)}: seed={seed}")
        print(f"{'='*60}")

        seed_start = time.time()
        try:
            results = run_single_seed(
                args.config, seed, args.epochs, args.device, verbose
            )
            for model_name, metrics in results.items():
                if model_name not in all_results:
                    all_results[model_name] = {}
                for k, v in metrics.items():
                    if k not in all_results[model_name]:
                        all_results[model_name][k] = []
                    if isinstance(v, (int, float)):
                        all_results[model_name][k].append(v)
            print(f"  Seed {seed} completed in {time.time()-seed_start:.1f}s")
        except Exception as e:
            print(f"  Seed {seed} FAILED: {e}")
            import traceback
            traceback.print_exc()

    total_time = time.time() - total_start
    print(f"\nTotal time: {total_time:.1f}s")

    # ===== Statistical Analysis =====
    print("\n" + "=" * 70)
    print("  Mean +/- Std Results:")
    print("=" * 70)
    for mn in sorted(all_results.keys()):
        m = all_results[mn]
        rmse = m.get('rmse', m.get('test_rmse', []))
        r2 = m.get('r2', m.get('test_r2', []))
        if rmse:
            print(f"  {mn:<30} RMSE={np.mean(rmse):.4f} +/- {np.std(rmse):.4f}")
        if r2:
            print(f"  {'':30} R2  ={np.mean(r2):.4f} +/- {np.std(r2):.4f}")

    # Significance test: Geo-FiLM vs Standard ST-GAT
    geo_name = std_name = None
    for n in all_results:
        if 'geo' in n.lower() and 'film' in n.lower():
            geo_name = n
        elif 'standard' in n.lower():
            std_name = n

    if geo_name and std_name:
        try:
            from scipy import stats
            print(f"\nSignificance: {geo_name} vs {std_name}")
            for mk, ml in [('rmse', 'RMSE'), ('r2', 'R2')]:
                gv = all_results[geo_name].get(mk, [])
                sv = all_results[std_name].get(mk, [])
                if len(gv) >= 3 and len(sv) >= 3:
                    t_s, p_t = stats.ttest_rel(gv, sv)
                    try:
                        w_s, p_w = stats.wilcoxon(gv, sv)
                    except ValueError:
                        p_w = float('nan')
                    sig = "SIGNIFICANT" if p_t < 0.05 else "not significant"
                    print(f"  {ml}: t={t_s:.4f} p={p_t:.4f} ({sig})")

            # FiLM Improvement
            geo_rmse = np.array(all_results[geo_name].get('rmse', []))
            std_rmse = np.array(all_results[std_name].get('rmse', []))
            if len(geo_rmse) > 0 and len(std_rmse) > 0:
                film_imp = (std_rmse - geo_rmse) / std_rmse * 100
                positive = int(np.sum(film_imp > 0))
                print(f"  FiLM Imp: {np.mean(film_imp):+.1f}% +/- {np.std(film_imp):.1f}% "
                      f"(positive in {positive}/{len(film_imp)} runs)")
        except ImportError:
            print("  scipy not available, skipping significance tests")

    # Save results
    output_dir = os.path.join(DATA_ROOT, 'outputs')
    os.makedirs(output_dir, exist_ok=True)

    with open(os.path.join(output_dir, 'multi_seed_results.txt'), 'w') as f:
        f.write(f"Multi-Seed Results\nDate: {datetime.now()}\nSeeds: {seeds}\n\n")
        for mn in sorted(all_results.keys()):
            f.write(f"{mn}:\n")
            for mk, vals in all_results[mn].items():
                if isinstance(vals, list) and vals:
                    f.write(f"  {mk}: {np.mean(vals):.4f} +/- {np.std(vals):.4f}  raw={vals}\n")

    json_safe = {}
    for mn, metrics in all_results.items():
        json_safe[mn] = {}
        for k, v in metrics.items():
            if isinstance(v, list):
                json_safe[mn][k] = [float(x) for x in v]
    with open(os.path.join(output_dir, 'multi_seed_results.json'), 'w') as f:
        json.dump(json_safe, f, indent=2)

    print(f"\nResults saved to {output_dir}/multi_seed_results.txt")


if __name__ == '__main__':
    main()
