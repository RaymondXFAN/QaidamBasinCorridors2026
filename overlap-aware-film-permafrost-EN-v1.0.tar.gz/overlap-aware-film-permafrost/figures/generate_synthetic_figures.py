#!/usr/bin/env python3
"""Generate all figures for the paper DOCX version."""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
import os

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
output_dir = os.path.join(PROJECT_ROOT, 'paper_figures')
os.makedirs(output_dir, exist_ok=True)

# Set global style
plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif'],
    'font.size': 11,
    'axes.labelsize': 12,
    'axes.titlesize': 13,
    'legend.fontsize': 10,
    'figure.dpi': 200,
    'savefig.dpi': 200,
    'savefig.bbox': 'tight',
    'axes.grid': True,
    'grid.alpha': 0.3,
})

# =========== Fig 2: RMSE Comparison Bar Chart ===========
models = ['XGBoost', 'Random Forest', 'Standard\nST-GAT', 'Geo-FiLM\nST-GAT', 'ST-GCN', 'DCRNN', 'PINN-Perm.', 'Stefan-Only']
rmse_values = [0.6136, 0.6175, 0.7094, 0.7449, 0.7458, 0.7568, 1.2903, 4.1517]
r2_values = [0.9774, 0.9771, 0.9820, 0.9801, 0.9801, 0.9795, 0.9000, -0.035]
colors = ['#2ecc71', '#2ecc71', '#3498db', '#e74c3c', '#95a5a6', '#95a5a6', '#f39c12', '#c0392b']

fig, ax = plt.subplots(figsize=(10, 5))
bars = ax.bar(models, rmse_values, color=colors, edgecolor='#2c3e50', linewidth=0.8, width=0.7)

# Add value labels on bars
for bar, val in zip(bars, rmse_values):
    ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.08,
            f'{val:.3f}', ha='center', va='bottom', fontsize=9, fontweight='bold')

ax.set_ylabel('RMSE (m)', fontweight='bold')
ax.set_title('Figure 2: Retrospective Settlement Prediction — RMSE Comparison', fontweight='bold', pad=15)
ax.set_ylim(0, 4.8)
ax.axhline(y=0.7094, color='#3498db', linestyle='--', linewidth=1.2, alpha=0.7, label='Standard ST-GAT baseline')
ax.axhline(y=0.7449, color='#e74c3c', linestyle='--', linewidth=1.2, alpha=0.7, label='Geo-FiLM ST-GAT')

# Legend
legend_patches = [
    mpatches.Patch(color='#2ecc71', label='Traditional ML'),
    mpatches.Patch(color='#3498db', label='Standard ST-GAT (baseline)'),
    mpatches.Patch(color='#e74c3c', label='Geo-FiLM ST-GAT (ours)'),
    mpatches.Patch(color='#95a5a6', label='Other GNN'),
    mpatches.Patch(color='#f39c12', label='PINN'),
    mpatches.Patch(color='#c0392b', label='Pure Physics'),
]
ax.legend(handles=legend_patches, loc='upper left', framealpha=0.9)

plt.tight_layout()
fig.savefig(f'{output_dir}/fig2_rmse_comparison.png')
print(f"Saved fig2_rmse_comparison.png")

# =========== Fig 3: R² Comparison Bar Chart ===========
fig, ax = plt.subplots(figsize=(10, 5))
bars = ax.bar(models, r2_values, color=colors, edgecolor='#2c3e50', linewidth=0.8, width=0.7)

for bar, val in zip(bars, r2_values):
    if val >= 0:
        ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.01,
                f'{val:.4f}', ha='center', va='bottom', fontsize=9, fontweight='bold')
    else:
        ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() - 0.03,
                f'{val:.3f}', ha='center', va='top', fontsize=9, fontweight='bold', color='red')

ax.set_ylabel('R²', fontweight='bold')
ax.set_title('Figure 3: R² (Coefficient of Determination) Comparison', fontweight='bold', pad=15)
ax.set_ylim(-0.3, 1.05)
ax.axhline(y=0, color='black', linewidth=0.5)
ax.axhline(y=0.9820, color='#3498db', linestyle='--', linewidth=1.2, alpha=0.7)
ax.axhline(y=0.9801, color='#e74c3c', linestyle='--', linewidth=1.2, alpha=0.7)

plt.tight_layout()
fig.savefig(f'{output_dir}/fig3_r2_comparison.png')
print(f"Saved fig3_r2_comparison.png")

# =========== Fig 4: FiLM Iteration History (FiLM Imp %) ===========
rounds = ['R1', 'R2', 'R3', 'R4(v5)']
film_imp = [-76.2, -27.7, -40.9, -5.0]
round_labels = [
    'Naive FiLM\n(48× in GAT)',
    'FiLM + β×0.1\n(48×, scaled)',
    'Residual FiLM\n(1×, multiplicative)',
    'Additive geo-bias\n(1×, zero-init)'
]
colors_film = ['#c0392b', '#e74c3c', '#f39c12', '#27ae60']

fig, ax = plt.subplots(figsize=(9, 5))
bars = ax.bar(rounds, film_imp, color=colors_film, edgecolor='#2c3e50', linewidth=0.8, width=0.6)

for bar, val, label in zip(bars, film_imp, round_labels):
    y_pos = bar.get_height() - 3 if val < 0 else bar.get_height() + 2
    ax.text(bar.get_x() + bar.get_width()/2., y_pos,
            f'{val:.1f}%\n{label}', ha='center', va='top' if val<0 else 'bottom',
            fontsize=8, fontweight='bold', color='#2c3e50')

ax.set_ylabel('FiLM Improvement (%)', fontweight='bold')
ax.set_title('Figure 4: FiLM Conditioning Architectural Iteration — FiLM Imp (%)', fontweight='bold', pad=15)
ax.axhline(y=0, color='#3498db', linewidth=1.5, linestyle='-', label='Neutral (0%)')
ax.set_ylim(-85, 15)

# Annotation arrow showing improvement trajectory
ax.annotate('', xy=(3, -5), xytext=(0, -76.2),
            arrowprops=dict(arrowstyle='->', color='#27ae60', lw=2, ls='--'))
ax.text(1.5, -45, '71.2 pp improvement', ha='center', fontsize=9, color='#27ae60', fontweight='bold', style='italic')

ax.legend(loc='upper right')
plt.tight_layout()
fig.savefig(f'{output_dir}/fig4_film_iteration.png')
print(f"Saved fig4_film_iteration.png")

# =========== Fig 5: Architecture Diagram (schematic) ===========
fig, ax = plt.subplots(figsize=(12, 6))
ax.set_xlim(0, 12)
ax.set_ylim(0, 8)
ax.axis('off')

# Boxes for architecture components
box_style = dict(boxstyle='round,pad=0.3', facecolor='#eaf2ff', edgecolor='#3498db', linewidth=1.5)
film_box_style = dict(boxstyle='round,pad=0.3', facecolor='#ffeaa7', edgecolor='#f39c12', linewidth=2)

# Input
ax.text(1.5, 7, 'Input X\n(B,N,T,F=12)', fontsize=10, ha='center', va='center', bbox=box_style)
# Input Projection
ax.text(3.5, 7, 'Input Proj\nLinear→ReLU→Drop', fontsize=9, ha='center', va='center', bbox=box_style)
# Spatial GAT
ax.text(5.5, 7, 'Spatial GAT×2\n(4 heads, H=64)', fontsize=9, ha='center', va='center', bbox=box_style)
# FiLM injection
ax.text(7.5, 7, 'Geo-FiLM\nh+σ(α)·β(g)', fontsize=10, ha='center', va='center', bbox=film_box_style, fontweight='bold')
# Geo features input
ax.text(7.5, 5.5, 'Geo Features g\n[ALT, kₛ, Iₜ]', fontsize=9, ha='center', va='center', bbox=dict(boxstyle='round,pad=0.3', facecolor='#fff3cd', edgecolor='#f39c12'))
# FiLM Generator
ax.text(7.5, 4.2, 'FiLM Generator\nMLP(G→H→2H)\nZero-init final layer', fontsize=8, ha='center', va='center', bbox=dict(boxstyle='round,pad=0.3', facecolor='#fff3cd', edgecolor='#f39c12', linewidth=1.5))
# Temporal GRU
ax.text(9.5, 7, 'Temporal GRU\n(H→H, 1 layer)', fontsize=9, ha='center', va='center', bbox=box_style)
# Output
ax.text(11, 7, 'Output Head\nH→1 (settlement)', fontsize=9, ha='center', va='center', bbox=box_style)

# Arrows (horizontal flow)
for x1, x2, y in [(2.2, 3.0, 7), (4.0, 4.8, 7), (6.2, 7.0, 7), (8.0, 8.8, 7), (10.0, 10.5, 7)]:
    ax.annotate('', xy=(x2, y), xytext=(x1, y),
                arrowprops=dict(arrowstyle='->', color='#2c3e50', lw=1.5))

# Arrow from geo_features to FiLM Generator
ax.annotate('', xy=(7.5, 4.7), xytext=(7.5, 5.1),
            arrowprops=dict(arrowstyle='->', color='#f39c12', lw=1.5))
# Arrow from FiLM Generator to FiLM injection
ax.annotate('', xy=(7.5, 6.6), xytext=(7.5, 4.7),
            arrowprops=dict(arrowstyle='->', color='#f39c12', lw=1.5, linestyle='dashed'))

# Title
ax.text(6, 0.5, 'Figure 1: Geo-FiLM ST-GAT Architecture Overview', fontsize=12, ha='center', fontweight='bold', color='#1a3c5e')

# Label annotations
ax.text(7.5, 3.5, 'σ(α) = sigmoid(α_raw) ∈ (0,1)\nα_raw init = −2.2 (σ≈0.10)', fontsize=7, ha='center', color='#f39c12')
ax.text(4, 5.5, 'Standard ST-GAT path\n(skip FiLM block)', fontsize=8, ha='center', color='#3498db', style='italic')

plt.tight_layout()
fig.savefig(f'{output_dir}/fig1_architecture.png')
print(f"Saved fig1_architecture.png")

# =========== Fig 6: PhysViol Comparison ===========
models_short = ['XGBoost', 'RF', 'Std ST-GAT', 'Geo-FiLM', 'ST-GCN', 'DCRNN', 'PINN', 'Stefan']
phys_viol = [99.1, 98.8, 97.9, 99.0, 98.9, 99.1, 98.8, 0.0]
colors_phys = ['#2ecc71', '#2ecc71', '#3498db', '#e74c3c', '#95a5a6', '#95a5a6', '#f39c12', '#c0392b']

fig, ax = plt.subplots(figsize=(8, 5))
bars = ax.bar(models_short, phys_viol, color=colors_phys, edgecolor='#2c3e50', linewidth=0.8, width=0.6)

for bar, val in zip(bars, phys_viol):
    ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 1,
            f'{val:.1f}%', ha='center', va='bottom', fontsize=9, fontweight='bold')

ax.set_ylabel('Physical Violation Rate (%)', fontweight='bold')
ax.set_title('Figure 5: Stefan Constraint Violation Rate Across Models', fontweight='bold', pad=15)
ax.set_ylim(0, 110)
ax.axhline(y=50, color='red', linewidth=0.5, linestyle=':', alpha=0.5)

# Annotation
ax.text(7, 15, 'Stefan-Only: 0% by definition\n(all others > 97%)', fontsize=9, ha='center', 
        color='#c0392b', fontweight='bold', style='italic',
        bbox=dict(boxstyle='round', facecolor='#fce4e4', alpha=0.8))

plt.tight_layout()
fig.savefig(f'{output_dir}/fig5_physviol.png')
print(f"Saved fig5_physviol.png")

# =========== Fig 7: Additive vs Multiplicative FiLM conceptual diagram ===========
fig, axes = plt.subplots(1, 2, figsize=(10, 4))

# Left: Multiplicative (destructive)
ax1 = axes[0]
x = np.linspace(-3, 3, 100)
h_orig = np.sin(x)  # original feature
gamma = 2.5  # exaggerated for illustration
beta = 0.5
h_mult = gamma * h_orig + beta

ax1.plot(x, h_orig, 'b-', linewidth=2, label='h (original features)')
ax1.plot(x, h_mult, 'r--', linewidth=2, label=f'γ·h+β (γ={gamma}, β={beta})')
ax1.set_title('Multiplicative FiLM (γ·h + β)', fontweight='bold', color='red')
ax1.set_xlabel('Feature dimension')
ax1.set_ylabel('Feature value')
ax1.legend()
ax1.annotate('Feature\nDISTORTION', xy=(1.5, 2), fontsize=9, color='red', fontweight='bold', ha='center')

# Right: Additive (preserving)
ax2 = axes[1]
alpha_raw = -2.2
sigma_alpha = 1/(1+np.exp(-alpha_raw))  # ≈ 0.10
beta_add = 0.3
h_add = h_orig + sigma_alpha * beta_add

ax2.plot(x, h_orig, 'b-', linewidth=2, label='h (original features)')
ax2.plot(x, h_add, 'g--', linewidth=2, label=f'h+σ(α)·β (σ≈{sigma_alpha:.2f}, β={beta_add})')
ax2.set_title('Additive Geo-Bias (h + σ(α)·β)', fontweight='bold', color='green')
ax2.set_xlabel('Feature dimension')
ax2.set_ylabel('Feature value')
ax2.legend()
ax2.annotate('Feature\nSHIFT (preserved)', xy=(1.5, 0.8), fontsize=9, color='green', fontweight='bold', ha='center')

fig.suptitle('Figure 6: Multiplicative vs. Additive FiLM — Feature Distribution Impact', fontweight='bold', fontsize=12, y=1.02)
plt.tight_layout()
fig.savefig(f'{output_dir}/fig6_film_comparison.png')
print(f"Saved fig6_film_comparison.png")

print("\nAll figures generated successfully!")
print(f"Output directory: {output_dir}")
for f in os.listdir(output_dir):
    print(f"  {f}")
