#!/usr/bin/env python3
"""
Draw new figures: real MAGT validation + Fair FiLM ablation
Morandi color palette + Times New Roman + font size ≥12pt
"""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import os

# ── Global settings ──
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['DejaVu Serif', 'Times New Roman']
plt.rcParams['mathtext.fontset'] = 'dejavuserif'
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 13

# ── Morandi color palette ──
MORANDI = {
    'blue':    '#6B8E9B',   # grey-blue
    'green':   '#8BAF8E',   # grey-green
    'rose':    '#C4918A',   # dusty rose
    'sand':    '#C4A882',   # sand
    'lavender':'#9B8EC4',   # grey-purple
    'slate':   '#7A8B99',   # slate blue
    'terra':   '#B8856F',   # terracotta
    'sage':    '#A3B5A0',   # sage green
    'cream':   '#D4C5A9',   # cream
    'mauve':   '#A6899B',   # mauve
}

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
outdir = os.path.join(PROJECT_ROOT, 'outputs', 'figures')
os.makedirs(outdir, exist_ok=True)

# ============================================================
# Fig7.RealMAGT — real MAGT RMSE/R² comparison
# ============================================================
fig, axes = plt.subplots(1, 2, figsize=(10, 4.5))

# RMSE comparison
models = ['Geo-FiLM\nST-GAT', 'Standard\nST-GAT']
rmse_means = [1.716, 2.592]
rmse_stds = [0.074, 0.070]
colors = [MORANDI['blue'], MORANDI['sand']]

bars1 = axes[0].bar(models, rmse_means, yerr=rmse_stds, capsize=6,
                     color=colors, edgecolor='#555555', linewidth=0.8, width=0.5)
axes[0].set_ylabel('RMSE (°C)', fontsize=14)
axes[0].set_ylim(0, 3.2)
axes[0].set_title('(a) RMSE', fontsize=14, fontweight='bold')
for bar, val, std in zip(bars1, rmse_means, rmse_stds):
    axes[0].text(bar.get_x() + bar.get_width()/2, bar.get_height() + std + 0.08,
                 f'{val:.3f}', ha='center', va='bottom', fontsize=12)
axes[0].tick_params(axis='both', labelsize=12)
axes[0].spines['top'].set_visible(False)
axes[0].spines['right'].set_visible(False)

# R² comparison
r2_means = [0.9644, 0.9186]
r2_stds = [0.0028, 0.0054]
colors2 = [MORANDI['blue'], MORANDI['sand']]

bars2 = axes[1].bar(models, r2_means, yerr=r2_stds, capsize=6,
                     color=colors2, edgecolor='#555555', linewidth=0.8, width=0.5)
axes[1].set_ylabel('R²', fontsize=14)
axes[1].set_ylim(0.88, 1.0)
axes[1].set_title('(b) R²', fontsize=14, fontweight='bold')
for bar, val, std in zip(bars2, r2_means, r2_stds):
    axes[1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + std + 0.003,
                 f'{val:.4f}', ha='center', va='bottom', fontsize=12)
axes[1].tick_params(axis='both', labelsize=12)
axes[1].spines['top'].set_visible(False)
axes[1].spines['right'].set_visible(False)

fig.suptitle('Retrospective MAGT Prediction (5-seed)', fontsize=15, fontweight='bold', y=1.02)
plt.tight_layout()
fig.savefig(f'{outdir}/Fig7.RealMAGT.png', dpi=300, bbox_inches='tight')
plt.close()
print("✅ Fig7.RealMAGT.png")

# ============================================================
# Fig8.PerZone — RMSE by permafrost type
# ============================================================
fig, ax = plt.subplots(figsize=(8, 4.5))

zones = ['Cold\nPermafrost', 'Warm\nPermafrost', 'Seasonally\nFrozen']
geofilm_rmse = [2.394, 0.721, 1.463]
standard_rmse = [2.103, 2.110, 2.794]

x = np.arange(len(zones))
w = 0.3

bars_g = ax.bar(x - w/2, geofilm_rmse, w, label='Geo-FiLM ST-GAT',
                color=MORANDI['blue'], edgecolor='#555555', linewidth=0.8)
bars_s = ax.bar(x + w/2, standard_rmse, w, label='Standard ST-GAT',
                color=MORANDI['sand'], edgecolor='#555555', linewidth=0.8)

# Annotate the improvement
improvements = ['-13.8%', '+65.8%', '+47.6%']
for i, (imp, gv, sv) in enumerate(zip(improvements, geofilm_rmse, standard_rmse)):
    ymax = max(gv, sv)
    ax.text(i, ymax + 0.15, imp, ha='center', va='bottom',
            fontsize=12, fontweight='bold',
            color=MORANDI['terra'] if '+' in imp else MORANDI['slate'])

ax.set_xticks(x)
ax.set_xticklabels(zones, fontsize=12)
ax.set_ylabel('RMSE (°C)', fontsize=14)
ax.set_ylim(0, 3.5)
ax.legend(fontsize=12, frameon=False)
ax.tick_params(axis='both', labelsize=12)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.set_title('Per-Zone RMSE Comparison', fontsize=14, fontweight='bold')

plt.tight_layout()
fig.savefig(f'{outdir}/Fig8.PerZone.png', dpi=300, bbox_inches='tight')
plt.close()
print("✅ Fig8.PerZone.png")

# ============================================================
# Fig9.FairFiLM — Fair FiLM ablation comparison
# ============================================================
fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))

configs = ['Full\n(γ·h+β)', 'γ-only\n(γ·h)', 'β-only\n(h+β)', 'Standard\nwider']
rmse_vals = [1.594, 1.737, 1.761, 2.607]
rmse_errs = [0.034, 0.341, 0.220, 0.054]
r2_vals = [0.9693, 0.9621, 0.9619, 0.9178]

# Colors: blue tones for the FiLM variants, a contrasting color for Standard
colors_film = [MORANDI['blue'], MORANDI['lavender'], MORANDI['mauve'], MORANDI['sand']]

# RMSE
bars3 = axes[0].bar(configs, rmse_vals, yerr=rmse_errs, capsize=5,
                     color=colors_film, edgecolor='#555555', linewidth=0.8, width=0.55)
axes[0].set_ylabel('RMSE (°C)', fontsize=14)
axes[0].set_ylim(0, 3.5)
axes[0].set_title('(a) RMSE', fontsize=14, fontweight='bold')
for bar, val in zip(bars3, rmse_vals):
    axes[0].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.12,
                 f'{val:.3f}', ha='center', va='bottom', fontsize=12)
axes[0].tick_params(axis='both', labelsize=12)
axes[0].spines['top'].set_visible(False)
axes[0].spines['right'].set_visible(False)

# R²
bars4 = axes[1].bar(configs, r2_vals,
                     color=colors_film, edgecolor='#555555', linewidth=0.8, width=0.55)
axes[1].set_ylabel('R²', fontsize=14)
axes[1].set_ylim(0.89, 1.0)
axes[1].set_title('(b) R²', fontsize=14, fontweight='bold')
for bar, val in zip(bars4, r2_vals):
    axes[1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.003,
                 f'{val:.4f}', ha='center', va='bottom', fontsize=12)
axes[1].tick_params(axis='both', labelsize=12)
axes[1].spines['top'].set_visible(False)
axes[1].spines['right'].set_visible(False)

fig.suptitle('Fair Multiplicative FiLM Ablation (5-seed)', fontsize=15, fontweight='bold', y=1.02)
plt.tight_layout()
fig.savefig(f'{outdir}/Fig9.FairFiLM.png', dpi=300, bbox_inches='tight')
plt.close()
print("✅ Fig9.FairFiLM.png")

# ============================================================
# Fig10.CrossValidation — ALT-MAGT cross-validation
# ============================================================
fig, ax = plt.subplots(figsize=(7, 4.5))

periods = ['Historical\n(ALT₂₀₂₀ vs MAGT)', 'Future\n(ALT₂₀₇₀ vs MAGT)']
r_vals = [0.105, -0.340]
p_vals = [0.071, 1e-5]
colors_alt = [MORANDI['sage'], MORANDI['terra']]

bars5 = ax.bar(periods, r_vals, color=colors_alt, edgecolor='#555555', linewidth=0.8, width=0.45)
ax.axhline(y=0, color='#888888', linewidth=0.8, linestyle='--')
ax.set_ylabel('Pearson r', fontsize=14)
ax.set_ylim(-0.5, 0.3)

for bar, r, p in zip(bars5, r_vals, p_vals):
    y_pos = bar.get_height() + 0.03 if bar.get_height() > 0 else bar.get_height() - 0.06
    p_str = f'p={p:.3f}' if p > 0.001 else 'p<10⁻⁵'
    ax.text(bar.get_x() + bar.get_width()/2, y_pos,
            f'r={r:+.3f}\n({p_str})', ha='center', va='bottom' if bar.get_height()>0 else 'top',
            fontsize=12)

ax.tick_params(axis='both', labelsize=12)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.set_title('ALT-MAGT Correlation Shift', fontsize=14, fontweight='bold')

# Add an arrow annotating the sign reversal
ax.annotate('Sign reversal:\nStefan-consistent', xy=(1.05, -0.2),
            xytext=(1.2, 0.05), fontsize=11,
            arrowprops=dict(arrowstyle='->', color=MORANDI['terra'], lw=1.5),
            color=MORANDI['terra'], fontweight='bold')

plt.tight_layout()
fig.savefig(f'{outdir}/Fig10.AltMagt.png', dpi=300, bbox_inches='tight')
plt.close()
print("✅ Fig10.AltMagt.png")

print("\n✅ All figures generated!")
