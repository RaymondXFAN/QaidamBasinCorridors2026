#!/usr/bin/env bash
# =============================================================================
#  竞争实验 / competition probe — 明早一条命令跑完
#
#  问的问题：模型不用描述子，是因为数据里没有信息，还是因为 x 通道把答案
#           解释掉了（竞争），使条件化分支拿不到梯度？
#
#  设计（2×2 + 两个对照，全部 h=5 协议、5 seeds、250 epochs）：
#     C2  正常 x  + oracle 描述子      ← 已有，不重跑（若缺失则补）
#     C3  零   x  + oracle 描述子      ← 关键条件
#     C4  零   x  + 零描述子            ← 对照：确认真的没信息可用
#     C5  零   x  + origin 描述子       ← 对照：真实描述子在无竞争时值多少
#
#  预计 20 个 run，约 12 分钟（GPU）；全部落盘后自动打印汇总。
#  判读规则写死在 scripts/summarize_probe.py 里，避免"看到数字再挑说法"。
#
#  Author: Raymond Xiaohu Fan
#
#  用法 / Usage:
#     bash scripts/run_probe_competition.sh              # 后台跑
#     BG=0 bash scripts/run_probe_competition.sh         # 前台跑（看实时日志）
# =============================================================================
set -euo pipefail

ROOT="${ROOT:-/root/autodl-tmp/revision_v2}"
DEVICE="${DEVICE:-cuda}"
SEEDS="${SEEDS:-5}"
EPOCHS="${EPOCHS:-250}"
BG="${BG:-1}"

CODE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DATA="${DATA:-$ROOT/datasets_v2/real_magt_data_v2_clean.npz}"
YEARS="${YEARS:-2015,2016,2017,2018}"
LOG="$ROOT/logs"
mkdir -p "$LOG" "$ROOT/datasets_v2" "$ROOT/runs/probe"

echo "=============================================================="
echo " competition probe"
echo "  host : $(hostname)"
echo "  root : $ROOT"
echo "  code : $CODE"
echo "  data : $DATA"
if [ ! -f "$DATA" ]; then
  echo "  [fatal] 找不到 $DATA —— 先确认机器与 ROOT"
  exit 1
fi
echo "  npz  : $(find "$ROOT" -maxdepth 3 -name '*.npz' | wc -l | tr -d ' ') 个"
echo "=============================================================="

run() {  # run <tag> <data> <configs>
  local tag="$1" data="$2" cfgs="$3"
  local log="$LOG/probe_${tag}_$(date +%Y%m%d_%H%M%S).log"
  local cmd=(python "$CODE/filmstgat/experiments/e1_info_matched.py"
             --data "$data" --out "$ROOT/runs/probe/$tag"
             --n-sub 500 --seeds "$SEEDS" --epochs "$EPOCHS"
             --configs "$cfgs" --device "$DEVICE")
  echo "  [$tag] configs=$cfgs → $ROOT/runs/probe/$tag"
  if [ "$BG" = "1" ]; then
    nohup env PYTHONUNBUFFERED=1 "${cmd[@]}" > "$log" 2>&1 &
    echo "         PID=$!  log=$log"
  else
    PYTHONUNBUFFERED=1 "${cmd[@]}" 2>&1 | tee "$log"
  fi
}

# ---- 0) 构造变体（CPU，几秒） ----
echo
echo "[0/3] build variants"
python "$CODE/scripts/make_probe_variant.py" --data "$DATA" \
  --out "$ROOT/datasets_v2/probe_zeroX_oracle.npz" \
  --zero-input --oracle-years "$YEARS"
python "$CODE/scripts/make_probe_variant.py" --data "$DATA" \
  --out "$ROOT/datasets_v2/probe_zeroX_zeroG.npz" \
  --zero-input --zero-geo
python "$CODE/scripts/make_probe_variant.py" --data "$DATA" \
  --out "$ROOT/datasets_v2/probe_zeroX_origin.npz" \
  --zero-input

# ---- 1) C3：零 x + oracle（关键条件：standard 作对照） ----
echo
echo "[1/3] C3 zeroX + oracle"
run C3_zeroX_oracle "$ROOT/datasets_v2/probe_zeroX_oracle.npz" "standard,film_full"

# ---- 2) C4 / C5：两个对照 ----
echo
echo "[2/3] C4 zeroX + zeroG"
run C4_zeroX_zeroG "$ROOT/datasets_v2/probe_zeroX_zeroG.npz" "film_full"

echo
echo "[2/3] C5 zeroX + origin descriptors"
run C5_zeroX_origin "$ROOT/datasets_v2/probe_zeroX_origin.npz" "film_full"

# ---- 3) 汇总 ----
if [ "$BG" = "1" ]; then
  echo
  echo "[3/3] 已后台启动。跑完后执行："
  echo "  python $CODE/scripts/summarize_probe.py --runs $ROOT/runs/probe"
  echo
  echo "  进度: ls -d $ROOT/runs/probe/*/*/ | wc -l    # 目标 20"
  echo "  日志: tail -f $LOG/probe_*.log"
else
  echo
  echo "[3/3] summarize"
  python "$CODE/scripts/summarize_probe.py" --runs "$ROOT/runs/probe"
fi
