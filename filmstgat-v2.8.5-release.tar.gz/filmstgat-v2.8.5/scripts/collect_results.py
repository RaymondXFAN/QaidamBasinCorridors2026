#!/usr/bin/env python3
"""把结果文件收进 results/，让审稿人不必跑 GPU 就能重建全部图表。

Collect result files into `results/` so that every figure and table can be
regenerated without a GPU and without the raw observations.

为什么需要 / Why
----------------
论文声称"结论来自结果文件"，那审稿人就必须能拿到那些文件。只给代码，
他要么信任我们，要么重跑几小时 GPU——两者都不该是默认选项。

收录什么 / What is copied
-------------------------
每次 run 的 `metrics.json`、`run_manifest.json`、`predictions.npz`（通常几十 KB），
以及各级汇总 JSON/JSONL/MD。**权重文件（*.pt/*.ckpt）默认不收录**，用
`--with-weights` 显式开启。

产出 / Output
-------------
  results/<stage>/<run_id>/{metrics,predictions,run_manifest}
  results/MANIFEST.json     每个文件的 sha256 + 大小 + 总览
  results/README.md         给审稿人的两行说明

作者 / Author: Raymond Xiaohu Fan

用法 / Usage:
    python scripts/collect_results.py --runs /root/autodl-tmp/revision_v2 --out results
    python scripts/collect_results.py --runs ... --out results --max-mb 200
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil

KEEP_NAMES = {"metrics.json", "run_manifest.json", "predictions.npz"}
KEEP_EXT = {".json", ".jsonl", ".md", ".csv", ".txt", ".npy", ".npz"}
WEIGHT_EXT = {".pt", ".pth", ".ckpt"}
SKIP_DIRS = {"__pycache__", ".git", "logs", "figures", "tables", "datasets_v2",
             "datasets_v2_h1", "datasets_synth", "datasets_synth_v2", "legacy_server",
             "repo", "pkgs", "manifests"}
# runs/ 下我们关心的阶段（其余如 probe/e4 也保留，见 KEEP_PREFIX）
KEEP_PREFIX = ("e1", "e3", "e5", "e2", "e4", "e1oracle", "probe", "synth", "e2b", "signal")


def sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def should_copy(path: str, name: str, with_weights: bool) -> bool:
    ext = os.path.splitext(name)[1].lower()
    if ext in WEIGHT_EXT:
        return with_weights
    if name in KEEP_NAMES:
        return True
    return ext in KEEP_EXT


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", required=True, help="含 runs/ 的根目录（服务器上的 ROOT）")
    ap.add_argument("--out", required=True, help="输出目录，建议 results/")
    ap.add_argument("--max-mb", type=float, default=150.0,
                    help="超过这个体积就停止并报错（默认 150 MB）")
    ap.add_argument("--with-weights", action="store_true", help="同时收录模型权重")
    args = ap.parse_args()

    src_root = os.path.join(args.runs, "runs")
    if not os.path.isdir(src_root):
        print(f"[fatal] 找不到 {src_root}")
        return 1

    out = os.path.abspath(args.out)
    os.makedirs(out, exist_ok=True)
    manifest: dict = {"source": src_root, "files": {}, "stages": {}}
    total = 0
    copied = 0

    for stage in sorted(os.listdir(src_root)):
        sp = os.path.join(src_root, stage)
        if not os.path.isdir(sp) or stage in SKIP_DIRS:
            continue
        if not any(stage.startswith(p) for p in KEEP_PREFIX):
            continue
        n_stage = 0
        for dp, dns, fns in os.walk(sp):
            dns[:] = sorted(d for d in dns if d not in SKIP_DIRS)
            for fn in sorted(fns):
                if not should_copy(dp, fn, args.with_weights):
                    continue
                fp = os.path.join(dp, fn)
                size = os.path.getsize(fp)
                if size > 60 * 1024 * 1024:      # 单个文件上限
                    print(f"  skip (too large, {size/1e6:.1f} MB): {fp}")
                    continue
                total += size
                if total > args.max_mb * 1024 * 1024:
                    print(f"[fatal] 超过 --max-mb={args.max_mb}，停止。"
                          f" 先确认 predictions.npz 是否过大")
                    return 1
                rp = os.path.relpath(fp, src_root)
                dst = os.path.join(out, rp)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(fp, dst)
                manifest["files"][rp] = {"sha256": sha256(fp), "bytes": size}
                copied += 1
                n_stage += 1
        if n_stage:
            manifest["stages"][stage] = n_stage
            print(f"  [{stage}] {n_stage} files")

    manifest["summary"] = {"files": copied, "bytes": total,
                           "mb": round(total / 1e6, 2),
                           "with_weights": bool(args.with_weights)}
    with open(os.path.join(out, "MANIFEST.json"), "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=2, ensure_ascii=False)

    with open(os.path.join(out, "README.md"), "w", encoding="utf-8") as fh:
        fh.write(
            "# results/\n\n"
            "每次 run 的 `metrics.json`、`predictions.npz` 与 `run_manifest.json`，"
            "以及各级汇总。\n"
            f"共 {copied} 个文件，{total/1e6:.1f} MB。逐文件 sha256 见 `MANIFEST.json`。\n\n"
            "用它重建论文的全部图表（**不需要 GPU、不需要原始数据**）：\n\n"
            "```bash\n"
            "ROOT=results bash run_all.sh figures\n"
            "ROOT=results bash run_all.sh tables\n"
            "```\n\n"
            "`predictions.npz` 里是物理单位（°C）的预测与真值，形状 `(test_windows, n_pixels)`，"
            "可直接与 `metrics.json` 中的指标对照复核。\n")

    print(f"\n→ {out}  ({copied} files, {total/1e6:.2f} MB)")
    print(f"  MANIFEST.json  {len(manifest['files'])} 条 sha256")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
