#!/usr/bin/env python3
"""Statistics for the real-data conditioning ablations (E1 / E1 h=1).

真实数据条件化对照的统计检验：与 persistence 的单样本检验 + 配置间配对检验。

Two distinct questions / 两个不同的问题
-------------------------------------
1. **vs persistence** — persistence is an analytic constant, so there is no
   pairing and no seed variance to cancel: a one-sample t-test on the per-seed
   RMSE is the correct test. Pairing does not exist here.
2. **configuration vs configuration** — same seeds, so a paired t-test is both
   possible and more powerful. This is the test that answers "does conditioning
   itself cost anything relative to no conditioning?"

They are reported separately because conflating them produced a wrong claim
during this revision (AUDIT_LOG D-27).

作者 / Author: Raymond Xiaohu Fan

用法 / Usage:
    python scripts/analyze_e1.py --stage e1h1 --runs <ROOT>/runs/e1h1 \
        --ref-json <ROOT>/runs/e3h1/metrics_e3.json
"""

from __future__ import annotations

import argparse
import glob
import itertools
import json
import os
import re

import numpy as np
from scipy import stats

RUN_RE = re.compile(r"^(?P<cfg>.+)_seed(?P<seed>\d+)$")


def holm(pvals):
    m = len(pvals)
    order = np.argsort(pvals)
    adj = np.empty(m, dtype=float)
    run = 0.0
    for rank, idx in enumerate(order):
        run = max(run, (m - rank) * float(pvals[idx]))
        adj[idx] = min(1.0, run)
    return adj.tolist()


def mde_paired(sd, n, alpha=0.05, power=0.8):
    if not np.isfinite(sd) or sd <= 0 or n < 2:
        return float("nan")
    tc = stats.t.ppf(1 - alpha / 2, n - 1)
    lo, hi = 0.0, 10.0 * sd
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        nc = mid * np.sqrt(n) / sd
        pw = (1 - stats.nct.cdf(tc, n - 1, nc)) + stats.nct.cdf(-tc, n - 1, nc)
        if pw < power:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def collect(runs_dir):
    """Group per-seed RMSE by configuration, reading metrics.json only."""
    per = {}
    for d in sorted(glob.glob(os.path.join(runs_dir, "*"))):
        if not os.path.isdir(d):
            continue
        m = RUN_RE.match(os.path.basename(d))
        if not m:
            continue
        mf = os.path.join(d, "metrics.json")
        if not os.path.exists(mf):
            continue
        j = json.load(open(mf, encoding="utf-8"))
        rmse = float(j.get("metrics", {}).get("rmse", np.nan))
        if not np.isfinite(rmse):
            continue
        per.setdefault(m.group("cfg"), []).append((int(m.group("seed")), rmse))
    return {k: dict(v) for k, v in per.items()}


def read_ref(path):
    if not path or not os.path.exists(path):
        return None
    d = json.load(open(path, encoding="utf-8"))
    if isinstance(d, list):
        for r in d:
            if r.get("model") == "persistence":
                return float(r["rmse"])
    return None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", required=True)
    ap.add_argument("--runs", required=True)
    ap.add_argument("--ref-json", default=None)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    per = collect(args.runs)
    if not per:
        raise SystemExit(f"no *_seed*/metrics.json under {args.runs}")

    seeds = sorted(set.intersection(*[set(v) for v in per.values()]))
    cfgs = sorted(per)
    if not seeds:
        raise SystemExit("configurations do not share a common set of seeds")
    arr = {c: np.array([per[c][s] for s in seeds]) for c in cfgs}
    n = len(seeds)

    ref = read_ref(args.ref_json)
    out = args.out or os.path.join(args.runs, "analysis")
    os.makedirs(out, exist_ok=True)

    lines = [f"# {args.stage} — conditioning ablations, statistics", "",
             f"seeds used: {seeds} (n = {n})",
             f"reference (persistence): "
             f"{'%.4f °C' % ref if ref else 'not found — table A skipped'}", ""]

    rows_a = []
    if ref is not None:
        for c in cfgs:
            v = arr[c]
            d = v - ref
            sd = float(d.std(ddof=1))
            t, p = stats.ttest_1samp(d, 0.0) if sd > 0 else (np.nan, 1.0)
            rows_a.append({"config": c, "mean": float(v.mean()), "sd": sd,
                           "delta": float(d.mean()),
                           "delta_pct": float(100 * d.mean() / ref),
                           "p": float(p), "mde": mde_paired(sd, n)})
        for r, pa in zip(rows_a, holm([r["p"] for r in rows_a])):
            r["p_holm"] = float(pa)

        lines += ["## A. Each configuration vs persistence (one-sample t; no pairing exists)", "",
                  "| config | RMSE | Δ (°C) | Δ (%) | p | p (Holm) | MDE (°C) |",
                  "|:--|--:|--:|--:|--:|--:|--:|"]
        for r in rows_a:
            lines.append(f"| {r['config']} | {r['mean']:.4f} ± {r['sd']:.4f} | "
                         f"{r['delta']:+.4f} | {r['delta_pct']:+.2f}% | {r['p']:.4f} | "
                         f"{r['p_holm']:.4f} | {r['mde']:.4f} |")

    rows_b = []
    for a, b in itertools.combinations(cfgs, 2):
        d = arr[a] - arr[b]
        sd = float(d.std(ddof=1))
        if sd > 0:
            t, p = stats.ttest_rel(arr[a], arr[b])
            r = float(np.corrcoef(arr[a], arr[b])[0, 1])
        else:
            t, p, r = np.nan, 1.0, np.nan
        rows_b.append({"a": a, "b": b, "delta": float(d.mean()), "sd": sd, "r": r,
                       "p": float(p), "mde": mde_paired(sd, n)})
    if rows_b:
        for r, pa in zip(rows_b, holm([r["p"] for r in rows_b])):
            r["p_holm"] = float(pa)

    lines += ["", "## B. Configuration vs configuration (paired, same seeds)", "",
              "| A | B | Δ = A − B (°C) | sd(Δ) | r | p | p (Holm) | MDE (°C) |",
              "|:--|:--|--:|--:|--:|--:|--:|--:|"]
    for r in rows_b:
        lines.append(f"| {r['a']} | {r['b']} | {r['delta']:+.4f} | {r['sd']:.4f} | "
                     f"{r['r']:+.2f} | {r['p']:.4f} | {r['p_holm']:.4f} | {r['mde']:.4f} |")

    verdict = []
    if rows_a:
        sig = [r["config"] for r in rows_a if r["p_holm"] < 0.05]
        raw = [r["config"] for r in rows_a if r["p"] < 0.05]
        verdict.append(f"Worse than persistence, uncorrected p<0.05: {raw or 'none'}; "
                       f"after Holm: {sig or 'none'}.")
    if rows_b:
        sigb = [(r["a"], r["b"]) for r in rows_b if r["p_holm"] < 0.05]
        verdict.append(f"Detectable configuration-to-configuration differences: "
                       f"{sigb or 'none'}.")
        key = [r for r in rows_b if {r["a"], r["b"]} == {"standard", "film_add"}]
        if key:
            k = key[0]
            verdict.append(
                f"Conditioning cost (film_add − standard) = {k['delta']:+.4f} °C, "
                f"p = {k['p']:.4f} (Holm {k['p_holm']:.4f}); MDE {k['mde']:.4f} °C.")
    lines += ["", "## Verdict", ""] + [f"- {v}" for v in verdict]

    with open(os.path.join(out, "e1_stats.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    with open(os.path.join(out, "e1_stats.json"), "w", encoding="utf-8") as fh:
        json.dump({"stage": args.stage, "seeds": seeds, "reference": ref,
                   "vs_reference": rows_a, "pairwise": rows_b, "verdict": verdict},
                  fh, indent=2, ensure_ascii=False)

    print("\n".join(lines))
    print(f"\nwritten: {out}/e1_stats.md")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
