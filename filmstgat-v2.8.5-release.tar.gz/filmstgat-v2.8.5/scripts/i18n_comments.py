#!/usr/bin/env python3
"""One-shot pass: make Chinese-only comments English-first (English + Chinese). 一次性改写。

One-shot pass: make every standalone Chinese comment English-first.

只改注释/文档字符串行，不碰任何代码。改完会打印 diff 摘要并复检代码 token 未变。
Only comment/docstring lines are touched; code tokens are verified unchanged.

作者 / Author: Raymond Xiaohu Fan
"""

from __future__ import annotations

import io
import os
import sys
import tokenize

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# (relative path, 1-based line number, replacement text WITHOUT leading indent and newline)
REPLACEMENTS = [
    ("filmstgat/data/real.py", 206, "# 3) Sliding windows + temporal split / 开窗 + 划分"),
    ("filmstgat/data/real.py", 213, "# 5) Graph construction / 建图"),
    ("filmstgat/data/real.py", 248, "# 8) Dataset card, written for reviewers / 数据集说明"),
    ("filmstgat/data/synth_windows.py", 78, "# ---- 1) Sliding windows / 滑窗 ----"),
    ("filmstgat/data/synth_windows.py", 82,
     "# ---- 2) Temporal split by target index, never by flattened position / 按目标索引切分 ----"),
    ("filmstgat/data/synth_windows.py", 90,
     "# Completeness check: the three splits must tile all windows and never overlap / 完备性检查"),
    ("filmstgat/data/synth_windows.py", 98, "# ---- 4) Graph / 建图 ----"),
    ("filmstgat/data/synth_windows.py", 101,
     "# ---- 5) Per-feature scaling stats, fitted on the training period only / 只用训练期 ----"),
    ("filmstgat/data/windows.py", 1,
     '"""Data pipeline: sliding windows, temporal split, scaling, window manifest. 数据管线。'),
    ("filmstgat/data/windows.py", 83,
     '"""Split by **window index** (= chronological order), never by flattened row number. 按窗口序号切分。'),
    ("filmstgat/data/windows.py", 125,
     '"""A scaler fitted on training statistics only. 只用训练集统计量。'),
    ("filmstgat/eval/metrics.py", 1,
     '"""One evaluator: one metric set, one test set, one inverse-transform path. 统一评估器。'),
    ("filmstgat/eval/metrics.py", 59,
     '"""Compute everything at once, including n — the column that settles "same test set?". 一次算全。"""'),
    ("filmstgat/eval/metrics.py", 87,
     '"""Check that a group of results shares one test set. 检查是否共用同一测试集。'),
    ("filmstgat/eval/overlap.py", 1,
     '"""Overlap degree rho: spatial-gradient agreement. 重叠度指标。'),
    ("filmstgat/eval/overlap.py", 34,
     '"""Spatial-gradient agreement between two fields, rho in [0, 1]. 两场一致性。'),
    ("filmstgat/experiments/common.py", 1,
     '"""Shared experiment plumbing: tensor assembly, batching, result persistence. 实验公共件。'),
    ("filmstgat/experiments/common.py", 32, '"""Select a pixel subset. 选像素子集。'),
    ("filmstgat/experiments/e1_info_matched.py", 46,
     '"""Brute-force scan over legal widths to match parameter counts. 扫描合法宽度匹配参数量。'),
    ("filmstgat/experiments/e1_info_matched.py", 95,
     "# Residual parameterisation and spatial self-connection are on by default / 默认启用："),
    ("filmstgat/experiments/e1_info_matched.py", 97,
     "# shared by every configuration, so the comparison stays fair / 所有配置共用，公平性不受影响。"),
    ("filmstgat/experiments/e1_info_matched.py", 145, "# Aggregate / 汇总"),
    ("filmstgat/experiments/e1_synthetic.py", 81, "# ---- Lagged target channel / 滞后目标通道 ----"),
    ("filmstgat/experiments/e2_overlap_sweep.py", 62,
     '# ... on a torch-free machine, otherwise "verify the manipulation first" never happens / 无 torch 也能跑'),
    ("filmstgat/experiments/e2_overlap_sweep.py", 77,
     '"""Rasterise scattered pixels onto a regular grid. 把散点插值到规则网格。'),
    ("filmstgat/experiments/e2_overlap_sweep.py", 188,
     "# Validate the tool before reading the result: the lowest alpha must sit near chance level 0.5 / 先验工具再读结论"),
    ("filmstgat/experiments/e2_overlap_sweep.py", 200,
     "# Two sources of significance, never to be conflated / 两种显著性来源："),
    ("filmstgat/experiments/e2_overlap_sweep.py", 267,
     "# so the stub test (whole chain with stand-in functions) is not blocked by the env guard / 桩测试不被误伤"),
    ("filmstgat/experiments/e2_overlap_sweep.py", 320,
     "# range [-1,1]; 0 = indistinguishable from chance. Restate the 0.3/0.5 thresholds on this scale / 口径重述"),
    ("filmstgat/experiments/e2_overlap_sweep.py", 385,
     "# Only the block bootstrap speaks to spatial generalisation. Report both; never cherry-pick / 两个都报"),
    ("filmstgat/experiments/e3_naive_baselines.py", 41,
     '"""Return persistence and trend-extrapolation predictions. 持久化与趋势外推基线。"""'),
    ("filmstgat/experiments/e3_naive_baselines.py", 120, "# Paper-ready table / 论文用小表"),
    ("filmstgat/models/factory.py", 1,
     '"""Model factory: seed first, build second. 先定种子，再造模型。'),
    ("filmstgat/models/factory.py", 23,
     '"""Fix every RNG, then construct the model. 先固定随机源再构造模型。'),
    ("filmstgat/models/film.py", 99, '"""Apply the modulation to the features. 把调制作用到特征上。'),
    ("filmstgat/models/stgat.py", 66,
     "# shared by all configurations so fairness is unaffected; the model only learns the increment / 只学变化量"),
    ("filmstgat/models/stgat.py", 74,
     "# Without it, two attention layers wash each node's own level into a neighbour average / 会洗成邻居平均"),
    ("filmstgat/train/seeding.py", 1, '"""Centralised RNG management. 随机源统一管理。'),
    ("filmstgat/train/seeding.py", 49,
     '# Some ops have no deterministic implementation; let them raise — an error beats "looks like it runs" / 宁可报错'),
    ("filmstgat/train/trainer.py", 1, '"""The one and only training loop. 唯一的训练循环。'),
    ("scripts/analyze_e2b.py", 101, "# ---------- Per-level table / 逐档表 ----------"),
    ("scripts/analyze_e2b.py", 111, "# ---------- Cross-tool conflict check / 工具间冲突检查 ----------"),
    ("scripts/analyze_e2b.py", 156, "# ---------- Verdict / 判定 ----------"),
    ("scripts/diagnose_training.py", 2,
     '"""Training diagnostics: did the model learn anything, or is it predicting the mean? 训练诊断。'),
    ("scripts/horizon_probe.py", 2,
     '"""Horizon probe: how much signal survives at lead times of 1-5 years? 跨度探针。'),
    ("scripts/horizon_probe.py", 94,
     "# Absolute-domain fitting is dominated by pixel level; the anomaly domain targets the change / 异常域对准变化"),
    ("scripts/regen_synthetic.py", 64,
     '"""Element-wise comparison: report shape mismatches and max abs diff, never a vague "looks close". 逐元素对拍。"""'),
    ("scripts/skill_check.py", 39,
     '"""Four features per (window, pixel): [last, mean, slope, std]. 四个特征。"""'),
    ("scripts/skill_check.py", 81, "# ---- Baselines / 基线 ----"),
    ("scripts/skill_check.py", 87, "# ---- Ridge, fitted on training windows only / 只用训练窗口 ----"),
    ("scripts/skill_check.py", 109,
     '# Also check on validation, to rule out a lucky test set / 防"测试集偶然"'),
    ("tests/test_core.py", 54, "# First window: input 0..4, 3-year gap, target at year 8 / 第一个窗口"),
    ("tests/test_core.py", 108, "# New logic: select windows first / 先选窗口"),
    ("tests/test_core.py", 145, "# Same test set, two prediction sets / 同一测试集"),
    ("tests/test_core.py", 187,
     "# Same structure, different amplitude: only a linear rescale, gradients align, so rho ~ 1 / 应≈1"),
    ("tests/test_core.py", 191,
     "# Smooth a **structured** field (smoothed white noise would not stay structured) / 平滑有结构的场"),
    ("tests/test_e2_design.py", 58, "# ------------------------------------------------- The manipulation itself / 操纵本身"),
    ("tests/test_e2_design.py", 61,
     '"""alpha=1 must return the input unchanged, else the high-overlap level is not the real field. α=1 恒等。"""'),
    ("tests/test_e2_design.py", 69,
     '"""alpha=0 may only permute; values must be preserved (information is conserved). 信息量守恒。"""'),
    ("tests/test_e2_design.py", 81,
     '"""All channels must share one permutation, or the pixel falls apart. 通道共用置换。"""'),
    ("tests/test_e2_design.py", 92,
     '"""Core check: smaller alpha means lower measured rho (ties allowed, increases not). ρ 随 α 单调。"""'),
    ("tests/test_e2_design.py", 138,
     '"""Regression test: deltas look monotone but nothing is significant -> verdict must be "no evidence". 无证据。'),
    ("tests/test_e2_design.py", 162,
     '"""Counterpart: if a real effect exists, it must be acknowledged. 反向对照。"""'),
    ("tests/test_e2_design.py", 202,
     '"""Identical models must yield a CI for delta containing 0. 自助法不造效应。"""'),
    ("tests/test_e2_design.py", 220, "# --------------------------------------------- Stub end-to-end run / 桩跑全流程"),
    ("tests/test_e2_design.py", 293, "# --------------------------------------------- Bare-python entry / 裸跑入口"),
    ("tests/test_synth.py", 2,
     '"""Synthetic pipeline checks: reproducible generator, complete split, non-leaking lag. 合成管线自检。'),
    ("tests/test_synth.py", 93, "# Target indices must agree with the window split / 目标索引一致"),
]


def code_tokens(path: str) -> list:
    """Return the token stream with comments/strings blanked out.

    Used to prove we only touched prose: if this stream is identical before and
    after, no code semantics changed.
    """
    drop = {tokenize.COMMENT, tokenize.STRING, tokenize.FSTRING_MIDDLE}
    out = []
    with open(path, "rb") as fh:
        for tok in tokenize.tokenize(io.BytesIO(fh.read()).readline):
            if tok.type in drop:
                out.append((tok.type, ""))
            elif tok.type in (tokenize.NL, tokenize.NEWLINE, tokenize.INDENT,
                              tokenize.DEDENT, tokenize.ENCODING):
                out.append((tok.type, ""))
            else:
                out.append((tok.type, tok.string))
    return out


def main() -> int:
    before = {}
    touched = 0
    by_file = {}

    for rel, lineno, new in REPLACEMENTS:
        path = os.path.join(ROOT, rel)
        if path not in before:
            before[path] = code_tokens(path)
        lines = open(path, encoding="utf-8").read().split("\n")
        idx = lineno - 1
        old = lines[idx]
        indent = old[: len(old) - len(old.lstrip())]
        stripped = old.strip()
        if not stripped:
            print(f"[skip] {rel}:{lineno} 空行 / empty line")
            continue
        # Only comment / docstring lines may be rewritten. 只允许改注释行
        if not (stripped.startswith("#") or stripped.startswith('"""')
                or stripped.startswith("'''")):
            print(f"[skip] {rel}:{lineno} 不是注释行 / not a comment: {stripped[:40]}")
            continue
        lines[idx] = indent + new
        open(path, "w", encoding="utf-8").write("\n".join(lines))
        by_file[rel] = by_file.get(rel, 0) + 1
        touched += 1

    print(f"已改写 / rewritten: {touched} 行，涉及 {len(by_file)} 个文件")
    for rel, n in sorted(by_file.items()):
        print(f"  {n:3d}  {rel}")

    # 代码 token 必须完全不变
    bad = []
    for path, toks in before.items():
        if code_tokens(path) != toks:
            bad.append(path)
    if bad:
        print("\n[fail] 代码 token 发生变化：")
        for b in bad:
            print(f"  {os.path.relpath(b, ROOT)}")
        return 1
    print("\n[ok] 代码 token 完全不变（只改了注释）")

    # Re-check: no Chinese-only comment line should remain. 复检
    import re
    cjk = re.compile(r"[\u4e00-\u9fff]")
    alpha = re.compile(r"[A-Za-z]")
    left = []
    for dp, dns, fns in os.walk(ROOT):
        dns[:] = [d for d in dns if d not in ("__pycache__", ".pytest_cache")]
        for fn in fns:
            if not fn.endswith(".py"):
                continue
            p = os.path.join(dp, fn)
            for i, line in enumerate(open(p, encoding="utf-8"), 1):
                s = line.strip()
                if s and (s.startswith("#") or s.startswith('"""') or s.startswith("'''")) \
                        and cjk.search(line) and not alpha.search(line):
                    left.append(f"{os.path.relpath(p, ROOT)}:{i} {s[:50]}")
    print(f"剩余纯中文注释行：{len(left)}")
    for x in left[:10]:
        print(f"  {x}")
    return 0 if not left else 1


if __name__ == "__main__":
    sys.exit(main())
