#!/usr/bin/env bash
# =============================================================================
#  Status report / 状态总览
#
#  一条命令回答：还在跑吗？跑出什么了？结论是什么？表和图在哪？
#  One command answers: still running? what came out? what is the verdict?
#
#  Usage:  ROOT=<output root> bash scripts/report.sh
#  Author: Raymond Xiaohu Fan
# =============================================================================
set -uo pipefail

R="${ROOT:-${R:-/root/autodl-tmp/revision_v2}}"
echo "ROOT = $R"
[ -d "$R" ] || { echo "[fatal] no such directory: $R"; exit 1; }

echo
echo "===== 1. Still running? / 还在跑吗 ====="
ps -eo pid,etime,cmd 2>/dev/null \
  | grep -E "e1_info_matched|e2_overlap|e1_synthetic|e3_naive|make_tables|make_figures" \
  | grep -v grep || echo "  (none / 无进程)"

echo
echo "===== 2. Runs per stage / 各阶段产出 ====="
for s in e1 e1h1 e2 e2b e1synth; do
  n=$(find "$R/runs/$s" -maxdepth 2 -name metrics.json 2>/dev/null | wc -l)
  [ "$n" -gt 0 ] && printf "  %-8s %3d run(s)\n" "$s" "$n" || printf "  %-8s   —\n" "$s"
done
for s in e3 e3h1; do
  if [ -f "$R/runs/$s/metrics_e3.json" ]; then printf "  %-8s   ok (analytic)\n" "$s"
  else printf "  %-8s   —\n" "$s"; fi
done
for s in e2 e2b; do
  [ -f "$R/runs/$s/e2_summary.json" ] && printf "  %-8s   summary ok\n" "$s"
done

echo
echo "===== 3. Latest logs / 最近日志 ====="
found=0
for f in $(ls -t "$R"/logs/*.log 2>/dev/null | head -3); do
  found=1
  echo "--- $(basename "$f")"
  grep -E "Traceback|Error|error:|fatal|Killed" "$f" >/dev/null 2>&1 \
    && echo "  [!] log contains an error line — inspect it" || true
  tail -5 "$f" | sed 's/^/  /'
done
[ "$found" -eq 0 ] && echo "  (no logs)"

echo
echo "===== 4. Verdicts / 判定 ====="
if [ -f "$R/runs/e2/verdict.txt" ]; then
  echo "--- E2 (overlap sweep)"
  grep -E "rho_range|delta_spread|spearman|verdict" "$R/runs/e2/verdict.txt" | sed 's/^/  /'
fi
if [ -f "$R/runs/e2b/analysis/analysis.md" ]; then
  echo "--- E2b (endpoint contrast)"
  sed -n '/## 判定/,$p' "$R/runs/e2b/analysis/analysis.md" | tail -4 | sed 's/^/  /'
fi
if [ -f "$R/runs/e1synth/analysis/synth_stats.md" ]; then
  echo "--- Synthetic benchmark"
  sed -n '/## Verdict/,$p' "$R/runs/e1synth/analysis/synth_stats.md" | tail -4 | sed 's/^/  /'
fi

echo
echo "===== 5. Tables / 表格 ====="
ls -1 "$R"/tables/*.md 2>/dev/null | sed 's/^/  /' || echo "  (none — run: ROOT=$R bash run_all.sh tables)"
for t in "$R"/tables/*.md; do
  [ -f "$t" ] || continue
  grep -qE "STALE RESULTS|IMPLAUSIBLE|UNVERIFIED UNITS" "$t" 2>/dev/null \
    && echo "  [!] $(basename "$t") carries a warning banner"
done

echo
echo "===== 6. Figures / 图 ====="
ls -1 "$R"/figures/*.png 2>/dev/null | sed 's/^/  /' || echo "  (none — run: ROOT=$R bash run_all.sh figures)"

echo
echo "Next / 下一步:"
echo "  ROOT=$R bash run_all.sh tables    # regenerate tables"
echo "  ROOT=$R bash run_all.sh figures   # regenerate figures"
