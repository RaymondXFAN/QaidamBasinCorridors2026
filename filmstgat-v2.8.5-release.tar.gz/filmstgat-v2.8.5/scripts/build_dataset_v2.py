#!/usr/bin/env python3
"""从旧 npz 重建可复现的 v2 数据集。

Rebuild the reproducible v2 dataset from the legacy npz.

用法 / Usage:
    python scripts/build_dataset_v2.py \
        --legacy <DATA_ROOT>/datasets/processed/real_magt/real_magt_data.npz \
        --out    <ROOT>/datasets_v2 \
        --n-samples 45041 --k 8 --seed 42

产物 / Outputs:
    real_magt_data_v2_clean.npz    数据集本体
    window_manifest_v2.csv         逐窗口 origin / 输入年段 / 目标年段
    dataset_manifest_v2.json       生成规则与统计（给审稿人看）
"""

from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from filmstgat.data.real import build_dataset_v2  # noqa: E402
from filmstgat.utils.provenance import sha256_file  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--legacy", required=True, help="旧 npz 路径")
    ap.add_argument("--out", required=True, help="输出目录")
    ap.add_argument("--n-samples", type=int, default=45041)
    ap.add_argument("--k", type=int, default=8)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--T-in", type=int, default=10)
    ap.add_argument("--gap", type=int, default=4, help="输入结束到目标开始的间隔（年）")
    ap.add_argument("--T-out", type=int, default=1)
    args = ap.parse_args()

    print("=" * 70)
    print("Building dataset v2")
    print("=" * 70)
    print(f"legacy : {args.legacy}  (sha256={sha256_file(args.legacy)[:16]}…)")

    meta = build_dataset_v2(
        args.legacy, args.out,
        n_samples=args.n_samples, k=args.k, seed=args.seed,
        T_in=args.T_in, gap=args.gap, T_out=args.T_out,
    )

    print(f"\n像素：{meta['n_pixels_total']} → 选中 {meta['n_pixels_selected']}")
    print(f"窗口：{meta['n_windows']} 个，划分 {meta['split_sizes']}")
    print(f"目标年份：{meta['target_years'][0]} … {meta['target_years'][-1]}")
    print(f"\n输出：\n  {meta['npz_path']}\n  {meta['manifest_csv']}")
    print(f"  {os.path.join(args.out, 'dataset_manifest_v2.json')}")
    print(f"\nnpz sha256 = {sha256_file(meta['npz_path'])}")
    print("把这个 hash 记进论文的 Data Availability，别靠'我记得'。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
