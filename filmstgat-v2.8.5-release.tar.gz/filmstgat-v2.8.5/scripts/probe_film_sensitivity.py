#!/usr/bin/env python3
"""⚠ 本脚本已被 probe_film_learnability.py 取代，结论不可用。

DEPRECATED — its measurements cannot support its conclusions:
  · 在初始化处测敏感度无意义：恒等初始化（gamma=1, beta=0）使偏导在 step 0 精确为 0；
  · 梯度阶段的目标与描述子无关（常数 target），因此那 50 步证明不了任何事。

保留文件只为留档。正确做法见 scripts/probe_film_learnability.py。

--- 以下为原始说明（勿据此下结论）---

FiLM 敏感度探针（CPU，几秒）：描述子动 2 个标准差，输出能动多少？

Film sensitivity probe: how far does the output move when the descriptor moves
two standard deviations, at initialisation and after a few gradient steps?

为什么需要 / Why
----------------
在真实数据上，即使把描述子换成"测试期统计量"（泄漏），模型也没有利用它
（RMSE 1.34，而"输出描述子"本该到 0.58）。这有两种解释：

  A. 数据里没有可用的信息（我们的主张）；
  B. FiLM 通路本身太弱，给什么都用不上（我们自己的实现问题）。

两者在论文里的分量完全不同。这个探针把 B 单独拎出来测：

  · 若 2 sd 的描述子变化只能挪动 < 0.05 °C ⇒ 该通路在结构上就表达不出
    1 °C 量级的修正，那么"模型不用描述子"是**必然的**，与数据无关。
  · 若能动 0.5–2 °C ⇒ 通路通畅；真实数据上不用它，才轮到"没有信息"来解释。

注意：这里量的是**归一化单位**下的输出。乘以 ts_std（约 3–9 °C）才是物理量，
但相对比较已经够了——我们只关心"能不能表达 1 °C"。

作者 / Author: Raymond Xiaohu Fan

用法 / Usage:
    python scripts/probe_film_sensitivity.py --hidden 64 --layers 2
"""

from __future__ import annotations

import argparse
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from filmstgat.models.stgat import STGAT  # noqa: E402
from filmstgat.train.seeding import set_all_seeds  # noqa: E402


def ring_edges(n: int) -> torch.Tensor:
    src = torch.arange(n)
    dst = (src + 1) % n
    return torch.stack([torch.cat([src, dst]), torch.cat([dst, src])], dim=0)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--nodes", type=int, default=64)
    ap.add_argument("--steps", type=int, default=24)
    ap.add_argument("--features", type=int, default=1)
    ap.add_argument("--geo-dim", type=int, default=3)
    ap.add_argument("--hidden", type=int, default=64)
    ap.add_argument("--layers", type=int, default=2)
    ap.add_argument("--batch", type=int, default=2)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--gsteps", type=int, default=0,
                    help="先跑多少步梯度（让调制长起来），再测敏感度")
    args = ap.parse_args()

    set_all_seeds(args.seed)
    model = STGAT(input_dim=args.features, geo_dim=args.geo_dim,
                  hidden_dim=args.hidden, num_spatial_layers=args.layers,
                  conditioning="film", film_mode="full", num_heads=4)
    model.eval()

    x = torch.randn(args.batch, args.nodes, args.steps, args.features)
    edge = ring_edges(args.nodes)
    geo0 = torch.zeros(args.batch, args.nodes, args.geo_dim)

    def out_for(scale: float) -> torch.Tensor:
        g = torch.zeros_like(geo0)
        g[..., 0] = scale           # 只动第一维（均值），其余保持 0
        with torch.no_grad():
            return model(x, edge, g)

    y0 = out_for(0.0)
    print("=" * 72)
    print("FiLM 敏感度 / sensitivity — 描述子第 1 维从 0 移到 s 个 sd")
    print(f"  nodes={args.nodes} T={args.steps} hidden={args.hidden} "
          f"layers={args.layers} film_mode=full  gsteps={args.gsteps}")
    print(f"  {'s (sd)':>8}{'max|Δy|':>12}{'mean|Δy|':>12}{'物理量换算(×3 °C)':>22}")
    print("-" * 72)
    rows = []
    for s in (0.5, 1.0, 2.0, 3.0):
        ys = out_for(s)
        d = (ys - y0).abs()
        rows.append((s, float(d.max()), float(d.mean())))
        print(f"  {s:>8.1f}{float(d.max()):>12.4f}{float(d.mean()):>12.4f}"
              f"{float(d.max()) * 3:>20.2f} °C")

    # 若给了梯度步数，看看调制能不能长起来
    if args.gsteps > 0:
        model.train()
        opt = torch.optim.Adam(model.parameters(), lr=1e-3)
        target = out_for(1.0).detach() * 0 + 1.0     # 简单目标：把输出推到 1.0
        for _ in range(args.gsteps):
            opt.zero_grad()
            y = model(x, edge, geo0)
            loss = torch.mean((y - target) ** 2)
            loss.backward()
            opt.step()
        model.eval()
        y1 = out_for(1.0)
        d = (y1 - out_for(0.0)).abs()
        print("-" * 72)
        print(f"  梯度 {args.gsteps} 步后：max|Δy| = {float(d.max()):.4f} "
              f"（target=1.0，loss={float(loss):.4f}）")

    print("=" * 72)
    mx = rows[2][1]
    if mx < 0.05:
        print("[DEPRECATED] 该判读不成立：初始化处敏感度为 0 是恒等初始化的必然结果。")
        print("            请改用 scripts/probe_film_learnability.py。")
        print("      FiLM 通路在结构上表达不出 1 °C 量级的修正 —— 模型不用描述子是**必然**的，")
        print("      与数据里有没有信息无关。这不是论文的发现，这是实现的限制，必须先修。")
    elif mx < 0.5:
        print("判读：通路偏弱（<0.5 归一化单位）。可能仍然限制了机制发挥作用，")
        print("      建议对比 init_scale 更大时的敏感度，再决定是否把它写成数据层面的结论。")
    else:
        print("判读：通路通畅（可表达 >0.5 归一化单位 ≈ 1.5 °C）。")
        print("      真实数据上不利用泄漏信息，就不能归咎于通路 —— 这是数据层面的结论。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
