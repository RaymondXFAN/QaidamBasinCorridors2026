#!/usr/bin/env python3
"""构造探针数据集变体：可组合地"破坏"信息通道。

Build probe variants by selectively destroying information channels.

三个开关 / Three switches
-------------------------
  --oracle-years Y,...   把描述子换成**目标期**逐像素统计量（泄漏；仅用于上限探针）
  --zero-input           把输入窗口全部置零（拿掉 x 通道，只剩描述子）
  --zero-geo             把描述子全部置零（拿掉条件化通道）

为什么要组合 / Why compose
--------------------------
要回答的是"模型不用描述子，是因为数据里没有信息，还是因为 x 通道把答案解释掉了"。
唯一干净的对照是：**同一个模型、同一批描述子，只把 x 拿走**。
所以需要同时置零 x 与换成 oracle 描述子——两个开关都能独立开合。

⚠ 本脚本产出的任何数据集**都不是可用预测**，只能用于诊断。
   文件名里带 _probe，写论文时必须标 oracle / diagnostic。

作者 / Author: Raymond Xiaohu Fan

用法 / Usage:
    # C3：零输入 + oracle 描述子
    python scripts/make_probe_variant.py \
        --data datasets_v2/real_magt_data_v2_clean.npz \
        --out  datasets_v2/probe_zeroX_oracle.npz \
        --zero-input --oracle-years 2015,2016,2017,2018

    # C4：零输入 + 零描述子（对照）
    python scripts/make_probe_variant.py \
        --data datasets_v2/real_magt_data_v2_clean.npz \
        --out  datasets_v2/probe_zeroX_zeroG.npz \
        --zero-input --zero-geo
"""

from __future__ import annotations

import argparse
import os

import numpy as np

START_YEAR = 1981


def _oracle_descriptors(series: np.ndarray, idx: np.ndarray, W: int) -> np.ndarray:
    """用目标期年份算逐像素 [均值, 趋势, 标准差]，并在所有窗口上重复。"""
    block = series[:, idx]
    mean = block.mean(axis=1)
    std = block.std(axis=1)
    t = np.arange(len(idx), dtype=np.float64)
    t = t - t.mean()
    denom = float(np.sum(t ** 2)) or 1.0
    trend = ((block - block.mean(axis=1, keepdims=True)) @ t) / denom
    desc = np.stack([mean, trend, std], axis=1).astype(np.float32)      # (n, 3)
    return np.repeat(desc[None, :, :], W, axis=0)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--oracle-years", default=None,
                    help="逗号分隔年份；给了就把描述子换成目标期统计量（泄漏）")
    ap.add_argument("--zero-input", action="store_true", help="输入窗口置零")
    ap.add_argument("--zero-geo", action="store_true", help="描述子置零")
    args = ap.parse_args()

    if not (args.oracle_years or args.zero_input or args.zero_geo):
        raise SystemExit("至少要开一个开关，否则和原数据完全一样"
                         "（--oracle-years / --zero-input / --zero-geo）")
    if args.oracle_years and args.zero_geo:
        raise SystemExit("--oracle-years 与 --zero-geo 互相冲突")

    d = np.load(args.data, allow_pickle=True)
    keys = {k: d[k] for k in d.files}
    series = np.asarray(keys["series"], dtype=np.float64)
    W = int(keys["descriptors"].shape[0])
    n, T = series.shape

    notes = []

    if args.oracle_years:
        years = [int(y) for y in args.oracle_years.split(",")]
        idx = np.array([y - START_YEAR for y in years], dtype=int)
        if (idx < 0).any() or (idx >= T).any():
            raise SystemExit(f"年份越界：series 覆盖 {START_YEAR}–{START_YEAR + T - 1}")
        target_idx = np.asarray(keys["target_idx"], dtype=int)
        want = sorted(int(target_idx[w]) for w in np.asarray(keys["split_test"], dtype=int))
        if sorted(idx.tolist()) != want:
            print(f"[warn] --oracle-years 推出下标 {sorted(idx.tolist())}，"
                  f"而 split_test 的目标是 {want}；确认这是你要的")
        keys["descriptors"] = _oracle_descriptors(series, idx, W)
        notes.append(f"oracle descriptors from {years}")

    if args.zero_geo:
        keys["descriptors"] = np.zeros_like(keys["descriptors"])
        notes.append("descriptors zeroed")

    if args.zero_input:
        # X_windows 与新加的通道无关；直接整体置零，保留形状。
        keys["X_windows"] = np.zeros_like(keys["X_windows"])
        notes.append("input windows zeroed")

    os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
    np.savez_compressed(args.out, **keys)

    desc = keys["descriptors"]
    print(f"→ {args.out}")
    print(f"  switches : {' + '.join(notes)}")
    print(f"  windows={W}  pixels={n}")
    print(f"  descriptors: 窗口间一致={np.allclose(desc[0], desc[-1])}  "
          f"像素间sd={float(desc[0, :, 0].std()):.3f}  "
          f"全零={bool(np.all(desc == 0))}")
    print(f"  X_windows  : 全零={bool(np.all(keys['X_windows'] == 0))}")
    print("⚠ 诊断用数据集，不可作为预测结果报告。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
