#!/usr/bin/env python3
"""技能上限检查：这个任务到底有没有"超过 persistence"的可学信号？

Skill-ceiling check: is there ANY learnable signal beyond persistence?

为什么必须做 / Why this is necessary
------------------------------------
GNN 跑出来 ≈ persistence（±2%）。这有两种解释：
  (a) 模型太弱 / 训不好
  (b) 任务本身几乎没有可预测的时序信号
两者的应对完全相反，所以先用最简单的模型（岭回归）探底：
如果连"去年值 + 10 年趋势"这种特征都赢不了 persistence，那换任何模型都没用。

A GNN sitting within ±2% of persistence has two explanations: the model is
weak, or the task has almost no signal. The responses are opposite, so probe
the ceiling with ridge regression first. If even last-value + trend features
cannot beat persistence, no architecture will.

用法 / Usage:
    python scripts/skill_check.py --data .../real_magt_data_v2_clean.npz --n-sub 500
"""

from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from filmstgat.experiments.common import load_v2, pick_pixels  # noqa: E402


def window_features(series: np.ndarray, target_idx: np.ndarray,
                    T_in: int, gap: int, T_out: int) -> np.ndarray:
    """Four features per (window, pixel): [last, mean, slope, std]. 四个特征。"""
    W = len(target_idx)
    N = series.shape[0]
    feats = np.zeros((W, N, 4), dtype=np.float64)
    for w, t_end in enumerate(target_idx):
        t_start = int(t_end) - T_out + 1
        t_in_end = t_start - gap - 1
        t_in_start = t_in_end - T_in + 1
        seg = series[:, t_in_start:t_in_end + 1].astype(np.float64)
        t = np.arange(seg.shape[1]) - (seg.shape[1] - 1) / 2
        feats[w, :, 0] = seg[:, -1]
        feats[w, :, 1] = seg.mean(axis=1)
        feats[w, :, 2] = (seg - seg.mean(axis=1, keepdims=True)) @ t / np.sum(t ** 2)
        feats[w, :, 3] = seg.std(axis=1)
    return feats


def rmse(p, y):
    return float(np.sqrt(np.mean((p - y) ** 2)))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--n-sub", type=int, default=500)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--T-in", type=int, default=10)
    ap.add_argument("--gap", type=int, default=4)
    ap.add_argument("--T-out", type=int, default=1)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    data = load_v2(args.data)
    series = data["series"]
    pix = pick_pixels(data, args.n_sub, seed=args.seed, mode="stratified")
    s = series[pix]
    ti = data["target_idx"]
    tr, va, te = data["split_train"], data["split_val"], data["split_test"]

    feats = window_features(s, ti, args.T_in, args.gap, args.T_out)
    y = data["y_windows"][pix][:, :, 0].transpose(1, 0).astype(np.float64)   # (W,N)

    # ---- Baselines / 基线 ----
    pers = feats[:, :, 0]
    climat = np.zeros_like(y)
    train_mean = s[:, :30].mean(axis=1)
    climat[:] = train_mean[None, :]

    # ---- Ridge, fitted on training windows only / 只用训练窗口 ----
    Xtr = feats[tr].reshape(-1, feats.shape[-1])
    ytr = y[tr].reshape(-1)
    mu, sd = Xtr.mean(0), Xtr.std(0) + 1e-8
    Xtr_n = (Xtr - mu) / sd

    lam = 1.0
    A = Xtr_n.T @ Xtr_n + lam * np.eye(Xtr_n.shape[1])
    coef = np.linalg.solve(A, Xtr_n.T @ (ytr - ytr.mean()))
    b0 = ytr.mean()

    def predict(idx):
        X = (feats[idx].reshape(-1, feats.shape[-1]) - mu) / sd
        return (X @ coef + b0).reshape(len(idx), -1)

    results = {}
    for name, pred in (("persistence", pers[te]),
                       ("climatology", climat[te]),
                       ("ridge(last,mean,slope,std)", predict(te))):
        results[name] = {"rmse": rmse(pred, y[te]),
                         "skill_vs_persistence": 1 - rmse(pred, y[te]) / rmse(pers[te], y[te])}

    # Also check on validation, to rule out a lucky test set / 防"测试集偶然"
    for name, pred in (("ridge_val", predict(va)),):
        results[name] = {"rmse": rmse(pred, y[va]),
                         "skill_vs_persistence": 1 - rmse(pred, y[va]) / rmse(pers[va], y[va])}

    order = ["persistence", "climatology", "ridge(last,mean,slope,std)", "ridge_val"]
    print("=" * 74)
    print(f"像素={len(pix)}  训练窗={len(tr)}  测试窗={len(te)}")
    print("=" * 74)
    print(f"{'model':30}{'RMSE(°C)':>12}{'skill vs persistence':>24}")
    print("-" * 74)
    for k in order:
        r = results[k]
        print(f"{k:30}{r['rmse']:12.4f}{r['skill_vs_persistence']*100:>22.2f}%")

    best_skill = max(results[k]["skill_vs_persistence"] for k in order if not k.startswith("ridge_val"))
    print("-" * 74)
    if best_skill < 0.02:
        print("结论：❌ 连岭回归都赢不了 persistence（<2%）")
        print("      → 这个任务在年尺度上几乎没有可学的时序信号。")
        print("      → 换模型没用，要换评估目标或换任务粒度。")
    elif best_skill < 0.10:
        print("结论：⚠️ 上限很低（2%–10%），说明信号存在但很弱")
        print("      → GNN 只差几个点，值得调；但别指望大提升。")
    else:
        print(f"结论：✅ 上限 {best_skill*100:.1f}%，GNN 明显没跑到位")
        print("      → 优先修模型/训练，而不是改论文叙事。")

    if args.out:
        os.makedirs(args.out, exist_ok=True)
        with open(os.path.join(args.out, "skill_check.json"), "w", encoding="utf-8") as fh:
            json.dump(results, fh, indent=2, ensure_ascii=False)
        print(f"\n结果 → {args.out}/skill_check.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
