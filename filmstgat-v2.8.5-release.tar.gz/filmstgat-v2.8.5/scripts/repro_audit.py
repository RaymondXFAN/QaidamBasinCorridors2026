#!/usr/bin/env python3
"""可复现性自检 / Reproducibility self-audit.

给审稿人用的：一条命令检查这份代码在他机器上**能不能跑起来**，以及有没有
留下作者本机的绝对路径、凭据、或没提交的数据文件。

Run this first. It needs only the standard library + numpy-free static analysis:

    python scripts/repro_audit.py

Exit code 0 = 全部通过；1 = 有 FAIL（必须修）；WARN 不阻断但要人工看。

检查项 / What it checks
-----------------------
A. 结构    必需文件是否齐全；run_all.sh 与文档里提到的每个脚本是否真的存在
B. 语法    每个 .py 能否编译（在别人的机器上语法错是最常见的"跑不起来"）
C. 可移植  有没有 /root/... 、C:\\Users\\... 这类作者本机路径
D. 安全    有没有硬编码的密码 / token / 带凭据的 URL
E. 数据    有没有把大数据文件塞进仓库（应当用下载脚本或环境变量）
F. 完整性  VERSION.json 里的 tree_hash 是否与当前文件一致（防"交的代码不是跑的那份"）

作者 / Author: Raymond Xiaohu Fan
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import py_compile
import re
import sys
import tempfile

REQUIRED_TOP = ["README.md", "LICENSE", "CITATION.cff", "requirements.txt",
                "pyproject.toml", "VERSION.json", "run_all.sh"]
SKIP_DIRS = {"__pycache__", ".pytest_cache", ".git", ".ipynb_checkpoints"}
SKIP_EXT = {".pyc", ".pyo", ".pdf", ".png", ".jpg", ".npz", ".pt", ".ckpt"}

SECRET_PAT = re.compile(
    r"(password\s*=\s*['\"][^'\"\s]{3,}|passwd\s*=\s*['\"]|api[_-]?key\s*=\s*['\"][^'\"]{8,}"
    r"|secret\s*=\s*['\"][^'\"]{8,}|ftp://[^/\s]+:[^/\s]+@|ssh-rsa\s+AAAA)", re.I)
LOCAL_PATH = re.compile(r"(/root/[^\s'\"]+|/home/[A-Za-z0-9_.-]+/|[A-Za-z]:\\\\Users\\\\[^\s'\"]+)")

results: list = []


def add(level: str, section: str, msg: str, detail: str = "") -> None:
    results.append({"level": level, "section": section, "msg": msg, "detail": detail})


def walk(root: str):
    for dp, dns, fns in os.walk(root):
        dns[:] = sorted(d for d in dns if d not in SKIP_DIRS)
        for fn in sorted(fns):
            yield os.path.join(dp, fn)


def rel(root: str, p: str) -> str:
    return os.path.relpath(p, root)


# ---------------------------------------------------------------- A. structure
def check_structure(root: str) -> None:
    for name in REQUIRED_TOP:
        p = os.path.join(root, name)
        (add("PASS", "A", f"{name} 存在") if os.path.exists(p)
         else add("FAIL", "A", f"{name} 缺失", "审稿人拿到的是不完整的仓库"))

    # run_all.sh 里调用的脚本是否存在
    ru = os.path.join(root, "run_all.sh")
    if os.path.exists(ru):
        text = open(ru, encoding="utf-8").read()
        refs = set(re.findall(r"(filmstgat/[\w/]+\.py|scripts/[\w/]+\.py|figures/[\w/]+\.py)",
                              text))
        missing = [r for r in sorted(refs) if not os.path.exists(os.path.join(root, r))]
        if missing:
            add("FAIL", "A", f"run_all.sh 引用了 {len(missing)} 个不存在的脚本",
                ", ".join(missing))
        else:
            add("PASS", "A", f"run_all.sh 引用的 {len(refs)} 个脚本全部存在")

    # 文档里提到的脚本是否存在
    doc_refs: set = set()
    for p in walk(root):
        if p.endswith(".md"):
            text = open(p, encoding="utf-8", errors="ignore").read()
            doc_refs |= set(re.findall(r"(scripts/[\w/]+\.(?:py|sh)|filmstgat/[\w/]+\.py)", text))
    missing = [r for r in sorted(doc_refs)
               if not os.path.exists(os.path.join(root, r))]
    if missing:
        add("WARN", "A", f"文档提到 {len(missing)} 个不存在的脚本",
            ", ".join(missing))
    else:
        add("PASS", "A", f"文档提到的 {len(doc_refs)} 个脚本全部存在")

    # 是否有 DEPLOY / 数据来源说明
    for want in ("docs/DEPLOY.md", "docs/DATA.md"):
        (add("PASS", "A", f"{want} 存在") if os.path.exists(os.path.join(root, want))
         else add("WARN", "A", f"{want} 缺失",
                  "审稿人需要知道怎么装、数据从哪来"))


# ---------------------------------------------------------------- B. syntax
def check_syntax(root: str) -> None:
    bad, n = [], 0
    for p in walk(root):
        if not p.endswith(".py"):
            continue
        n += 1
        try:
            with tempfile.TemporaryDirectory() as td:
                py_compile.compile(p, cfile=os.path.join(td, "x.pyc"),
                                   doraise=True, quiet=2)
        except Exception as exc:
            bad.append(f"{rel(root, p)}: {type(exc).__name__}")
    if bad:
        add("FAIL", "B", f"{len(bad)}/{n} 个 .py 无法编译", "; ".join(bad[:6]))
    else:
        add("PASS", "B", f"{n} 个 .py 全部可编译")


# ---------------------------------------------------------------- C. portability
def check_paths(root: str) -> None:
    """只把**代码**里的本机路径算作问题。

    文档里出现 /root/... 往往是 runbook 的示例命令，把它报成 WARN 会让审稿人
    以为仓库不可移植，其实代码本身是干净的。示例路径单独计数、不阻断。
    Only code files count. Example paths inside docs are runbook commands, not
    portability defects; flagging them trains reviewers to ignore the audit.
    """
    hits: list = []
    doc_hits = 0
    for p in walk(root):
        is_doc = p.endswith(".md")
        if not p.endswith((".py", ".sh", ".toml", ".cff", ".md")):
            continue
        for i, line in enumerate(open(p, encoding="utf-8", errors="ignore"), 1):
            for m in LOCAL_PATH.finditer(line):
                frag = m.group(0)
                # 允许：默认值/示例里出现，且该行明确写了 default 或 ROOT
                low = line.lower()
                stripped = line.strip()
                # 允许：默认值、环境变量回退、注释、docstring 里的用法示例
                if ("default" in low or "root=" in low or ":-" in line or "-e " in low
                        or "示例" in line or "e.g." in low
                        or stripped.startswith("#")
                        or "python scripts/" in low or "python filmstgat/" in low):
                    continue
                # 本文件自己就在描述这条规则，跳过自查
                if os.path.basename(p) == "repro_audit.py":
                    continue
                if is_doc:
                    doc_hits += 1
                    continue
                hits.append(f"{rel(root, p)}:{i}  {frag}")
    if hits:
        add("WARN", "C", f"代码里 {len(hits)} 处本机绝对路径",
            " | ".join(hits[:5]))
    else:
        add("PASS", "C", f"代码里没有写死的本机路径"
                         + (f"（docs 中另有 {doc_hits} 处示例路径，不计）" if doc_hits else ""))


# ---------------------------------------------------------------- D. secrets
def check_secrets(root: str) -> None:
    hits = []
    for p in walk(root):
        if not p.endswith((".py", ".sh", ".md", ".toml", ".yaml", ".yml", ".json")):
            continue
        for i, line in enumerate(open(p, encoding="utf-8", errors="ignore"), 1):
            if SECRET_PAT.search(line) and "README" not in p:
                hits.append(f"{rel(root, p)}:{i}")
    if hits:
        add("FAIL", "D", f"疑似凭据 {len(hits)} 处", " | ".join(hits[:5]))
    else:
        add("PASS", "D", "没有发现硬编码凭据")


# ---------------------------------------------------------------- E. data
def check_data(root: str) -> None:
    """区分两类文件：观测数据（不该发）与结果文件（**应该**发）。

    早期版本把 results/predictions.npz 也算成"夹带数据"，会误导审稿人以为
    我们违反了数据许可。结果文件是 L2 复现的载体，必须存在。
    Distinguish raw observations (must NOT ship) from result files (must ship):
    a blanket size check on .npz conflates the two.
    """
    big, total = [], 0
    res_files, res_bytes = 0, 0
    for p in walk(root):
        r = rel(root, p)
        if r.startswith(os.path.join("results", "")):
            res_files += 1
            res_bytes += os.path.getsize(p)
            continue
        if p.endswith((".npz", ".npy", ".h5", ".pt", ".ckpt", ".tif")):
            sz = os.path.getsize(p)
            total += sz
            if sz > 5 * 1024 * 1024:
                big.append(f"{rel(root, p)} ({sz / 1e6:.1f} MB)")
    if big:
        add("FAIL", "E", f"仓库里有 {len(big)} 个大文件（>5 MB）",
            "; ".join(big[:4]) + " —— 应改用下载脚本")
    elif total:
        add("WARN", "E", f"仓库内有 {total / 1e6:.1f} MB 数据文件",
            "确认体积可接受、且许可允许随代码发布")
    else:
        add("PASS", "E", "仓库内没有观测数据文件（符合预期）")

    if res_files:
        add("PASS", "E", f"results/ 含 {res_files} 个结果文件，{res_bytes / 1e6:.1f} MB"
                         f"（L2 复现所需，应当随代码发布）")
        mf = os.path.join(root, "results", "MANIFEST.json")
        if os.path.exists(mf):
            try:
                man = json.load(open(mf, encoding="utf-8"))
                n = len(man.get("files", {}))
                add("PASS", "E", f"results/MANIFEST.json 记录 {n} 条 sha256")
            except Exception as exc:
                add("WARN", "E", "results/MANIFEST.json 无法解析", str(exc))
        else:
            add("WARN", "E", "results/ 存在但缺 MANIFEST.json",
                "审稿人无法逐文件校验；用 scripts/collect_results.py 重新生成")


# ---------------------------------------------------------------- F. integrity
def check_integrity(root: str) -> None:
    vp = os.path.join(root, "VERSION.json")
    if not os.path.exists(vp):
        add("FAIL", "F", "VERSION.json 缺失")
        return
    meta = json.load(open(vp, encoding="utf-8"))
    stored = meta.get("tree_hash")
    if not stored:
        add("WARN", "F", "VERSION.json 没有 tree_hash")
        return
    h = hashlib.sha256()
    n = 0
    for p in walk(root):
        r = rel(root, p)
        if r == "VERSION.json" or os.path.splitext(p)[1] in SKIP_EXT:
            continue
        h.update(r.encode())
        h.update(open(p, "rb").read())
        n += 1
    actual = h.hexdigest()
    if actual == stored:
        add("PASS", "F", f"tree_hash 与 {n} 个文件一致（{stored[:12]}…）")
    else:
        add("WARN", "F", "tree_hash 不匹配",
            f"记录 {stored[:12]}… 实际 {actual[:12]}… —— 打包前请重新生成")


# ---------------------------------------------------------------- 汇总
def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=os.path.dirname(os.path.dirname(
        os.path.abspath(__file__))))
    ap.add_argument("--quiet", action="store_true", help="只打印 FAIL/WARN")
    ap.add_argument("--write-version", action="store_true",
                    help="重新计算 tree_hash 并写回 VERSION.json（打包前用）")
    args = ap.parse_args()
    root = os.path.abspath(args.root)

    print("=" * 78)
    print(f"可复现性自检 / reproducibility audit   {root}")
    print("=" * 78)

    if args.write_version:
        vp = os.path.join(root, "VERSION.json")
        meta = json.load(open(vp, encoding="utf-8")) if os.path.exists(vp) else {}
        h, n = hashlib.sha256(), 0
        for p in walk(root):
            r = rel(root, p)
            if r == "VERSION.json" or os.path.splitext(p)[1] in SKIP_EXT:
                continue
            h.update(r.encode())
            h.update(open(p, "rb").read())
            n += 1
        meta["tree_hash"] = h.hexdigest()
        meta["n_files"] = n
        json.dump(meta, open(vp, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
        print(f"[write-version] tree_hash={h.hexdigest()[:16]}… over {n} files\n")

    for fn in (check_structure, check_syntax, check_paths,
               check_secrets, check_data, check_integrity):
        fn(root)

    for level in ("FAIL", "WARN", "PASS"):
        group = [r for r in results if r["level"] == level]
        if not group or (args.quiet and level == "PASS"):
            continue
        print(f"\n[{level}] {len(group)} 项")
        for r in group:
            print(f"  · [{r['section']}] {r['msg']}")
            if r["detail"] and level != "PASS":
                print(f"      {r['detail']}")

    n_fail = sum(1 for r in results if r["level"] == "FAIL")
    n_warn = sum(1 for r in results if r["level"] == "WARN")
    print("\n" + "=" * 78)
    print(f"FAIL={n_fail}  WARN={n_warn}  PASS={sum(1 for r in results if r['level'] == 'PASS')}")
    if n_fail:
        print("→ 有 FAIL，先修好再上传。")
        return 1
    print("→ 结构、语法、可移植性、凭据、数据、完整性：无阻断项。")
    if n_warn:
        print("   WARN 项请人工确认（多为文档缺失或默认路径）。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
