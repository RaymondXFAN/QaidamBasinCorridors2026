#!/usr/bin/env python3
"""AST 指纹比对：区分「文案翻译」与「逻辑改动」。

AST fingerprint comparison: tell "translated strings" apart from "changed logic".

为什么需要两层比对 / Why two levels
------------------------------------
初版比对把字符串常量也算进结构里，于是把 `'冷冻土'` 翻成 `'Cold permafrost'`
也报"逻辑差异"——这不合理，翻译不是改逻辑。
The first version counted string literals as structure, so translating
'冷冻土' to 'Cold permafrost' was reported as a logic change. That's wrong.

现在分三层 / Now three layers
------------------------------
1. **结构**：把所有字符串常量替换为占位符后的 AST —— 比控制流、调用、算子
2. **数值**：按出现顺序提取所有数值常量（int/float/complex）—— 比超参、阈值
3. **文案**：列出被改动的字符串 —— 只做提示，不影响判定

判定规则 / Verdict
------------------
- 结构一致 且 数值一致 → ✅ 逻辑等价（文案差异仅提示）
- 否则                 → ❌ 存在逻辑差异，打印定位

用法 / Usage
------------
    python scripts/compare_ast.py A.py B.py
    python scripts/compare_ast.py -d LEGACY_DIR REPO_DIR
    python scripts/compare_ast.py --strict A.py B.py   # 连字符串也必须一致
"""

from __future__ import annotations

import argparse
import ast
import difflib
import os
import sys

PLACEHOLDER = "<STR>"


class _Normalize(ast.NodeTransformer):
    """剥 docstring + 把所有字符串常量替换成占位符。"""

    def __init__(self, mask_strings: bool = True):
        self.mask_strings = mask_strings

    def visit_Module(self, node):
        self.generic_visit(node)
        self._strip_doc(node)
        return node

    def visit_FunctionDef(self, node):
        self.generic_visit(node)
        self._strip_doc(node)
        return node

    def visit_AsyncFunctionDef(self, node):
        self.generic_visit(node)
        self._strip_doc(node)
        return node

    def visit_ClassDef(self, node):
        self.generic_visit(node)
        self._strip_doc(node)
        return node

    @staticmethod
    def _strip_doc(node):
        body = getattr(node, "body", None)
        if not body:
            return
        first = body[0]
        if (isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant)
                and isinstance(first.value.value, str)):
            body.pop(0)

    def visit_Constant(self, node):
        if self.mask_strings and isinstance(node.value, str):
            return ast.copy_location(ast.Constant(value=PLACEHOLDER), node)
        return node


def _parse(path: str) -> ast.AST:
    with open(path, encoding="utf-8", errors="ignore") as fh:
        return ast.parse(fh.read())


def structure_fingerprint(path: str, strict: bool = False) -> str:
    tree = _Normalize(mask_strings=not strict).visit(_parse(path))
    return ast.dump(tree, annotate_fields=True, include_attributes=False)


def numeric_constants(path: str) -> list:
    out = []
    for node in ast.walk(_parse(path)):
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float, complex)) \
                and not isinstance(node.value, bool):
            out.append(node.value)
    return out


def string_constants(path: str) -> list:
    return [n.value for n in ast.walk(_parse(path))
            if isinstance(n, ast.Constant) and isinstance(n.value, str)]


def compare(a: str, b: str, strict: bool = False, show_diff: bool = True) -> bool:
    fa, fb = structure_fingerprint(a, strict), structure_fingerprint(b, strict)
    na, nb = numeric_constants(a), numeric_constants(b)
    sa, sb = string_constants(a), string_constants(b)

    struct_ok = fa == fb
    nums_ok = na == nb
    strings_changed = [x for x in sa if x not in set(sb)]
    strings_added = [y for y in sb if y not in set(sa)]

    print(f"\n{'='*74}")
    print(f"A: {a}")
    print(f"B: {b}")
    print(f"  结构（字符串已归一）: {'✅ 一致' if struct_ok else '❌ 不同'}")
    print(f"  数值常量序列      : {'✅ 一致' if nums_ok else '❌ 不同'}")
    if strings_changed or strings_added:
        print(f"  文案差异          : {len(strings_changed)} 处旧文案 / {len(strings_added)} 处新文案")
        for s in strings_changed[:5]:
            print(f"      - {s!r}")
        for s in strings_added[:5]:
            print(f"      + {s!r}")

    logical_ok = struct_ok and nums_ok and (strict is False or not (strings_changed or strings_added))
    if logical_ok:
        print("  判定: ✅ 逻辑等价" + ("" if strict else "（仅文案不同，不影响数值）"))
    else:
        print("  判定: ❌ 存在逻辑差异")
        if not nums_ok and show_diff:
            print(f"     数值序列长度 A={len(na)} B={len(nb)}")
            for i, (x, y) in enumerate(zip(na, nb)):
                if x != y:
                    print(f"     首个数值差异 #{i}: {x!r} -> {y!r}")
                    break
        if not struct_ok and show_diff:
            la = fa.replace("),", "),\n").splitlines()
            lb = fb.replace("),", "),\n").splitlines()
            diff = list(difflib.unified_diff(la, lb, "A", "B", lineterm="", n=1))
            for line in diff[:40]:
                print("     " + line)
            if len(diff) > 40:
                print(f"     ... 还有 {len(diff)-40} 行")
    return logical_ok


def pair_by_name(legacy_dir: str, repo_dir: str, strict: bool = False) -> int:
    mapping = {
        "preprocess_real_magt.py": "data/preprocess_real_magt.py",
        "run_real_magt_experiment.py": "experiments/run_real_magt_experiment.py",
    }
    bad = 0
    checked = 0
    for name, rel in mapping.items():
        cand = [f for f in os.listdir(legacy_dir) if f.endswith(name)]
        if not cand:
            print(f"[skip] legacy 中找不到 {name}")
            continue
        a = os.path.join(legacy_dir, cand[0])
        b = os.path.join(repo_dir, rel)
        if not os.path.exists(b):
            print(f"[skip] repo 中找不到 {rel}")
            continue
        checked += 1
        bad += 0 if compare(a, b, strict=strict) else 1
    print(f"\n结论：{checked} 个文件比对完成，{'全部逻辑等价 ✅' if bad == 0 else f'{bad} 个存在逻辑差异 ❌'}")
    return bad


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("a", nargs="?", help="文件 A")
    ap.add_argument("b", nargs="?", help="文件 B")
    ap.add_argument("-d", "--dirs", nargs=2, metavar=("LEGACY", "REPO"))
    ap.add_argument("--strict", action="store_true", help="字符串也必须一致")
    args = ap.parse_args()

    if args.dirs:
        return 0 if pair_by_name(*args.dirs, strict=args.strict) == 0 else 1
    if not (args.a and args.b):
        ap.print_help()
        return 2
    return 0 if compare(args.a, args.b, strict=args.strict) else 1


if __name__ == "__main__":
    sys.exit(main())
