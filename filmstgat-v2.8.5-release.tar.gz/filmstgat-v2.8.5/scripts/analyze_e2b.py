#!/usr/bin/env python3
"""E2b 结果分析：逐种子双重差分（DiD），检验"overlap 是否调制 FiLM 形式效应"。

E2b analysis: per-seed difference-in-differences.

为什么要 DiD / Why DiD
----------------------
E2b 只跑两个端点。如果分别看：
    α=1: Δ = +0.0152 (°C)，种子级 p=0.002   → full 更差
    α=0: Δ = −0.0021 (°C)，种子级 p=0.560   → 没差别
这两句话**并不等价于**"overlap 调制了 FiLM 形式"。要证明调制，必须看
**同一批种子**上两个端点的 Δ 之差：

    DiD_i = Δ_i(α=1) − Δ_i(α=0)

同一 seed 的初始化与 shuffle 完全相同，因此是配对样本，检验力远高于
把两组当独立样本。这才是 C6 的生杀判决。
Two endpoints alone do not prove modulation. The decisive quantity is the
paired difference of differences on the SAME seeds.

注意 α=0 处块自助区间不含 0，但种子级 p=0.56 —— 两者测的不是同一个东西：
块自助只反映"这批像素上的确定差异"，种子级反映"换一批初始化还成不成立"。
凡两者冲突，一律以种子级为准，并在报告里显式标注。
Where the two disagree, the seed-level test wins, and the disagreement is
reported rather than hidden.

作者 / Author: Raymond Xiaohu Fan

用法 / Usage:
    python scripts/analyze_e2b.py --runs <ROOT>/runs/e2b
"""

from __future__ import annotations

import argparse
import json
import os

import numpy as np
from scipy import stats


def holm(pvals: list) -> list:
    """Holm–Bonferroni 校正；输入顺序即输出顺序。"""
    m = len(pvals)
    order = np.argsort(pvals)
    adj = np.empty(m, dtype=float)
    running = 0.0
    for rank, idx in enumerate(order):
        val = (m - rank) * pvals[idx]
        running = max(running, val)
        adj[idx] = min(1.0, running)
    return adj.tolist()


def paired_ci(d: np.ndarray, alpha: float = 0.05) -> tuple:
    """配对差的 t 分布置信区间。"""
    n = len(d)
    se = d.std(ddof=1) / np.sqrt(n)
    crit = stats.t.ppf(1 - alpha / 2, n - 1)
    return float(d.mean() - crit * se), float(d.mean() + crit * se)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", required=True, help="runs/e2b 目录（含 e2_summary.json）")
    ap.add_argument("--ref", type=float, default=None,
                    help="DiD 的参照档（默认取 ρ 最小的那档）")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    src = os.path.join(args.runs, "e2_summary.json")
    if not os.path.exists(src):
        raise SystemExit(f"找不到 {src}，先跑完 E2b。")
    rows = json.load(open(src, encoding="utf-8"))
    rows.sort(key=lambda r: r["rho"])
    out = args.out or os.path.join(args.runs, "analysis")
    os.makedirs(out, exist_ok=True)

    levels = []
    for r in rows:
        ps = r["per_seed"]
        a = np.asarray(ps["add_only"], dtype=float)
        f = np.asarray(ps["full"], dtype=float)
        if a.size != f.size:
            raise SystemExit(f"α={r['alpha']} 两侧种子数不一致，无法配对。")
        d = f - a                                  # >0 表示 full 更差
        t, p = stats.ttest_1samp(d, 0.0)
        lo, hi = paired_ci(d)
        levels.append({
            "alpha": r["alpha"], "rho": r["rho"],
            "rho_star": r.get("rho_chance_corrected", 2 * r["rho"] - 1),
            "n_seeds": int(a.size),
            "rmse_add": float(a.mean()), "rmse_full": float(f.mean()),
            "delta": float(d.mean()), "delta_sd": float(d.std(ddof=1)),
            "ci95": [lo, hi], "t": float(t), "p": float(p),
            "ci95_reported": r.get("delta_ci95"),
            "delta_per_seed": d.tolist(),
        })

    # ---------- Per-level table / 逐档表 ----------
    lines = ["# E2b 分析：逐种子配对检验 + 双重差分", ""]
    lines.append("| α | ρ | ρ* | n | RMSE add | RMSE full | Δ (full−add) | 95% CI (配对 t) | t | p |")
    lines.append("|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|")
    for L in levels:
        lines.append(
            f"| {L['alpha']:.2f} | {L['rho']:.3f} | {L['rho_star']:+.3f} | {L['n_seeds']} | "
            f"{L['rmse_add']:.4f} | {L['rmse_full']:.4f} | {L['delta']:+.4f} | "
            f"[{L['ci95'][0]:+.4f}, {L['ci95'][1]:+.4f}] | {L['t']:+.2f} | {L['p']:.4f} |")

    # ---------- Cross-tool conflict check / 工具间冲突检查 ----------
    conflicts = []
    for L in levels:
        rep = L["ci95_reported"]
        if not rep:
            continue
        boot_sig = not (rep[0] <= 0.0 <= rep[1])
        seed_sig = L["p"] < 0.05
        if boot_sig != seed_sig:
            conflicts.append(
                f"α={L['alpha']:.2f}：块自助区间 [{rep[0]:+.4f}, {rep[1]:+.4f}] "
                f"{'不含' if boot_sig else '含'} 0，但种子级 p={L['p']:.3f}。"
                f"→ 以种子级为准，**不得**引用自助区间的显著性。")
    if conflicts:
        lines += ["", "## ⚠ 两种不确定性来源冲突", ""]
        lines += [f"- {c}" for c in conflicts]

    # ---------- DiD ----------
    ref = levels[0] if args.ref is None else next(
        L for L in levels if abs(L["alpha"] - args.ref) < 1e-9)
    did_rows, p_raw = [], []
    for L in levels:
        if L is ref:
            continue
        n = min(len(L["delta_per_seed"]), len(ref["delta_per_seed"]))
        dd = (np.asarray(L["delta_per_seed"][:n]) - np.asarray(ref["delta_per_seed"][:n]))
        t, p = stats.ttest_1samp(dd, 0.0)
        lo, hi = paired_ci(dd)
        did_rows.append({"alpha": L["alpha"], "rho": L["rho"], "rho_star": L["rho_star"],
                         "did": float(dd.mean()), "sd": float(dd.std(ddof=1)),
                         "ci95": [lo, hi], "t": float(t), "p": float(p), "n": n})
        p_raw.append(p)
    if p_raw:
        for r, pa in zip(did_rows, holm(p_raw)):
            r["p_holm"] = float(pa)

    lines += ["", f"## 双重差分（参照 α={ref['alpha']:.2f}，ρ*={ref['rho_star']:+.3f}）", ""]
    if did_rows:
        lines.append("| α | ρ* | DiD = Δ(α) − Δ(ref) | 95% CI | t | p | p (Holm) |")
        lines.append("|--:|--:|--:|--:|--:|--:|--:|")
        for r in did_rows:
            lines.append(f"| {r['alpha']:.2f} | {r['rho_star']:+.3f} | {r['did']:+.4f} | "
                         f"[{r['ci95'][0]:+.4f}, {r['ci95'][1]:+.4f}] | {r['t']:+.2f} | "
                         f"{r['p']:.4f} | {r['p_holm']:.4f} |")

    # ---------- Verdict / 判定 ----------
    verdict = []
    if len(levels) < 3:
        verdict.append(
            f"本次只有 {len(levels)} 档（两个端点），**不做**趋势/相关推断——"
            f"两点之间的 Spearman 无定义，别让脚本输出一个 +0.00 的假数字带偏结论。")
    any_lvl = [L for L in levels if L["p"] < 0.05]
    if any_lvl:
        verdict.append(
            "种子级显著的档位：" + "，".join(
                f"α={L['alpha']:.2f}（Δ={L['delta']:+.4f} °C, p={L['p']:.4f}）" for L in any_lvl))
    if did_rows:
        sig_did = [r for r in did_rows if r["p_holm"] < 0.05]
        if sig_did:
            verdict.append(
                "DiD 显著（Holm 校正后）：" + "，".join(
                    f"α={r['alpha']:.2f} 相对参照多差 {r['did']:+.4f} °C（p_Holm={r['p_holm']:.4f}）"
                    for r in sig_did))
            verdict.append("→ 可以陈述：**overlap 越高，乘性调制相对加性调制的代价越大**；"
                           "但仍不给阈值、不写设计规则。")
        else:
            verdict.append("DiD 不显著：两端点的差异不能被认定为 overlap 调制，"
                           "只能分别陈述各档事实。")

    lines += ["", "## 判定", ""] + [f"- {v}" for v in verdict]

    with open(os.path.join(out, "analysis.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    with open(os.path.join(out, "analysis.json"), "w", encoding="utf-8") as fh:
        json.dump({"levels": levels, "did": did_rows, "conflicts": conflicts,
                   "verdict": verdict}, fh, indent=2, ensure_ascii=False)

    print("\n".join(lines))
    print(f"\n结果 → {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
