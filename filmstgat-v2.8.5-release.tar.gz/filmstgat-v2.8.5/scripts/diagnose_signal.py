#!/usr/bin/env python3
"""诊断：这份数据里到底还有多少可学的信号？

Diagnose how much learnable signal is left in this dataset.

背景 / Why
----------
E1 + E5 重跑后出现一个刺眼的结果：所有模型（含三家外部基线）都落在
RMSE ≈ 1.34–2.9，而 persistence（拿最后一年当预测）是 1.360。最好的模型
只赢 1.2%，FiLM 与 standard 的差是 0.001 °C。

这时候继续调模型是没有意义的——必须先回答一个更基础的问题：
**目标的可解释方差里，有多少来自"像素是谁"，有多少来自"时间怎么变"？**

如果"像素身份"就解释了 95% 的方差，那么任何模型只要记住像素平均温度
就能拿到 1.3x，时空建模的空间被压到 5%——论文里所有 RMSE 差异都会缩成
小数第三位，怎么调都调不出来。

本脚本计算 / What it computes
------------------------------
1. **地板（floor）**：persistence / 像素训练期均值（climatology）/ 均值+趋势
2. **方差分解**：between-pixel（跨像素的均值差）vs within-pixel（同像素跨年变化）
3. **可实现上限**：任何只依赖"像素身份+训练期信息"的模型，其 RMSE 下限
4. **逐窗口对比**：我们的模型在 4 个测试窗口里各赢几个

判读 / How to read it
---------------------
· 若 within/total < 10%：本任务近乎"记像素"，条件化机制（FiLM）在原理上
  也没有施展空间——这不是模型问题，是任务定义问题。
· 若 within/total > 30%：信号存在，模型没学到，才值得继续调。

作者 / Author: Raymond Xiaohu Fan

用法 / Usage:
    python scripts/diagnose_signal.py \
        --data <ROOT>/datasets_v2/real_magt_data_v2_clean.npz --n-sub 500
"""

from __future__ import annotations

import argparse
import glob
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from filmstgat.eval.metrics import rmse, summarize  # noqa: E402
from filmstgat.experiments.common import load_v2, pick_pixels  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--n-sub", type=int, default=500)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--selection", choices=["stratified", "random"], default="stratified")
    ap.add_argument("--T-in", type=int, default=10)
    ap.add_argument("--gap", type=int, default=4)
    ap.add_argument("--runs", default=None, help="E1 输出目录，用于对比模型成绩")
    args = ap.parse_args()

    d = load_v2(args.data)
    pix = pick_pixels(d, args.n_sub, seed=args.seed, mode=args.selection)
    series = d["series"][pix].astype(np.float64)          # (n, T)
    target_idx = d["target_idx"]
    test_w = d["split_test"]
    train_w = d["split_train"]
    years = 1981 + target_idx

    y = d["y_windows"][pix][:, :, 0].T.astype(np.float64)  # (W, n)
    tr_mean = series[:, :30].mean(axis=1)                  # 训练期（1981–2010）均值
    n_train_years = 30

    rows = []

    def add(name, pred, truth):
        m = summarize(pred, truth)
        rows.append({"floor": name, **m})

    # ---- 1) 三个"零建模"地板 ----
    # ⚠️ persistence 必须取**输入窗的最后一个观测**，也就是 target-gap-1，
    #    而不是 target-1：后者落在 gap 里面，等于偷看了一个模型看不到的年份，
    #    会把地板压低 0.1–0.3 °C，于是所有模型都显得"不如基线"。
    #    这里与 E3 的 persistence 完全一致，否则两张表不可比（R3-3）。
    # Persistence must be the LAST INPUT observation (target-gap-1). Using
    # target-1 peeks inside the gap and silently lowers the floor.
    pers = np.stack([series[:, int(target_idx[w]) - args.gap - 1] for w in test_w], axis=0)
    add("persistence (t-1 observation)", pers, y[test_w])

    # 像素训练期均值：完全忽略时间变化
    clim = np.tile(tr_mean, (len(test_w), 1))
    add("pixel train-period mean", clim, y[test_w])

    # 均值 + 线性趋势（用训练期拟合）
    t = np.arange(n_train_years, dtype=np.float64) - (n_train_years - 1) / 2
    denom = float(np.sum(t ** 2))
    slope = (series[:, :n_train_years] - tr_mean[:, None]) @ t / denom
    hind = np.stack([(years[w] - 1981) - (n_train_years - 1) / 2 for w in test_w])
    trend = tr_mean[None, :] + slope[None, :] * hind[:, None]
    add("pixel mean + linear trend", trend, y[test_w])

    # ---- 2) 方差分解：between / within pixel ----
    # 只在测试目标上分解，避免训练期趋势污染
    yt = y[test_w]                                          # (w, n)
    between = float(np.var(yt.mean(axis=0), ddof=0))        # 跨像素的均值差异
    within = float(np.mean(np.var(yt, axis=0, ddof=0)))     # 同像素跨窗口变化
    total = between + within
    within_share = within / total if total > 0 else float("nan")

    # ---- 3) 只依赖"像素身份"的信息上限 ----
    # 用测试目标的逐像素均值去预测（这是 oracle，只能用来量级参照）
    oracle_level = np.tile(yt.mean(axis=0), (len(test_w), 1))
    add("ORACLE pixel level (uses test yrs)", oracle_level, yt)

    print("=" * 78)
    print("信号诊断 / signal diagnosis")
    print(f"  data={args.data}")
    print(f"  pixels={len(pix)}  windows: train={len(train_w)} val="
          f"{len(d['split_val'])} test={len(test_w)}")
    print(f"  target years (test) = {[int(years[w]) for w in test_w]}")
    print("=" * 78)
    print(f"{'floor':34}{'RMSE':>10}{'MAE':>10}{'R²':>10}")
    print("-" * 78)
    for r in rows:
        print(f"{r['floor']:34}{r['rmse']:>10.4f}{r['mae']:>10.4f}{r['r2']:>10.4f}")
    print("-" * 78)
    print(f"  方差分解: between-pixel={between:.3f}  within-pixel={within:.3f}")
    print(f"  可学份额 (within/total) = {within_share:.1%}")
    print(f"  只靠像素身份即可达到的 RMSE ≈ sqrt(within) = {np.sqrt(within):.4f}")
    # ---- 5) 误差分解：RMSE² = bias² + var，检验"共同偏移"假说 ----
    # 如果误差的主体是**逐年共同偏移**（所有像素同向偏冷/偏暖），那这份基准
    # 的难度就来自一次区域性的状态迁移，而不是"时空建模难度"。两者的结论
    # 完全不同：前者说明任务定义有问题，后者说明模型不行。
    # If the error is dominated by a year-wide common offset, the benchmark's
    # difficulty comes from a regime shift, not from spatiotemporal modelling.
    print("\n误差分解 / error decomposition (RMSE² = bias² + var):")
    print(f"{'predictor':12}{'year':>7}{'bias':>9}{'rmse':>9}{'bias² share':>13}"
          f"{'rmse after oracle bias removal':>32}")
    print("-" * 78)
    for label, pr in (("persistence", pers), ("climatology", clim)):
        for i, w in enumerate(test_w):
            err = pr[i] - y[w]
            b = float(err.mean())
            r = float(np.sqrt(np.mean(err ** 2)))
            share = (b ** 2) / max(r ** 2, 1e-12)
            resid = float(np.sqrt(np.mean((err - b) ** 2)))
            print(f"{label:12}{int(years[w]):>7}{b:>+9.3f}{r:>9.3f}"
                  f"{share:>12.1%}{resid:>32.3f}")
        e_all = pr - y[test_w]
        b_all = float(e_all.mean())
        r_all = float(np.sqrt(np.mean(e_all ** 2)))
        print(f"{'  → pooled':12}{'':>7}{b_all:>+9.3f}{r_all:>9.3f}"
              f"{(b_all**2)/max(r_all**2,1e-12):>12.1%}"
              f"{float(np.sqrt(np.mean((e_all-b_all)**2))):>32.3f}")
        print("-" * 78)

    print("=" * 78)

    if within_share < 0.10:
        print("判读：within 占比 < 10%，本任务近乎\"记像素平均温度\"。")
        print("      任何时空模型的改进空间被压在个位数百分比内——RMSE 差异")
        print("      会落在小数第三位，且随时序漂移而翻转。这不是调参能解决的。")
    elif within_share < 0.30:
        print("判读：within 占 10–30%，信号存在但很薄；模型差异容易淹没在 seed 噪声里。")
    else:
        print("判读：within > 30%，信号确实存在；模型没学到才是问题，值得继续。")

    # ---- 3b) 滞后剖面：这条序列到底能预测多远？ ----
    # 用 series[target-k] 预测 y[target]，k=1..10。
    # ⚠️ k < gap+1 的那些滞后在真实预测时**拿不到**（落在预测空档里），
    #    这里只作为"序列可预测性"的诊断，绝不能当基线写进论文。
    # Diagnostics only: lags shorter than the forecast gap are unavailable at
    # prediction time. This measures how fast predictability decays with lag.
    print("\n滞后剖面 / lag profile (diagnostic only, k<gap+1 is not available):")
    print(f"{'lag k':>7}{'RMSE':>10}{'MAE':>10}{'note':>28}")
    print("-" * 78)
    lag_rows = []
    for k in range(1, min(11, series.shape[1])):
        try:
            pred_k = np.stack([series[:, int(target_idx[w]) - k] for w in test_w], axis=0)
        except Exception:
            break
        m = summarize(pred_k, y[test_w])
        note = "unavailable at forecast time" if k < args.gap + 1 else "usable"
        lag_rows.append({"lag": k, **m})
        print(f"{k:>7}{m['rmse']:>10.4f}{m['mae']:>10.4f}{note:>28}")
    print(f"{'clim':>7}{rows[1]['rmse']:>10.4f}{rows[1]['mae']:>10.4f}"
          f"{'no history at all':>28}")

    # ---- 4) 我们的模型 vs 地板 ----
    if args.runs:
        pats = sorted(glob.glob(os.path.join(args.runs, "*", "predictions.npz")))
        if pats:
            print("\n我们的模型 vs persistence（逐窗口）/ per-window comparison:")
            base = rmse(pers, y[test_w])
            print(f"  persistence RMSE={base:.4f}")
            for p in pats:
                z = np.load(p)
                pr, tr = z["pred"], z["true"]
                r = rmse(pr, tr)
                pw = [rmse(pr[i], tr[i]) for i in range(len(tr))]
                bw = [rmse(pers[i], y[test_w][i]) for i in range(len(test_w))]
                wins = int(np.sum(np.array(pw) < np.array(bw)))
                # ★ 最尖锐的一问：模型是不是干脆学成了 persistence？
                #   若 RMSE(pred, pers) 很小而 RMSE(pred, true)≈RMSE(pers, true)，
                #   那模型学到的就是"复制最后一年"，所有增益都是噪声。
                #   The sharpest question: did the model just collapse to persistence?
                d_gap = rmse(pr, pers) if pr.shape == pers.shape else float("nan")
                corr = (float(np.corrcoef(pr.ravel(), pers.ravel())[0, 1])
                        if pr.shape == pers.shape else float("nan"))
                print(f"  {os.path.basename(os.path.dirname(p)):22} RMSE={r:.4f}  "
                      f"({(r-base)/base*100:+.1f}% vs persistence)  "
                      f"赢 {wins}/{len(test_w)} 窗口  "
                      f"|pred-pers| RMSE={d_gap:.3f}  r={corr:.4f}")
        else:
            print(f"\n[warn] {args.runs} 下没有 predictions.npz")

    out = os.path.join(os.path.dirname(args.data), "signal_diagnosis.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump({"floors": rows, "lag_profile": lag_rows,
                   "between": between, "within": within,
                   "within_share": within_share,
                   "oracle_level_rmse": float(np.sqrt(within))}, fh,
                  indent=2, ensure_ascii=False)
    print(f"\n→ {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
