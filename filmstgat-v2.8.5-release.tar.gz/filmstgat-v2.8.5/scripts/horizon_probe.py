#!/usr/bin/env python3
"""Horizon probe: how much signal survives at lead times of 1-5 years? 跨度探针。

Horizon probe: how much signal remains at lead times of 1–5 years?

为什么做 / Why
--------------
当前协议是"提前 5 年"，结果所有模型都只能追平 persistence。有两种可能：
  (a) 5 年太长，年际信号早被噪声吃掉；
  (b) 这个变量本来就几乎没有可预测的年际变化。

把跨度从 1 年扫到 5 年，就能把两者分开：
  · 1 年还有明显 skill，5 年没有 → 是"跨度问题"，协议可改
  · 1 年也没有 skill            → 是"变量问题"，必须改叙事

同时给出**异常域**（Δy = 目标 − 起点值）的 skill：
绝对值域的 RMSE 被跨像素方差主导，异常域才真正反映"预测变化"的能力。

作者 / Author: Raymond Xiaohu Fan

用法 / Usage:
    python scripts/horizon_probe.py --data .../real_magt_data_v2_clean.npz --n-sub 500
"""

from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from filmstgat.experiments.common import load_v2, pick_pixels  # noqa: E402

START_YEAR = 1981


def build(series, T_in, gap, T_out=1):
    """返回 (feats, y, target_idx)，feats=(W,N,4)。"""
    N, T = series.shape
    starts = np.arange(0, T - T_in - gap - T_out + 1)
    W = len(starts)
    feats = np.zeros((W, N, 4))
    y = np.zeros((W, N))
    for i, s in enumerate(starts):
        in_start, in_end = s, s + T_in - 1
        t_start = s + T_in + gap
        t_end = t_start + T_out - 1
        seg = series[:, in_start:in_end + 1]
        t = np.arange(T_in) - (T_in - 1) / 2
        feats[i, :, 0] = seg[:, -1]
        feats[i, :, 1] = seg.mean(axis=1)
        feats[i, :, 2] = (seg - seg.mean(axis=1, keepdims=True)) @ t / np.sum(t ** 2)
        feats[i, :, 3] = seg.std(axis=1)
        y[i] = series[:, t_end]
    target_idx = starts + T_in + gap + T_out - 1
    return feats, y, target_idx


def ridge_fit_predict(Xtr, ytr, Xte, lam=1.0):
    mu, sd = Xtr.mean(0), Xtr.std(0) + 1e-8
    Xtr_n, Xte_n = (Xtr - mu) / sd, (Xte - mu) / sd
    A = Xtr_n.T @ Xtr_n + lam * np.eye(Xtr_n.shape[1])
    coef = np.linalg.solve(A, Xtr_n.T @ (ytr - ytr.mean()))
    return Xte_n @ coef + ytr.mean()


def rmse(p, y):
    return float(np.sqrt(np.mean((p - y) ** 2)))


def probe(series, T_in=10, horizons=(1, 2, 3, 4, 5)):
    rows = []
    for h in horizons:
        feats, y, tidx = build(series, T_in, gap=h - 1)
        years = START_YEAR + tidx
        tr = np.where(years <= 2010)[0]
        te = np.where(years >= 2015)[0]
        if len(tr) < 4 or len(te) < 2:
            continue

        Xtr = feats[tr].reshape(-1, 4)
        ytr = y[tr].reshape(-1)
        Xte = feats[te].reshape(-1, 4)
        yte = y[te].reshape(-1)

        base = feats[te].reshape(-1, 4)[:, 0]          # persistence = 起点值
        pred = ridge_fit_predict(Xtr, ytr, Xte)

        # 异常域岭回归：直接拟合 Δ = y − 起点，再回加起点。
        # Absolute-domain fitting is dominated by pixel level; the anomaly domain targets the change / 异常域对准变化
        # Delta-domain ridge: fit the increment directly, then add the origin
        # back. Fitting the absolute level lets pixel identity dominate.
        base_tr = feats[tr].reshape(-1, 4)[:, 0]
        d_pred = ridge_fit_predict(Xtr, ytr - base_tr, Xte)
        pred_delta = base + d_pred

        # 异常域：Δy = 目标 − 起点
        d_true = yte - base
        d_pers = np.zeros_like(d_true)                 # 持续性预测"零变化"
        d_ridge = pred - base

        rows.append({
            "horizon": h,
            "n_train_windows": int(len(tr)),
            "n_test_windows": int(len(te)),
            "persistence_rmse": rmse(base, yte),
            "ridge_rmse": rmse(pred, yte),
            "skill_abs": 1 - rmse(pred, yte) / rmse(base, yte),
            "delta_std": float(np.std(d_true)),
            "skill_delta_ridge": 1 - rmse(d_ridge, d_true) / rmse(d_pers, d_true),
            "corr_delta": float(np.corrcoef(d_ridge, d_true)[0, 1]) if np.std(d_ridge) > 1e-12 else 0.0,
            "ridge_delta_rmse": rmse(pred_delta, yte),
            "skill_delta_model": 1 - rmse(pred_delta, yte) / rmse(base, yte),
        })
    return rows


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--n-sub", type=int, default=500)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    data = load_v2(args.data)
    pix = pick_pixels(data, args.n_sub, seed=args.seed, mode="stratified")
    series = data["series"][pix].astype(np.float64)

    rows = probe(series)

    print("=" * 92)
    print(f"像素={len(pix)}   协议：10 年输入 → 提前 h 年预测单年")
    print("=" * 92)
    print(f"{'h':>3}{'trainW':>8}{'testW':>7}{'persist':>10}{'ridge':>9}"
          f"{'skill_abs':>11}{'Δy_std':>9}{'ridge_Δ':>10}{'skill_Δridge':>14}{'corr_Δ':>9}")
    print("-" * 92)
    for r in rows:
        print(f"{r['horizon']:>3}{r['n_train_windows']:>8}{r['n_test_windows']:>7}"
              f"{r['persistence_rmse']:>10.4f}{r['ridge_rmse']:>9.4f}"
              f"{r['skill_abs']*100:>10.1f}%{r['delta_std']:>9.3f}"
              f"{r['ridge_delta_rmse']:>10.4f}{r['skill_delta_model']*100:>13.1f}%{r['corr_delta']:>9.3f}")
    print("-" * 92)

    best = max(rows, key=lambda r: max(r["skill_delta_ridge"], r["skill_delta_model"])) if rows else None
    if best:
        best_skill = max(best["skill_delta_ridge"], best["skill_delta_model"])
        print(f"异常域最好：h={best['horizon']}，skill={best_skill*100:.1f}%，"
              f"corr(Δ)= {best['corr_delta']:.3f}（ridge绝对值 {best['skill_delta_ridge']*100:.1f}% / "
              f"ridge异常域 {best['skill_delta_model']*100:.1f}%）")
        if best_skill > 0.05:
            print("→ 存在可提取的年际变化：协议可改到更短跨度，叙事不必推倒。")
        else:
            print("→ 各跨度都没有异常域技能：这个变量本身几乎不可预测，必须改叙事。")
    print("\n读法：")
    print("  skill_abs   = 1 − RMSE_ridge / RMSE_persistence（绝对值域，被空间方差主导）")
    print("  skill_Δ     = 1 − RMSE(Δpred) / RMSE(Δ=0)（异常域，真正衡量'预测变化'）")
    print("  corr_Δ      = 预测变化与真实变化的相关，>0.2 才算有点信号")

    if args.out:
        os.makedirs(args.out, exist_ok=True)
        with open(os.path.join(args.out, "horizon_probe.json"), "w", encoding="utf-8") as fh:
            json.dump(rows, fh, indent=2, ensure_ascii=False)
        print(f"\n结果 → {args.out}/horizon_probe.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
