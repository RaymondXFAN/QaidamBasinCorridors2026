#!/usr/bin/env python3
"""把逐 seed 的 E4 结果合成一张可入稿的表，并算出这套设计的 MDE。

Aggregate per-seed E4 outputs into one manuscript table, and report the
minimum detectable effect (MDE) of the design.

为什么需要 / Why
----------------
E4 是逐 seed 跑的（每个 seed 一个目录），但论文要的是**一个**效应量。
而 5 个 seed 的 Δ 不能简单堆在一起求 CI——它们共用同一批测试窗口，
真正的独立单元是 seed。所以这里做两级汇总：

  · 第一级：每个 seed 内部，块自助法给出该 seed 的 Δ 与 CI（E4 已算）
  · 第二级：seed 之间，配对 t 给出均值的 CI（df = n_seed − 1）

两级都要报。只报第一级会把"4 个窗口的内部不确定性"当成总体不确定性；
只报第二级会忽略窗口结构。**取哪一级更保守，就用哪一级下结论。**

另一件更重要的事：**MDE**
------------------------
如果一套设计连 ±0.06 °C 都分辨不出来，而文献里报告的改进是 0.03 °C，
那么"显著/不显著"的讨论毫无意义——**效应本身在做法的分辨率之下**。
本脚本把这个分辨率算出来，供论文的 Limitations 直接引用。

作者 / Author: Raymond Xiaohu Fan

用法 / Usage:
    python scripts/aggregate_e4.py --glob "runs/e4/h5_ff_vs_std_s*" --margin 0.01
    python scripts/aggregate_e4.py --glob "runs/e4/h1_ff_vs_std_s*" --margin 0.01
"""

from __future__ import annotations

import argparse
import glob
import json
import os
import re

import numpy as np


def _seed_of(path: str) -> int:
    m = re.search(r"_s(\d+)$", os.path.basename(os.path.dirname(path)))
    return int(m.group(1)) if m else -1


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--glob", required=True, help="e4 输出目录的 glob，如 'runs/e4/h5_ff_vs_std_s*'")
    ap.add_argument("--margin", type=float, default=0.01)
    ap.add_argument("--label", default="")
    ap.add_argument("--rmse", type=float, default=None,
                    help="该协议下被比较模型的 RMSE，用于把 MDE 换算成百分比；"
                         "不给则只报绝对值（不同协议的 RMSE 量级不同，别用同一个常数）")
    args = ap.parse_args()

    paths = sorted(glob.glob(os.path.join(args.glob, "e4_summary.json")))
    if not paths:
        print(f"[fatal] 没有匹配到 {args.glob}/e4_summary.json")
        return 1

    rows = []
    for p in paths:
        s = json.load(open(p, encoding="utf-8"))
        rows.append({"seed": _seed_of(p),
                     "win": s.get("window", {}), "pix": s.get("pixel", {}),
                     "dir": os.path.dirname(p)})
    rows.sort(key=lambda r: r["seed"])

    label = args.label or os.path.basename(args.glob.rstrip("/"))
    print("=" * 84)
    print(f"E4 汇总 / aggregation   {label}   n_seed={len(rows)}   margin={args.margin}")
    print("=" * 84)
    print(f"{'seed':>6}{'window Δ':>12}{'window 95%CI':>26}"
          f"{'pixel Δ':>12}{'pixel 95%CI':>26}{'非劣':>6}")
    print("-" * 84)
    for r in rows:
        w, x = r["win"], r["pix"]
        wci = w.get("ci95", [np.nan, np.nan])
        xci = x.get("ci95", [np.nan, np.nan])
        ok = "✅" if w.get("non_inferior") and x.get("non_inferior") else "❌"
        print(f"{r['seed']:>6}{w.get('delta_mean', np.nan):>+12.4f}"
              f"  [{wci[0]:+.4f}, {wci[1]:+.4f}]"
              f"{x.get('delta_mean', np.nan):>+12.4f}"
              f"  [{xci[0]:+.4f}, {xci[1]:+.4f}]{ok:>6}")

    # ---- 第二级：seed 之间的配对 t ----
    d_win = np.array([r["win"].get("delta_mean", np.nan) for r in rows], dtype=float)
    n = int(np.sum(np.isfinite(d_win)))
    if n < 2:
        print("[fatal] 有效 seed 少于 2 个")
        return 1

    from scipy import stats

    t_w, p_w = stats.ttest_1samp(d_win[np.isfinite(d_win)], 0.0)
    se_w = float(np.std(d_win, ddof=1) / np.sqrt(n))
    half = float(stats.t.ppf(0.975, n - 1) * se_w)
    mean_w = float(np.mean(d_win))
    pos = int(np.sum(d_win > 0))

    print("-" * 84)
    print(f"seed 级均值 window Δ = {mean_w:+.4f} °C   sd={np.std(d_win, ddof=1):.4f}   "
          f"95%CI [{mean_w - half:+.4f}, {mean_w + half:+.4f}]   t={t_w:+.2f}  p={p_w:.4f}")
    print(f"符号一致性: {pos}/{n} 个 seed 为正（full 更差）")

    # ---- MDE：这套设计到底能分辨多大的效应 ----
    # 用 seed 级 SE 与窗口级半宽取较大者，作为"分辨率"的保守估计。
    win_half = float(np.median([(r["win"]["ci95"][1] - r["win"]["ci95"][0]) / 2
                                for r in rows]))
    mde_seed = float(stats.t.ppf(0.975, n - 1) * se_w)
    mde = max(mde_seed, win_half)
    print("\n分辨率 / MDE")
    print(f"  seed 级 95%CI 半宽        = {mde_seed:.4f} °C")
    print(f"  窗口级 CI 半宽（逐 seed 中位）= {win_half:.4f} °C")
    print(f"  → 本设计的 MDE ≈ {mde:.4f} °C "
          + (f"(≈ {mde / args.rmse * 100:.1f}% of RMSE={args.rmse:.3f})"
             if args.rmse else "  [未给 --rmse，无法换算百分比]"))

    # ---- 判定 ----
    print("\n判定")
    sig = (mean_w - half) > 0 or (mean_w + half) < 0
    if sig and mean_w > 0:
        print(f"  · seed 级显著且为正：条件化**一致更差** {mean_w:+.4f} °C")
    elif sig and mean_w < 0:
        print(f"  · seed 级显著且为负：条件化**一致更好** {mean_w:+.4f} °C")
    elif pos in (0, n):
        print(f"  · 方向一致（{pos}/{n}）但 n={n} 不足以显著；只能写'趋势'")
    elif max(pos, n - pos) / n >= 0.8:
        side = "更差（full > add/std）" if pos > n - pos else "更好"
        print(f"  · 方向倾向{side}（{max(pos, n - pos)}/{n}），但 n={n} 未达显著："
              f"只能写'方向一致的趋势'，不能写'显著'")
    else:
        print(f"  · 方向不一致（{pos}/{n} 为正）：**无法判定**，不能写'无差异'或'更好'")

    if mde > abs(mean_w) * 3:
        print(f"  · 观测效应 {abs(mean_w):.4f} 小于 MDE {mde:.4f} 的 1/3 —— "
              f"该效应在设计分辨率之下。")
        print(f"    论文应写：本设计**无法**分辨 {mde:.3f} °C 以下的效应，"
              f"而非'未发现差异'。")
    ni = all(r["win"].get("non_inferior") and r["pix"].get("non_inferior") for r in rows)
    print(f"  · 非劣性（margin={args.margin}）: {'全部通过' if ni else '未全部通过 → 不得声称等价'}")

    # ---- 出表 ----
    out = os.path.join(os.path.dirname(os.path.dirname(paths[0])),
                       f"aggregate_{label}.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump({"label": label, "n_seed": n, "margin": args.margin,
                   "per_seed": [{"seed": r["seed"], **r["win"], "pixel": r["pix"]}
                                for r in rows],
                   "seed_level": {"mean": mean_w, "sd": float(np.std(d_win, ddof=1)),
                                  "ci95": [mean_w - half, mean_w + half],
                                  "t": float(t_w), "p": float(p_w),
                                  "n_positive": pos},
                   "mde": {"seed_level_halfwidth": mde_seed,
                           "window_halfwidth_median": win_half,
                           "mde": mde},
                   "verdict": {"significant": bool(sig), "sign_consistent": pos in (0, n),
                               "equivalent_claimable": bool(ni)}}, fh,
                  indent=2, ensure_ascii=False)
    print(f"\n→ {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
