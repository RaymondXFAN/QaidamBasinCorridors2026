#!/usr/bin/env python3
"""数据集契约检查 / Dataset contract check.

审稿人拿到 npz 之后，先跑这个——它检查文件是否满足训练所需的全部条件，
而不是等到训练第 3 分钟才崩。

Run this on any .npz before training. Everything the loader assumes is checked
here explicitly, so a mismatched file fails in one second instead of mid-run.

用法 / Usage:
    python scripts/check_dataset.py --data data/real_magt_data_v2_clean.npz
    python scripts/check_dataset.py --data ... --expect h1

作者 / Author: Raymond Xiaohu Fan
"""

from __future__ import annotations

import argparse
import sys

import numpy as np

REQUIRED = ["series", "X_windows", "y_windows", "target_idx", "descriptors",
            "pixel_indices", "edge_index", "split_train", "split_val",
            "split_test", "ts_mean", "ts_std"]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--expect", choices=["h5", "h1", "any"], default="any",
                    help="h5=五年协议（gap=4）；h1=一年协议（gap=0）")
    args = ap.parse_args()

    problems: list[str] = []
    notes: list[str] = []

    try:
        d = np.load(args.data, allow_pickle=True)
        keys = set(d.files)
    except Exception as exc:
        print(f"[FAIL] 无法读取 {args.data}: {exc}")
        return 1

    print("=" * 74)
    print(f"数据集契约检查 / dataset contract   {args.data}")
    print("=" * 74)

    missing = [k for k in REQUIRED if k not in keys]
    if missing:
        problems.append(f"缺少键: {missing}")
    else:
        print("[ok] 必需键齐全")

    if missing:
        for p in problems:
            print(f"[FAIL] {p}")
        return 1

    series = np.asarray(d["series"])
    X = np.asarray(d["X_windows"])
    y = np.asarray(d["y_windows"])
    desc = np.asarray(d["descriptors"])
    ti = np.asarray(d["target_idx"])
    splits = {k: np.asarray(d[f"split_{k}"]) for k in ("train", "val", "test")}

    n, T = series.shape
    W = X.shape[0]
    print(f"  series      {series.shape}   像素数 n={n}, 年份数 T={T}")
    print(f"  X_windows   {X.shape}")
    print(f"  y_windows   {y.shape}")
    print(f"  descriptors {desc.shape}")
    print(f"  target_idx  {ti.shape}  范围 [{ti.min()}, {ti.max()}]")
    print(f"  split       train={len(splits['train'])} val={len(splits['val'])} "
          f"test={len(splits['test'])}")

    # 形状一致性
    if X.shape[0] != W or y.shape[0] != W or desc.shape[0] != W:
        problems.append("X/y/descriptors 的窗口数不一致")
    if X.shape[1] != n or y.shape[1] != n or desc.shape[1] != n:
        problems.append("X/y/descriptors 的像素数不一致")
    if y.shape[2] != 1:
        problems.append(f"y_windows 末维应为 1，实际 {y.shape[2]}")
    if desc.shape[2] != 3:
        problems.append(f"descriptors 末维应为 3（均值/趋势/标准差），实际 {desc.shape[2]}")
    if ti.shape[0] != W:
        problems.append(f"target_idx 长度 {ti.shape[0]} 与窗口数 {W} 不一致")

    # 划分必须是窗口下标的合法划分，且互不重叠
    allidx = np.concatenate([splits[k] for k in ("train", "val", "test")])
    if allidx.size and (allidx.min() < 0 or allidx.max() >= W):
        problems.append("split 里有越界的窗口下标")
    for a in ("train", "val", "test"):
        for b in ("train", "val", "test"):
            if a < b and np.intersect1d(splits[a], splits[b]).size:
                problems.append(f"split_{a} 与 split_{b} 有重叠窗口（会造成泄漏）")

    # 数值健康
    for name, arr in (("series", series), ("X", X), ("y", y), ("desc", desc)):
        nan = int(np.sum(~np.isfinite(arr)))
        if nan:
            problems.append(f"{name} 含 {nan} 个非有限值")
    if float(np.asarray(d["ts_std"])) <= 0:
        problems.append("ts_std <= 0，标准化会除零")

    # 协议一致性：输入窗必须有足够历史。
    # gap 本身无法从文件反推（它只影响输入窗末端与目标之间的距离），
    # 所以这里只做可判定的下界检查，并在 --expect 里提示人工确认。
    T_in = X.shape[2]
    if np.any(ti - (T_in - 1) < 0):
        problems.append("有窗口的目标年早于输入窗长度，构造有误")
    notes.append(f"T_in={T_in}（由 X_windows 推出）")
    if args.expect == "h5":
        notes.append("期望 h=5 协议：请确认该文件由 gap=4 构造（见 docs/DATA.md）")
    elif args.expect == "h1":
        notes.append("期望 h=1 协议：请确认该文件由 gap=0 构造")

    # 边索引
    ei = np.asarray(d["edge_index"])
    if ei.ndim != 2 or ei.shape[0] != 2:
        problems.append(f"edge_index 形状应为 (2, E)，实际 {ei.shape}")
    elif ei.size and (ei.min() < 0 or ei.max() >= n):
        problems.append("edge_index 里有越界的像素下标")

    print()
    for nt in notes:
        print(f"  · {nt}")
    print()
    if problems:
        print(f"[FAIL] {len(problems)} 项不合规：")
        for p in problems:
            print(f"   - {p}")
        return 1
    print("[PASS] 数据满足训练契约。")
    print(f"  提示：记录 sha256 以便审稿人核对 —— sha256sum {args.data}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
