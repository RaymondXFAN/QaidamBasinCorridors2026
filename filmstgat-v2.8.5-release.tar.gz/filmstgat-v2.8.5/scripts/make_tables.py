#!/usr/bin/env python3
"""Table generation — one entry point for every manuscript table.

表生成器：论文所有表都从这里出，每张表只读结果文件。

Rule / 规则
-----------
A table may only contain numbers that exist in a result file. If a file is
missing, the table is skipped and the reason is printed — never filled with a
remembered value. That is how Table 5 drifted out of sync in the original
submission, and it is the one mistake worth engineering against.

作者 / Author: Raymond Xiaohu Fan

用法 / Usage:
    python scripts/make_tables.py --root <ROOT>
"""

from __future__ import annotations

import argparse
import glob
import json
import os

import numpy as np
from scipy import stats


def holm(pvals):
    """Holm step-down correction, order preserved."""
    m = len(pvals)
    order = np.argsort(pvals)
    adj = np.empty(m, dtype=float)
    run = 0.0
    for rank, idx in enumerate(order):
        run = max(run, (m - rank) * float(pvals[idx]))
        adj[idx] = min(1.0, run)
    return adj.tolist()


def _j(path):
    if not os.path.exists(path):
        return None, f"missing: {path}"
    with open(path, encoding="utf-8") as fh:
        return json.load(fh), None


def _units_audit(root, stage, limit=40):
    """Classify per-run metrics by their recorded unit.

    Returns (state, examples) where state is one of:
      "ok"         every run stamps units: physical
      "normalised" at least one run explicitly reports normalised metrics
      "unstamped"  no unit recorded at all (legacy run) — NOT the same thing
      None         no runs found
    The previous version conflated "unstamped" with "normalised" and produced a
    false alarm on correct results; the two must stay separate.
    """
    paths = sorted(glob.glob(os.path.join(root, "runs", stage, "*", "metrics.json")))[:limit]
    if not paths:
        return None, []
    bad_norm, unstamped = [], []
    for p in paths:
        try:
            u = str(json.load(open(p, encoding="utf-8")).get("units", "")).lower()
        except Exception:
            u = ""
        name = os.path.basename(os.path.dirname(p))
        if "physical" in u:
            continue
        if "normal" in u:
            bad_norm.append(name)
        else:
            unstamped.append(name)
    if bad_norm:
        return "normalised", bad_norm
    if unstamped:
        return "unstamped", unstamped
    return "ok", []


def _persistence_rmse(root):
    d, _ = _j(os.path.join(root, "runs/e3/metrics_e3.json"))
    if isinstance(d, list):
        for r in d:
            if r.get("model") == "persistence":
                return float(r["rmse"])
    return None


def _vs_ref(mean, sd, n, ref):
    """One-sample t against a constant reference (persistence has no variance).

    Returns (delta, delta_pct, t, p). Everything comes from the aggregate, so no
    per-seed array is required — the arithmetic is identical to a paired test
    against a constant.
    """
    if not np.isfinite(mean) or not np.isfinite(sd) or n < 2 or sd <= 0:
        return mean - ref, 100.0 * (mean - ref) / ref, float("nan"), float("nan")
    se = sd / np.sqrt(n)
    t = (mean - ref) / se
    p = 2 * (1 - stats.t.cdf(abs(t), n - 1))
    return mean - ref, 100.0 * (mean - ref) / ref, t, p


def _md_table(headers, rows):
    out = ["| " + " | ".join(headers) + " |",
           "|" + "|".join([":--"] + ["--:"] * (len(headers) - 1)) + "|"]
    for r in rows:
        out.append("| " + " | ".join(str(c) for c in r) + " |")
    return "\n".join(out)


def t_dataset(root, w):
    """T1: dataset card — sizes, splits, hashes."""
    rows = []
    real, err1 = _j(os.path.join(root, "datasets_v2/dataset_manifest_v2.json"))
    h1, err2 = _j(os.path.join(root, "datasets_v2_h1/dataset_manifest_v2.json"))
    syn, err3 = _j(os.path.join(root, "datasets_synth_v2/synth_manifest_v2.json"))
    for name, m, err in (("real MAGT (h=5)", real, err1),
                         ("real MAGT (h=1)", h1, err2),
                         ("synthetic", syn, err3)):
        if m is None:
            rows.append([name, "—", "—", "—", err])
            continue
        n_units = m.get("n_pixels_selected") or m.get("N")
        rows.append([name, n_units, m.get("n_windows"),
                     str(m.get("split_sizes")), m.get("T_in")])
    w("T1_dataset.md", _md_table(
        ["dataset", "units (pixels/nodes)", "windows", "split sizes", "T_in"], rows))


def t_windows(root, w):
    """T2: window manifest summary (the answer to R3-1)."""
    csv = os.path.join(root, "datasets_v2/window_manifest_v2.csv")
    if not os.path.exists(csv):
        w("T2_windows.md", "skipped: missing datasets_v2/window_manifest_v2.csv")
        return
    rows = [ln.strip().split(",") for ln in open(csv, encoding="utf-8")][1:]
    by_split = {}
    for r in rows:
        by_split.setdefault(r[6], []).append((r[1], r[2], r[4]))
    out = []
    for s in ("train", "val", "test"):
        v = by_split.get(s, [])
        if not v:
            continue
        out.append([s, len(v), v[0][0], v[-1][1], v[0][2]])
    w("T2_windows.md", _md_table(
        ["split", "n windows", "first input window", "last target", "gap (years)"], out))


def _conditioning_table(root, stage, ref_json, title, fname, w):
    """Shared body for the h=5 and h=1 conditioning tables."""
    d, err = _j(os.path.join(root, f"runs/{stage}/summary_e1.json"))
    if d is None:
        w(fname, f"skipped: {err}")
        return

    ref = None
    meta, _ = _j(os.path.join(root, ref_json))
    if isinstance(meta, list):
        for row in meta:
            if row.get("model") == "persistence":
                ref = float(row["rmse"])
                break

    rows, ps = [], []
    for k, v in d.items():
        n = v.get("n_seeds", 0)
        if ref is not None:
            delta, pct, t, p = _vs_ref(v["rmse_mean"], v["rmse_std"], n, ref)
            ps.append(p)
            rows.append([k, f"{v['rmse_mean']:.4f} ± {v['rmse_std']:.4f}",
                         f"{delta:+.4f}", f"{pct:+.2f}%", f"{v['r2_mean']:+.4f}",
                         f"{p:.3f}" if np.isfinite(p) else "—", n, v.get("params")])
        else:
            rows.append([k, f"{v['rmse_mean']:.4f} ± {v['rmse_std']:.4f}",
                         "—", "—", f"{v['r2_mean']:+.4f}", "—", n, v.get("params")])

    if ps:
        for r, pa in zip(rows, holm(ps)):
            r.insert(6, f"{pa:.3f}")

    headers = (["configuration", "RMSE (°C)", "Δ (°C)", "Δ (%)", "R²", "p", "p (Holm)",
                "n seeds", "params"] if ps else
               ["configuration", "RMSE (°C)", "Δ (°C)", "Δ (%)", "R²", "p", "n seeds",
                "params"])

    warn = []
    state, bad = _units_audit(root, stage)
    if state == "normalised":
        warn.append(f"**STALE RESULTS — DO NOT USE.** {len(bad)} run(s) report "
                    f"normalised metrics. Re-run `bash run_all.sh {stage}`.")
    elif state == "unstamped":
        warn.append(f"**UNVERIFIED UNITS.** {len(bad)} run(s) carry no unit stamp; "
                    f"values look physical, but re-run before the final release.")
    if ref is not None:
        best = min(v["rmse_mean"] for v in d.values())
        if best < 0.9 * ref:
            warn.append(f"**IMPLAUSIBLE.** best RMSE ({best:.4f}) is >10% below "
                        f"persistence ({ref:.4f}); check units and test indices.")

    body = f"### {title}\n\n"
    if ref is not None:
        body += f"reference: persistence = {ref:.4f} °C\n\n"
    if warn:
        body += "\n\n".join("> ⚠️ " + x for x in warn) + "\n\n"
    body += _md_table(headers, rows)
    w(fname, body)


def t_e1(root, w):
    """T3: conditioning ablations, h=5 protocol."""
    _conditioning_table(root, "e1", "runs/e3/metrics_e3.json",
                        "T3. Conditioning ablations (h = 5)", "T3_e1_conditioning.md", w)


def t_e1h1(root, w):
    """T3b: conditioning ablations, h=1 protocol (the one with detectable signal)."""
    _conditioning_table(root, "e1h1", "runs/e3h1/metrics_e3.json",
                        "T3b. Conditioning ablations (h = 1)",
                        "T3b_e1h1_conditioning.md", w)


def t_overlap(root, w):
    """T4: overlap sweep and endpoint contrast."""
    sweep, e1 = _j(os.path.join(root, "runs/e2/e2_summary.json"))
    endp, e2 = _j(os.path.join(root, "runs/e2b/analysis/analysis.json"))
    parts = []
    if sweep:
        rows = [[f"{r['alpha']:.2f}", f"{r['rho']:.3f}",
                 f"{r.get('rho_chance_corrected', 2 * r['rho'] - 1):+.3f}",
                 f"{r['delta_full_minus_add']:+.4f}",
                 "—" if r.get("delta_std") is None else f"{r['delta_std']:.4f}",
                 "—" if r.get("p_value") is None else f"{r['p_value']:.3f}"]
                for r in sweep]
        parts.append("### T4a. Five-level sweep (exploratory, n=5)\n\n" + _md_table(
            ["alpha", "rho", "rho*", "Δ (full−add) °C", "sd", "p"], rows))
    else:
        parts.append(f"### T4a\n\nskipped: {e1}")
    if endp:
        rows = [[f"{L['alpha']:.2f}", f"{L['rho_star']:+.3f}", f"{L['delta']:+.4f}",
                 f"[{L['ci95'][0]:+.4f}, {L['ci95'][1]:+.4f}]", f"{L['p']:.4f}"]
                for L in endp["levels"]]
        txt = "### T4b. Endpoint contrast (n=24 seeds)\n\n" + _md_table(
            ["alpha", "rho*", "Δ (full−add) °C", "95% CI", "p"], rows)
        if endp.get("did"):
            dg = [[f"{r['alpha']:.2f}", f"{r['did']:+.4f}",
                   f"[{r['ci95'][0]:+.4f}, {r['ci95'][1]:+.4f}]", f"{r['p_holm']:.4f}"]
                  for r in endp["did"]]
            txt += "\n\nDifference-in-differences (paired by seed):\n\n" + _md_table(
                ["alpha", "DiD °C", "95% CI", "p (Holm)"], dg)
        parts.append(txt)
    else:
        parts.append(f"### T4b\n\nskipped: {e2}")
    w("T4_overlap.md", "\n\n".join(parts))


def t_synthetic(root, w):
    """T5: synthetic benchmark, with the pairwise matrix if available."""
    d, err = _j(os.path.join(root, "runs/e1synth/e1_synth_summary.json"))
    if d is None:
        w("T5_synthetic.md", f"skipped: {err}")
        return
    naive, cfgs = d["naive"], d["configs"]
    def _num(x, fmt):
        # 缺字段或非有限值一律写 "—"：不要崩，也绝不瞎补数字
        if x is None or (isinstance(x, (int, float)) and not np.isfinite(x)):
            return "—"
        return format(x, fmt)

    rows = [[f"{k} (baseline)", f"{v['rmse']:.4f}", _num(v.get("r2"), "+.3f"),
             "—", "—", "—"] for k, v in naive.items()]
    for k, v in cfgs.items():
        pp = "—" if v.get("p_vs_persistence") is None else f"{v['p_vs_persistence']:.3f}"
        rows.append([k, f"{v['rmse_mean']:.4f} ± {v['rmse_std']:.4f}",
                     _num(v.get("r2_mean"), "+.3f"),
                     _num(v.get("delta_vs_persistence"), "+.4f"),
                     pp, v.get("params", "—")])
    txt = "### T5a. Synthetic benchmark\n\n" + _md_table(
        ["model", "RMSE (°C)", "R²", "Δ vs persistence", "p (uncorrected)", "params"], rows)

    st, _ = _j(os.path.join(root, "runs/e1synth/analysis/synth_stats.json"))
    if st:
        rows = [[r["a"], r["b"], f"{r['delta']:+.4f}", f"{r['sd_diff']:.4f}",
                 f"{r['r']:+.2f}", f"{r['p']:.4f}", f"{r['p_holm']:.4f}",
                 f"{r['mde']:.4f}"] for r in st["pairwise"]]
        txt += ("\n\n### T5b. Configuration vs configuration (paired, same seed)\n\n"
                + _md_table(["A", "B", "Δ = A−B °C", "sd(Δ)", "r", "p", "p (Holm)",
                             "MDE °C"], rows))
        txt += ("\n\n**Note.** MDE is the smallest effect detectable at 80% power; "
                "differences below it are *not* evidence of equivalence.\n")
    w("T5_synthetic.md", txt)


def t_baselines(root, w):
    """T6: naive baselines on real data."""
    d, err = _j(os.path.join(root, "runs/e3/metrics_e3.json"))
    if d is None:
        w("T6_baselines.md", f"skipped: {err}")
        return
    rows = [[r["model"], f"{r['rmse']:.4f}",
             "—" if r.get("mae") is None else f"{r['mae']:.4f}",
             "—" if r.get("r2") is None else f"{r['r2']:+.4f}",
             r.get("n_samples", "—")] for r in d]
    w("T6_baselines.md", _md_table(["model", "RMSE (°C)", "MAE (°C)", "R²", "n"], rows))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=os.environ.get("ROOT", "/root/autodl-tmp/revision_v2"))
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    out = args.out or os.path.join(args.root, "tables")
    os.makedirs(out, exist_ok=True)

    def write(name, text):
        path = os.path.join(out, name)
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(text.rstrip() + "\n")
        status = "skipped" if text.startswith("skipped") or "skipped:" in text[:60] else "ok"
        if "STALE RESULTS" in text or "IMPLAUSIBLE" in text or "UNVERIFIED UNITS" in text:
            status = "SUSPECT"
        print(f"  [{status:7s}] {name}")

    print(f"tables → {out}")
    for fn in (t_dataset, t_windows, t_e1, t_e1h1, t_overlap, t_synthetic,
               t_baselines):
        fn(args.root, write)
    print("\nEvery cell above is read from a result file; nothing is typed by hand.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
