#!/usr/bin/env python3
"""Shape probe for the baseline adapters — run this BEFORE any training.

基线适配层的形状探针：训练之前先跑一遍前向。

为什么先探针 / Why a probe first
--------------------------------
The three baselines disagree on calling conventions (one has no batch dimension,
two want a dense adjacency). A wrong axis does not raise; it trains silently on
the wrong thing. That is exactly how the GRU bug cost a day. Ten seconds here
saves an hour of GPU and a wrong number in a table.

三个基线约定不同，轴写错不报错、只会静默训错。十秒钟的探针省一小时 GPU 和一张错表。

作者 / Author: Raymond Xiaohu Fan

用法 / Usage:
    python scripts/probe_baselines.py            # CPU, ~10 s
    python scripts/probe_baselines.py --device cuda
"""

from __future__ import annotations

import argparse
import os
import sys
import traceback

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np                       # noqa: E402
import torch                             # noqa: E402

from filmstgat.models.baselines import BASELINE_NAMES, build_baseline   # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--nodes", type=int, default=47)
    ap.add_argument("--steps", type=int, default=24)
    ap.add_argument("--features", type=int, default=13)
    ap.add_argument("--batch", type=int, default=2)
    args = ap.parse_args()

    dev = torch.device(args.device)
    B, N, T, F = args.batch, args.nodes, args.steps, args.features

    X = torch.randn(B, N, T, F, device=dev)
    # a ring graph + self loops, dense enough that every message-passing layer sees edges
    src = np.arange(N)
    dst = (src + 1) % N
    edge_index = torch.as_tensor(np.stack([np.r_[src, dst], np.r_[dst, src]]), device=dev)
    geo = torch.randn(B, N, 3, device=dev)

    print(f"probe: X={tuple(X.shape)} edge_index={tuple(edge_index.shape)} "
          f"geo={tuple(geo.shape)} device={dev}")
    print(f"expected output: ({B}, {N})   # v2 trainer targets are (B,N)\n")

    failures = 0
    sets_geo = set()
    for name in BASELINE_NAMES:
        line = f"[{name:5s}]"
        try:
            model = build_baseline(name, n_nodes=N, input_dim=F, geo_dim=3, seed=42)
            model = model.to(dev)
            model.eval()
            shapes = []
            with torch.no_grad():
                for bs in (1, args.batch):
                    xb = torch.randn(bs, N, T, F, device=dev)
                    gb = torch.randn(bs, N, 3, device=dev)
                    y1 = model(xb, edge_index, gb)      # first call builds the graph
                    y2 = model(xb, edge_index, gb)      # second call must reuse the cache
                    if tuple(y1.shape) != (bs, N) or tuple(y2.shape) != (bs, N):
                        raise ValueError(f"expected ({bs},{N},1), got "
                                         f"{tuple(y1.shape)} / {tuple(y2.shape)}")
                    if not torch.isfinite(y1).all():
                        raise ValueError("output contains non-finite values")
                    if not torch.allclose(y1, y2):
                        raise ValueError("two identical forward passes differ — "
                                         "graph cache or dropout is misconfigured")
                    # Empirical check: does this model actually consume the priors?
                    gb2 = torch.randn_like(gb)
                    y3 = model(xb, edge_index, gb2)
                    uses_geo = not torch.allclose(y1, y3, atol=1e-6)
                    sets_geo.add(uses_geo)
                    shapes.append(tuple(y1.shape))
            print(f"{line} out={shapes[0]} & {shapes[1]}  params={model.num_params:,}  "
                  f"uses_priors={'YES' if uses_geo else 'no (unconditioned)'}  OK")
        except Exception as exc:                              # noqa: BLE001
            failures += 1
            print(f"{line} FAILED: {type(exc).__name__}: {exc}")
            traceback.print_exc(limit=3)

    print()
    if failures:
        print(f"[fatal] {failures} adapter(s) failed the probe. Do NOT start training.")
        return 1
    print("[ok] all adapters produce (B, N) — the trainer's target shape. Safe to train.")
    print("\nnote: a model that reports 'no (unconditioned)' ignores the priors in "
          "its forward pass;\n      it is a valid unconditioned baseline, but the "
          "manuscript must say so.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
