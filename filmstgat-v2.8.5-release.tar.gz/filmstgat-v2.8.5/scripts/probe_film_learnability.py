#!/usr/bin/env python3
"""FiLM 可学性测试（CPU，约 1 分钟）：描述子是唯一信息源时，它学得会吗？

Learnability probe: can the conditioning pathway learn when the descriptor is
the ONLY source of information?

为什么重写 / Why this replaces probe_film_sensitivity.py
------------------------------------------------------
上一版探针有两个致命缺陷，结论必须撤回：

1. **在初始化处测敏感度毫无意义**。FiLM 采用恒等初始化（gamma=1, beta=0），
   输出对描述子的偏导在 step 0 必然精确为 0。测出 0.0000 是数学必然，不是缺陷。
   Measuring sensitivity at initialisation is vacuous: identity init makes the
   derivative exactly zero at step 0 by construction.

2. **梯度阶段的训练目标与描述子无关**（我把 target 设成常数 1.0）。既然任务
   不需要描述子，梯度当然不会流向 FiLM，那 50 步什么也证明不了。
   The gradient stage optimised a constant target, which gives the descriptor
   nothing to explain — so it could not possibly learn to use it.

本脚本换一个设计：让 **x = 0（常数）**，目标 y 只由描述子决定：

    y_i = 2 * g_i        （g_i 是第 i 个节点的描述子第 1 维）

于是唯一可能的下降路径就是条件化通路。对照：
  · 能学会 → 通路可用；真实数据上不用它，是数据层面的结论。
  · 学不会 → 实现有问题（初始化尺度 / gate / 调制施加位置），必须先修。

作者 / Author: Raymond Xiaohu Fan

用法 / Usage:
    python scripts/probe_film_learnability.py            # 默认 400 步
    python scripts/probe_film_learnability.py --steps 800 --hidden 64
"""

from __future__ import annotations

import argparse
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from filmstgat.models.stgat import STGAT  # noqa: E402
from filmstgat.train.seeding import set_all_seeds  # noqa: E402


def ring_edges(n: int) -> torch.Tensor:
    src = torch.arange(n)
    dst = (src + 1) % n
    return torch.stack([torch.cat([src, dst]), torch.cat([dst, src])], dim=0)


def build(cond: str, geo_dim: int, hidden: int, layers: int, seed: int) -> STGAT:
    set_all_seeds(seed)
    return STGAT(input_dim=1, geo_dim=geo_dim, hidden_dim=hidden,
                 num_heads=4, num_spatial_layers=layers,
                 conditioning=cond, film_mode="full",
                 residual_output=False, spatial_residual=False)


def run(cond: str, args) -> dict:
    N, T = args.nodes, args.steps_t
    model = build(cond, args.geo_dim, args.hidden, args.layers, args.seed)
    edge = ring_edges(N)

    g = torch.zeros(1, N, args.geo_dim)
    g[0, :, 0] = torch.randn(N)                       # 唯一的信息源
    y = (2.0 * g[0, :, 0]).view(1, N)                 # 目标只由描述子决定
    x = torch.zeros(1, N, T, 1)                       # 输入是常数：逼它用描述子

    opt = torch.optim.Adam(model.parameters(), lr=args.lr)
    model.train()
    for step in range(1, args.learn_steps + 1):
        opt.zero_grad()
        pred = model(x, edge, g)
        loss = torch.mean((pred - y) ** 2)
        loss.backward()
        opt.step()
        if step in (1, 10, 50, 100, 200, 400) and step <= args.learn_steps:
            with torch.no_grad():
                model.eval()
                p = model(x, edge, g)
                model.train()
            print(f"    [{cond:9}] step {step:>3}  loss={float(loss):.4f}  "
                  f"RMSE={float(torch.sqrt(torch.mean((p - y) ** 2))):.4f}")

    model.eval()
    with torch.no_grad():
        pred = model(x, edge, g)
    rmse = float(torch.sqrt(torch.mean((pred - y) ** 2)))
    sd = float(torch.std(y))
    # 换一组描述子，检验是真的学到了映射，还是记住了这一组
    g2 = torch.zeros_like(g)
    g2[0, :, 0] = torch.randn(N)
    y2 = (2.0 * g2[0, :, 0]).view(1, N)
    with torch.no_grad():
        p2 = model(x, edge, g2)
    rmse2 = float(torch.sqrt(torch.mean((p2 - y2) ** 2)))
    return {"cond": cond, "rmse_train": rmse, "rmse_new": rmse2, "sd_y": sd}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--nodes", type=int, default=48)
    ap.add_argument("--steps-t", type=int, default=8)
    ap.add_argument("--geo-dim", type=int, default=3)
    ap.add_argument("--hidden", type=int, default=64)
    ap.add_argument("--layers", type=int, default=2)
    ap.add_argument("--learn-steps", type=int, default=400)
    ap.add_argument("--lr", type=float, default=3e-3)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    print("=" * 74)
    print("FiLM 可学性 / learnability — x 为常数、y 只由描述子决定")
    print(f"  nodes={args.nodes} T={args.steps_t} hidden={args.hidden} "
          f"layers={args.layers} steps={args.learn_steps} lr={args.lr:g}")
    print("=" * 74)

    out = []
    for cond in ("film", "none"):
        print(f"\n[{cond}]")
        out.append(run(cond, args))

    print("\n" + "=" * 74)
    print(f"{'conditioning':16}{'RMSE (same g)':>16}{'RMSE (new g)':>16}{'sd(y)':>10}")
    print("-" * 74)
    for r in out:
        print(f"{r['cond']:16}{r['rmse_train']:>16.4f}{r['rmse_new']:>16.4f}"
              f"{r['sd_y']:>10.4f}")
    print("=" * 74)

    film = next(r for r in out if r["cond"] == "film")
    none = next(r for r in out if r["cond"] == "none")
    sd = film["sd_y"]
    print(f"参照：什么都不学（预测均值）的 RMSE = sd(y) = {sd:.4f}")
    if film["rmse_new"] < 0.3 * sd:
        print("\n判读：FiLM 在'描述子是唯一信息源'时**学得会**（新描述子上仍成立）。")
        print("      通路可用 ⇒ 真实数据上它不利用泄漏信息，是数据层面的结论，可以写进论文。")
        print("      同时说明：模型并不是靠记住这一组描述子蒙对的（new g 也成立）。")
    elif film["rmse_new"] < 0.8 * sd:
        print("\n判读：只学到一部分。通路勉强可用但效率低，")
        print("      需要检查初始化尺度与调制施加的位置，再决定能否下数据层面的结论。")
    else:
        print("\n判读：FiLM **学不会**（与不做条件化无差别）。")
        print("      这是实现问题，不是数据问题 —— 在修好之前，")
        print("      任何'模型不利用描述子'的表述都不能写进论文。")
    print(f"      对照：unconditioned 的 RMSE={none['rmse_new']:.4f}"
          f"（应当接近 sd(y)={sd:.4f}）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
