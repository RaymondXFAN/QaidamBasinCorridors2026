#!/usr/bin/env python3
"""合成基准的统计检验：配对 t、Holm 校正、最小可检测效应（MDE）。

Statistics for the synthetic benchmark: paired t-tests, Holm correction, and the
minimum detectable effect (MDE).

为什么必须有 MDE / Why MDE is not optional
------------------------------------------
n=5 时"不显著"有三种完全不同的含义：真没差异、样本太少、波动太大。
不报 MDE，读者只能理解成第一种——而那是我们无权主张的。
This script therefore reports, for every comparison, the smallest effect the
design could have detected at 80% power. A null result is then reported as
"below the detection floor", never as "equivalent".

事故背景 / Incident this encodes
--------------------------------
2026-11-08：报告里只有"各配置 vs persistence"的 p 值，我把它们读成了
"配置之间显著不同"。实际配对检验显示配置之间全部不显著（最小 p=0.163）。
把两类比较**分开列、各自标注参照**，就是为了防止这种误读再次发生。
The table in the original run mixed two different references. Here every
comparison carries an explicit reference label.

作者 / Author: Raymond Xiaohu Fan

用法 / Usage:
    python scripts/analyze_synth.py --runs runs/e1synth
"""

from __future__ import annotations

import argparse
import json
import os

import numpy as np
from scipy import stats


def holm(pvals: list) -> list:
    """Holm-Bonferroni step-down correction, preserving input order."""
    m = len(pvals)
    order = np.argsort(pvals)
    adj = np.empty(m, dtype=float)
    run = 0.0
    for rank, idx in enumerate(order):
        run = max(run, (m - rank) * float(pvals[idx]))
        adj[idx] = min(1.0, run)
    return adj.tolist()


def mde_paired(sd_diff: float, n: int, alpha: float = 0.05,
               power: float = 0.8) -> float:
    """Minimum detectable effect for a paired t-test (two-sided).

    Solved numerically because the non-central t has no closed form here.
    """
    if not np.isfinite(sd_diff) or sd_diff <= 0 or n < 2:
        return float("nan")
    tc = stats.t.ppf(1 - alpha / 2, n - 1)
    lo, hi = 0.0, 10.0 * sd_diff
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        nc = mid * np.sqrt(n) / sd_diff
        pw = (1 - stats.nct.cdf(tc, n - 1, nc)) + stats.nct.cdf(-tc, n - 1, nc)
        if pw < power:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", required=True, help="directory holding e1_synth_summary.json")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    src = os.path.join(args.runs, "e1_synth_summary.json")
    if not os.path.exists(src):
        raise SystemExit(f"missing {src}; run: bash run_all.sh synth")
    d = json.load(open(src, encoding="utf-8"))
    cfgs = d["configs"]
    naive = d["naive"]
    pers = float(naive["persistence"]["rmse"])
    names = list(cfgs)
    per_seed = {k: np.asarray(v["rmse_per_seed"], dtype=float) for k, v in cfgs.items()}
    n = min(len(v) for v in per_seed.values())

    out = args.out or os.path.join(args.runs, "analysis")
    os.makedirs(out, exist_ok=True)

    # ---------- A) 每个配置 vs persistence（参照是常数，故为单样本检验） ----------
    rows_a = []
    for k in names:
        v = per_seed[k][:n]
        diff = v - pers
        sd = float(diff.std(ddof=1)) if n > 1 else 0.0
        t, p = stats.ttest_1samp(diff, 0.0) if n > 1 and sd > 0 else (np.nan, 1.0)
        rows_a.append({"config": k, "rmse_mean": float(v.mean()), "rmse_std": sd,
                       "delta": float(diff.mean()),
                       "delta_pct": float(100.0 * diff.mean() / pers),
                       "t": float(t), "p": float(p),
                       "mde": mde_paired(sd, n)})
    for r, pa in zip(rows_a, holm([r["p"] for r in rows_a])):
        r["p_holm"] = float(pa)

    # ---------- B) 配置之间（同 seed 配对） ----------
    rows_b = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            a, b = names[i], names[j]
            va, vb = per_seed[a][:n], per_seed[b][:n]
            diff = va - vb
            sd = float(diff.std(ddof=1))
            if sd > 0:
                t, p = stats.ttest_rel(va, vb)
                r = float(np.corrcoef(va, vb)[0, 1])
            else:
                t, p, r = np.nan, 1.0, np.nan
            rows_b.append({"a": a, "b": b, "delta": float(diff.mean()),
                           "sd_diff": sd, "r": r, "t": float(t), "p": float(p),
                           "mde": mde_paired(sd, n)})
    if rows_b:
        for r, pa in zip(rows_b, holm([r["p"] for r in rows_b])):
            r["p_holm"] = float(pa)

    # ---------- C) 输出 ----------
    lines = ["# Synthetic benchmark — statistics", "",
             f"reference (persistence) RMSE = {pers:.4f} °C, n = {n} seeds, "
             f"MDE at 80% power, two-sided alpha = 0.05", ""]
    lines += ["## A. Each configuration vs persistence (one-sample t on per-seed RMSE)", "",
              "| config | RMSE | Δ (°C) | Δ (%) | p | p (Holm) | MDE (°C) |",
              "|:--|--:|--:|--:|--:|--:|--:|"]
    for r in rows_a:
        lines.append(f"| {r['config']} | {r['rmse_mean']:.4f} ± {r['rmse_std']:.4f} | "
                     f"{r['delta']:+.4f} | {r['delta_pct']:+.2f}% | {r['p']:.4f} | "
                     f"{r['p_holm']:.4f} | {r['mde']:.4f} |")

    lines += ["", "## B. Configuration vs configuration (paired t, same seed)", "",
              "| A | B | Δ = A − B (°C) | sd(Δ) | r | p | p (Holm) | MDE (°C) |",
              "|:--|:--|--:|--:|--:|--:|--:|--:|"]
    for r in rows_b:
        lines.append(f"| {r['a']} | {r['b']} | {r['delta']:+.4f} | {r['sd_diff']:.4f} | "
                     f"{r['r']:+.2f} | {r['p']:.4f} | {r['p_holm']:.4f} | {r['mde']:.4f} |")

    # ---------- D) 自动判读（只陈述，不夸大） ----------
    sig_a = [r["config"] for r in rows_a if r["p_holm"] < 0.05]
    sig_b = [(r["a"], r["b"]) for r in rows_b if r["p_holm"] < 0.05]
    verdict = []
    verdict.append(
        f"Worse than persistence at Holm-corrected alpha = 0.05: {sig_a or 'none'}.")
    verdict.append(
        f"Detectable differences between configurations: {sig_b or 'none'}.")
    biggest = max(rows_b, key=lambda r: abs(r["delta"])) if rows_b else None
    if biggest:
        verdict.append(
            f"Largest config-vs-config difference: {biggest['a']} − {biggest['b']} = "
            f"{biggest['delta']:+.4f} °C, i.e. "
            f"{abs(biggest['delta']) / biggest['mde']:.2f}× its MDE "
            f"({biggest['mde']:.4f} °C).")
        if abs(biggest["delta"]) < biggest["mde"]:
            verdict.append(
                "All observed differences lie BELOW the detection floor. This is a "
                "statement about our design, not evidence that the models are equivalent.")
    lines += ["", "## Verdict", ""] + [f"- {v}" for v in verdict]

    with open(os.path.join(out, "synth_stats.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    with open(os.path.join(out, "synth_stats.json"), "w", encoding="utf-8") as fh:
        json.dump({"reference": pers, "n": n, "vs_persistence": rows_a,
                   "pairwise": rows_b, "verdict": verdict}, fh,
                  indent=2, ensure_ascii=False)

    print("\n".join(lines))
    print(f"\nwritten: {out}/synth_stats.md")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
