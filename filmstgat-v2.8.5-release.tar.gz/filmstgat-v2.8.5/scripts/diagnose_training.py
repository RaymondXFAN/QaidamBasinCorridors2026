#!/usr/bin/env python3
"""Training diagnostics: did the model learn anything, or is it predicting the mean? 训练诊断。

Training diagnostic: is the model learning at all, or just predicting the mean?

背景 / Background
-----------------
第一次全量跑出 R²≈0.07、RMSE≈8.8 °C，几乎等于"输出全局均值"。这说明
训练预算/超参有问题，而不是 FiLM 有没有用的问题。**在模型学会之前，
任何配置间比较都是噪声。**
The first full run gave R²≈0.07 and RMSE≈8.8 °C — essentially predicting the
global mean. That says nothing about FiLM; it says the model isn't training.
Comparing configurations before it learns is comparing noise.

这个脚本干三件事 / What it does
-------------------------------
1. 打印同一测试集上的 persistence 基线（°C），给出"必须打赢"的底线
2. 训练一个 standard 模型，逐 epoch 打印 val RMSE（°C）
3. 输出最好 epoch、测试 RMSE、R²，并保存学习曲线

用法 / Usage:
    python scripts/diagnose_training.py --data ... --n-sub 500 --epochs 600
"""

from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from filmstgat.experiments.common import load_v2, pick_pixels, make_splits  # noqa: E402
from filmstgat.models.factory import build_model  # noqa: E402
from filmstgat.train.trainer import train_stgat  # noqa: E402


def persistence_rmse(data, pix, T_in=10, gap=4, T_out=1):
    """同口径的 persistence 基线（°C）。"""
    series = data["series"][pix].astype(np.float64)
    ti = data["target_idx"]
    te = data["split_test"]
    preds = []
    for w in te:
        t_end = int(ti[w])
        t_start = t_end - T_out + 1
        t_in_end = t_start - gap - 1
        preds.append(series[:, t_in_end])
    pred = np.stack(preds, axis=0)
    true = data["y_windows"][pix][:, te, 0].transpose(1, 0).astype(np.float64)
    return float(np.sqrt(np.mean((pred - true) ** 2))), pred, true


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--n-sub", type=int, default=500)
    ap.add_argument("--epochs", type=int, default=600)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--patience", type=int, default=100)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--selection", default="stratified")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--residual", action="store_true",
                    help="残差参数化：ŷ = x_last + f(·)，只学增量")
    ap.add_argument("--no-spatial", action="store_true",
                    help="去掉 GAT 层，用纯 GRU，判断是不是空间层把信号抹平了")
    ap.add_argument("--tag", default="", help="输出目录后缀")
    ap.add_argument("--spatial-residual", action="store_true",
                    help="空间层加自连接：h ← h + GAT(h)")
    ap.add_argument("--layers", type=int, default=2, help="空间层数（0=无图）")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    data = load_v2(args.data)
    pix = pick_pixels(data, args.n_sub, seed=args.seed, mode=args.selection)
    splits = make_splits(data, pix)

    pers_rmse, _, _ = persistence_rmse(data, pix)
    y_mean, y_std = splits["mean"], splits["std"]

    print("=" * 72)
    print(f"像素={len(pix)}  训练窗={len(splits['X_train'])}  "
          f"标准均值={y_mean:.3f} 标准差={y_std:.3f}")
    print(f"底线 persistence RMSE = {pers_rmse:.4f} °C  ← 打不过它就别谈'更准'")
    print("=" * 72)

    model = build_model(args.seed, input_dim=splits["X_train"].shape[-1],
                        geo_dim=splits["geo_train"].shape[-1], hidden_dim=64,
                        conditioning="none",
                        num_spatial_layers=0 if args.no_spatial else args.layers,
                        residual_output=bool(args.residual),
                        spatial_residual=bool(args.spatial_residual))
    print(f"配置：residual={args.residual}  spatial_layers={0 if args.no_spatial else args.layers}"
          f"  spatial_residual={args.spatial_residual}")

    res = train_stgat(
        model, splits, splits["edge_index"], None, seed=args.seed,
        epochs=args.epochs, lr=args.lr, batch_size=args.batch_size,
        patience=args.patience, device=args.device, verbose=1,
        y_mean=y_mean, y_std=y_std,
    )

    m = res["metrics"]
    print("\n" + "-" * 72)
    print(f"最好 epoch = {res['best_epoch']}   实际跑了 {res['epochs_run']} 轮")
    print(f"测试 RMSE  = {m['rmse']:.4f} °C   MAE = {m['mae']:.4f} °C   R² = {m['r2']:.4f}")
    print(f"persistence= {pers_rmse:.4f} °C")
    if m["rmse"] < pers_rmse:
        print(f"✅ 优于 persistence {(1-m['rmse']/pers_rmse)*100:.1f}%")
    else:
        print(f"❌ 仍不如 persistence（差 {(m['rmse']/pers_rmse-1)*100:.1f}%）"
              f"——继续增加训练预算，而不是改 FiLM")
    print("-" * 72)

    out_dir = os.path.join(args.out, args.tag) if args.tag else args.out
    os.makedirs(out_dir, exist_ok=True)
    curve = res["history"]
    with open(os.path.join(out_dir, "training_curve.json"), "w", encoding="utf-8") as fh:
        json.dump({"persistence_rmse": pers_rmse, "metrics": m,
                   "best_epoch": res["best_epoch"], "curve": curve},
                  fh, indent=2, ensure_ascii=False)
    with open(os.path.join(out_dir, "training_curve.csv"), "w", encoding="utf-8") as fh:
        fh.write("epoch,train_loss,val_rmse_c\n")
        for r in curve:
            fh.write(f"{r['epoch']},{r['train_loss']:.6f},{r['val_rmse']:.6f}\n")

    print(f"\n学习曲线 → {out_dir}/training_curve.csv")
    print("下一步判断：")
    print("  · val_rmse 还在下降 → 训练预算不够，继续加 epoch")
    print("  · val_rmse 早早平台 → 学习率/模型容量问题，先别碰 FiLM")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
