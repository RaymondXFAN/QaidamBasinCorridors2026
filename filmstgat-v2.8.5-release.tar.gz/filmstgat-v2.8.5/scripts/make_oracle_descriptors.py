#!/usr/bin/env python3
"""构造"泄漏上限"数据集：把描述子换成**目标期统计量**。

Build an upper-bound (leaky-oracle) variant of the dataset.

为什么做这个 / Why
------------------
负结果最容易被问的一句是："是不是你们的条件化机制太弱/没调好？"
这个问题用"再调一调"是回答不了的，必须换个问法：

  **如果描述子真的携带目标期的信息，这个机制用得上吗？**

做法：把所有窗口的描述子都替换成**测试期（2015–2018）逐像素的均值/趋势/标准差**。
这份描述子直接泄漏了目标期的水平——真实预测里永远拿不到。
于是：

  · 若 film_full 的 RMSE 明显低于 standard ⇒ 机制**能**利用信息，我们观测不到增益是
    **因为数据里没有信息**，不是因为机制坏了。
  · 若 film_full 仍然 ≈ standard ⇒ 机制本身无法承载这类信息，问题回到架构。

两种结果都能写进论文，而且都比"我们调过了"有力。

⚠ 这不是一个可用的模型，只是**上限探针**。表里必须标 oracle / not a forecast。

作者 / Author: Raymond Xiaohu Fan

用法 / Usage:
    python scripts/make_oracle_descriptors.py \
        --data <ROOT>/datasets_v2/real_magt_data_v2_clean.npz \
        --out  <ROOT>/datasets_v2/real_magt_data_v2_oracle.npz
"""

from __future__ import annotations

import argparse
import os

import numpy as np


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--years", default="2015,2016,2017,2018",
                    help="用来计算 oracle 统计量的年份（必须与测试目标年一致）")
    args = ap.parse_args()

    d = np.load(args.data, allow_pickle=True)
    keys = {k: d[k] for k in d.files}
    series = np.asarray(keys["series"], dtype=np.float64)      # (n, T)
    target_idx = np.asarray(keys["target_idx"], dtype=int)
    split_test = np.asarray(keys["split_test"], dtype=int)
    start_year = 1981
    n, T = series.shape

    # 用目标年份反查时间下标；找不到就报错，不要静默用别的年份——
    # 静默替换会让"泄漏"变成别的东西，实验结论就废了。
    test_years = [int(y) for y in args.years.split(",")]
    idx = []
    for y in test_years:
        t = y - start_year
        if t < 0 or t >= T:
            raise SystemExit(f"target year {y} out of range for series length {T}")
        idx.append(t)
    # 校验：这些下标应当正好是 split_test 对应的目标
    want = sorted(int(target_idx[w]) for w in split_test)
    got = sorted(idx)
    if want != got:
        print(f"[warn] --years 推出的下标 {got} 与 split_test 的目标 {want} 不一致；"
              f"继续但请确认这是你要的")
    idx_arr = np.array(idx, dtype=int)

    block = series[:, idx_arr]                                  # (n, k)
    mean = block.mean(axis=1)
    std = block.std(axis=1)
    t = np.arange(len(idx_arr), dtype=np.float64)
    t = t - t.mean()
    denom = float(np.sum(t ** 2)) or 1.0
    trend = ((block - block.mean(axis=1, keepdims=True)) @ t) / denom

    desc = np.stack([mean, trend, std], axis=1).astype(np.float32)   # (n, 3)
    W = keys["descriptors"].shape[0]
    keys["descriptors"] = np.repeat(desc[None, :, :], W, axis=0)     # (W, n, 3)

    os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
    np.savez_compressed(args.out, **keys)

    print(f"→ {args.out}")
    print(f"  windows={W}  pixels={n}  years={test_years}")
    print(f"  oracle descriptor (per pixel): mean {mean.mean():+.3f} ± {mean.std():.3f} °C, "
          f"trend {trend.mean():+.4f} ± {trend.std():.4f} °C/yr")
    print("⚠ 这份数据**只能**用于上限探针：描述子含目标期信息，不可作为预测结果报告。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
