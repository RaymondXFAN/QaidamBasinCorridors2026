#!/usr/bin/env python3
"""汇总竞争实验的结果：按条件 × 配置打印 RMSE，并直接给出判定。

Summarise the competition probe: RMSE per condition and configuration, plus the
verdict implied by the pre-registered decision rule.

判读规则是**事先定好的**（写在 docs/EXP_competition_runbook.md），不是看到数字再挑说法：
  · C3(zeroX+oracle) 的 film_full 明显低于 C2(oracle, 有 x)      → 竞争解释成立
  · C3 与 C4(zeroX+zeroG) 无差别                                 → 描述子根本没被用上
  · C3 与 C5(zeroX+origin) 无差别                                → 被利用的是泄漏，不是真实信息

作者 / Author: Raymond Xiaohu Fan
"""

from __future__ import annotations

import argparse
import glob
import json
import os
import re

import numpy as np

COND = {
    "C1_baseline": "正常 x + origin 描述子",
    "C2_oracle": "正常 x + oracle 描述子（泄漏）",
    "C3_zeroX_oracle": "零 x + oracle 描述子",
    "C4_zeroX_zeroG": "零 x + 零描述子",
    "C5_zeroX_origin": "零 x + origin 描述子",
}


FALLBACK_C2 = "e1oracle"   # C2 早期在独立目录跑过，允许兜底


def collect(runs_dir: str) -> dict:
    out: dict = {}
    for mp in sorted(glob.glob(os.path.join(runs_dir, "*", "*", "metrics.json"))):
        seed_dir = os.path.dirname(mp)
        cond = os.path.basename(os.path.dirname(seed_dir))
        m = re.match(r"(.+)_seed(\d+)$", os.path.basename(seed_dir))
        if not m:
            continue
        cfg, seed = m.group(1), int(m.group(2))
        try:
            metrics = json.load(open(mp, encoding="utf-8"))["metrics"]
        except Exception:
            continue
        out.setdefault(cond, {}).setdefault(cfg, []).append(
            (seed, float(metrics["rmse"])))
    return out


def collect_fallback(base: str) -> dict:
    """C2 早期跑在 runs/e1oracle 下，命名不同，单独读。"""
    out: dict = {}
    for mp in sorted(glob.glob(os.path.join(base, FALLBACK_C2, "*_seed*", "metrics.json"))):
        d = os.path.basename(os.path.dirname(mp))
        m = re.match(r"(.+)_seed(\d+)$", d)
        if not m:
            continue
        try:
            v = float(json.load(open(mp, encoding="utf-8"))["metrics"]["rmse"])
        except Exception:
            continue
        out.setdefault(m.group(1), []).append((int(m.group(2)), v))
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", required=True)
    args = ap.parse_args()

    data = collect(args.runs)
    fb = collect_fallback(args.runs) or collect_fallback(
        os.path.dirname(os.path.abspath(args.runs)))
    if fb:
        for cfg, vals in fb.items():
            cur = data.setdefault("C2_oracle", {}).setdefault(cfg, [])
            if not cur:
                data["C2_oracle"][cfg] = vals
                print(f"[info] C2 从 {FALLBACK_C2}/ 兜底读入 {len(vals)} 个 run")
    if not data:
        print(f"[fatal] {args.runs} 下没有 *_seed*/metrics.json")
        return 1

    print("=" * 88)
    print(f"竞争实验汇总 / competition probe   {args.runs}")
    print("=" * 88)
    print(f"{'condition':18}{'config':16}{'n':>4}{'RMSE mean':>12}{'sd':>9}   说明")
    print("-" * 88)
    table = {}
    for cond in sorted(data):
        for cfg in sorted(data[cond]):
            vals = np.array([v for _, v in data[cond][cfg]], dtype=float)
            table[(cond, cfg)] = (vals.mean(), vals.std(ddof=1) if len(vals) > 1 else 0.0)
            print(f"{cond:18}{cfg:16}{len(vals):>4}{vals.mean():>12.4f}"
                  f"{vals.std(ddof=1) if len(vals) > 1 else 0.0:>9.4f}"
                  f"   {COND.get(cond, '')}")
    print("-" * 88)

    def get(c, f):
        return table.get((c, f), (float("nan"), float("nan")))[0]

    c2_ff = get("C2_oracle", "film_full")
    c3_ff = get("C3_zeroX_oracle", "film_full")
    c4_ff = get("C4_zeroX_zeroG", "film_full")
    c5_ff = get("C5_zeroX_origin", "film_full")
    c3_std = get("C3_zeroX_oracle", "standard")

    print("\n判定 / verdict")
    if not np.isfinite(c3_ff):
        print("  · C3 缺失，无法判定")
        return 0

    print(f"  C1 有 x + origin   = {get('C1_baseline','film_full'):.4f}"
          if np.isfinite(get("C1_baseline", "film_full")) else "  C1 缺失")
    print(f"  C2 有 x + oracle   = {c2_ff:.4f}" if np.isfinite(c2_ff) else "  C2 缺失")
    print(f"  C3 无 x + oracle   = {c3_ff:.4f}" + (f"   [standard={c3_std:.4f}]"
                                                   if np.isfinite(c3_std) else ""))
    print(f"  C4 无 x + 无描述子 = {c4_ff:.4f}" if np.isfinite(c4_ff) else "  C4 缺失")
    print(f"  C5 无 x + origin   = {c5_ff:.4f}" if np.isfinite(c5_ff) else "  C5 缺失")

    # 无信息参照是 C4：既没有 x 也没有描述子，模型只能输出均值。
    # C2 回答的是另一个问题——把 x 加回去，同一批描述子是否被抑制。
    print()
    verdicts = []
    if np.isfinite(c4_ff):
        gain_oracle = c4_ff - c3_ff
        print(f"  C4→C3（无 x，加 oracle 描述子）= {gain_oracle:+.3f} °C")
        if np.isfinite(c5_ff):
            print(f"  C4→C5（无 x，加真实描述子）  = {c4_ff - c5_ff:+.3f} °C")
        if np.isfinite(c2_ff):
            print(f"  C3→C2（把 x 加回去）          = {c2_ff - c3_ff:+.3f} °C")
        print()
        if gain_oracle > 1.0:
            verdicts.append("通路有效：撤掉 x 之后，条件化分支被激活"
                            f"（{c4_ff:.3f} → {c3_ff:.3f}）")
        if np.isfinite(c2_ff) and (c2_ff - c3_ff) > 0.15:
            verdicts.append("竞争成立：把 x 加回去，同一批描述子从被利用变为被忽略"
                            f"（{c3_ff:.3f} → {c2_ff:.3f}）")
            verdicts.append("⇒ 条件化分支的问题在**优化/竞争**，不在数据、也不在实现")
        if np.isfinite(c2_ff) and c3_ff < c2_ff - 0.15:
            verdicts.append(f"泄漏描述子比整个输入窗更值钱（{c3_ff:.3f} < {c2_ff:.3f}）")
        if np.isfinite(c5_ff) and np.isfinite(c2_ff):
            if abs(c3_ff - c5_ff) < 0.1 and (c4_ff - c3_ff) > 0.1:
                verdicts.append("被利用的主要是泄漏信息，真实描述子即使无竞争也无额外价值")

    if not verdicts:
        print("  · 差异不构成清晰结论，按实测值如实写，不要外推。")
    for v in verdicts:
        print(f"  ✅ {v}" if not v.startswith("⇒") else f"     {v}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
