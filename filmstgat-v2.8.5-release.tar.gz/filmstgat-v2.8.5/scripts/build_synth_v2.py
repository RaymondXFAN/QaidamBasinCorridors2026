#!/usr/bin/env python3
"""把合成数据原始 npz 转成 v2 数据集（滑窗 + 时域切分 + 逐特征统计）。

Convert the raw synthetic npz into the v2 dataset layout.

用法 / Usage:
    python scripts/build_synth_v2.py \
        --raw  <ROOT>/datasets_synth/qaidam_inSAR.npz \
        --out  <ROOT>/datasets_synth_v2

作者 / Author: Raymond Xiaohu Fan
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from filmstgat.data.synth_windows import build_synth_v2      # noqa: E402


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--T-in", type=int, default=24)
    ap.add_argument("--T-out", type=int, default=1)
    ap.add_argument("--val-months", type=int, default=6)
    args = ap.parse_args()

    print("=" * 78)
    print("合成数据 → v2 数据集")
    print(f"  raw : {args.raw}")
    print(f"  sha : {sha256_file(args.raw)[:16]}…")
    print("=" * 78)

    meta = build_synth_v2(args.raw, args.out, T_in=args.T_in,
                          T_out=args.T_out, val_months=args.val_months)

    print(f"  窗口数   : {meta['n_windows']}")
    print(f"  切分     : {meta['split_sizes']}")
    print(f"  目标范围 : {meta['target_range']}")
    print(f"  边数     : {meta['n_edges']}")
    print(f"  切分规则 : {meta['split_rule']}")
    print(f"\n  输出     : {meta['npz_path']}")
    print(f"  sha256   : {sha256_file(meta['npz_path'])}")
    print("\n  ⚠ 合成数据的 geo 先验是外生的（非线性派生），与输入的 overlap 天生偏低。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
