# Manuscript v3 — Sections 1–2 (draft)

**Working title:** *What a permafrost temperature benchmark can and cannot resolve:
zero-modelling floors, persistence collapse, and the resolution limit of the standard
evaluation design*

**Status:** draft v0.1 — §1–2. §3–6 in `manuscript_v3_sections_3-6.md`.
Every number here is taken from a result file; nothing is estimated.

---

## 1. Introduction

Near-surface ground temperature is the variable through which permafrost change is most
directly observed, and forecasting it a few years ahead underpins infrastructure siting,
ecological monitoring and carbon-response assessment [CITE]. The forecasting problem is
posed as a spatiotemporal regression: given a window of annual observations on a set of
pixels, predict the same pixels several years ahead.

Recent work has approached this with graph neural networks whose node update is modulated by
*geological priors* — terrain, thermal and land-cover descriptors attached to each pixel —
typically through feature-wise linear modulation (FiLM) [CITE]. The appeal is intuitive:
two pixels with identical temperature history may respond differently because their
subsurface differs, and a conditioning signal should let one model express that difference.
Reported improvements for this family of methods are in the low single digits of RMSE.

### 1.1 What changed in this version

The version of this manuscript originally submitted reported that descriptor conditioning
reduced forecast error, and proposed a rule relating the form of conditioning (additive
versus multiplicative) to the overlap between the descriptor field and the input field.

That conclusion does not survive the revision. Following the reviewers' requests on protocol
rather than on architecture — origin consistency of the conditioning field, explicit seeding
of weight initialisation, and a leakage-free split — we rebuilt the evaluation pipeline and
re-ran every ablation. Under the corrected protocol:

* the reported improvement is not reproduced at either forecast horizon (§5);
* the design-rule claim cannot be reinstated, because a controlled five-level manipulation of
  descriptor overlap yields no dose–response (§6);
* and the reason is visible in the data rather than in the architecture: two zero-modelling
  references — persistence and per-pixel climatology — differ by 2.5% of RMSE, and every
  trained configuration reproduces persistence to within a Pearson correlation of 0.9974
  (§3–§4).

We report this because a negative result that is mechanically explained is more useful than a
positive one that is not. The explanation we offer is that the standard evaluation design for
this task — a handful of temporally held-out windows — has a minimum detectable effect of
6.7–9.0% of RMSE (§5.1), which is larger than the effects the literature reports. On this
benchmark, architecture comparisons are not resolving what they claim to resolve.

### 1.2 Contributions

1. **Floors.** We quantify what a decade of history adds over a constant per pixel
   (2.5% of RMSE) and show that per-pixel trend extrapolation is markedly worse than doing
   nothing (RMSE 2.689 vs 1.395, §3.1).
2. **Collapse.** We show that all trained configurations — five conditioning variants and
   three external backbones — converge on the persistence forecast, with
   $r \in [0.9974, 1.0000]$ between model output and persistence (§4).
3. **Resolution.** We compute the minimum detectable effect of the standard design and show
   that it exceeds the effect sizes typically reported for this task (§5.1); we therefore
   report an undetermined result at the five-year horizon rather than a null one, and a
   consistent small penalty at the one-year horizon.
4. **Overlap.** We hold marginal descriptor information constant while moving only its spatial
   correspondence, and find no dose–response across five levels; the only defensible effect
   is a 0.015 °C penalty for multiplicative conditioning at maximal alignment, established
   with 24 seeds rather than 5 (§6).

All code, audit logs and result files are released with the paper [CITE: repository/DOI].

---

## 2. Protocol

### 2.1 Data and task

Annual near-surface ground temperature on a fixed pixel grid, 1981–2020, together with three
per-pixel descriptors (terrain, thermal and land-cover). Pixels are restricted to those with
adequate coverage in the training period and a stratified subsample of 500 pixels is drawn by
training-period mean temperature (10 bins, fixed seed) — the same subset for every model and
every baseline.

A sample is a window of $T_{\text{in}} = 10$ annual observations for one pixel; the target is
the value $G$ years after the last input observation, with $G = 5$ (five-year protocol) or
$G = 0$ (one-year protocol). All models, all baselines and the two zero-modelling references
are evaluated on the identical test windows; every result file carries a fingerprint of the
test targets so that mismatched sets cannot be silently merged.

### 2.2 Splits and the leakage-free protocol

Splits are made by **target year**: training targets ≤ 2010, validation 2011–2014, test
2015–2018. Windows are disjoint by construction.

Two protocol corrections distinguish this version from the original submission:

* **Origin consistency.** Descriptors are taken at each window's own origin, not shared across
  windows. Sharing them allows a model to see a pixel's state at a time it should not know,
  and is the channel through which a conditioning signal can leak the target's own era.
* **Seeded initialisation.** Every run fixes all random sources *before* the model is
  constructed. Seeding the trainer afterwards leaves weight initialisation dependent on
  whatever global state was left over from the previous run.

### 2.3 Models

The backbone is a spatiotemporal graph attention network over a $k$-nearest-neighbour pixel
graph ($k = 8$). Five conditioning configurations are compared, all with identical backbone
width and depth:

| Configuration | Role |
|---|---|
| `standard` | no descriptors — the unconditioned reference |
| `standard_wider` | same, width increased to match the parameter count of the FiLM variant |
| `concat_info` | descriptors concatenated to the input channels (information-matched, no mechanism) |
| `film_add` | descriptors enter through an additive shift |
| `film_full` | descriptors enter through additive shift and multiplicative gain |

`standard_wider` and `concat_info` exist so that a difference, if any, can be attributed to the
*mechanism* rather than to capacity or to the presence of the information itself.

### 2.4 References and baselines

Two zero-modelling references are computed on the same test windows: persistence (the last
observation available before the forecast gap) and per-pixel training-period climatology. A
per-pixel linear-trend extrapolation is reported as a third, physically motivated reference.
Three external backbones (STGCN, DCRNN, a physics-informed network) are re-run inside this
harness rather than quoted from their original papers; a probe verifies that each consumes the
inputs it is given in the way the harness assumes, and reports whether it uses the descriptors
at all.

### 2.5 Evaluation

Metrics are computed in the physical unit on inverse-transformed predictions, so that learned
models and the physical references are commensurable.

Uncertainty is reported at two levels and the more conservative governs: within a seed, a
spatial block bootstrap over pixels; across seeds, a paired $t$ interval with $n - 1$ degrees
of freedom. Where the two disagree, the seed-level test decides, because five seeds are five
replicate experiments whereas a bootstrap over one seed's pixels is not.

Finally, every comparison reports the design's **minimum detectable effect**, computed from the
interval half-width. An effect smaller than the MDE is not evidence of absence, and we do not
report it as such: we distinguish *undetermined* (interval spans zero with inconsistent sign)
from *no difference* (equivalence established against a prespecified margin, which we were
unable to establish anywhere).

---

## Notes on this draft

* `[CITE]` markers are placeholders. Every reference must be verified against a real record —
  none should be written from memory. Needed: permafrost/MAGT observation and forecasting;
  graph-based spatiotemporal forecasting; FiLM; random-walk/persistence baselines in
  environmental forecasting; equivalence testing and MDE reporting; benchmark leakage.
* §1.1 states the withdrawal of the earlier claim in one paragraph, without arguing that the
  reviewers were right or that the original analysis was careless. The cause — a protocol that
  let conditioning see the target's own era — speaks for itself.
* §2 must be reconciled with the original §2 for anything that did not change (data source,
  network definition); only the protocol changes are restated here.
