# 明早执行清单 / Morning runbook

> 目标：**用最少 GPU 时间**跑完唯一还缺的实验，然后把发布物整理好。
> 总耗时 ≈ 20 分钟（GPU 12 min + CPU 8 min）。
>
> 纪律：**不要重跑 E1 / E1h1 / E2 / E2b / E5 / E5h1** —— 那些结果已经在
> `runs/` 里，重跑纯烧钱。

---

## Step 0 — 开工前 30 秒（一定要做）

```bash
hostname
ls /root/autodl-tmp/revision_v2/runs -d && ls /root/autodl-tmp/revision_v2/datasets_v2/*.npz
nvidia-smi --query-gpu=name,memory.used --format=csv
```

对着看三件事：

| 检查 | 期望 | 不对怎么办 |
|---|---|---|
| hostname | `autodl-container-c0d64989c1-1a754a12` | 换了机器 → 结果不在这，先确认 |
| `datasets_v2/*.npz` | 有 2 个（clean + oracle） | 缺 → 结果目录被清过，别硬跑 |
| GPU 显存 | 空 | 还有别人的进程 → **先问，别抢** |

---

## Step 1 — 解压与自检（CPU，1 分钟）

```bash
cd /root/autodl-tmp/revision_v2
tar -xzf filmstgat-v2.8.0.tar.gz
cd filmstgat-v2.8.0

python scripts/repro_audit.py
```

**看最后一行**：必须是 `FAIL=0`。WARN 可以有（runbook 里的示例路径），FAIL 一个都不能有。

顺便确认数据契约（10 秒）：

```bash
python scripts/check_dataset.py \
  --data /root/autodl-tmp/revision_v2/datasets_v2/real_magt_data_v2_clean.npz --expect h5
```

期望：`[PASS] 数据满足训练契约。`

---

## Step 2 — 唯一的 GPU 实验：竞争探针（12 分钟）

```bash
cd /root/autodl-tmp/revision_v2/filmstgat-v2.8.0
bash scripts/run_probe_competition.sh
```

默认 nohup 后台。**它会先跑 3 个变体构造（CPU，10 秒），再跑 20 个 run。**

监控（另开一个窗口）：

```bash
# 进度：目标 20
watch -n 10 'ls -d /root/autodl-tmp/revision_v2/runs/probe/*/*/ 2>/dev/null | wc -l'

# 实时日志
tail -f /root/autodl-tmp/revision_v2/logs/probe_*.log
```

跑完后汇总：

```bash
python scripts/summarize_probe.py --runs /root/autodl-tmp/revision_v2/runs/probe
```

### 怎么读这张表

```
condition         config       n   RMSE mean       sd
C2_oracle         film_full    5      1.34xx   0.0xxx   ← 有 x，泄漏描述子
C3_zeroX_oracle   film_full    5      0.7xxx   0.0xxx   ← 无 x，泄漏描述子（关键）
C3_zeroX_oracle   standard     5      1.34xx   0.0xxx   ← 无 x 的对照
C4_zeroX_zeroG    film_full    5      1.35xx   0.0xxx   ← 无 x 无描述子
C5_zeroX_origin   film_full    5      1.31xx   0.0xxx   ← 无 x，真实描述子
```

脚本会**直接打印判定**，对照下表确认：

| 判定 | 数字特征 | 含义 | 论文怎么写 |
|:--|:--|:--|:--|
| **A** | C3 明显 < C2（差 > 0.15）且 C3 ≪ C4 | 竞争成立 | "撤掉 x 后同一架构立刻用上描述子" → 优化问题，不是数据问题 |
| **B** | C3 ≈ C4（差 < 0.1） | 描述子始终没被用上 | §5.4 降级为"未观察到利用"，**不能**再推"通路可用" |
| **C** | C3 ≈ C5 且 C4 − C3 > 0.1 | 被利用的是泄漏 | 强化 §3 地板结论 |
| **D** | 差异都 < 0.1 | 无结论 | 按实测值如实写，禁止外推 |

> A 和 C 可以同时成立。**把判定结果和五行 RMSE 一起发我**，我据此改 §5.4 的措辞。

---

## Step 3 — 重建全部图表（CPU，2 分钟）

```bash
cd /root/autodl-tmp/revision_v2/filmstgat-v2.8.0
ROOT=/root/autodl-tmp/revision_v2 bash run_all.sh figures

ls -1 /root/autodl-tmp/revision_v2/figures/F*.pdf
```

**期望 4 个**：`F1_floors_and_lag` / `F2_collapse_to_persistence` /
`F3_effect_vs_resolution` / `F4_overlap_dose_response`。

如果末尾出现 `missing inputs (skipped, NOT fabricated)`，把缺的文件名发我——
那说明某个阶段的输出路径对不上，不是画图代码的问题。

---

## Step 4 — 打包结果文件（CPU，1 分钟）

```bash
cd /root/autodl-tmp/revision_v2/filmstgat-v2.8.0
python scripts/collect_results.py \
  --runs /root/autodl-tmp/revision_v2 \
  --out /root/autodl-tmp/revision_v2/filmstgat-v2.8.0/results
```

期望：`(N files, X.XX MB)`，且**不应超过 150 MB**。

看一眼 `results/MANIFEST.json` 里的 `summary.mb`——这个数决定审稿人下载是否舒服，
最好 < 20 MB。

> 这一步跑完，审稿人才能用 `ROOT=results bash run_all.sh figures` 在不碰 GPU 的情况下
> 重建全部图表。**不做这步，L2 复现就是断的。**

---

## Step 5 — 定版与打包（CPU，1 分钟）

```bash
cd /root/autodl-tmp/revision_v2/filmstgat-v2.8.0

python scripts/repro_audit.py --write-version    # 重算 tree_hash
python scripts/repro_audit.py                    # 确认 FAIL=0 且 hash 一致

cd /root/autodl-tmp/revision_v2
tar -czf filmstgat-v2.8.0-release.tar.gz filmstgat-v2.8.0
du -h filmstgat-v2.8.0-release.tar.gz
```

**看两处**：

1. audit 末行 `FAIL=0`，且 `[F] tree_hash 与 N 个文件一致`
2. tar 体积（含 `results/` 后应该在 1–30 MB）

---

## Step 6 — 关机前核对（30 秒）

```bash
cd /root/autodl-tmp/revision_v2
ls -l filmstgat-v2.8.0-release.tar.gz
ls -1 filmstgat-v2.8.0/results/MANIFEST.json
ls -1 figures/F*.pdf | wc -l          # 4
ls -d runs/probe/*/*/ | wc -l         # 20
```

四项都齐就可以关机。

---

## 发我什么

1. `summarize_probe.py` 的整张表（含判定）
2. `repro_audit.py` 的最后两行
3. `collect_results.py` 的 `(N files, X MB)`
4. 如果 figures 有 missing，贴那几行

我会据此改 §5.4、更新 AUDIT_LOG、并把 release 的说明写好。

---

## 时间预算

| 步骤 | 设备 | 耗时 |
|---|---|---|
| Step 0 体检 | — | 30 s |
| Step 1 解压 + audit + 数据契约 | CPU | 1 min |
| Step 2 竞争探针（20 run） | **GPU** | 12 min |
| Step 3 重建图表 | CPU | 2 min |
| Step 4 打包 results | CPU | 1 min |
| Step 5 定版 | CPU | 1 min |
| **合计** | | **≈ 18 min** |

GPU 只需 12 分钟，之后可以立刻关掉 GPU 实例，改无卡模式做剩下的。
