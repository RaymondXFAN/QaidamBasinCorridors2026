# 数据说明 / Data statement

> 本文件面向两类读者：**审稿人**（需要知道数据能不能拿到、怎么核验）与
> **作者**（上传前把 `<!-- FILL -->` 标记补齐）。

---

## 1. 数据是什么

| 项 | 内容 |
|---|---|
| 变量 | 逐像元年平均地温（MAGT, mean annual ground temperature, °C） |
| 空间 | 规则像元网格，像元边长约 1 km（`knn_edges(..., pixel_size_m=1000.0)`） |
| 时间 | 1981–2020，逐年 |
| 条件变量 | 每个像元 3 个地质先验：地形、热属性、地表覆盖（由 `origin_descriptors()` 从**该窗口自身的历史**计算为 [均值, 线性趋势, 标准差]） |
| 划分 | 按**目标年份**切分：train ≤2010 / val 2011–2014 / test 2015–2018 |

<!-- FILL: 原始产品名称、版本号、生产者、获取渠道、许可条款。这一段必须写实，
     审稿人会据此判断数据是否允许以本文方式切分与再发布。 -->

---

## 2. 能不能拿到

本仓库**不含原始观测数据**。原因：<!-- FILL: 第三方许可限制 / 体积 / 数据政策 -->。

审稿人获取方式（按优先级）：

1. **向通讯作者索取**已构建好的两个 `.npz`（见 §3 的契约）。
2. 若已具备原始产品：按 §4 的命令自行重建，结果应当与本文使用的文件在
   §5 的校验下一致。

<!-- FILL: 是否计划上传到公开仓库（Zenodo/figshare）以及 DOI。若可以，
     这是最强的可复现性保障，建议做。 -->

---

## 3. 文件契约

训练器假设的键与形状：

| 键 | 形状 | 含义 |
|---|---|---|
| `series` | `(n, T)` | 逐像元年序列，`T = 40`（1981–2020） |
| `X_windows` | `(W, n, T_in, 1)` | 输入窗，`T_in = 10`；末维为通道数（本数据为 1） |
| `y_windows` | `(W, n, 1)` | 目标值，窗口 `w` 的目标年由 `target_idx[w]` 指定 |
| `descriptors` | `(W, n, 3)` | 逐窗口描述子（origin 一致，见 §4） |
| `target_idx` | `(W,)` | 每个窗口的目标年在 `series` 时间轴上的下标 |
| `split_train/val/test` | 各 `(k,)` | **窗口下标**的划分，三者互斥 |
| `pixel_indices` | `(n,)` | 像元在原始网格中的编号 |
| `edge_index` | `(2, E)` | kNN 图（`k=8`），无向边双向存储 |
| `ts_mean`, `ts_std` | 标量 | 标准化统计量，**只用训练期**估计 |

`W` 随协议变化：h=5（`gap=4`）时 train/val/test = 16/4/4；h=1（`gap=0`）时为 20/4/4。

一键核验：

```bash
python scripts/check_dataset.py --data <file.npz> --expect h5   # 或 h1
```

它会检查键、形状、划分互斥、非有限值、边索引越界、`ts_std>0`。

---

## 4. 如何重建

前置：原始产品 → 旧格式 `legacy npz`（含 `series`/`geo_raw`/`pixel_indices`/`years`）。
构建入口是 `filmstgat/data/real.py::build_dataset_v2`：

```bash
# h=5 协议（gap=4）
python -c "
from filmstgat.data.real import build_dataset_v2
build_dataset_v2('<legacy.npz>', 'datasets_v2', n_samples=45041, k=8, seed=42,
                 T_in=10, gap=4, T_out=1)
"
# h=1 协议（gap=0）
python -c "
from filmstgat.data.real import build_dataset_v2
build_dataset_v2('<legacy.npz>', 'datasets_v2_h1', n_samples=45041, k=8, seed=42,
                 T_in=10, gap=0, T_out=1)
"
```

两个协议**只有 `gap` 不同**，其余完全一致。论文中"五年/一年"均指此处的 `gap`。

### 两个必须遵守的构造规则

1. **origin 一致**：窗口 `w` 的描述子只能用它自己输入窗末端（`origin`）之前的数据算。
   若所有窗口共用一套描述子，训练窗会看到目标年之后的信息，这是 R3-1 指出的泄漏。
   实现在 `origin_descriptors(series, origins)`。
2. **标准化只用训练期**：`ts_mean/ts_std` 由 1981–2010 估计，不得用全期。

---

## 5. 校验与版本

本文使用的两个文件：

| 协议 | 文件 | sha256（前 16 位） | 规模 |
|---|---|---|---|
| h=5 | `real_magt_data_v2_clean.npz` | <!-- FILL: sha256sum 前16位 --> | 500 像元子集用于实验，完整 45041 |
| h=1 | `real_magt_data_v2_h1/real_magt_data_v2_clean.npz` | <!-- FILL --> | 同上 |

```bash
sha256sum <file.npz>     # 与上表比对
```

若不一致：先跑 `check_dataset.py` 看契约是否仍满足，再核对 §4 的两个构造规则。
数值上的差异（例如像元顺序）会让结果不可直接比较，请以本文报告的子集与种子重跑。

---

## 6. 已知陷阱

| 陷阱 | 后果 | 检查方式 |
|---|---|---|
| 用 `gap=0` 的文件跑 h=5 实验 | 前瞻距离不对，RMSE 整体偏低 | `check_dataset.py --expect h5` + 核对 `target_idx` 范围 |
| 描述子跨窗口共用 | 泄漏；增益看起来很好 | 打印 `descriptors[0]` 与 `descriptors[-1]` 是否相同 |
| 标准化用了全期统计量 | 轻度泄漏，指标偏乐观 | 核对 `ts_mean/ts_std` 的估计区间 |
| 按年份切分后又随机打乱窗口 | 时间泄漏 | `check_dataset.py` 会报 split 重叠 |
| 把 oracle 探针数据当预测结果 | 结论作废 | 文件名带 `probe`/`oracle` 的一律只能用于诊断 |
