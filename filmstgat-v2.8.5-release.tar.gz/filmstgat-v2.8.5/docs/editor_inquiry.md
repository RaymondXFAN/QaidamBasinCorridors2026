# Presubmission inquiry to the editor — draft

> **Before sending:** replace `[Editor name]`, `[manuscript title]` and the manuscript
> number with the real values. Do not add results that are not in
> `datasets_v2/signal_diagnosis.json`, `runs/e4/aggregate_*.json` or `runs/e2b/analysis/`.

---

**Subject:** Presubmission inquiry — the central claim does not survive the
reviewer-requested re-analysis (manuscript no. 150196)

Dear [Editor name],

We are preparing the revision of manuscript no. 150196, *[manuscript title]*. Before
submitting it, we would like to raise a substantial change of conclusion and ask how you
would prefer us to proceed.

Several of the reviewers' requests concerned the evaluation protocol rather than the
method — in particular the origin-consistency of the conditioning field (R1-3), the seeding
of weight initialisation (R1-7), and whether the reported gains survived a leakage-free
split (R3-1, R3-3). We rebuilt the pipeline accordingly: every descriptor is now taken at
its own window's origin, all five training runs are seeded at initialisation, and the
splits are disjoint in time by construction. We then re-ran the full ablation on the same
500-pixel subset, under both the five-year and the one-year protocol.

**Under the corrected protocol the central claim of the manuscript does not hold.** Four
findings summarise why:

1. Two zero-modelling references nearly coincide: persistence reaches 1.361 °C and
   per-pixel training-period climatology 1.395 °C (−2.5%). A decade of windowed history is
   worth less than three percent of RMSE over a constant per pixel.
2. Every trained configuration reproduces persistence. Across 25 runs the RMSE between model
   output and the persistence forecast is 0.26–1.02 °C at a Pearson correlation of
   0.9974–1.0000.
3. With four test windows the design's minimum detectable effect is 0.091 °C (6.7% of RMSE)
   under the five-year protocol and 0.071 °C (9.0%) under the one-year protocol. Effects of
   the size typically reported for this task (1–3%) lie below what the design can resolve.
4. Full FiLM versus the unconditioned model gives Δ = −0.001 °C, 95% CI [−0.062, +0.060]
   (3/5 seeds positive) at five years, and Δ = +0.029 °C, 95% CI [−0.009, +0.067]
   (4/5 seeds positive) at one year. We do not claim equivalence: a prespecified
   non-inferiority margin of 0.01 °C is not met in 8 of 10 seed-level tests.

We are therefore not able to report the improvement claimed in the submitted version, and we
would not wish to. What we can report is a study of what this benchmark can and cannot
resolve, supported by the same data plus a 24-seed paired difference-in-differences design,
block-bootstrap intervals, and the resolution analysis above. Code, audit log and the
evaluation pipeline are already prepared for release.

**Our question.** Is a manuscript reframed in this way — a negative result on conditioning,
with a quantitative account of the evaluation design's resolution — within scope for the
journal? And would you prefer that we (a) submit it as a revision with an explicit change
note describing the altered conclusion, (b) withdraw and resubmit it as a new manuscript
with a new title and abstract, or (c) handle it differently?

We are happy to send the revised abstract, the full analysis, or the response to reviewers
in advance if that would help you decide.

Thank you for your time and for the reviewers' reports, which are the reason we found this.

Sincerely,

Raymond Xiaohu Fan
on behalf of all authors
[affiliation] · [email]

---

## Notes for us (not for sending)

* Send **before** uploading the revision, not after. If the editor says "resubmit as new",
  the revision portal is the wrong place and we would lose the reviewer continuity.
* Do not phrase this as "the reviewers were right and we were wrong" — it invites a
  decision on the old claim. Phrase it as "the protocol change altered the finding", which
  is what happened.
* Keep the four numbered findings in the email. Editors decide on scope from the abstract
  and the first page; giving them the numbers up front is what makes the inquiry
  answerable in one reply.
* If the answer is (a), the change note in the revision must state the withdrawal of the
  original claim in the first paragraph of the response-to-reviewers, not buried in §5.
