# Manuscript v3 — Sections 3–6 (draft)

**Working title:** *What a permafrost temperature benchmark can and cannot resolve:
zero-modelling floors, persistence collapse, and the resolution limit of the standard
evaluation design*

**Status:** draft v0.3 — §3–§6 (competition probe included). Numbers are frozen from runs of 2026-11-08
(code `filmstgat v2.4.1`, tree hash `71f80b6a`). §6 awaits the five-level overlap sweep.

All RMSE values are in °C, in the physical unit, computed on the same 500-pixel
stratified subset and the same test windows (fingerprint `51f4ab7a6887e681`).

---

## 3. What the zero-modelling floors allow

### 3.1 Two floors that nearly coincide

Before attributing any skill to a learned model, it is necessary to know what skill is
available to a procedure that does no learning at all. We computed three such references
on the identical test windows (Table 2).

*Persistence* — the last observation available at forecast time ($t-\text{gap}-1$) —
attains RMSE = **1.361**. *Per-pixel climatology*, the mean of the training period
(1981–2010) repeated for every target year, attains RMSE = **1.395**. The two differ by
**2.5%**.

The implication is narrow but consequential: on this task, a decade of windowed history is
worth less than three percent of RMSE over a single constant per pixel. Any architecture
whose contribution is expressed as a percentage of RMSE in the low single digits is
therefore competing inside a band that the two trivial references have already occupied.

A third reference, per-pixel linear trend extrapolation, is markedly worse (RMSE = 2.689,
Table 2). Per-pixel slopes estimated over 30 years are dominated by interannual noise, and
extrapolating them over a five-year gap amplifies rather than reduces error. We report it
because trend extrapolation is a common "physically motivated" baseline; on this dataset it
is not a competitive one.

> **Table 2. Zero-modelling floors (h = 5; 500 pixels; 4 test windows, 2015–2018).**
>
> | Reference | RMSE | MAE | R² |
> |---|---|---|---|
> | Persistence (last input observation) | 1.361 | 0.843 | 0.9778 |
> | Per-pixel training-period climatology | 1.395 | 1.061 | 0.9767 |
> | Per-pixel mean + linear trend | 2.689 | 2.013 | 0.9133 |
> | *Oracle pixel level (uses test-period means — not a forecast)* | *0.579* | *0.302* | *0.9960* |
>
> The last row is a diagnostic, not a baseline: it uses information unavailable at forecast
> time and marks the ceiling attainable by a model that knew each pixel's test-period level
> exactly.

### 3.2 Skill decays with forecast lag

To locate where predictability is lost, we forecast the same targets from observations at
lags $k = 1 \ldots 10$ (Table 3). Skill decays monotonically: RMSE rises from 0.778 at one
year to 1.361 at five years, and by $k = 5$ persistence is already worse than climatology
(0.778 vs 1.395 at $k=1$; 1.361 vs 1.395 at $k=5$).

Two readings follow. First, the series *is* predictable at short lags — a one-year
persistence forecast beats climatology by 44%. Second, that predictability is exhausted
within roughly four to five years, i.e. the five-year protocol sits at, or just beyond, the
edge of what the series supports.

We stress that lags shorter than the forecast gap are not available to any model evaluated
under the five-year protocol; they are reported here only to characterise the series.

> **Table 3. Lag profile (h = 5 test targets; diagnostic).**
>
> | lag k | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 10 | climatology |
> |---|---|---|---|---|---|---|---|---|---|---|
> | RMSE | 0.778 | 0.927 | 0.993 | 1.193 | 1.361 | 1.459 | 1.560 | 1.579 | 1.906 | 1.395 |
> | available at forecast time | no | no | no | no | yes | yes | yes | yes | yes | yes |

### 3.3 Variance decomposition — and its limitation

Decomposing the test targets into a between-pixel and a within-pixel component gives
83.02 and 0.34 respectively, i.e. **99.6% of the target variance is "which pixel this is"**
and 0.4% is year-to-year variation about each pixel's level.

This figure is indicative, not decisive, and we state the reason explicitly: it is estimated
from only four test windows. Its internal tension is visible — a within-pixel standard
deviation of 0.58 cannot produce a five-year forecast error of 1.36 unless year-to-year
variability is substantially larger than those four years suggest. We therefore use the
decomposition only to motivate §3.1, and base no claim on the exact 0.4% figure.

---

## 4. What the models actually learn

### 4.1 Collapse to persistence

If persistence is close to optimal, a sufficiently flexible model should approach it. We
therefore measured, for every trained configuration, the distance between its predictions
and the persistence forecast (§4.1).

Across 25 runs under the five-year protocol, the RMSE between model output and the
persistence forecast is **0.26–1.02**, with Pearson correlation **0.9974–1.0000**. The
closest run reproduces persistence to within 0.26 °C at $r = 1.0000$.

This is the expected behaviour of a squared-error learner on a series whose first difference
is dominated by noise: the conditional mean of the next value is close to the current value,
so the minimum-expected-loss solution *is* persistence. Models do not fail to converge to a
better function; persistence is the better function under this loss and this information set.

The consequence for the present study is direct: any mechanism whose intended role is to
*modulate* a learned representation has almost nothing to modulate once the model has
settled on a near-identity map. This reframes the negative result of §5 — it is not that the
conditioning mechanism is weak, but that its target has collapsed.

> **Table 4. Distance between model predictions and the persistence forecast (h = 5).**
>
> | Configuration | RMSE(pred, persistence) | Pearson r | RMSE(pred, truth) |
> |---|---|---|---|
> | standard | 0.26–0.57 | 0.9992–1.0000 | 1.311–1.374 |
> | standard, wider | 0.28–0.57 | 0.9987–0.9998 | 1.290–1.372 |
> | FiLM, additive | 0.61–0.94 | 0.9955–0.9997 | 1.352–1.389 |
> | FiLM, full | 0.43–0.64 | 0.9985–0.9999 | 1.307–1.403 |
> | Descriptor concatenation | 0.54–1.02 | 0.9974–0.9992 | 1.298–1.542 |
>
> Ranges are over five seeds, five configurations (25 runs). The last column is the test-set
> RMSE in °C and is repeated here only to show that every configuration sits within 3% of the
> persistence floor.

### 4.2 External backbones under the same protocol

The same collapse is visible in three independently implemented backbones (STGCN, DCRNN,
PINN) re-run under our protocol rather than quoted from their original papers: none beats
persistence at either horizon (Table 5). All three take a single input channel here — the
dataset provides no exogenous driver — which we regard as a limitation of the comparison
rather than a property of the architectures.

> **Table 5. External backbones, same protocol (5 seeds each).**
>
> | Model | priors | params | h = 5 RMSE | h = 1 RMSE |
> |---|---|---|---|---|
> | Persistence | — | 0 | **1.361** | **0.778** |
> | PINN | no | 4,739 | 1.570 ± 0.230 (+15.4%) | 1.266 ± 0.174 (+62.7%) |
> | STGCN | no | 39,297 | 1.942 ± 0.057 (+42.7%) | 0.961 ± 0.065 (+23.5%) |
> | DCRNN | no | 100,737 | 2.573 ± 0.339 (+89.1%) | 0.804 ± 0.026 (+3.3%) |
>
> A probe confirmed that all three ignore the geological descriptors in their forward pass
> under our configuration (the priors enter only a physics term that is switched off), so
> they are unconditioned baselines and are labelled accordingly.

---

## 5. What the design can resolve

### 5.1 The resolution limit comes first

We compute the minimum detectable effect (MDE) of our own design before reporting any
effect estimate, because an effect smaller than the design's resolution cannot be
established either way.

With four test windows and five seeds, the 95% interval half-width of the paired RMSE
difference is **0.091 °C (6.7% of RMSE)** under the five-year protocol and **0.071 °C
(9.0%)** under the one-year protocol. Effects below these magnitudes are not detectable by
this design, irrespective of how many seeds are added — the binding constraint is the number
of independent test windows, not the number of runs.

### 5.2 Effect estimates

Under the five-year protocol, full FiLM versus the unconditioned model gives
Δ = **−0.001 °C**, 95% CI **[−0.062, +0.060]**, with 3 of 5 seeds positive ($p = 0.96$).
The sign is not consistent, and the interval spans zero in both directions: the comparison is
**undetermined**.

Under the one-year protocol the same comparison gives Δ = **+0.029 °C**, 95% CI
**[−0.009, +0.067]**, with **4 of 5 seeds positive** ($p = 0.10$). The direction is
consistent and the point estimate is a small penalty, but at $n = 5$ seeds it does not reach
significance.

Because the observed effects are of the same order as, or below, the MDE, we do not claim
equivalence. A non-inferiority margin of 0.01 °C was prespecified and is not met in 8 of 10
seed-level tests; reporting a failed non-inferiority test as evidence of equivalence would
be a misreading of the same kind this paper is trying to correct.

### 5.3 What this implies for previously reported gains

Single-digit percentage improvements in RMSE are routinely reported for this class of task.
With a four-window test design, such improvements correspond to 0.01–0.04 °C — **below the
0.07–0.09 °C that the design can resolve**. Under the corrected protocol adopted here
(origin-consistent descriptors, no window overlap between splits), we observe no such
improvement for any of five conditioning configurations or three external backbones.

We therefore report a null result together with the resolution analysis that explains why
the underlying question cannot be settled with the evaluation design in common use, and we
recommend that persistence, the floors of Table 2, and the MDE of §5.1 be reported alongside
any claimed improvement.

> **Table 6. Effect estimates with the design's resolution (5 seeds).**
>
> | Protocol | Comparison | Δ RMSE | 95% CI | seeds positive | p | MDE |
> |---|---|---|---|---|---|---|
> | h = 5 | full FiLM − standard | −0.001 | [−0.062, +0.060] | 3/5 | 0.96 | 0.091 (6.7%) |
> | h = 1 | full FiLM − standard | +0.029 | [−0.009, +0.067] | 4/5 | 0.10 | 0.071 (9.0%) |


---

## 6. Does descriptor overlap explain anything?

### 6.1 A controlled manipulation

The submitted version claimed a design rule: high descriptor–input overlap favours
additive conditioning, low overlap favours multiplicative conditioning. The rule was never
implemented in code, and the descriptors are not independent of the input by construction.
We therefore made overlap a controlled variable inside one task, one dataset and one set of
test windows.

For each window the conditioning field is mixed as
$g(\alpha) = \alpha\, g_{\text{true}} + (1-\alpha)\, g_{\text{perm}}$, where $g_{\text{perm}}$
is the same set of descriptors randomly permuted **across pixels**. The marginal
distribution is untouched; only the spatial correspondence moves, so measured overlap
$\rho$ falls from 0.956 at $\alpha = 1$ to 0.503 at $\alpha = 0$ (chance-corrected
$\rho^{*} = 2\rho - 1$ from $+0.912$ to $+0.006$). Five levels, five seeds each.

### 6.2 No dose–response

The difference between multiplicative and additive conditioning does not track $\alpha$.
Across the five levels the per-seed mean $\Delta$(full − additive) spans 0.023 °C with no
monotonic relation (Spearman $\rho = +0.30$, $p = 0.62$), and no single level reaches
significance at the seed level (smallest $p = 0.28$).

Two levels (α = 0.25 and α = 1.00) have block-bootstrap intervals that exclude zero while
their seed-level tests do not. Following the rule we set out in §5 — that the more
conservative of the two uncertainty accounts governs — we do **not** treat these as
method-level findings.

**We therefore cannot reinstate the design rule in any form.** The defensible statement is
the weaker one: at this sample size, no difference in conditioning form was detected on this
data.

### 6.3 What the larger endpoint contrast does show

A separate contrast with 24 seeds per endpoint and the same manipulation tells a sharper
story at the two extremes:

* at $\alpha = 0$ (descriptors permuted, $\rho = 0.503$): $\Delta$ = −0.002 °C,
  $p = 0.56$ — indistinguishable;
* at $\alpha = 1$ (true descriptors, $\rho = 0.956$): $\Delta$ = +0.015 °C, $p = 0.0023$ —
  multiplicative conditioning is *worse*;
* difference-in-differences: +0.017 °C, 95% CI [+0.009, +0.026], $p_{\text{Holm}} = 0.0003$.

The interpretation we are willing to defend is narrow: **when the descriptors are genuinely
aligned with the input, multiplicative modulation costs about 0.015 °C (1.9% of the 0.784 °C
floor) relative to additive modulation.** It is a cost, not a benefit, and it is small — of
the same order as the resolution limit of §5.

That a 5-level sweep with 5 seeds cannot resolve what a 2-level contrast with 24 seeds can
is itself an instance of the paper's main point: **the power of the design, not the strength
of the mechanism, determines what gets reported.**

> **Table 7. Overlap manipulation.**
>
> | Design | levels | seeds/level | α | ρ | Δ (full − additive) | inference |
> |---|---|---|---|---|---|---|
> | Sweep | 5 | 5 | 0–1 | 0.503–0.956 | range 0.023, Spearman +0.30 (p = 0.62) | no evidence |
> | Endpoint contrast | 2 | 24 | 0 | 0.503 | −0.002 (p = 0.56) | indistinguishable |
> | Endpoint contrast | 2 | 24 | 1 | 0.956 | +0.015 (p = 0.0023) | small penalty |
> | DiD (α=1 vs α=0) | — | 24 | — | — | +0.017 [+0.009, +0.026] | p_Holm = 0.0003 |

### 5.4 Why conditioning is not used: a competition probe

The negative result invites an objection that tuning cannot settle: perhaps the conditioning
mechanism is too weak to carry information, in which case the absence of an effect says
nothing about the data. We separated the mechanism from the data with two probes.

**Probe 1 — an oracle descriptor.** For one run only, every descriptor was replaced by the
per-pixel statistics of the **test period**, a deliberate leak no forecast could obtain. The
substitution is verified to have taken effect (the descriptor field is identical across windows
in the oracle file and varies between windows in the real file; predictions shift by up to
0.202 °C). With the input window available, the leak changed nothing: 1.340 against 1.344 for
the unconditioned model, where an oracle level would have permitted ≈0.58.

**Probe 2 — remove the competing path.** We then zeroed the input window, leaving the
descriptors as the only route to the target, in a 2×2 with two controls (Table 8).

Three findings follow.

First, the conditioning branch is not weak. With neither input nor descriptors the model
predicts the mean (RMSE 9.000 against $\mathrm{sd}(y) = 9.13$); with the input removed and the
descriptors kept, it reaches **1.140** (oracle) and **1.507** (origin-consistent) — reductions
of 7.86 and 7.49 °C. An unconditioned model under the same zero-input condition stays at 8.999,
so it is the descriptors doing the work, not an artefact of removing the input.

Second, the branch is suppressed by competition. Adding the input back *raises* the error to
1.340, although the same leaking descriptor is still present: a branch that was carrying almost
all of the model's skill ceases to be used as soon as another path can explain the target.

Third, the leak is worth more than the entire input window: 1.140 against 1.340. Any study
that allows descriptor information to enter from the target era is therefore not making a small
error of degree; it is substituting a stronger predictor for the one under study.

A control establishes that the pathway learns at all: with the input held constant and the
target defined as a function of the descriptor alone ($y_i = 2g_i$), full conditioning fits to
RMSE **0.097** on the descriptors it saw and **0.170** on a fresh draw ($\mathrm{sd}(y)=1.96$),
while the unconditioned model stays at **1.86** — indistinguishable from predicting the mean.

We read these results as an **optimisation** finding rather than a statement about the data.
The data-level claim in this paper rests on the zero-modelling floors of §3, not on the models'
failure to use the descriptors; §4.1's collapse is then not only "persistence is close to
optimal" but "the identity solution occupies the model, and the conditioning branch is never
exercised". We note the boundary of this evidence: one architecture, one dataset, one horizon,
and the oracle residual (1.140 rather than 0.579) is left uninterpreted, since the mapping is
learned on training windows where the same descriptors are paired with earlier targets.

> **Table 8. Competition probe (h = 5, 5 seeds; RMSE in °C).**
>
> | Condition | input window | descriptors | RMSE | reference |
> |---|---|---|---|---|
> | C1 baseline | available | origin-consistent | 1.344 | persistence 1.361 |
> | C2 oracle | available | **test-period (leak)** | 1.340 | would permit ≈0.579 |
> | C3 zero-x | **zeroed** | **test-period (leak)** | **1.140** | |
> | C4 zero-x, no descriptors | zeroed | zeroed | **9.000** | sd(y) = 9.13 |
> | C5 zero-x | zeroed | origin-consistent | 1.507 | |
> | C3 with `standard` backbone | zeroed | test-period (leak) | 8.999 | control: not used without the pathway |
> | Pathway control ($x$ constant, $y=2g$) | constant | $y$-defining | 0.097 seen / 0.170 new | sd(y) = 1.96; unconditioned 1.86 |
>
> C2 and C3 are diagnostics, not forecasts: their descriptors contain test-period information.
> They bound what the mechanism could have achieved, and are never reported as results.

---

## Claims ledger — what may and may not be written

| Statement | Status |
|---|---|
| Persistence and climatology nearly coincide (1.361 vs 1.395) | ✅ supported |
| Skill decays monotonically with lag; exhausted by ~5 years | ✅ supported |
| Models reproduce persistence (r ≥ 0.9974) | ✅ supported |
| FiLM shows no improvement at h = 5 | ✅ "undetermined", not "equivalent" |
| FiLM shows a consistent small penalty at h = 1 | ⚠️ "consistent direction, not significant at n=5" |
| FiLM is equivalent to standard | ❌ non-inferiority fails; must not be written |
| Previously reported gains came from overlap leakage | ❌ not tested; do not write |
| Conditioning form shows a dose–response in ρ | ❌ no evidence (Spearman +0.30, p = 0.62) |
| The conditioning pathway is functional (learns from descriptors alone) | ✅ control: RMSE 0.097 / 0.170 vs sd 1.96 |
| Even an oracle (leaking) descriptor is not exploited while the input is available | ✅ Δ = 0.004 °C, predictions shift ≤ 0.20 °C |
| The pathway is used when it is the only route (9.000 → 1.140) | ✅ competition probe, 5 seeds |
| Conditioning is suppressed by a competing input path (1.140 → 1.340) | ✅ same descriptors, input restored |
| Therefore the limitation is optimisation, not representation | ✅ but scope: one architecture, one dataset, h=5 |
| The oracle descriptor is worth more than the input window (1.140 < 1.340) | ✅ |
| This explains previously reported gains in the literature | ⚠️ plausible, not tested on other papers |
| Full FiLM costs ~0.015 °C vs additive at ρ = 0.956 | ✅ 24 seeds, DiD p_Holm = 0.0003 |
| The 0.4% within-pixel share is a population property | ❌ n = 4 windows; indicative only |
| 99.6% of variance is between-pixel | ⚠️ same caveat |

---

## Open items before submission

1. §6 is complete but reports **no evidence** of a dose–response; the endpoint contrast with
   24 seeds carries the only defensible claim. Do not describe it as a trend.
2. Figures: F1 floors + lag profile; F2 pred-vs-persistence scatter (r = 1.0000);
   F3 forest plot of per-seed Δ with the MDE band; F4 Δ vs α.
3. §1–2 need rewriting: the introduction currently promises a method advantage that §5
   withdraws. The retraction of the earlier claim must be stated explicitly, not implied.
4. References: persistence/random-walk forecasting, equivalence testing and MDE reporting,
   benchmark-leakage literature. All to be verified against real records — none invented.
5. Data and code release (GitHub + Zenodo) updated to v2.4.1 with the audit log.
