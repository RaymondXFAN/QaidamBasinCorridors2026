# 竞争实验 runbook — 明早一条命令

**目的**：回答 §5.4 留下的那个问题——模型不用描述子，是**数据里没有信息**，还是
**x 通道把答案解释掉了**（条件化分支拿不到梯度）。

---

## 1. 设计（2×2 + 两个对照）

全部 h=5 协议、`n_sub=500`、`stratified`、5 seeds、250 epochs，同一批测试窗口。

| 条件 | 输入 x | 描述子 | 已有/新跑 | 作用 |
|---|---|:--|:--|:--|
| C1 | 正常 | origin（正确） | 已有 1.344 / 1.340 | 论文基线 |
| C2 | 正常 | **oracle（泄漏）** | 已有 1.340 | 有信息也不用 |
| **C3** | **置零** | oracle | **新跑** | **关键：撤掉竞争** |
| C4 | 置零 | 置零 | 新跑 | 对照：确认零输入=无信息 |
| C5 | 置零 | origin | 新跑 | 对照：真实描述子在无竞争时的价值 |

C3 是决定性的：**同一个模型、同一批泄漏描述子，只把 x 拿走。**

---

## 2. 执行

```bash
cd /root/autodl-tmp/revision_v2
# 代码 v2.7.0 已在 revision_v2/filmstgat-v2.7.0 下

bash filmstgat-v2.7.0/scripts/run_probe_competition.sh
```

默认后台跑（nohup，合盖不断）。约 **12 分钟 / 20 个 run**。

进度与汇总：

```bash
ls -d /root/autodl-tmp/revision_v2/runs/probe/*/*/ | wc -l     # 目标 20
tail -f /root/autodl-tmp/revision_v2/logs/probe_*.log
python filmstgat-v2.7.0/scripts/summarize_probe.py \
  --runs /root/autodl-tmp/revision_v2/runs/probe
```

前台跑（想实时看）：`BG=0 bash filmstgat-v2.7.0/scripts/run_probe_competition.sh`

---

## 3. 判读（**事先定好，不许事后改**）

| # | 观测 | 结论 | 论文怎么写 |
|:--|:--|:--|:--|
| **A** | C2 − C3 > 0.15，且 C3 ≪ C4 | 竞争解释成立：撤掉 x 之后，同一架构立刻用上描述子 | "条件化分支在存在近乎最优的竞争通路时学不到梯度" —— 这是**优化层面**的发现 |
| **B** | \|C3 − C4\| < 0.1 | 撤掉竞争也没起色 | 描述子在该架构下始终未被利用；§5.4 必须降级为"未观察到利用"，不能再推"通路可用" |
| **C** | \|C3 − C5\| < 0.1 且 C4 − C3 > 0.1 | 被利用的是**泄漏**，真实描述子无额外价值 | 强化 §3 的地板结论：数据本身没有可学信息 |
| **D** | 差异都在 0.1 以内 | 无清晰结论 | 按实测值如实写，禁止外推 |

⚠️ **A 与 C 可以同时成立**（C3 既显著低于 C2，又与 C5 接近）。那就两条都写。

---

## 4. 结果怎么落进论文

**若判为 A（竞争成立）** —— 替换 §5.4 最后一段：

> A candidate explanation, which we state as a hypothesis rather than a finding: the input
> window supplies a near-optimal solution (the persistence copy), so the modulation branch
> receives little gradient and never has to be used. **We tested this directly**: with the
> input window zeroed and the descriptors unchanged, the same architecture exploits the
> descriptors and reaches RMSE {C3:.3f}, against {C2:.3f} when the input is available. The
> limitation is therefore one of optimisation under competition, not of what the mechanism
> can represent.

**若判为 B** —— §5.4 的结论句改成：

> The pathway learns a descriptor-to-output mapping when it is the only route to the answer,
> but it is **not used even when the competing input path is removed**. We therefore do not
> infer anything about the information content of the descriptors from model behaviour; the
> data-level claim in §3 rests on the zero-modelling floors alone.

这句话要保留——**无论 A 还是 B，"数据里有没有信息"都只能由 §3 的地板来支撑，不能由模型行为来支撑。** 这是全篇最容易被攻的一点，先把话说明白。

---

## 5. 已知坑（我都提前处理了）

| 坑 | 处理 |
|---|---|
| 零输入会让 `standard` 退化成输出常数 | 预期如此，正好作为"零输入=无信息"的验证；C3 里同时跑 `standard` |
| 描述子置零后 `make_splits` 的标准化会除 0 | 代码里 `d_std + 1e-8`，已防；且置零后整列方差为 0，标准化结果是常数，不影响 |
| 混淆"泄漏被利用"与"真实信息被利用" | 专门设 C5 隔离 |
| 事后挑说法 | 判读规则写死在 `summarize_probe.py`，跑完直接打印 A/B/C/D |

---

## 6. 时间预算

| 步骤 | 设备 | 耗时 |
|---|---|---|
| 构造 3 个变体 | CPU | < 10 s |
| C3（2 配置 × 5 seed） | GPU | ~5 min |
| C4 / C5（各 5 seed） | GPU | ~7 min |
| 汇总 | CPU | 1 s |

**总计约 12 分钟。** 跑完即可关机。
