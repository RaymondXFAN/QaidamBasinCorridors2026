# Manuscript v3 — Abstract, title, figure captions

---

## Title (recommended)

**What a permafrost temperature benchmark can and cannot resolve: zero-modelling floors,
persistence collapse, and the resolution limit of the standard evaluation design**

*Alternative, if the editor prefers a method-forward framing:*
Descriptor conditioning does not improve multi-year ground-temperature forecasts — and the
design that says otherwise cannot resolve the difference.

---

## Abstract (draft v1, 249 words)

Forecasting near-surface ground temperature a few years ahead is a common testbed for
graph-based spatiotemporal models conditioned on geological priors. We revisit that task under
a protocol corrected in two respects: descriptors are taken at each window's own origin, and
weight initialisation is seeded before the model is constructed. Under this protocol, five
conditioning configurations — unconditioned, parameter-matched, descriptor concatenation,
additive modulation and full feature-wise linear modulation — produce no detectable
improvement at either a one-year or a five-year forecast horizon.

We then ask why, and find that the benchmark rather than the architecture is the binding
constraint. (i) Two zero-modelling references nearly coincide: persistence reaches 1.361 °C
and per-pixel training-period climatology 1.395 °C, so a decade of annual history is worth
less than three percent of RMSE over a constant per pixel. (ii) Every trained configuration,
and three external backbones re-run in the same harness, reproduces persistence: the
correlation between model output and the persistence forecast is 0.9974–1.0000. (iii) With
four test windows the minimum detectable effect is 0.091 °C (6.7% of RMSE) at the five-year
horizon and 0.071 °C (9.0%) at one year — larger than the single-digit improvements typically
reported for this task. Full conditioning therefore compares as undetermined at five years
(Δ = −0.001 °C, 95% CI [−0.062, +0.060]) and as a consistent small penalty at one year
(Δ = +0.029 °C, 4 of 5 seeds positive, p = 0.10); equivalence could not be established in
either protocol.

A controlled manipulation of descriptor–input overlap yields no dose–response (Spearman
+0.30, p = 0.62), so the design rule proposed in the earlier version of this work is
withdrawn. We recommend reporting persistence and the design's minimum detectable effect
alongside any claimed improvement on this class of benchmark, and release the code, result
files and audit log.

**Keywords:** permafrost ground temperature; spatiotemporal forecasting; feature-wise linear
modulation; persistence baseline; minimum detectable effect; benchmark leakage

---

## Figure captions

**F1 — Zero-modelling floors and the decay of skill with forecast lag.**
(a) RMSE of three zero-modelling references on the identical test windows, with the oracle
pixel level shown for scale only (it uses information unavailable at forecast time). Persistence
and per-pixel training-period climatology differ by 2.5%, so a decade of history is worth
little over a constant per pixel. (b) RMSE of the persistence forecast as a function of lag
k = 1…10; the dotted line marks the forecast gap of the five-year protocol, and lags shorter
than it are not available to any model evaluated under that protocol.

**F2 — Model output against the persistence forecast.**
Each panel shows one configuration (seed 42) on the test windows. Points on the diagonal are
predictions that equal persistence; r and the RMSE between prediction and persistence annotate
each panel. Correlations of 0.9974–1.0000 across all 25 runs indicate that the models have
converged on the persistence solution rather than on a different function of the inputs.

**F3 — Effect estimates against the resolution of the design.**
Per-seed differences (full conditioning minus unconditioned model) with 95% intervals, for the
five-year (left) and one-year (right) protocols; the shaded band is the design's minimum
detectable effect (±MDE). The pooled estimate is given on the y-axis label. At five years the
signs are inconsistent and the pooled interval spans zero; at one year four of five seeds are
positive but the interval includes zero at n = 5.

**F4 — Overlap dose–response.**
Per-seed mean difference between multiplicative and additive conditioning as descriptor–input
overlap α is swept from 0 (descriptors permuted across pixels) to 1 (true descriptors). Marginal
information is held constant, so only spatial correspondence changes. Vertical bars are
block-bootstrap intervals on the ensemble prediction; their centres need not coincide with the
per-seed means because they are different estimators. No monotonic relation is present
(Spearman +0.30, p = 0.62).

---

## Notes on the abstract

* The first sentence states the task and the method family; the second states the protocol
  correction; the third delivers the null. **No sentence promises an improvement.**
* Numbers appear in the second half only, after the claim they support.
* "undetermined" and "consistent small penalty" are used deliberately in place of "no
  difference" — §5.2 explains why equivalence was not established.
* The earlier version's design rule is described as *withdrawn*, not as *not supported*: we
  cannot reinstate it, and hedging the verb would misrepresent that.
* Word count 249; if the journal caps at 200, cut (i)–(ii) to a single sentence and keep the
  MDE figure, which is the load-bearing number.
