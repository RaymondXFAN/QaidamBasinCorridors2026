# Results map — which command produces which number

Every table and figure in the manuscript traces to exactly one command and one file.
Nothing in this repository is a number typed by hand.

Run with `export ROOT=/your/workdir` first.

---

## Tables

| Manuscript item | Command | File it reads | Notes |
|---|---|---|---|
| **Table 2** zero-modelling floors | `bash run_all.sh signal` | `datasets_v2/signal_diagnosis.json` → `floors` | persistence 1.361, climatology 1.395, trend 2.689, oracle 0.579 |
| **Table 3** lag profile | same command | same file → `lag_profile` | lags 1–10; lags < gap+1 are diagnostic only |
| **Table 4** collapse to persistence | `bash run_all.sh e1` then `bash run_all.sh signal` | `runs/e1/*/predictions.npz` + dataset | per-run `rms(pred−persistence)` and Pearson r |
| **Table 5** external backbones | `bash run_all.sh e5` and `bash run_all.sh e5h1` | `runs/e5/metrics_e5.json`, `runs/e5h1/metrics_e5h1.json` | includes `uses_priors` per model (all `no`) |
| **Table 6** effect estimates + MDE | `bash run_all.sh e4agg` | `runs/e4/aggregate_*.json` | two-level pooling; MDE in `mde.mde` |
| **Table 7** overlap manipulation | `bash run_all.sh e2` (sweep) and `bash run_all.sh e2b` + `analyze` | `runs/e2/e2_summary.json`, `runs/e2b/analysis/` | sweep gives no dose–response; endpoints give the DiD |
| **Table 8** competition probe | `bash scripts/run_probe_competition.sh` then `python scripts/summarize_probe.py` | `runs/probe/*/metrics.json`, `runs/e1oracle/*/metrics.json` | C2 read from `runs/e1oracle` as fallback |

## Figures

| Figure | Command | Reads |
|---|---|---|
| **F1** floors + lag profile | `bash run_all.sh figures` (`--only floors`) | `signal_diagnosis.json` |
| **F2** collapse scatter | same (`--only collapse`) | `runs/e1/<cfg>_seed42/predictions.npz` + dataset |
| **F3** effect vs resolution | same (`--only effects`) | `runs/e4/aggregate_*.json` |
| **F4** overlap dose–response | same (`--only dose`) | `runs/e2/e2_summary.json` |
| supporting four | same (`synthetic`, `real`, `overlap`, `split`) | stage summaries |

## Diagnostics that are not manuscript items

| Purpose | Command | Output |
|---|---|---|
| adapter shapes for external baselines | `bash run_all.sh probe` | stdout only |
| does the conditioning pathway learn at all | `python scripts/probe_film_learnability.py` | stdout only |
| dataset contract | `python scripts/check_dataset.py --data <npz>` | stdout only |
| archive self-audit | `python scripts/repro_audit.py` | stdout only |
| bundle results for release | `python scripts/collect_results.py --runs $ROOT --out results` | `results/MANIFEST.json` |

## Rebuilding without a GPU

```bash
ROOT=results bash run_all.sh figures
ROOT=results bash run_all.sh tables
```

`results/` holds every `metrics.json`, `predictions.npz` and `run_manifest.json` of the
reported runs (≈ 6 MB, 1000+ files), with a per-file SHA-256 in `results/MANIFEST.json`.
