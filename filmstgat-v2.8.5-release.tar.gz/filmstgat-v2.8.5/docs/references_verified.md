# References — verified entries only

**规则：只收录本次联网核验过的条目。字段未核实的用 `⚠ confirm` 标出，投稿前必须补齐；一条都不许凭记忆写。**

核验时间：2026-11-08

---

## A. 已核验，可直接引用

### [R1] FiLM — 条件化机制
Perez, E., Strub, F., de Vries, H., Dumoulin, V., & Courville, A. (2018).
*FiLM: Visual Reasoning with a General Conditioning Layer.*
Proceedings of the AAAI Conference on Artificial Intelligence, **32**(1), 3942–3951.
arXiv:1709.07871 · DOI for the AAAI proceedings volume ⚠ confirm (AAAI-18 Article No. 483)
**用途**：§1 引入 FiLM；§2.3 说明 additive / multiplicative 两种调制形式。

### [R2] STGCN — 时空图卷积
Yu, B., Yin, H., & Zhu, Z. (2018).
*Spatio-Temporal Graph Convolutional Networks: A Deep Learning Framework for Traffic Forecasting.*
Proceedings of the 27th International Joint Conference on Artificial Intelligence (IJCAI), 3634–3640. ⚠ confirm page range
**用途**：§2.4 / Table 5 外部基线。

### [R3] DCRNN — 扩散卷积循环网络
Li, Y., Yu, R., Shahabi, C., & Liu, Y. (2018).
*Diffusion Convolutional Recurrent Neural Network: Data-Driven Traffic Forecasting.*
International Conference on Learning Representations (ICLR). ⚠ confirm venue + arXiv id (1707.01926 to be checked)
**用途**：同上。

### [R4] Graph WaveNet
Wu, Z., Pan, S., Long, G., Jiang, J., & Zhang, C. (2019).
*Graph WaveNet for Deep Spatial-Temporal Graph Modeling.*
IJCAI 2019 · arXiv:1906.00121（已核验 arXiv 编号存在）
**用途**：§2.4 讨论自适应邻接矩阵与长程时间卷积（可选）。

### [R5] 冻土地温的深度学习预测（最相关的前作）
Liu, Y., Ran, Y., Li, X., Che, T., & Wu, T. (2023).
*Multisite evaluation of physics-informed deep learning for permafrost prediction in the Qinghai-Tibet Plateau.*
**Cold Regions Science and Technology, 216, 104009.** DOI: 10.1016/j.coldregions.2023.104009
**用途**：§1 说明该任务的现有方法与量级；§2.4 的物理信息基线（PI-LSTM / GIPL2）来源。

### [R6] 朴素基线在预测竞赛中的地位
Makridakis, S., Spiliotis, E., & Assimakopoulos, V. (2018).
*The M4 Competition: Results, findings, conclusion and way forward.*
**International Journal of Forecasting, 34(4), 802–808.** DOI: 10.1016/j.ijforecast.2018.06.001
**用途**：§3.1 —— 支撑"必须报告 naive/persistence 参照"这一做法。
配套：Makridakis, Spiliotis & Assimakopoulos (2020), *The M4 competition: 100,000 time series and 61
forecasting methods*, IJF **36**(1), 54–74（⚠ confirm page range）。
**用途**：§3.1 / §5.3 —— 组合与简单基线常常击败复杂方法。

### [R7] 等价检验（TOST）
Lakens, D. (2017).
*Equivalence Tests: A Practical Primer for t Tests, Correlations, and Meta-Analyses.*
**Social Psychological and Personality Science, 8(4), 355–362.** DOI: 10.1177/1948550617697177 · PMID 28736600
**用途**：§5.2 —— 为什么 p > 0.05 不能写成"无差异"；非劣性界必须预设。

### [R8] 泄漏与可复现性
Kapoor, S., & Narayanan, A. (2023).
*Leakage and the reproducibility crisis in machine-learning-based science.*
**Patterns, 4(9), 100804.** DOI: 10.1016/j.patter.2023.100804
**用途**：§1.1 / §5.3 —— 泄漏导致的过度乐观结论在 17 个领域、294 篇论文中出现；本文属于该谱系的一个实例。

---

## B. 需要补检索的类别（尚未核验，**不得先写进正文**）

| 需求 | 建议检索式 | 用在哪 |
|---|---|---|
| 冻土/MAGT 观测与变化背景 | `mean annual ground temperature Qinghai-Tibet Plateau warming trend` | §1 第一段 |
| 青藏高原 MAGT 空间数据集 | `QTP permafrost MAGT dataset 1 km product` | §2.1 数据来源（必须写明原始产品与版本） |
| 块自助法 / 空间分块重采样 | `block bootstrap spatial dependence confidence interval` | §2.5 |
| 环境预测中的随机游走/持久性基线 | `persistence forecast benchmark hydrology random walk` | §3.1 加强 |
| 深度学习预测的效应量/功效报道 | `minimum detectable effect reporting machine learning benchmarks` | §5.1 |

> 备注：`[R2]` 的页码、`[R3]` 的会议卷期、`[R6]` 配套文献的页码需要在投稿前逐一补齐。
> 补齐方式：查 DOI 落地页或出版社页面，不要用二手引用列表。

---

## C. 与本文结论直接冲突、必须正面处理的两点

1. **原稿的增益**：v11 报告了描述子条件化带来的改进。新稿 §1.1 已明确撤回。参考文献里若有引用
   支持"该机制有效"的文献，需要在 Discussion 里说明为何本文未能复现（协议不同），而不是回避。
2. **MAGT 的可预测性**：若后续检索到"用历史序列预测 MAGT 一年/五年"且报告了显著优于
   persistence 的工作，必须在 Discussion 中正面对比其协议（尤其：窗口是否重叠、描述子取哪个
   origin、测试集是否与训练期同时段）。这是本文最容易被攻击的地方。
