# Reproducing the results / 复现指南

Everything below is executed from the repository root. Stage names map to
`bash run_all.sh <stage>`; the raw commands are shown as well, because a
reviewer may want to change a seed or a subset size.

以下命令均在仓库根目录执行。`bash run_all.sh <stage>` 即对应右侧原始命令。

---

## 0. Environment

```bash
pip install -r requirements.txt
bash run_all.sh check          # offline suites, ~10 s, no GPU
```

Recorded environment for the reported results:

| item | value |
|:--|:--|
| GPU | NVIDIA RTX 4090 D (24 GB) |
| torch | 2.6.0+cu124 |
| numpy | 2.4.6 (server) / 1.26.4 (CPU checks) |
| scipy | 1.18.0 |

The offline suites pass on both numpy 1.26 and 2.x; the synthetic generator is
identical under both because it uses the legacy `np.random` MT19937 stream.

---

## 1. Datasets

```bash
bash run_all.sh data
```

Under the hood:

```bash
python scripts/build_dataset_v2.py --legacy <DATA_ROOT>/datasets/processed/real_magt/real_magt_data.npz \
    --out <ROOT>/datasets_v2    --T-in 10 --gap 4 --T-out 1     # 5-year protocol
python scripts/build_dataset_v2.py --legacy <same> \
    --out <ROOT>/datasets_v2_h1 --T-in 10 --gap 0 --T-out 1     # 1-year protocol
python scripts/regen_synthetic.py --out <ROOT>/datasets_synth
python scripts/build_synth_v2.py --raw <ROOT>/datasets_synth/qaidam_inSAR.npz \
    --out <ROOT>/datasets_synth_v2
```

Expected artefacts:

| artefact | property |
|:--|:--|
| `datasets_v2/real_magt_data_v2_clean.npz` | 45,041 pixels, 24 windows, split 16/4/4 |
| `datasets_v2_h1/...` | same pixels, 1-year protocol |
| `datasets_synth/qaidam_inSAR.npz` | 47 nodes × 120 months × 12 features, 96 windows |
| `datasets_synth_v2/synth_v2.npz` | 96 windows, split 66/6/24, 212 edges |

Known SHA-256 (printed by the scripts, not asserted — a mismatch is meant to be
visible):

| file | sha256 |
|:--|:--|
| `datasets_v2/real_magt_data_v2_clean.npz` | `d319c9a3ef7ad07e0a1fee14300a7b888cae49982838a773fa3d612c893c215e` |
| `datasets_synth/qaidam_inSAR.npz` | `75d92d2e149477b6e5ea2f3e02f3aca03424cb1cfe1cd7b3a0e3d291ed02fe70` |
| `datasets_synth_v2/synth_v2.npz` | `db3382ad99212ead15c0ddace43ad3b250625aff04077cf0aa6420d86596db21` |

The synthetic hash is **stable by construction**: `scripts/regen_synthetic.py`
prints it, and regenerating on a second machine reproduces it byte-for-byte.
Record the hash you obtain in your own run; if it differs, stop and report it
rather than proceeding.

---

## 2. Experiments

| stage | command | runs | wall time (RTX 4090D) |
|:--|:--|--:|--:|
| `e1` | `python filmstgat/experiments/e1_info_matched.py --data <v2 npz> --out runs/e1` | 25 | ~25 min |
| `e2` | `python filmstgat/experiments/e2_overlap_sweep.py --data <h1 npz> --out runs/e2 --alphas 0,0.25,0.5,0.75,1` | 50 | ~30 min |
| `e2b` | `... --alphas 0,1 --seeds 24` | 96 | ~60 min |
| `e3` | `python filmstgat/experiments/e3_naive_baselines.py --data <h1 npz> --out runs/e3` | 0 (analytic) | <1 min |
| `synth` | `python filmstgat/experiments/e1_synthetic.py --data <synth npz> --out runs/e1synth` | 25 | ~25 min (800 epochs) |
| `analyze` | `python scripts/analyze_e2b.py --runs runs/e2b` | 0 | <5 s |

All long stages go through `nohup` (see `BG=1`), so an SSH drop does not kill
them. Each run writes `predictions.npz`, `metrics.json` and `run_manifest.json`.

---

## 3. What to check when a number looks off

1. **Same test set?** `run_manifest.json` records the window indices; compare
   them, not the RMSE.
2. **Units.** `metrics.json` carries `units: physical`. If RMSE is ~1.0 on real
   data, something was computed in normalised space.
3. **Determinism.** Re-run one seed twice; `predictions.npz` must be identical.
   `tests/test_torch.py::test_determinism` pins this.
4. **Chance level of rho.** A fully permuted conditioning field gives
   `rho ≈ 0.5`, not 0 (see `filmstgat/eval/overlap.py`). If you see 0, the
   rasterisation is broken.

---

## 4. Regenerating a single table

Every manuscript table maps to one JSON:

| table | source |
|:--|:--|
| executable configuration (S1) | any `run_manifest.json` (config block) |
| window manifest (S2) | `datasets_*/window_manifest_v2.csv` |
| conditioning ablations | `runs/e1/summary.json` |
| overlap sweep / endpoint contrast | `runs/e2/table_e2.md`, `runs/e2b/analysis/analysis.md` |
| naive baselines | `runs/e3/*.json` |
| synthetic benchmark | `runs/e1synth/table_e1_synth.md` |

Figures must be plotted from these files, never from hard-coded numbers — that
is how Table 5 drifted out of sync in the original submission.

### Table 5 — external baselines (one command)

```bash
bash run_all.sh probe     # ~10 s, no training; refuse to continue if it fails
bash run_all.sh e5        # STGCN / DCRNN / PINN, h=5, 5 seeds each
bash run_all.sh e5h1      # same three, h=1 protocol
```

`runs/e5/metrics_e5.json` carries `uses_priors` per model. **All three legacy
baselines report `no` in our protocol** (their priors live in the physics loss,
which is switched off), so Table 5 must label them unconditioned. The script
also writes a test-set fingerprint; two result files with different fingerprints
are not comparable and the table generator will refuse to merge them.

---

*Raymond Xiaohu Fan*
