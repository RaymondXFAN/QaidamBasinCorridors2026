# results/

每次 run 的 `metrics.json`、`predictions.npz` 与 `run_manifest.json`，以及各级汇总。
共 1084 个文件，5.7 MB。逐文件 sha256 见 `MANIFEST.json`。

用它重建论文的全部图表（**不需要 GPU、不需要原始数据**）：

```bash
ROOT=results bash run_all.sh figures
ROOT=results bash run_all.sh tables
```

`predictions.npz` 里是物理单位（°C）的预测与真值，形状 `(test_windows, n_pixels)`，可直接与 `metrics.json` 中的指标对照复核。
