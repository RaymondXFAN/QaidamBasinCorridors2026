# Synthetic benchmark — statistics

reference (persistence) RMSE = 0.4951 °C, n = 5 seeds, MDE at 80% power, two-sided alpha = 0.05

## A. Each configuration vs persistence (one-sample t on per-seed RMSE)

| config | RMSE | Δ (°C) | Δ (%) | p | p (Holm) | MDE (°C) |
|:--|--:|--:|--:|--:|--:|--:|
| standard | 0.4988 ± 0.0026 | +0.0037 | +0.74% | 0.0350 | 0.1234 | 0.0044 |
| standard_wider | 0.4979 ± 0.0034 | +0.0028 | +0.57% | 0.1420 | 0.1420 | 0.0058 |
| concat_info | 0.4970 ± 0.0014 | +0.0019 | +0.38% | 0.0368 | 0.1234 | 0.0023 |
| film_add | 0.5014 ± 0.0040 | +0.0064 | +1.28% | 0.0247 | 0.1234 | 0.0068 |
| film_full | 0.5013 ± 0.0041 | +0.0062 | +1.25% | 0.0281 | 0.1234 | 0.0069 |

## B. Configuration vs configuration (paired t, same seed)

| A | B | Δ = A − B (°C) | sd(Δ) | r | p | p (Holm) | MDE (°C) |
|:--|:--|--:|--:|--:|--:|--:|--:|
| standard | standard_wider | +0.0009 | 0.0039 | +0.19 | 0.6454 | 1.0000 | 0.0066 |
| standard | concat_info | +0.0018 | 0.0033 | -0.32 | 0.2918 | 1.0000 | 0.0056 |
| standard | film_add | -0.0027 | 0.0035 | +0.52 | 0.1633 | 1.0000 | 0.0059 |
| standard | film_full | -0.0025 | 0.0055 | -0.30 | 0.3641 | 1.0000 | 0.0093 |
| standard_wider | concat_info | +0.0009 | 0.0041 | -0.32 | 0.6376 | 1.0000 | 0.0069 |
| standard_wider | film_add | -0.0035 | 0.0068 | -0.65 | 0.3081 | 1.0000 | 0.0114 |
| standard_wider | film_full | -0.0034 | 0.0067 | -0.59 | 0.3240 | 1.0000 | 0.0113 |
| concat_info | film_add | -0.0045 | 0.0038 | +0.34 | 0.0582 | 0.5823 | 0.0064 |
| concat_info | film_full | -0.0043 | 0.0049 | -0.47 | 0.1199 | 1.0000 | 0.0082 |
| film_add | film_full | +0.0002 | 0.0058 | -0.00 | 0.9539 | 1.0000 | 0.0097 |

## Verdict

- Worse than persistence at Holm-corrected alpha = 0.05: none.
- Detectable differences between configurations: none.
- Largest config-vs-config difference: concat_info − film_add = -0.0045 °C, i.e. 0.70× its MDE (0.0064 °C).
- All observed differences lie BELOW the detection floor. This is a statement about our design, not evidence that the models are equivalent.
