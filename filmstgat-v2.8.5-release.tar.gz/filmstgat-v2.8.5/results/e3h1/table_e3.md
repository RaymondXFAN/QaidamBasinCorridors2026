| Model | RMSE (°C) | MAE (°C) | R² | n |
|---|---|---|---|---|
| persistence | 0.778 | 0.441 | 0.9927 | 2000 |
| trend_extrapolation | 0.909 | 0.523 | 0.9901 | 2000 |
