# e1 — conditioning ablations, statistics

seeds used: [42, 43, 44, 45, 46] (n = 5)
reference (persistence): 1.3605 °C

## A. Each configuration vs persistence (one-sample t; no pairing exists)

| config | RMSE | Δ (°C) | Δ (%) | p | p (Holm) | MDE (°C) |
|:--|--:|--:|--:|--:|--:|--:|
| concat_info | 1.4141 ± 0.0926 | +0.0536 | +3.94% | 0.2649 | 1.0000 | 0.1557 |
| film_add | 1.3679 ± 0.0153 | +0.0074 | +0.54% | 0.3412 | 1.0000 | 0.0258 |
| film_full | 1.3433 ± 0.0373 | -0.0172 | -1.26% | 0.3618 | 1.0000 | 0.0627 |
| standard | 1.3435 ± 0.0304 | -0.0170 | -1.25% | 0.2797 | 1.0000 | 0.0511 |
| standard_wider | 1.3438 ± 0.0360 | -0.0167 | -1.22% | 0.3588 | 1.0000 | 0.0605 |

## B. Configuration vs configuration (paired, same seeds)

| A | B | Δ = A − B (°C) | sd(Δ) | r | p | p (Holm) | MDE (°C) |
|:--|:--|--:|--:|--:|--:|--:|--:|
| concat_info | film_add | +0.0462 | 0.0916 | +0.15 | 0.3221 | 1.0000 | 0.1540 |
| concat_info | film_full | +0.0708 | 0.1084 | -0.26 | 0.2181 | 1.0000 | 0.1824 |
| concat_info | standard | +0.0706 | 0.1130 | -0.58 | 0.2349 | 1.0000 | 0.1901 |
| concat_info | standard_wider | +0.0703 | 0.1193 | -0.65 | 0.2580 | 1.0000 | 0.2006 |
| film_add | film_full | +0.0246 | 0.0291 | +0.68 | 0.1320 | 1.0000 | 0.0489 |
| film_add | standard | +0.0244 | 0.0297 | +0.29 | 0.1406 | 1.0000 | 0.0500 |
| film_add | standard_wider | +0.0241 | 0.0436 | -0.33 | 0.2842 | 1.0000 | 0.0733 |
| film_full | standard | -0.0002 | 0.0475 | +0.03 | 0.9933 | 1.0000 | 0.0798 |
| film_full | standard_wider | -0.0005 | 0.0395 | +0.42 | 0.9790 | 1.0000 | 0.0664 |
| standard | standard_wider | -0.0003 | 0.0520 | -0.22 | 0.9902 | 1.0000 | 0.0874 |

## Verdict

- Worse than persistence, uncorrected p<0.05: none; after Holm: none.
- Detectable configuration-to-configuration differences: none.
- Conditioning cost (film_add − standard) = +0.0244 °C, p = 0.1406 (Holm 1.0000); MDE 0.0500 °C.
