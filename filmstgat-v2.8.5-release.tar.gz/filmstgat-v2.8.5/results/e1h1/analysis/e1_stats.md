# e1h1 — conditioning ablations, statistics

seeds used: [42, 43, 44, 45, 46] (n = 5)
reference (persistence): 0.7783 °C

## A. Each configuration vs persistence (one-sample t; no pairing exists)

| config | RMSE | Δ (°C) | Δ (%) | p | p (Holm) | MDE (°C) |
|:--|--:|--:|--:|--:|--:|--:|
| concat_info | 0.8838 ± 0.0727 | +0.1056 | +13.56% | 0.0315 | 0.1260 | 0.1223 |
| film_add | 0.7930 ± 0.0081 | +0.0147 | +1.89% | 0.0151 | 0.0757 | 0.0136 |
| film_full | 0.8105 ± 0.0285 | +0.0322 | +4.14% | 0.0649 | 0.1946 | 0.0480 |
| standard | 0.7839 ± 0.0090 | +0.0057 | +0.73% | 0.2337 | 0.4674 | 0.0152 |
| standard_wider | 0.7733 ± 0.0128 | -0.0049 | -0.63% | 0.4370 | 0.4674 | 0.0215 |

## B. Configuration vs configuration (paired, same seeds)

| A | B | Δ = A − B (°C) | sd(Δ) | r | p | p (Holm) | MDE (°C) |
|:--|:--|--:|--:|--:|--:|--:|--:|
| concat_info | film_add | +0.0909 | 0.0793 | -0.79 | 0.0624 | 0.4629 | 0.1333 |
| concat_info | film_full | +0.0733 | 0.0669 | +0.39 | 0.0704 | 0.4629 | 0.1126 |
| concat_info | standard | +0.0999 | 0.0722 | +0.12 | 0.0364 | 0.3276 | 0.1214 |
| concat_info | standard_wider | +0.1105 | 0.0728 | +0.08 | 0.0274 | 0.2743 | 0.1224 |
| film_add | film_full | -0.0175 | 0.0315 | -0.24 | 0.2810 | 0.5309 | 0.0529 |
| film_add | standard | +0.0090 | 0.0156 | -0.67 | 0.2654 | 0.5309 | 0.0263 |
| film_add | standard_wider | +0.0196 | 0.0167 | -0.24 | 0.0579 | 0.4629 | 0.0280 |
| film_full | standard | +0.0266 | 0.0308 | -0.10 | 0.1261 | 0.4629 | 0.0518 |
| film_full | standard_wider | +0.0372 | 0.0348 | -0.32 | 0.0754 | 0.4629 | 0.0585 |
| standard | standard_wider | +0.0106 | 0.0103 | +0.60 | 0.0820 | 0.4629 | 0.0172 |

## Verdict

- Worse than persistence, uncorrected p<0.05: ['concat_info', 'film_add']; after Holm: none.
- Detectable configuration-to-configuration differences: none.
- Conditioning cost (film_add − standard) = +0.0090 °C, p = 0.2654 (Holm 0.5309); MDE 0.0263 °C.
