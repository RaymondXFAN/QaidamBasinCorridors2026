| model | RMSE (°C) | R² | params |
|:--|--:|--:|--:|
| persistence (baseline) | 0.4951 | +0.994 | 0 |
| climatology (baseline) | 3.6516 | +0.649 | 0 |
| trend (baseline) | 0.6056 | +0.990 | 0 |
| standard | 5.3915 ± 0.0000 | +0.235 | 52929 |
| film_full | 5.0263 ± 0.0000 | +0.335 | 61506 |

> 最强朴素基线 RMSE = 0.4951 °C
