| Model | RMSE (°C) | MAE (°C) | R² | n |
|---|---|---|---|---|
| persistence | 1.360 | 0.843 | 0.9778 | 2000 |
| trend_extrapolation | 2.704 | 1.884 | 0.9123 | 2000 |
