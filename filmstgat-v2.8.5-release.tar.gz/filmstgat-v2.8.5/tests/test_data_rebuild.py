"""数据重建自测（纯 numpy + scipy，无需 GPU）。

Dataset rebuild tests — numpy + scipy only.

最关键的一条：**描述子绝不能看到目标期**（R3-1 / D-08）。
我们直接把"未来"改掉，看描述子有没有变——变了就是泄漏。
The critical one: descriptors must not see the target period. We literally
perturb the "future" and check the descriptors do not move.
"""

import os
import sys
import tempfile

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from filmstgat.data.real import (  # noqa: E402
    load_legacy, train_period_mask, stratified_sample, origin_descriptors,
    knn_edges, build_windows_v2, build_dataset_v2,
)


def _fake_legacy(path, N=60, seed=0):
    """造一份与真实 npz 同结构的假数据。"""
    rng = np.random.default_rng(seed)
    years = np.arange(1981, 2019)
    base = rng.normal(2.0, 6.0, size=(N, 1))
    trend = rng.normal(0.02, 0.03, size=(N, 1))
    series = base + trend * np.arange(38) + rng.normal(0, 0.3, size=(N, 38))

    geo = np.stack([
        series[:, :30].mean(axis=1),
        trend[:, 0],
        series[:, :30].std(axis=1),
    ], axis=1).astype(np.float32)

    pix = np.stack([rng.integers(0, 200, N), rng.integers(0, 200, N)], axis=1).astype(np.int64)
    pix = np.unique(pix, axis=0)
    N = pix.shape[0]
    series, geo = series[:N], geo[:N]

    np.savez_compressed(
        path,
        X_train_raw=series[:, :30].astype(np.float32),
        y_val_raw=series[:, 30:35].astype(np.float32),
        y_test_raw=series[:, 35:].astype(np.float32),
        geo_raw=geo,
        pixel_indices=pix,
        years=years.astype(np.int64),
        # 复刻旧文件的"别名"陷阱（D-13），确认新代码不依赖它
        y_train=series[:, 30:35].astype(np.float32),
        X_train=series[:, :30].astype(np.float32),
        X_val=series[:, :30].astype(np.float32),
        X_test=series[:, :30].astype(np.float32),
    )
    return path


def test_load_legacy_rebuilds_38_years():
    with tempfile.TemporaryDirectory() as td:
        p = _fake_legacy(os.path.join(td, "legacy.npz"))
        d = load_legacy(p)
        assert d["series"].shape[1] == 38, d["series"].shape
        assert d["pixel_indices"].shape[1] == 2


def test_train_period_mask_ignores_future():
    """D-07：只改未来，合格性判定不应变化。"""
    series = np.ones((5, 38), dtype=np.float32)
    series[0, 35:] = np.nan          # 未来缺测
    series[1, 5] = np.nan            # 训练期缺测 → 不合格
    m = train_period_mask(series, n_train=30, min_valid=30)
    assert m[0] is np.True_ or bool(m[0]) is True, "未来缺测不应影响资格"
    assert not bool(m[1]), "训练期缺测应判为不合格"


def test_stratified_sample_size_and_range():
    rng = np.random.default_rng(0)
    vals = rng.normal(0, 1, 500)
    cand = np.arange(500)
    sel = stratified_sample(cand, vals, n_samples=100, n_bins=10, seed=1)
    assert sel.size == 100, sel.size
    assert len(np.unique(sel)) == 100
    assert sel.min() >= 0 and sel.max() < 500


def test_descriptors_never_see_future():
    """★ D-08：改掉目标期数据，描述子必须逐位不变。

    注意：必须**逐个 origin 单独测**。一次性把多个 origin 之后的数据都改掉，
    会连带破坏更晚 origin 的合法输入，从而误判为泄漏（第一版就栽在这）。
    Test each origin separately: mutating everything after every origin would
    also destroy the legitimate input of later origins and produce a false alarm.
    """
    rng = np.random.default_rng(0)
    series = rng.normal(size=(20, 38)).astype(np.float32)

    for t0 in (9, 14, 20, 30, 35):
        d1 = origin_descriptors(series, np.array([t0]))
        tampered = series.copy()
        tampered[:, t0 + 1:] = 999.0          # 只改该 origin 之后的"未来"
        d2 = origin_descriptors(tampered, np.array([t0]))
        assert np.allclose(d1, d2), f"origin={t0} 的描述子随未来变化 → 信息穿越！"


def test_descriptors_use_expanding_window():
    """不同 origin 的描述子必须不同（证明不是统一用 2010）。"""
    rng = np.random.default_rng(1)
    series = rng.normal(size=(10, 38)).astype(np.float32)
    d = origin_descriptors(series, np.array([9, 19, 29]))
    assert not np.allclose(d[0], d[1]), "不同 origin 描述子相同，说明没按 origin 计算"


def test_knn_edges_shape():
    pix = np.stack([np.arange(20) % 5, np.arange(20) // 5], axis=1)
    edge, w = knn_edges(pix, k=4)
    assert edge.shape == (2, 20 * 4)
    assert edge.max() < 20 and edge.min() >= 0
    assert w.shape == (80,)
    assert np.all(w > 0) and np.all(w <= 1.0)


def test_windows_and_split_match_paper_protocol():
    series = np.random.default_rng(0).normal(size=(10, 38)).astype(np.float32)
    Xw, yw, tidx, split = build_windows_v2(series, T_in=10, gap=4, T_out=1)
    assert Xw.shape[1] == 24
    assert tidx[0] == 14 and tidx[-1] == 37          # 1995 … 2018
    assert split["train"].size == 16
    assert split["val"].size == 4
    assert split["test"].size == 4


def test_end_to_end_build():
    with tempfile.TemporaryDirectory() as td:
        legacy = _fake_legacy(os.path.join(td, "legacy.npz"))
        out = os.path.join(td, "v2")
        meta = build_dataset_v2(legacy, out, n_samples=30, k=4, seed=3)

        assert os.path.exists(meta["npz_path"])
        assert os.path.exists(meta["manifest_csv"])
        d = np.load(meta["npz_path"])
        for key in ("series", "X_windows", "y_windows", "descriptors",
                    "edge_index", "split_train", "split_val", "split_test"):
            assert key in d.files, key
        assert d["X_windows"].shape[1] == 24
        assert d["descriptors"].shape == (24, meta["n_pixels_selected"], 3)

        rows = open(meta["manifest_csv"], encoding="utf-8").read().strip().split("\n")
        assert len(rows) == 25, len(rows)          # 表头 + 24 窗

        # 关键：v2 里不应再有 X_train/y_train 这类歧义字段（D-13）
        for bad in ("X_train", "y_train", "X_val"):
            assert bad not in d.files, f"v2 仍保留了歧义字段 {bad}"


if __name__ == "__main__":
    fns = [(k, v) for k, v in sorted(globals().items()) if k.startswith("test_")]
    failed = 0
    for name, fn in fns:
        try:
            fn()
            print(f"  ✅ {name}")
        except Exception as e:
            failed += 1
            print(f"  ❌ {name}: {type(e).__name__}: {e}")
    print(f"\n{len(fns) - failed}/{len(fns)} passed")
    sys.exit(1 if failed else 0)
