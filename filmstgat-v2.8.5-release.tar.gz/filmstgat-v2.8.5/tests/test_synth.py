#!/usr/bin/env python3
"""Synthetic pipeline checks: reproducible generator, complete split, non-leaking lag. 合成管线自检。

Synthetic pipeline self-check: reproducible generator, complete split,
non-leaking lag channel. Needs neither torch nor pytest.

为什么必须先验这三件 / Why these three first
--------------------------------------------
1. **生成器可复现**：如果两次 `generate()` 结果不同，后面所有"可由配置重建"
   的说法都是假的；
2. **切分完备**：三个集合必须无重叠且覆盖全部窗口——原论文 77.5% 的测试样本
   实为训练期窗口，就是切分之祸；
3. **滞后通道不泄漏**：第 13 通道在窗口末时刻必须等于 y(t−1)，不能是 y(t)。

作者 / Author: Raymond Xiaohu Fan

用法 / Usage:
    python tests/test_synth.py          # 裸跑
"""

from __future__ import annotations

import os
import sys
import tempfile
import traceback

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from filmstgat.data.synthetic import SyntheticDataGenerator        # noqa: E402
from filmstgat.data.synth_windows import (                         # noqa: E402
    adj_to_edge_index, build_synth_v2,
)

SMALL = {"N_nodes": 8, "T_steps": 40, "F_features": 12, "G_geo_features": 3,
         "T_in": 8, "T_out": 1, "train_ratio": 0.8, "seed": 42,
         "noise_level": 0.05, "k_thaw": 1.2, "adj_threshold_km": 50.0,
         "region": "Test", "dataset_name": "tiny", "output_dir": ""}


def _gen(cfg=None):
    c = dict(SMALL)
    if cfg:
        c.update(cfg)
    return SyntheticDataGenerator(c).generate()


def test_generator_is_deterministic():
    a, b = _gen(), _gen()
    for k in ("X", "y", "adj_matrix", "geo_features", "coords", "settlements"):
        assert np.array_equal(a[k], b[k]), f"{k} 两次生成不一致 —— 不可复现"


def test_generator_changes_with_seed():
    a = _gen()
    b = _gen({"seed": 43})
    assert not np.array_equal(a["X"], b["X"]), "换种子结果不变，说明种子没生效"


def test_adj_to_edge_index():
    adj = np.array([[1, 1, 0], [1, 1, 1], [0, 1, 1]], dtype=float)
    ei, w = adj_to_edge_index(adj, drop_self=True)
    assert ei.shape == (2, 4), f"应有 4 条无自环边，得到 {ei.shape}"
    assert (ei[0] != ei[1]).all(), "自环没有被去掉"
    assert w.shape == (4,)


def test_build_synth_v2_split_is_complete():
    tmp = tempfile.mkdtemp()
    raw_dir = os.path.join(tmp, "raw")
    os.makedirs(raw_dir)
    cfg = dict(SMALL)
    cfg["output_dir"] = raw_dir
    path = SyntheticDataGenerator(cfg).generate_and_save()

    meta = build_synth_v2(path, os.path.join(tmp, "v2"), T_in=8, T_out=1, val_months=6)
    d = np.load(meta["npz_path"], allow_pickle=True)
    tr, va, te = (np.asarray(d[f"split_{s}"]) for s in ("train", "val", "test"))

    W = int(meta["n_windows"])
    union = np.sort(np.concatenate([tr, va, te]))
    assert union.size == W, f"三集合之和 {union.size} ≠ 窗口数 {W}"
    assert np.array_equal(union, np.arange(W)), "三集合没有恰好覆盖全部窗口（有重叠或缺口）"
    assert tr.max() < va.min() and va.max() < te.min(), "切分不是按时间顺序"

    # 40 - 8 - 1 + 1 = 32 个窗口；split_idx = 32；val 取训练段末 6 个
    assert W == 32, f"窗口数应为 32，得到 {W}"
    assert te.size == 8, f"测试窗口应为 8，得到 {te.size}"
    assert va.size == 6, f"验证窗口应为 6，得到 {va.size}"

    # Target indices must agree with the window split / 目标索引一致
    tgt = np.asarray(d["target_idx"])
    assert tgt[te].min() == 32, f"测试期起点应为 32，得到 {tgt[te].min()}"


def test_lag_channel_uses_only_past():
    """第 13 通道在窗口末时刻必须等于正规化后的 y(t−1)。"""
    from filmstgat.experiments.e1_synthetic import load_synth

    tmp = tempfile.mkdtemp()
    raw_dir = os.path.join(tmp, "raw")
    os.makedirs(raw_dir)
    cfg = dict(SMALL)
    cfg["output_dir"] = raw_dir
    path = SyntheticDataGenerator(cfg).generate_and_save()
    meta = build_synth_v2(path, os.path.join(tmp, "v2"), T_in=8, T_out=1)

    d = load_synth(meta["npz_path"], lags=1)
    npz = np.load(meta["npz_path"], allow_pickle=True)
    y_series = np.asarray(npz["y_series"])
    y_mean, y_std = float(npz["y_mean"]), float(npz["y_std"])
    target_idx = np.asarray(npz["target_idx"])

    X_te = d["splits"]["X_test"]              # (W_test, N, T, F')
    te = d["test_idx"]
    for j, w in enumerate(te):
        t = int(target_idx[w])
        expect = (y_series[:, t - 1] - y_mean) / y_std
        got = X_te[j, :, -1, -1]
        assert np.allclose(got, expect, atol=1e-4), \
            f"窗口 {w} 的滞后通道不是 y(t−1)（可能泄漏了 y(t)）"


def test_naive_baselines_run_headless():
    """三个朴素基线在原始单位下必须能算出来，且 persistence 不可能是 NaN。"""
    from filmstgat.experiments.e1_synthetic import load_synth, naive_baselines

    tmp = tempfile.mkdtemp()
    raw_dir = os.path.join(tmp, "raw")
    os.makedirs(raw_dir)
    cfg = dict(SMALL)
    cfg["output_dir"] = raw_dir
    path = SyntheticDataGenerator(cfg).generate_and_save()
    meta = build_synth_v2(path, os.path.join(tmp, "v2"), T_in=8, T_out=1)

    res = naive_baselines(load_synth(meta["npz_path"], lags=1))
    assert set(res) == {"persistence", "climatology", "trend"}
    for name, m in res.items():
        assert np.isfinite(m["rmse"]) and m["rmse"] > 0, f"{name} 的 RMSE 异常：{m['rmse']}"


def test_residual_base_points_at_lag_channel():
    """残差基底必须指向滞后通道，否则模型要以 4 倍劣势对打 persistence.

    Regression test for a real mistake (2026-11-08): the lag channel was added so
    that persistence would be a fair reference, but the residual shortcut was
    disabled, so models had to learn the absolute level from scratch and lost by
    ~4x. The shortcut must point at the lag channel.
    """
    from filmstgat.experiments.e1_synthetic import load_synth

    tmp = tempfile.mkdtemp()
    raw_dir = os.path.join(tmp, "raw")
    os.makedirs(raw_dir)
    cfg = dict(SMALL)
    cfg["output_dir"] = raw_dir
    path = SyntheticDataGenerator(cfg).generate_and_save()
    meta = build_synth_v2(path, os.path.join(tmp, "v2"), T_in=8, T_out=1)

    d = load_synth(meta["npz_path"], lags=1)
    lag = d["lag_channel"]
    assert lag == 12, f"lag channel index should equal the original feature count (12), got {lag}"
    assert 0 <= lag < d["input_dim"], "residual_channel must be a valid channel index"

    npz = np.load(meta["npz_path"], allow_pickle=True)
    y_series = np.asarray(npz["y_series"])
    y_mean, y_std = float(npz["y_mean"]), float(npz["y_std"])
    target_idx = np.asarray(npz["target_idx"])
    X_te = d["splits"]["X_test"]
    for j, w in enumerate(d["test_idx"][:3]):
        t = int(target_idx[w])
        expect = (y_series[:, t - 1] - y_mean) / y_std
        assert np.allclose(X_te[j, :, -1, lag], expect, atol=1e-4), \
            "residual base is not y(t-1)"


def test_e1_synthetic_end_to_end_with_stubs():
    """桩跑 e1_synthetic.main()：检查汇总字段、收敛诊断与溯源三件套。

    2026-11-08 的教训：第一次跑完只存了 predictions.npz，没有 metrics.json /
    run_manifest.json，也没有 best_epoch——于是"没学好"和"没信号"分不开。
    这条测试把这两件事都钉住。
    """
    import contextlib
    import json
    from filmstgat.experiments import e1_synthetic as e1s

    tmp = tempfile.mkdtemp()
    raw_dir = os.path.join(tmp, "raw")
    os.makedirs(raw_dir)
    cfg = dict(SMALL)
    cfg["output_dir"] = raw_dir
    path = SyntheticDataGenerator(cfg).generate_and_save()
    meta = build_synth_v2(path, os.path.join(tmp, "v2"), T_in=8, T_out=1)
    out = os.path.join(tmp, "out")

    class _Stub:
        num_params = 1234

        def to(self, dev):
            return self

    def fake_train(model, splits, edge, geo, *, seed, epochs, **kw):
        shape = splits["y_test"].shape
        true = np.full(shape, 1.0, dtype=np.float32)
        pred = true + np.float32(0.5)
        return {"metrics": {"rmse": 0.5, "mae": 0.4, "r2": 0.1,
                            "n_samples": int(true.size)},
                "pred": pred, "true": true,
                "best_epoch": 7, "best_val_rmse": 0.5, "epochs_run": 7,
                "seconds": 0.0, "seed": seed, "lambda_phys": 0.0, "seeding": {}}

    saved = []

    def fake_save(out_dir, run_id, result, **kw):
        saved.append(run_id)
        return run_id

    @contextlib.contextmanager
    def patched():
        old = (e1s.build_model, e1s.train_stgat, e1s.save_run, sys.argv)
        e1s.build_model = lambda seed, **kw: _Stub()
        e1s.train_stgat = fake_train
        e1s.save_run = fake_save
        sys.argv = ["e1synthetic", "--data", meta["npz_path"], "--out", out,
                    "--seeds", "2", "--epochs", "9", "--configs", "standard,film_full",
                    "--device", "cpu"]
        try:
            yield
        finally:
            (e1s.build_model, e1s.train_stgat, e1s.save_run, sys.argv) = old

    with patched():
        assert e1s.main() == 0

    summary = json.load(open(os.path.join(out, "e1_synth_summary.json"), encoding="utf-8"))
    assert set(summary["configs"]) == {"standard", "film_full"}
    for name, v in summary["configs"].items():
        for key in ("rmse_per_seed", "best_epoch_mean", "any_early_stopped",
                    "delta_vs_persistence", "p_vs_persistence", "params"):
            assert key in v, f"{name} 缺少汇总字段 {key}"
        assert v["best_epoch_max"] == 7
        assert v["any_early_stopped"] is True, "epochs_run < epochs 时应标记为早停"

    assert len(saved) == 4, f"应有 4 次落盘（2 配置 × 2 seed），实际 {len(saved)}"
    assert all("_seed" in r for r in saved)

    table = open(os.path.join(out, "table_e1_synth.md"), encoding="utf-8").read()
    assert "Δ vs persistence" in table and "best epoch" in table


def _run_all() -> int:
    tests = [(n, f) for n, f in sorted(globals().items())
             if n.startswith("test_") and callable(f)]
    passed, failed = 0, []
    print(f"裸跑 {len(tests)} 项合成管线自检")
    for name, fn in tests:
        try:
            fn()
            print(f"  PASS  {name}")
            passed += 1
        except Exception:                              # noqa: BLE001
            print(f"  FAIL  {name}")
            traceback.print_exc()
            failed.append(name)
    print(f"\n结果：{passed}/{len(tests)} 通过")
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(_run_all())
