#!/usr/bin/env python3
"""E2 设计自检：不依赖 torch / GPU，也**不依赖 pytest**。

E2 design self-check — needs neither torch nor pytest.

为什么塞在 tests/ 里还要能裸跑：上一版脚本第一句就是 `python -m pytest`，
结果服务器上压根没装 pytest，整条流水线还没开始训练就先死了。
工具链不该成为门槛——所以这里既能在 pytest 下跑，也能 `python tests/test_e2_design.py`
直接跑，两条路走同一份断言。
Why runnable with bare python: the previous runner assumed pytest was installed,
so the whole pipeline died before training even started. A toolchain should not
be the gate. Same assertions, two entry points.

作者 / Author: Raymond Xiaohu Fan

用法 / Usage:
    python tests/test_e2_design.py          # 裸跑（无 pytest 也行）
    python -m pytest tests/test_e2_design.py -v   # 有 pytest 时
"""

from __future__ import annotations

import contextlib
import json
import os
import sys
import tempfile
import traceback

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:                                                    # pytest 可有可无
    import pytest
except ImportError:                                     # pragma: no cover
    pytest = None

from filmstgat.experiments import e2_overlap_sweep as e2   # noqa: E402


# ------------------------------------------------------------ 迷你 monkeypatch

@contextlib.contextmanager
def _patched(*triples):
    """临时替换模块属性，退出时原样还原（pytest 不在也能用）。"""
    saved = []
    try:
        for obj, name, value in triples:
            saved.append((obj, name, getattr(obj, name, None)))
            setattr(obj, name, value)
        yield
    finally:
        for obj, name, old in reversed(saved):
            setattr(obj, name, old)


# ------------------------------------------------- The manipulation itself / 操纵本身

def test_alpha_one_is_identity():
    """alpha=1 must return the input unchanged, else the high-overlap level is not the real field. α=1 恒等。"""
    rng = np.random.default_rng(0)
    geo = rng.normal(size=(3, 20, 3)).astype(np.float32)
    out = e2.mix_conditioning(geo, 1.0, seed=42)
    assert np.allclose(out, geo, atol=1e-6), "α=1 没有还原成原始条件场"


def test_alpha_zero_preserves_marginals():
    """alpha=0 may only permute; values must be preserved (information is conserved). 信息量守恒。"""
    rng = np.random.default_rng(0)
    geo = rng.normal(size=(3, 20, 3)).astype(np.float32)
    out = e2.mix_conditioning(geo, 0.0, seed=42)
    for w in range(geo.shape[0]):
        a = np.sort(geo[w].reshape(-1))
        b = np.sort(out[w].reshape(-1))
        assert np.allclose(a, b, atol=1e-6), f"窗口 {w} 的边缘分布被改动了"
        assert not np.allclose(out[w], geo[w]), f"窗口 {w} 没有真正置换"


def test_permutation_shared_across_channels():
    """All channels must share one permutation, or the pixel falls apart. 通道共用置换。"""
    rng = np.random.default_rng(1)
    geo = rng.normal(size=(2, 15, 3)).astype(np.float32)
    out = e2.mix_conditioning(geo, 0.0, seed=7)
    for w in range(2):
        for row in out[w]:
            assert np.any(np.all(np.isclose(geo[w], row, atol=1e-6), axis=1)), \
                "某一行在原始场里找不到对应像素——通道被拆散了"


def test_rho_decreases_with_alpha():
    """Core check: smaller alpha means lower measured rho (ties allowed, increases not). ρ 随 α 单调。"""
    yy, xx = np.mgrid[0:40, 0:40]
    field = np.sin(xx / 6.0) + np.cos(yy / 8.0)
    pix = np.stack([yy.ravel(), xx.ravel()], axis=1)[:120]
    vals = field[yy.ravel(), xx.ravel()][:120]

    geo = np.stack([vals, vals * 0.5, vals * 0.1], axis=1)[None, :, :].repeat(4, axis=0)
    geo = geo.astype(np.float32)
    inputs = np.repeat(vals[None, :], 4, axis=0)

    rhos = []
    for alpha in e2.ALPHAS:
        g = e2.mix_conditioning(geo, alpha, seed=42)
        rhos.append(e2.measure_rho(g, inputs, pix, np.arange(4)))

    assert rhos[-1] > 0.9, f"α=1 时 ρ 应接近 1，实测 {rhos[-1]:.3f}"
    assert rhos[0] < rhos[-1] - 0.1, \
        f"α=0 应显著更低，实测 {rhos[0]:.3f} vs {rhos[-1]:.3f}"
    for i in range(1, len(rhos)):
        assert rhos[i] >= rhos[i - 1] - 0.02, f"ρ 不单调：{np.round(rhos, 3)}"
    print(f"    ρ 序列 = {np.round(rhos, 3).tolist()}")


def test_rho_chance_floor_is_half():
    """ρ=(cos+1)/2 的随机水平是 0.5 —— 这条必须钉死。

    如果 α=0（完全置换）算出来的 ρ 明显偏离 0.5，说明置换或栅格化有 bug；
    更要紧的是：它说明论文里"ρ<0.3 用 full"这个区间几乎不可达，阈值必须重述。
    If the fully-permuted level does not land near 0.5, either the mixing or
    the rasterisation is broken — and the paper's rho<0.3 branch is unreachable
    anyway, so the thresholds have to be restated on a chance-corrected scale.
    """
    yy, xx = np.mgrid[0:40, 0:40]
    field = np.sin(xx / 6.0) + np.cos(yy / 8.0)
    pix = np.stack([yy.ravel(), xx.ravel()], axis=1)[:120]
    vals = field[yy.ravel(), xx.ravel()][:120]
    geo = np.stack([vals, vals, vals], axis=1)[None, :, :].repeat(3, axis=0).astype(np.float32)
    inputs = np.repeat(vals[None, :], 3, axis=0)

    g0 = e2.mix_conditioning(geo, 0.0, seed=42)
    rho0 = e2.measure_rho(g0, inputs, pix, np.arange(3))
    assert 0.40 <= rho0 <= 0.62, \
        f"完全置换的 ρ 应贴在 0.5 附近，实测 {rho0:.3f}（怀疑置换/栅格化有 bug）"


def test_verdict_rejects_noise_with_right_sign():
    """Regression test: deltas look monotone but nothing is significant -> verdict must be "no evidence". 无证据。

    这就是 2026-11-08 那次真实结果：Δ 极差 0.0226 °C、Spearman +0.30，
    但五档 p 全 > 0.28、Spearman p=0.62。若判定只看符号，这条噪声会被
    写成"方向一致 → C6 保留"，正是最危险的过度解读。
    Regression test for the real 2026-11-08 run: the deltas happened to line up
    with the hypothesis, but nothing was significant. A sign-only rule would
    have promoted noise into a design rule.
    """
    rows = [
        {"alpha": 0.00, "rho": 0.503, "delta_full_minus_add": +0.0018, "p_value": 0.850},
        {"alpha": 0.25, "rho": 0.535, "delta_full_minus_add": -0.0051, "p_value": 0.577},
        {"alpha": 0.50, "rho": 0.595, "delta_full_minus_add": +0.0015, "p_value": 0.843},
        {"alpha": 0.75, "rho": 0.734, "delta_full_minus_add": -0.0010, "p_value": 0.905},
        {"alpha": 1.00, "rho": 0.956, "delta_full_minus_add": +0.0175, "p_value": 0.281},
    ]
    verdict, st = e2.build_verdict(rows)
    text = "\n".join(verdict)
    assert st["sig_levels"] == [], f"不应有显著档位，得到 {st['sig_levels']}"
    assert "无证据" in text, f"应判为无证据，实际输出：\n{text}"
    assert "不得作为设计规则保留" in text


def test_verdict_accepts_real_effect():
    """Counterpart: if a real effect exists, it must be acknowledged. 反向对照。"""
    rows = [
        {"alpha": 0.00, "rho": 0.503, "delta_full_minus_add": -0.0020, "p_value": 0.010},
        {"alpha": 0.25, "rho": 0.560, "delta_full_minus_add": +0.0040, "p_value": 0.008},
        {"alpha": 0.50, "rho": 0.630, "delta_full_minus_add": +0.0090, "p_value": 0.002},
        {"alpha": 0.75, "rho": 0.780, "delta_full_minus_add": +0.0140, "p_value": 0.001},
        {"alpha": 1.00, "rho": 0.950, "delta_full_minus_add": +0.0210, "p_value": 0.001},
    ]
    verdict, st = e2.build_verdict(rows)
    text = "\n".join(verdict)
    assert len(st["sig_levels"]) >= 4, f"应有多个显著档位，得到 {st['sig_levels']}"
    assert "显著档位" in text
    assert "无证据" not in text


def test_verdict_does_not_upgrade_ci_only_significance():
    """回归测试：块自助区间不含 0、但种子级 p 不显著时，不得算作「supported」。

    这就是 2026-11-08 E2b 的真实情形（α=0：CI [−0.008,−0.001]，p=0.560）。
    若把 CI 显著性当方法级结论，就会写出"低重叠时 full 也更好"这种没有
    种子支撑的话。
    Regression test for the real E2b α=0 case: bootstrap CI excludes zero but
    the seed-level test does not. CI significance is a claim about these pixels,
    not about the method.
    """
    rows = [
        {"alpha": 0.00, "rho": 0.503, "delta_full_minus_add": -0.0021,
         "p_value": 0.560, "delta_ci95": [-0.008, -0.001]},
        {"alpha": 1.00, "rho": 0.956, "delta_full_minus_add": +0.0152,
         "p_value": 0.002, "delta_ci95": [+0.003, +0.020]},
    ]
    verdict, st = e2.build_verdict(rows)
    text = "\n".join(verdict)
    assert st["sig_levels"] == [1.0], f"只有 α=1 应算显著，得到 {st['sig_levels']}"
    assert st["ci_only_levels"] == [0.0], f"α=0 应被标为 ci-only，得到 {st['ci_only_levels']}"
    assert "不得" in text and "方法级" in text, f"必须显式警告，实际：\n{text}"
    assert "不做趋势推断" in text, f"两点不该谈趋势，实际：\n{text}"


def test_block_bootstrap_delta_covers_zero_for_identical_modes():
    """Identical models must yield a CI for delta containing 0. 自助法不造效应。"""
    rng = np.random.default_rng(0)
    e = (rng.normal(size=400) ** 2).astype(float)
    blocks = np.tile(np.repeat(np.arange(25), 16), 1)
    lo, hi = e2.block_bootstrap_delta(e, e, blocks, n_boot=300)
    assert lo <= 0.0 <= hi, f"相同模型的 Δ 区间应含 0，得到 [{lo:.4f}, {hi:.4f}]"


def test_to_grid_no_nan():
    """网格里有 NaN 会污染 np.gradient，进而把 ρ 算成垃圾。"""
    rng = np.random.default_rng(3)
    pix = rng.integers(0, 200, size=(50, 2))
    vals = rng.normal(size=50)
    g = e2.to_grid(pix, vals, bins=32)
    assert g.shape == (32, 32)
    assert np.isfinite(g).all(), "网格里出现 NaN"


# --------------------------------------------- Stub end-to-end run / 桩跑全流程

def _make_fake_npz(path: str, N: int = 40, W: int = 6, T: int = 4, F: int = 1):
    rng = np.random.default_rng(0)
    series = rng.normal(size=(N, 38)).astype(np.float32)
    np.savez_compressed(
        path,
        series=series,
        X_windows=rng.normal(size=(N, W, T, F)).astype(np.float32),
        y_windows=rng.normal(size=(N, W, 1)).astype(np.float32),
        target_idx=np.arange(W, dtype=np.int64) + 30,
        descriptors=rng.normal(size=(W, N, 3)).astype(np.float32),
        geo_raw=rng.normal(size=(N, 3)).astype(np.float32),
        pixel_indices=rng.integers(0, 60, size=(N, 2)).astype(np.int64),
        edge_index=np.stack([np.arange(N), np.roll(np.arange(N), 1)]),
        edge_weight=np.ones(N, dtype=np.float32),
        split_train=np.array([0, 1, 2]), split_val=np.array([3]),
        split_test=np.array([4, 5]),
        ts_mean=np.float32(0.0), ts_std=np.float32(1.0),
        years=np.arange(1981, 2019, dtype=np.int64),
    )


class _StubModel:
    def __init__(self, **kw):
        self.num_params = 1234
        self.kw = kw

    def to(self, dev):
        return self


def test_main_end_to_end_with_stubs():
    """用桩模型把 main() 整条链路跑一遍：形状、落盘、统计、CSV 都要对。"""
    tmp = tempfile.mkdtemp()
    data = os.path.join(tmp, "fake.npz")
    _make_fake_npz(data)
    out = os.path.join(tmp, "e2")

    def fake_train(model, splits, edge, geo, *, seed, **kw):
        n = splits["y_test"].size
        true = np.full(n, 1.0, dtype=np.float32)
        pred = true + np.float32(0.1 * (seed % 3))
        return {"metrics": {"rmse": float(np.sqrt(np.mean((pred - true) ** 2))),
                            "mae": 0.1, "r2": 0.0, "n": int(n)},
                "pred": pred, "true": true, "best_epoch": 1, "best_val_rmse": 0.1,
                "epochs_run": 1, "seconds": 0.0, "seed": seed, "lambda_phys": 0.0,
                "seeding": {}}

    argv = ["e2", "--data", data, "--out", out, "--n-sub", "40",
            "--seeds", "3", "--epochs", "2", "--device", "cpu",
            "--selection", "random"]
    old_argv = sys.argv
    with _patched((e2, "build_model", lambda seed, **kw: _StubModel(**kw)),
                  (e2, "train_stgat", fake_train),
                  (e2, "save_run", lambda *a, **k: "stub"),
                  (sys, "argv", argv)):
        try:
            assert e2.main() == 0
        finally:
            sys.argv = old_argv

    for fn in ("e2_summary.json", "rho_vs_delta.csv", "table_e2.md", "verdict.txt"):
        assert os.path.exists(os.path.join(out, fn)), f"缺 {fn}"

    rows = json.load(open(os.path.join(out, "e2_summary.json"), encoding="utf-8"))
    assert len(rows) == len(e2.ALPHAS), "档数与 ALPHAS 不一致"
    for r in rows:
        assert set(r["runs"]) == {"add_only", "full"}, "少跑了一个 FiLM 形式"
        assert 0.0 <= r["rho"] <= 1.0, f"ρ 越界：{r['rho']}"
        assert np.isfinite(r["delta_full_minus_add"]), "Δ 不是有限值"


# --------------------------------------------- Bare-python entry / 裸跑入口

def _run_all() -> int:
    tests = [(n, f) for n, f in sorted(globals().items())
             if n.startswith("test_") and callable(f)]
    passed, failed = 0, []
    print(f"裸跑 {len(tests)} 项自检（无需 pytest）")
    for name, fn in tests:
        try:
            fn()
            print(f"  PASS  {name}")
            passed += 1
        except Exception:                             # noqa: BLE001
            print(f"  FAIL  {name}")
            traceback.print_exc()
            failed.append(name)
    print(f"\n结果：{passed}/{len(tests)} 通过")
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(_run_all())
