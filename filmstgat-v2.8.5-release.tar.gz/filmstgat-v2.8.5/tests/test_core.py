"""核心逻辑自测（纯 numpy，无需 GPU）。

Core logic tests — pure numpy, no GPU required.

跑法 / Run:
    python tests/test_core.py
或 / or:
    pytest tests/test_core.py -q

这些测试对应审稿意见的具体条目，注释里标了编号。
Each test maps to a reviewer comment; the ID is in the docstring.
"""

import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from filmstgat.data.windows import (  # noqa: E402
    sliding_windows, temporal_split, to_graph, to_flat, Standardizer, window_manifest,
)
from filmstgat.eval.metrics import (  # noqa: E402
    rmse, mae, r2, summarize, implied_target_variance, assert_metric_consistency,
)
from filmstgat.eval.overlap import overlap_degree, select_mode  # noqa: E402


def _toy(N=5, T=12, F=3, seed=0):
    rng = np.random.default_rng(seed)
    X = rng.normal(size=(N, T, F)).astype(np.float32)
    y = rng.normal(size=(N, T)).astype(np.float32)
    return X, y


# --------------------------------------------------------------------------- #
def test_sliding_windows_shapes():
    """窗口数量与目标索引必须自洽 / counts and target indices must agree."""
    X, y = _toy()
    Xw, yw, tidx = sliding_windows(X, y, T_in=4, T_out=2)
    W = 12 - 4 - 2 + 1
    assert Xw.shape == (5, W, 4, 3), Xw.shape
    assert yw.shape == (5, W, 2), yw.shape
    assert tidx.tolist() == list(range(4 + 2 - 1, 12))
    # 目标紧接输入窗之后 / target starts right after the input window
    assert np.allclose(yw[2, 0], y[2, 4:6])


def test_gap_is_explicit():
    """R3-1：提前量必须显式可查，不能藏在变量名里。"""
    X, y = _toy(N=3, T=20, F=2)
    Xw, yw, tidx = sliding_windows(X, y, T_in=5, T_out=1, gap=3)
    # First window: input 0..4, 3-year gap, target at year 8 / 第一个窗口
    assert np.allclose(yw[1, 0, 0], y[1, 8]), (yw[1, 0, 0], y[1, 8])
    assert tidx[0] == 8
    assert Xw.shape[1] == 20 - 5 - 3 - 1 + 1


def test_split_is_chronological_and_disjoint():
    """R1-5：切分必须按时间、且三集合不相交。"""
    idx = temporal_split(24, train_ratio=0.8, val_ratio=0.0)
    assert idx["train"].tolist() == list(range(19))
    assert idx["test"].tolist() == list(range(19, 24))
    assert set(idx["train"]) & set(idx["test"]) == set()
    # 训练窗口的目标年份必须早于测试窗口 / train targets precede test targets
    assert idx["train"].max() < idx["test"].min()


def test_flat_and_graph_are_the_same_samples():
    """★ 核心：flat 与 graph 必须是同一批样本（修 R1-5 / R3-3）。

    旧代码 node-major 展平后按时间切片，导致两类模型吃到不同测试集。
    新代码两者由同一个 idx 派生，展平后应逐元素相等。
    Old code flattened node-major then sliced by time, so the two model
    families saw different test sets. Here both derive from one idx and
    must be element-wise identical.
    """
    X, y = _toy(N=4, T=20, F=2)
    Xw, yw, _ = sliding_windows(X, y, T_in=5, T_out=1)
    idx = temporal_split(Xw.shape[1], 0.7)["test"]

    g = to_graph(Xw, idx)                       # (w,N,T,F)
    f = to_flat(Xw, idx)                        # (N*w,T,F)

    assert g.shape == (len(idx), 4, 5, 2)
    assert f.shape == (4 * len(idx), 5, 2)
    assert np.array_equal(g.reshape(-1, 5, 2), f), "flat 与 graph 样本不一致！"

    yg = yw[:, idx, :].transpose(1, 0, 2)       # (w,N,1)
    yf = yw[:, idx, :].transpose(1, 0, 2).reshape(-1, 1)
    assert np.array_equal(yg.reshape(-1, 1), yf)


def test_old_bug_is_gone_quantified():
    """把旧 bug 写成可执行的对照，证明我们真的修好了。

    旧逻辑：X.reshape(N*W)[:N*sw] —— node-major 展平后按时间切。
    """
    N, W, sw = 40, 96, 76
    grid = np.arange(N * W).reshape(N, W)          # (node, window)
    old_tr = grid.reshape(-1)[:N * sw]
    old_te = grid.reshape(-1)[N * sw:]

    leak = int((old_te % W < sw).sum())
    ratio = leak / old_te.size
    assert 0.75 < ratio < 0.80, f"旧 bug 泄漏比例异常: {ratio:.3f}"
    # New logic: select windows first / 先选窗口
    new_te = grid[:, sw:].reshape(-1)
    assert int((new_te % W < sw).sum()) == 0, "新逻辑仍存在泄漏！"


def test_standardizer_fits_on_train_only():
    """R1-5：scaler 只能看训练集，未来极值不得影响均值。"""
    rng = np.random.default_rng(1)
    train = rng.normal(0, 1, size=(100, 3)).astype(np.float32)
    future = np.full((10, 3), 1000.0, dtype=np.float32)   # 极端未来值

    sc = Standardizer().fit(train)
    mean_before = sc.mean
    _ = sc.transform(future)                               # 只看不用 fit
    assert sc.mean == mean_before, "transform 不得改变统计量！"

    sc_leaky = Standardizer().fit(np.vstack([train, future]))
    assert sc_leaky.mean > 50, "对照组应被未来值污染（用于证明差异）"
    assert abs(mean_before) < 1.0


def test_metrics_basic():
    y = np.array([1.0, 2.0, 3.0, 4.0])
    p = np.array([1.0, 2.0, 3.0, 4.0])
    assert rmse(p, y) == 0.0
    assert r2(p, y) == 1.0
    assert mae(p, y) == 0.0

    p2 = y + 1.0
    s = summarize(p2, y)
    assert s["n_samples"] == 4
    assert abs(s["rmse"] - 1.0) < 1e-12
    assert s["r2"] < 1.0


def test_metric_consistency_catches_table5_problem():
    """R3-3：不同测试集反推出的目标方差不同 → 必须报警。"""
    # Same test set, two prediction sets / 同一测试集
    rng = np.random.default_rng(0)
    y = rng.normal(0, 5, size=500)
    p1 = y + rng.normal(0, 0.5, size=500)
    p2 = y + rng.normal(0, 1.0, size=500)

    recs = [
        {"model": "A", "rmse": rmse(p1, y), "r2": r2(p1, y)},
        {"model": "B", "rmse": rmse(p2, y), "r2": r2(p2, y)},
    ]
    out = assert_metric_consistency(recs)
    assert out["ok"], f"同一测试集不应报错，spread={out['spread']:.4f}"

    # 模拟论文里的情形：B 换了测试集（方差不同）
    recs_bad = [
        {"model": "XGBoost", "rmse": 0.6136, "r2": 0.9774},
        {"model": "ST-GAT", "rmse": 0.7094, "r2": 0.9820},
    ]
    v1 = implied_target_variance(0.6136, 0.9774)
    v2 = implied_target_variance(0.7094, 0.9820)
    assert 16.0 < v1 < 17.5 and 27.5 < v2 < 28.5, (v1, v2)

    try:
        assert_metric_consistency(recs_bad)
    except AssertionError as e:
        assert "测试集不一致" in str(e) or "inconsistent" in str(e).lower()
    else:
        raise AssertionError("应当检出 Table 5 那类不一致，但没有！")


def test_overlap_degree_sanity():
    """R1-1：ρ 的定义必须能区分高/低重叠。"""
    rng = np.random.default_rng(3)
    a = rng.normal(size=(40, 50))

    assert overlap_degree(a, a) > 0.99, "同场应 ρ≈1"
    assert overlap_degree(a, -a) < 0.01, "反向场应 ρ≈0"

    b = rng.normal(size=(40, 50))
    mid = overlap_degree(a, b)
    assert 0.2 < mid < 0.8, f"无关场应接近 0.5，实际 {mid:.3f}"

    # Same structure, different amplitude: only a linear rescale, gradients align, so rho ~ 1 / 应≈1
    scaled = a * 3.0 + 7.0
    assert overlap_degree(a, scaled) > 0.99, "线性缩放不改变结构，应仍高重叠"

    # Smooth a **structured** field (smoothed white noise would not stay structured) / 平滑有结构的场
    # Use a structured field: smoothing white noise destroys its structure,
    # which would make this test meaningless.
    yy, xx = np.mgrid[0:60, 0:60]
    structured = np.sin(xx / 6.0) + np.cos(yy / 9.0)
    from scipy.ndimage import gaussian_filter
    smoothed = gaussian_filter(structured, 1.5)
    assert overlap_degree(structured, smoothed) > 0.8, "同结构平滑后应仍高重叠"

    assert select_mode(0.9) == "add_only"
    assert select_mode(0.1) == "full"
    assert select_mode(0.4) == "add_only"   # 灰区保守


def test_window_manifest_years():
    """R3-1：窗口清单必须能说清 origin 与预测年份。

    复刻原协议：10 年输入、预测"输入结束后第 5 年"（gap=4, T_out=1）
    → 38 年数据正好 24 个窗口，与论文的 16/4/4 对得上。
    """
    X, y = _toy(N=2, T=38, F=1)
    Xw, yw, tidx = sliding_windows(X, y, T_in=10, T_out=1, gap=4)
    split = temporal_split(Xw.shape[1], 0.8)
    rows = window_manifest(tidx, T_in=10, T_out=1, gap=4, split=split, start_year=1981)

    assert len(rows) == 24, len(rows)
    first, last = rows[0], rows[-1]
    assert first["input_years"] == "1981-1990"
    assert first["target_years"] == "1995-1995"
    assert first["horizon_years"] == 5
    assert first["origin_year"] == 1990
    assert last["target_years"] == "2018-2018"
    assert {r["split"] for r in rows} <= {"train", "val", "test", "unassigned"}


# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    fns = [(k, v) for k, v in sorted(globals().items()) if k.startswith("test_")]
    failed = 0
    for name, fn in fns:
        try:
            fn()
            print(f"  ✅ {name}")
        except Exception as e:
            failed += 1
            print(f"  ❌ {name}: {type(e).__name__}: {e}")
    print(f"\n{len(fns) - failed}/{len(fns)} passed")
    sys.exit(1 if failed else 0)
