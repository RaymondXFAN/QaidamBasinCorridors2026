"""torch 侧自测（需 GPU/CPU 版 torch，在服务器上跑）。

Torch-side tests — run on the server.

跑法 / Run:
    python tests/test_torch.py

对应审稿意见：
  - R1-2  gate init / 生成器层数必须与论文一致
  - R1-7  宽度必须能被 heads 整除
  - A1（自查）gamma 必须真的参与运算
  - R3-3  同一测试集 → 隐含目标方差一致
"""

import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from filmstgat.models.film import FiLMGenerator, apply_film          # noqa: E402
from filmstgat.models.gat import SparseGATLayer, round_up_to_heads   # noqa: E402
from filmstgat.models.stgat import STGAT                             # noqa: E402
from filmstgat.train.seeding import set_all_seeds                    # noqa: E402
from filmstgat.train.trainer import train_stgat                       # noqa: E402


def _toy_graph(N=12, T=6, F=4, G=3, B=5, k=3, seed=0):
    g = torch.Generator().manual_seed(seed)
    X = torch.randn(B, N, T, F, generator=g)
    geo = torch.randn(N, G, generator=g)
    src = torch.arange(N).repeat_interleave(k)
    dst = (torch.arange(N * k) + 1) % N
    edge = torch.stack([src, dst])
    return X, geo, edge


def test_gamma_is_actually_applied():
    """★ A1：gamma 必须真的乘上去（原版算了却不用）。"""
    torch.manual_seed(0)
    gen = FiLMGenerator(geo_dim=3, hidden_dim=8, mode="full")
    # 手动把最后一层权重设成非零，让 gamma≠1
    with torch.no_grad():
        gen.mlp[-1].weight.normal_(0, 0.5)
        gen.mlp[-1].bias.normal_(0, 0.5)

    geo = torch.randn(12, 3)
    gamma, beta, gate = gen(geo)
    assert gamma is not None and beta is not None
    assert not torch.allclose(gamma, torch.ones_like(gamma)), "gamma 仍是 1，测试无效"

    h = torch.randn(2, 12, 6, 8)
    out_full = apply_film(h, gamma.view(1, 12, 1, -1), beta.view(1, 12, 1, -1), gate, "full")
    out_add = apply_film(h, None, beta.view(1, 12, 1, -1), gate, "add_only")

    assert not torch.allclose(out_full, out_add, atol=1e-6), \
        "full 与 add_only 输出相同 → gamma 没生效！"
    # full = gamma*h + gate*beta
    expect = h * gamma.view(1, 12, 1, -1) + gate * beta.view(1, 12, 1, -1)
    assert torch.allclose(out_full, expect, atol=1e-5)


def test_identity_at_init():
    """identity init 只保初始化：三种模式在 step 0 都应等价于恒等。"""
    for mode in ("full", "mul_only", "add_only"):
        gen = FiLMGenerator(geo_dim=3, hidden_dim=8, mode=mode)
        geo = torch.randn(12, 3)
        gamma, beta, gate = gen(geo)
        h = torch.randn(1, 12, 1, 8)
        g = gamma.view(1, 12, 1, -1) if gamma is not None else None
        b = beta.view(1, 12, 1, -1) if beta is not None else None
        out = apply_film(h, g, b, gate, mode)
        assert torch.allclose(out, h, atol=1e-6), f"{mode} 在初始化时不是恒等"


def test_gate_init_matches_paper():
    """R1-2：init=-1.5，论文也必须写 -1.5（不能一边 -2.2 一边 -1.5）。"""
    gen = FiLMGenerator(geo_dim=3, hidden_dim=8, mode="add_only", init_scale=-1.5)
    _, _, gate = gen(torch.zeros(4, 3))
    assert abs(float(gate) - float(torch.sigmoid(torch.tensor(-1.5)))) < 1e-6
    assert abs(float(gate) - 0.18) < 0.02, f"gate≈{float(gate):.3f}，应为 ~0.18"


def test_generator_hidden_layers():
    """R1-2：默认 1 个隐层（与代码一致），论文若写两层就必须改。"""
    gen = FiLMGenerator(geo_dim=3, hidden_dim=16, mode="add_only", num_hidden_layers=1)
    linears = [m for m in gen.mlp if isinstance(m, torch.nn.Linear)]
    assert len(linears) == 2, f"期望 1 个隐层(2 个 Linear)，实际 {len(linears)}"

    gen2 = FiLMGenerator(geo_dim=3, hidden_dim=16, mode="add_only", num_hidden_layers=2)
    linears2 = [m for m in gen2.mlp if isinstance(m, torch.nn.Linear)]
    assert len(linears2) == 3


def test_width_divisibility():
    """R1-7：宽度不整除时必须给可操作报错，且 round_up 能修好。"""
    assert round_up_to_heads(71, 4) == 72
    assert round_up_to_heads(68, 4) == 68
    try:
        SparseGATLayer(8, 71, num_heads=4)
    except ValueError as e:
        assert "整除" in str(e) or "divisible" in str(e)
    else:
        raise AssertionError("应当抛出可读错误，而不是裸 assert")

    layer = SparseGATLayer(8, 72, num_heads=4)
    h = torch.randn(3, 10, 8)
    edge = torch.stack([torch.arange(10), (torch.arange(10) + 1) % 10])
    assert layer(h, edge).shape == (3, 10, 72)


def test_forward_all_conditioning_modes():
    X, geo, edge = _toy_graph()
    configs = [
        dict(conditioning="none"),
        dict(conditioning="concat"),
        dict(conditioning="film", film_mode="add_only"),
        dict(conditioning="film", film_mode="mul_only"),
        dict(conditioning="film", film_mode="full"),
    ]
    for cfg in configs:
        m = STGAT(input_dim=X.shape[-1], geo_dim=geo.shape[-1], hidden_dim=32, **cfg)
        out = m(X, edge, geo)
        assert out.shape == (X.shape[0], X.shape[1]), (cfg, out.shape)


def test_flatten_nodes_preserves_order():
    """★ 回归测试：GRU 的输入必须是"每个节点一条时间序列"。

    这里错一行，模型照样能跑、不报错，但永远学不会（R²≈0.07）。
    用可辨识的张量把顺序钉死：(b,n) 的整条序列必须原样出现在第 b*N+n 行。
    """
    from filmstgat.models.stgat import _flatten_nodes
    B, N, T, H = 3, 4, 5, 2
    x = torch.arange(B * N * T * H, dtype=torch.float32).reshape(B, N, T, H)
    y = _flatten_nodes(x)
    assert y.shape == (B * N, T, H), y.shape
    for b in range(B):
        for n in range(N):
            assert torch.equal(y[b * N + n], x[b, n]), f"节点 ({b},{n}) 的序列被搅乱了"


def test_per_window_descriptors_all_modes():
    """★ 回归测试：逐窗口描述子（3D geo）必须能在所有模式下前向。

    冒烟时就是这里炸的：concat 只处理了 2D geo，遇到 (B,N,G) 直接
    "Tensors must have same number of dimensions: got 4 and 3"。
    """
    X, geo2d, edge = _toy_graph(N=8, T=5, F=3, B=4)
    geo3d = geo2d.unsqueeze(0).expand(4, -1, -1).contiguous()
    for cfg in (dict(conditioning="none"),
                dict(conditioning="concat"),
                dict(conditioning="film", film_mode="add_only"),
                dict(conditioning="film", film_mode="full")):
        m = STGAT(input_dim=3, geo_dim=3, hidden_dim=16, **cfg)
        out = m(X, edge, geo3d)
        assert out.shape == (4, 8), (cfg, out.shape)


def test_parameter_matching_is_close():
    """参数匹配对照：full 与 concat 的参数量应在同一量级（±15%）。"""
    X, geo, edge = _toy_graph()
    m_full = STGAT(input_dim=4, geo_dim=3, hidden_dim=64, conditioning="film", film_mode="full")
    m_cat = STGAT(input_dim=4, geo_dim=3, hidden_dim=64, conditioning="concat")
    ratio = m_cat.num_params / m_full.num_params
    assert 0.85 < ratio < 1.15, f"参数量比 {ratio:.3f}，需要调 hidden_dim 做匹配"


def test_determinism_same_seed():
    """R1-8：同 seed 两次必须逐元素一致。

    ⚠️ 注意构造顺序：必须用 build_model(seed, ...)，它在造模型前先定种子。
    第一次跑这个测试就是在这栽的——先 STGAT() 再 train(seed=)，权重初始化
    早就用掉了上一轮的全局随机状态，同 seed 也救不回来。
    Lesson learned the hard way: seed BEFORE constructing the model, otherwise
    the weight init already consumed the previous RNG state.
    """
    from filmstgat.models.factory import build_model

    X, geo, edge = _toy_graph(N=8, T=5, F=3, B=6)
    splits = {
        "X_train": X[:4].numpy(), "y_train": torch.randn(4, 8, generator=torch.Generator().manual_seed(1)).numpy(),
        "X_val": X[4:5].numpy(), "y_val": torch.zeros(1, 8).numpy(),
        "X_test": X[5:].numpy(), "y_test": torch.zeros(1, 8).numpy(),
    }
    edge_np = edge.numpy()
    geo_np = geo.numpy()
    kw = dict(input_dim=3, geo_dim=3, hidden_dim=16,
              conditioning="film", film_mode="add_only")

    r1 = train_stgat(build_model(7, **kw), splits, edge_np, geo_np,
                     seed=7, epochs=2, batch_size=2, patience=10, device="cpu")
    r2 = train_stgat(build_model(7, **kw), splits, edge_np, geo_np,
                     seed=7, epochs=2, batch_size=2, patience=10, device="cpu")
    assert np.allclose(r1["pred"], r2["pred"], atol=1e-6), "同 seed 结果不一致！"
    assert r1["seeding"]["seed"] == 7


def test_lambda_phys_is_recorded():
    """R1-2：实际用的 loss 必须落盘，不能嘴上说加了物理项。"""
    X, geo, edge = _toy_graph(N=6, T=4, F=3, B=4)
    splits = {
        "X_train": X.numpy(), "y_train": np.zeros((4, 6), dtype=np.float32),
        "X_val": X[:1].numpy(), "y_val": np.zeros((1, 6), dtype=np.float32),
        "X_test": X[:1].numpy(), "y_test": np.zeros((1, 6), dtype=np.float32),
    }
    r = train_stgat(STGAT(3, 3, hidden_dim=8, conditioning="none"), splits,
                    edge.numpy(), geo.numpy(), seed=1, epochs=1, batch_size=2,
                    lambda_phys=0.3, device="cpu")
    assert r["lambda_phys"] == 0.3
    assert "seeding" in r and "history" in r


if __name__ == "__main__":
    set_all_seeds(0)
    fns = [(k, v) for k, v in sorted(globals().items()) if k.startswith("test_")]
    failed = 0
    for name, fn in fns:
        try:
            fn()
            print(f"  ✅ {name}")
        except Exception as e:
            failed += 1
            print(f"  ❌ {name}: {type(e).__name__}: {e}")
    print(f"\n{len(fns) - failed}/{len(fns)} passed")
    sys.exit(1 if failed else 0)
