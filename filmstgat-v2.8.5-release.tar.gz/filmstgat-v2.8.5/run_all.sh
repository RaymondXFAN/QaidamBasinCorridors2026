#!/usr/bin/env bash
# =============================================================================
#  filmstgat v2.0.0 — single entry point
#  统一入口：一次装好，按阶段跑，所有产物落在 $ROOT 下
#
#  Author: Raymond Xiaohu Fan
#
#  Usage / 用法:
#     bash run_all.sh check      # offline tests, no GPU, ~10 s
#     bash run_all.sh data       # rebuild real (h=5, h=1) + synthetic datasets
#     bash run_all.sh e1         # conditioning ablations on real data
#     bash run_all.sh e1h1       # conditioning ablations, h=1 protocol
#     bash run_all.sh e2         # controlled overlap sweep (5 levels)
#     bash run_all.sh e2b        # endpoint contrast, 24 seeds
#     bash run_all.sh e3         # naive baselines (persistence / trend)
#     bash run_all.sh e4         # uncertainty + non-inferiority (needs e1)
#     bash run_all.sh synth      # synthetic benchmark + naive baselines
#     bash run_all.sh synthstats # synthetic paired tests + MDE
#     bash run_all.sh analyze    # paired DiD analysis of e2b
#     bash run_all.sh e3h1       # naive baselines, h=1 protocol
#     bash run_all.sh e5         # external baselines STGCN/DCRNN/PINN, h=5
#     bash run_all.sh e5h1       # external baselines, h=1 protocol
#     bash run_all.sh report     # one-screen status: runs, logs, verdicts
#     bash run_all.sh probe      # adapter shape check for the external baselines
#     bash run_all.sh signal     # how much learnable signal is left? (floors)
#     bash run_all.sh e4agg      # pool per-seed E4 runs + report the design's MDE
#     bash run_all.sh stats      # per-seed tests for E1 (both protocols)
#     bash run_all.sh tables     # every manuscript table (from result files)
#     bash run_all.sh figures    # every manuscript figure (from result files)
#     bash run_all.sh audit      # reproducibility self-audit (reviewers: start here)
#     bash run_all.sh bundle     # collect results/ for release (no weights)
#     bash run_all.sh all        # everything, in order
#
#  Environment / 环境变量:
#     ROOT       output root          (default: /root/autodl-tmp/revision_v2)
#     DATA_ROOT  raw/legacy data root (default: /root/autodl-tmp)
#     DEVICE     cuda|cpu             (default: cuda)
#     SEEDS      seeds per config     (default: 5)
#     EPOCHS     epochs per run       (default: 250)
#     BG         1 = nohup long stages (default: 1)
#
#  Why one entry point: the original submission had a different script (and a
#  different convention) for every table. That is how "which numbers produced
#  Table 5?" became unanswerable. Here every table has exactly one command.
#  原稿每张表对应一个脚本、各写各的约定，于是"Table 5 是哪次跑出来的"没人数得清。
# =============================================================================
set -euo pipefail

ROOT="${ROOT:-/root/autodl-tmp/revision_v2}"
DATA_ROOT="${DATA_ROOT:-/root/autodl-tmp}"
DEVICE="${DEVICE:-cuda}"
SEEDS="${SEEDS:-5}"
EPOCHS="${EPOCHS:-250}"
BG="${BG:-1}"

CODE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="$ROOT/logs"
DATA_REAL="$ROOT/datasets_v2/real_magt_data_v2_clean.npz"
DATA_H1="$ROOT/datasets_v2_h1/real_magt_data_v2_clean.npz"
DATA_SYN="$ROOT/datasets_synth_v2/synth_v2.npz"
LEGACY="$DATA_ROOT/datasets/processed/real_magt/real_magt_data.npz"

mkdir -p "$LOG_DIR" "$ROOT/runs"
cd "$CODE"

stage="${1:-check}"

banner() {
  echo "=============================================================="
  echo " $1"
  echo "  host : $(hostname)"
  echo "  root : $ROOT"
  echo "  code : $CODE"
  # 根目录体检：曾在另一台实例上跑，ROOT 是空目录，脚本一路"缺文件"却看不出是机器搞错了。
  # Root sanity check: a wrong machine looks identical to "experiments not run yet".
  if [ ! -d "$ROOT" ]; then
    echo "  [!] ROOT 不存在 / does not exist"
  else
    local n_entry n_npz
    n_entry=$(ls -1 "$ROOT" 2>/dev/null | wc -l | tr -d ' ')
    n_npz=$(find "$ROOT" -maxdepth 3 -name '*.npz' 2>/dev/null | wc -l | tr -d ' ')
    echo "  root : $n_entry entries, $n_npz npz file(s)"
    if [ "$n_npz" = "0" ]; then
      echo "  [!] ROOT 里没有任何 .npz —— 很可能不是同一台机器，或 ROOT 指错了。"
      echo "      先跑: find / -maxdepth 4 -name signal_diagnosis.json 2>/dev/null"
    fi
  fi
  echo "=============================================================="
}

need_file() {
  if [ ! -f "$1" ]; then
    echo "[fatal] missing: $1"
    echo "        run: bash run_all.sh data   (or check your ROOT / DATA_ROOT)"
    exit 1
  fi
}

# Run a command, logging to $LOG_DIR, backgrounded when BG=1 and the stage is long.
launch() {
  local name="$1"; shift
  local log="$LOG_DIR/${name}_$(date +%Y%m%d_%H%M%S).log"
  if [ "$BG" = "1" ]; then
    # PYTHONUNBUFFERED=1：python 输出到文件时是块缓冲（4–8 KB），长任务的前几十分钟
    # 日志会是空的，看起来像"卡住了"。强制无缓冲后 tail -f 才有意义。
    # Without this, a backgrounded python buffers 4–8 KB of stdout before
    # writing anything — the log looks dead for the first half hour.
    nohup env PYTHONUNBUFFERED=1 "$@" > "$log" 2>&1 &
    local pid=$!
    echo "$pid" > "$LOG_DIR/${name}.pid"
    echo "  started in background: PID=$pid"
    echo "  log  : $log"
    echo "  watch: tail -f $log"
  else
    echo "  running in foreground; log: $log"
    PYTHONUNBUFFERED=1 "$@" 2>&1 | tee "$log"
  fi
}

preflight() {
  echo "[preflight]"
  local missing=0
  for f in filmstgat/__init__.py filmstgat/train/trainer.py \
           filmstgat/models/stgat.py filmstgat/data/windows.py; do
    if [ -f "$f" ]; then echo "  ok    $f"; else echo "  MISS  $f"; missing=1; fi
  done
  [ "$missing" -eq 0 ] || { echo "[fatal] package incomplete (pwd=$(pwd))"; exit 1; }
  python - <<'PY'
import importlib, sys
for m in ("numpy", "scipy"):
    try:
        mod = importlib.import_module(m); print(f"  {m:6s} {getattr(mod,'__version__','?')}")
    except ImportError:
        sys.exit(f"  {m:6s} MISSING — pip install -r requirements.txt")
try:
    import torch
    print(f"  torch  {torch.__version__}  cuda={torch.cuda.is_available()}")
except ImportError:
    print("  torch  MISSING (only needed for experiments, not for 'check')")
PY
}

case "$stage" in
  help)
    sed -n '9,40p' "$0"
    ;;

  check)
    banner "Offline self-checks (no GPU)"
    preflight
    echo
    for t in tests/test_core.py tests/test_data_rebuild.py tests/test_e2_design.py tests/test_synth.py; do
      echo "[$t]"
      python "$t" | tail -2
    done
    echo
    echo "All offline suites passed. Next: bash run_all.sh data"
    ;;

  data)
    banner "Rebuild datasets"
    need_file "$LEGACY"
    # ★ 保护：已有数据集默认不覆盖。重建会用同一套参数，但"应该一样"不等于
    #   "一定一样"，把正在用的数据覆盖掉是不可逆的。要看重建结果，先显式 FORCE=1。
    #   Guard: never overwrite an existing dataset unless FORCE=1 is set.
    if [ -f "$ROOT/datasets_v2/real_magt_data_v2_clean.npz" ] && [ "${FORCE:-0}" != "1" ]; then
      echo "[skip] $ROOT/datasets_v2 already exists (FORCE=1 to rebuild)"
    else
      echo "[1/3] real, 5-year protocol (gap=4)"
      python scripts/build_dataset_v2.py --legacy "$LEGACY" \
        --out "$ROOT/datasets_v2" --T-in 10 --gap 4 --T-out 1
    fi

    if [ -f "$ROOT/datasets_v2_h1/real_magt_data_v2_clean.npz" ] && [ "${FORCE:-0}" != "1" ]; then
      echo "[skip] $ROOT/datasets_v2_h1 already exists (FORCE=1 to rebuild)"
    else
      echo "[2/3] real, 1-year protocol (gap=0)"
      python scripts/build_dataset_v2.py --legacy "$LEGACY" \
        --out "$ROOT/datasets_v2_h1" --T-in 10 --gap 0 --T-out 1
    fi

    if [ -f "$ROOT/datasets_synth_v2/synth_v2.npz" ] && [ "${FORCE:-0}" != "1" ]; then
      echo "[skip] $ROOT/datasets_synth_v2 already exists (FORCE=1 to rebuild)"
    else
      echo "[3/3] synthetic (bit-reproducible from config)"
      python scripts/regen_synthetic.py --out "$ROOT/datasets_synth"
      python scripts/build_synth_v2.py --raw "$ROOT/datasets_synth/qaidam_inSAR.npz" \
        --out "$ROOT/datasets_synth_v2"
    fi
    echo
    echo "Existing datasets are never overwritten without FORCE=1."
    ;;

  e1)
    banner "E1 — conditioning ablations (real data, h=5)"
    need_file "$DATA_REAL"
    launch e1 python filmstgat/experiments/e1_info_matched.py \
      --data "$DATA_REAL" --out "$ROOT/runs/e1" \
      --n-sub 500 --seeds "$SEEDS" --epochs "$EPOCHS" --device "$DEVICE"
    ;;

  e1h1)
    banner "E1 — conditioning ablations (real data, h=1 protocol)"
    need_file "$DATA_H1"
    launch e1h1 python filmstgat/experiments/e1_info_matched.py \
      --data "$DATA_H1" --out "$ROOT/runs/e1h1" \
      --n-sub 500 --seeds "$SEEDS" --epochs "$EPOCHS" --device "$DEVICE"
    ;;

  e2)
    banner "E2 — controlled overlap sweep (5 levels)"
    need_file "$DATA_H1"
    launch e2 python filmstgat/experiments/e2_overlap_sweep.py \
      --data "$DATA_H1" --out "$ROOT/runs/e2" \
      --n-sub 500 --seeds 5 --epochs 250 --alphas 0,0.25,0.5,0.75,1 --device "$DEVICE"
    ;;

  e2b)
    banner "E2b — endpoint contrast (24 seeds)"
    need_file "$DATA_H1"
    launch e2b python filmstgat/experiments/e2_overlap_sweep.py \
      --data "$DATA_H1" --out "$ROOT/runs/e2b" \
      --n-sub 500 --seeds 24 --epochs 250 --alphas 0,1 --device "$DEVICE"
    ;;

  e3)
    banner "E3 — naive baselines (real data, h=1)"
    need_file "$DATA_H1"
    launch e3 python filmstgat/experiments/e3_naive_baselines.py \
      --data "$DATA_H1" --out "$ROOT/runs/e3" --n-sub 500 --T-in 10 --gap 0
    ;;

  e4)
    banner "E4 — uncertainty / non-inferiority"
    if [ ! -d "$ROOT/runs/e1" ]; then
      echo "[fatal] E4 needs E1 outputs: bash run_all.sh e1"; exit 1
    fi
    launch e4 python filmstgat/experiments/e4_uncertainty.py \
      --a "$ROOT/runs/e1" --b "$ROOT/runs/e1" --out "$ROOT/runs/e4"
    ;;

  synth)
    banner "Synthetic benchmark — ablations + naive baselines"
    need_file "$DATA_SYN"
    launch synth python filmstgat/experiments/e1_synthetic.py \
      --data "$DATA_SYN" --out "$ROOT/runs/e1synth" \
      --seeds "$SEEDS" --epochs "${SYNTH_EPOCHS:-800}" --patience "${SYNTH_PATIENCE:-120}" --batch-size 16 --device "$DEVICE"
    ;;

  synthstats)
    banner "Synthetic benchmark — paired tests, Holm, MDE"
    if [ ! -f "$ROOT/runs/e1synth/e1_synth_summary.json" ]; then
      echo "[fatal] no synthetic results yet: bash run_all.sh synth"; exit 1
    fi
    python scripts/analyze_synth.py --runs "$ROOT/runs/e1synth"
    ;;

  e3h1)
    banner "E3 — naive baselines (h=1 protocol)"
    need_file "$DATA_H1"
    launch e3h1 python filmstgat/experiments/e3_naive_baselines.py \
      --data "$DATA_H1" --out "$ROOT/runs/e3h1" --n-sub 500 --T-in 10 --gap 0
    ;;

  e5)
    banner "E5 — external baselines (STGCN / DCRNN / PINN), h=5"
    need_file "$DATA_REAL"
    launch e5 python filmstgat/experiments/e5_baselines.py \
      --data "$DATA_REAL" --out "$ROOT/runs/e5" \
      --n-sub 500 --seeds "$SEEDS" --epochs "$EPOCHS" \
      --T-in 10 --gap 4 --device "$DEVICE" --tag e5
    ;;

  e5h1)
    banner "E5 — external baselines, h=1 protocol"
    need_file "$DATA_H1"
    launch e5h1 python filmstgat/experiments/e5_baselines.py \
      --data "$DATA_H1" --out "$ROOT/runs/e5h1" \
      --n-sub 500 --seeds "$SEEDS" --epochs "$EPOCHS" \
      --T-in 10 --gap 0 --device "$DEVICE" --tag e5h1
    ;;

  signal)
    banner "SIGNAL — how much is left above the zero-modelling floors?"
    need_file "$DATA_REAL"
    python scripts/diagnose_signal.py \
      --data "$DATA_REAL" --n-sub 500 --T-in 10 --gap 4 --runs "$ROOT/runs/e1"
    ;;

  e4agg)
    banner "E4-AGG — pool per-seed equivalence runs, report the MDE"
    # --rmse 必须按协议给：h=5 与我们模型的 RMSE 是 1.34 量级，h=1 是 0.78 量级，
    # 用同一个常数换算百分比会得出"11.3%"这种错误结论。
    python scripts/aggregate_e4.py --glob "$ROOT/runs/e4/h5_ff_vs_std_s*" \
      --margin 0.01 --rmse 1.344 --label h5_ff_vs_std
    echo
    python scripts/aggregate_e4.py --glob "$ROOT/runs/e4/h1_ff_vs_std_s*" \
      --margin 0.01 --rmse 0.784 --label h1_ff_vs_std
    ;;

  audit)
    banner "Reproducibility audit — reviewers start here"
    python scripts/repro_audit.py --root "$CODE"
    ;;

  bundle)
    banner "Bundle result files for release (no GPU, no raw data needed)"
    python scripts/collect_results.py --runs "$ROOT" --out "$ROOT/results"
    ;;

  report)
    ROOT="$ROOT" bash scripts/report.sh
    ;;

  probe)
    banner "Baseline adapter probe — no training, ~10 s"
    python scripts/probe_baselines.py --device "${PROBE_DEVICE:-cpu}"
    ;;

  stats)
    banner "E1 statistics — per-seed tests for both protocols"
    if [ -d "$ROOT/runs/e1" ]; then
      python scripts/analyze_e1.py --stage e1 --runs "$ROOT/runs/e1" \
        --ref-json "$ROOT/runs/e3/metrics_e3.json" || true
    fi
    if [ -d "$ROOT/runs/e1h1" ]; then
      python scripts/analyze_e1.py --stage e1h1 --runs "$ROOT/runs/e1h1" \
        --ref-json "$ROOT/runs/e3h1/metrics_e3.json" || true
    fi
    ;;

  tables)
    banner "Manuscript tables — generated from result files only"
    python scripts/make_tables.py --root "$ROOT"
    echo "  → $ROOT/tables/"
    ;;

  figures)
    banner "Manuscript figures — read from result files only"
    python figures/make_figures.py --root "$ROOT"
    echo "  → $ROOT/figures/"
    ;;

  analyze)
    banner "E2b analysis — paired DiD"
    if [ ! -f "$ROOT/runs/e2b/e2_summary.json" ]; then
      echo "[fatal] no e2b results yet: bash run_all.sh e2b"; exit 1
    fi
    python scripts/analyze_e2b.py --runs "$ROOT/runs/e2b"
    echo
    cat "$ROOT/runs/e2b/analysis/analysis.md"
    ;;

  all)
    bash "$0" check
    bash "$0" data
    bash "$0" e1
    bash "$0" e1h1
    bash "$0" e3
    bash "$0" e3h1
    bash "$0" e2
    bash "$0" e2b
    bash "$0" synth
    echo
    echo "All stages launched. When they finish:"
    echo "  bash run_all.sh analyze      # E2b paired DiD"
    echo "  bash run_all.sh synthstats   # synthetic paired tests + MDE"
    echo "  bash run_all.sh e5           # external baselines (Table 5)"
    echo "  bash run_all.sh tables       # every manuscript table"
    echo "  bash run_all.sh figures      # every manuscript figure"
    ;;

  *)
    echo "unknown stage: $stage"
    sed -n '9,22p' "$0"
    exit 1
    ;;
esac
