"""filmstgat — Overlap-aware FiLM conditioning for spatio-temporal graph networks.

v2 重构版：单一真相源。
Single source of truth, v2 rewrite.

作者 / Author: Raymond Xiaohu Fan
"""

__version__ = "2.8.5"
__all__ = ["__version__"]
