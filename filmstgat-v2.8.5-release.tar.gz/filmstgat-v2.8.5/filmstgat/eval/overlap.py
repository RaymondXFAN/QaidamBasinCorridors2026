"""Overlap degree rho: spatial-gradient agreement. 重叠度指标。

Overlap degree rho: spatial-gradient agreement between conditioning field
and target field.

README 当年就写了"ρ 由 spatial-gradient agreement 计算，ρ>0.5 用 additive，
ρ<0.3 用 full"，但**代码里一行都没有**（审稿人 R1-1 抓得死死的）。
这个模块就是把它补齐，并且给出可复现的定义。
The README promised this metric but the code never implemented it — exactly
what Reviewer 1 nailed. Here it is, with an explicit, reproducible definition.
"""

from __future__ import annotations

import numpy as np

__all__ = ["spatial_gradient", "overlap_degree", "select_mode"]


def spatial_gradient(field: np.ndarray) -> np.ndarray:
    """返回 (H, W, 2) 的空间梯度 [gx, gy]。

    用 np.gradient 的中心差分；边缘为一阶差分。
    """
    f = np.asarray(field, dtype=np.float64)
    if f.ndim != 2:
        raise ValueError(f"field 必须是二维 (H,W)，收到 {f.shape}")
    gy, gx = np.gradient(f)
    return np.stack([gx, gy], axis=-1)


def overlap_degree(field_a: np.ndarray, field_b: np.ndarray,
                   mask: np.ndarray | None = None) -> float:
    """Spatial-gradient agreement between two fields, rho in [0, 1]. 两场一致性。

    定义 / Definition
    ----------------
    1. 各取空间梯度 g_a, g_b ∈ R^{H×W×2}
    2. 逐像元余弦相似度 cos = <g_a, g_b> / (‖g_a‖‖g_b‖)
    3. ρ = (mean(cos) + 1) / 2

    为什么用 (cos+1)/2：余弦天然落在 [-1,1]（反向梯度 = 完全不同的结构），
    映射到 [0,1] 后便于和阈值 0.3 / 0.5 对话。
    Why (cos+1)/2: cosine lives in [-1,1]; mapping to [0,1] makes the
    0.3/0.5 thresholds meaningful.

    注意 / Caveat
    -------------
    这是**空间结构**的一致性，不是数值相关。两个场数值差很多但空间
    起伏一致时，ρ 依然很高——这正是"overlap"该有的含义。
    This measures structural agreement, not value correlation.
    """
    a = np.asarray(field_a, dtype=np.float64)
    b = np.asarray(field_b, dtype=np.float64)
    if a.shape != b.shape:
        raise ValueError(f"两场形状不一致 {a.shape} vs {b.shape}")

    ga, gb = spatial_gradient(a), spatial_gradient(b)

    if mask is not None:
        m = np.asarray(mask, dtype=bool)
        ga, gb = ga[m], gb[m]
    else:
        ga, gb = ga.reshape(-1, 2), gb.reshape(-1, 2)

    na = np.linalg.norm(ga, axis=1)
    nb = np.linalg.norm(gb, axis=1)
    valid = np.isfinite(na) & np.isfinite(nb) & (na > 1e-12) & (nb > 1e-12)
    if not np.any(valid):
        # 全平场：梯度为零，无从谈重叠，返回 0 而不是 nan。
        return 0.0

    cos = np.sum(ga[valid] * gb[valid], axis=1) / (na[valid] * nb[valid])
    cos = np.clip(cos, -1.0, 1.0)
    return float((np.mean(cos) + 1.0) / 2.0)


def select_mode(rho: float, hi: float = 0.5, lo: float = 0.3) -> str:
    """按 ρ 给出建议的 FiLM 形式（保守优先）。

    高重叠 → additive（不改写特征分布）；
    低重叠 → full（乘性调制有信息可加）；
    中间带 → 保守选 additive，因为"错用 additive"的代价小于"错用 full"。
    High overlap -> additive (does not rewrite the feature distribution);
    low overlap -> full; the grey zone defaults to the safer additive.
    """
    if rho >= hi:
        return "add_only"
    if rho <= lo:
        return "full"
    return "add_only"
