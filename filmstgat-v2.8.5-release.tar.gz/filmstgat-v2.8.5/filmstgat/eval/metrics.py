"""One evaluator: one metric set, one test set, one inverse-transform path. 统一评估器。

Unified evaluator: one metric set, one test set, one inverse-transform path.

为什么单独做这个模块？因为 R3 发现 Table 5 里 XGBoost 的 RMSE 更低、
R² 也更低——反推目标方差一个是 16.66、一个是 27.96，说明**根本没在
同一个测试集上算**。这个模块就把这事焊死：同一批 y_true，同一批索引。
Why a separate module? Reviewer 3 spotted that XGBoost had lower RMSE but
also lower R² — implying target variances of 16.66 vs 27.96, i.e. different
test sets entirely. This module welds that shut: same y_true, same indices.
"""

from __future__ import annotations

import numpy as np

__all__ = [
    "rmse", "mae", "r2", "summarize",
    "implied_target_variance", "assert_metric_consistency",
]


def _as_1d(a) -> np.ndarray:
    a = np.asarray(a, dtype=np.float64).ravel()
    return a


def rmse(y_pred, y_true) -> float:
    p, t = _as_1d(y_pred), _as_1d(y_true)
    if p.shape != t.shape:
        raise ValueError(f"形状不一致 {p.shape} vs {t.shape} / shape mismatch")
    return float(np.sqrt(np.mean((p - t) ** 2)))


def mae(y_pred, y_true) -> float:
    p, t = _as_1d(y_pred), _as_1d(y_true)
    if p.shape != t.shape:
        raise ValueError(f"形状不一致 {p.shape} vs {t.shape} / shape mismatch")
    return float(np.mean(np.abs(p - t)))


def r2(y_pred, y_true) -> float:
    """R² 用**测试集自身**的方差做分母（sklearn 一致口径）。

    R² uses the variance of y_true itself, matching the pooled definition.
    这里坚持"同一 y_true"，否则反推出的目标方差就会对不上。
    """
    p, t = _as_1d(y_pred), _as_1d(y_true)
    ss_res = float(np.sum((t - p) ** 2))
    ss_tot = float(np.sum((t - np.mean(t)) ** 2))
    if ss_tot <= 0:
        # 常数目标：R² 无定义，返回 nan 而不是瞎给个数。
        # Constant target: R² is undefined; return nan instead of inventing one.
        return float("nan")
    return float(1.0 - ss_res / ss_tot)


def summarize(y_pred, y_true) -> dict:
    """Compute everything at once, including n — the column that settles "same test set?". 一次算全。"""
    p, t = _as_1d(y_pred), _as_1d(y_true)
    return {
        "n_samples": int(p.size),
        "rmse": rmse(p, t),
        "mae": mae(p, t),
        "r2": r2(p, t),
        "y_true_mean": float(np.mean(t)),
        "y_true_var": float(np.var(t)),
    }


def implied_target_variance(rmse_value: float, r2_value: float) -> float:
    """由 RMSE 与 R² 反推目标方差：Var = RMSE² / (1 − R²)。

    这是个"体检指标"：同一个测试集上，所有模型反推出的 Var 必须相同。
    如果不同，说明有人在偷偷换测试集。
    A sanity metric: on one test set this number must be identical across all
    models. If it differs, somebody swapped the test set.
    """
    denom = 1.0 - float(r2_value)
    if denom <= 0:
        # R² <= 0 时公式失去意义，返回 inf 让上层显式处理。
        return float("inf")
    return float(rmse_value) ** 2 / denom


def assert_metric_consistency(records, rtol: float = 0.02, raise_error: bool = True) -> dict:
    """Check that a group of results shares one test set. 检查是否共用同一测试集。

    Parameters
    ----------
    records : list of dict
        每条至少含 `model`, `rmse`, `r2`。
    rtol : float
        允许的相对偏差（默认 2%，仅为浮点误差留余量）。
    """
    variances = {}
    for r in records:
        v = implied_target_variance(r["rmse"], r["r2"])
        variances[r.get("model", "?")] = v

    finite = {k: v for k, v in variances.items() if np.isfinite(v)}
    if not finite:
        return {"ok": True, "variances": variances, "spread": float("nan")}

    lo, hi = min(finite.values()), max(finite.values())
    spread = (hi - lo) / max(lo, 1e-12)
    ok = spread <= rtol

    if not ok and raise_error:
        detail = ", ".join(f"{k}={v:.2f}" for k, v in variances.items())
        raise AssertionError(
            "指标不自洽：不同模型反推出的目标方差不同，说明测试集不一致。\n"
            f"Inconsistent metrics: implied target variances differ ({detail}); "
            f"spread={spread*100:.1f}% > {rtol*100:.0f}%.\n"
            "→ 这就是 R3-3 那类问题，先在数据管线里找原因，别急着调模型。\n"
            "→ This is exactly the R3-3 problem. Fix the pipeline, not the model."
        )
    return {"ok": ok, "variances": variances, "spread": spread}
