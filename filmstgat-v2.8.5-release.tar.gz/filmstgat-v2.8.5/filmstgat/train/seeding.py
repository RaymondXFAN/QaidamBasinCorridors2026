"""Centralised RNG management. 随机源统一管理。

One place for all randomness.

R1-8 说得很准：原脚本只 seed 了空间子采样，模型初始化/dropout/训练顺序
全靠天意；五个 seed 的"显著性检验"因此站不住。
Reviewer 1 was right: only spatial subsampling was seeded; init, dropout and
training order were left to fate. A significance test built on that is void.
"""

from __future__ import annotations

import os
import random

import numpy as np

# cuBLAS 在 CUDA>=10.2 上默认不确定；这个环境变量必须在第一次 CUDA 运算前设好。
# 不设的话 torch 会一直警告，而且同 seed 仍可能差最后几位。
# Must be set before the first CUDA call, otherwise cuBLAS stays
# non-deterministic and the warning never goes away.
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")

__all__ = ["set_all_seeds", "worker_init_fn"]


def set_all_seeds(seed: int, deterministic: bool = True) -> dict:
    """一次性固定 python / numpy / torch / cuda 的随机源。

    返回实际生效的设置，写进 run_manifest —— 光"设了"没用，要能证明。
    Returns what was actually applied so it can be recorded in the manifest.
    Setting it is not enough; we need to prove it.
    """
    seed = int(seed)
    applied = {"seed": seed, "deterministic": bool(deterministic)}

    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)

    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
        if deterministic:
            torch.backends.cudnn.deterministic = True
            torch.backends.cudnn.benchmark = False
            # Some ops have no deterministic implementation; let them raise — an error beats "looks like it runs" / 宁可报错
            # Some ops lack deterministic kernels; fail loudly rather than
            # silently producing irreproducible numbers.
            try:
                torch.use_deterministic_algorithms(True, warn_only=True)
                applied["use_deterministic_algorithms"] = True
            except Exception:
                applied["use_deterministic_algorithms"] = False
        applied["torch"] = torch.__version__
    except ImportError:
        applied["torch"] = "not-installed"

    return applied


def worker_init_fn(worker_id: int) -> None:
    """DataLoader worker 的种子（如果以后用多进程加载）。"""
    base = int(os.environ.get("PYTHONHASHSEED", 0))
    np.random.seed(base + worker_id)
