"""The one and only training loop. 唯一的训练循环。

The one and only training loop.

原仓库有两套训练代码（trainers/trainer.py 一套，每个实验脚本里再各写一套），
早停/评估口径还不完全一样——这本身就是 R1-2 "exact executable configuration"
说不清的根源。现在只有一个。
The old repo had two training stacks (the shared trainer plus a bespoke loop in
every experiment script) with slightly different early-stopping rules. That is
precisely why R1-2 could not be answered. Now there is one.
"""

from __future__ import annotations

import copy
import time

import numpy as np
import torch
import torch.nn.functional as F

from ..eval.metrics import summarize
from .seeding import set_all_seeds

__all__ = ["train_stgat"]


def _to_t(x, device):
    return torch.as_tensor(np.ascontiguousarray(x), dtype=torch.float32, device=device)


def _iterate(n: int, batch: int, shuffle: bool, rng: np.random.Generator):
    idx = np.arange(n)
    if shuffle:
        rng.shuffle(idx)
    for s in range(0, n, batch):
        yield idx[s:s + batch]


def train_stgat(model, splits, edge_index, geo, *, seed: int = 42,
                epochs: int = 200, lr: float = 1e-3, batch_size: int = 8,
                weight_decay: float = 0.0, patience: int = 40,
                lambda_phys: float = 0.0, device: str = "cuda",
                verbose: int = 0, y_mean: float = 0.0, y_std: float = 1.0) -> dict:
    """训练一个 STGAT 并返回测试集结果。

    Parameters
    ----------
    splits : dict
        必须含 X_train/y_train/X_val/y_val/X_test/y_test，
        X 形如 (w, N, T, F)，y 形如 (w, N)；且 **必须是同一套窗口索引切出来的**。
        Must all come from the same window indices — that is the whole point.
    geo : np.ndarray, (N, G) 原始（未标准化）描述子
    lambda_phys : float
        物理约束权重。**必须在结果里记录实际取值**，否则又会出现
        "Methods 说加了物理项、脚本其实只用了 MSE"（R1-2）。
        Must be recorded in the output; otherwise we repeat the R1-2 mistake.
    """
    device = device if (device != "cuda" or torch.cuda.is_available()) else "cpu"
    applied = set_all_seeds(seed)
    dev = torch.device(device)

    model = model.to(dev)

    # 三个集合各自的条件描述子（逐窗口 origin 时必须分开传）。
    # 若 splits 里没有 geo_*，退回共享的 geo（2D 情形）。
    # Per-split descriptors: required when descriptors are per-window.
    def _as_tensor(g):
        return _to_t(g, dev) if g is not None else None

    geo_tr = _as_tensor(splits.get("geo_train", geo))
    geo_va = _as_tensor(splits.get("geo_val", geo))
    geo_te = _as_tensor(splits.get("geo_test", geo))
    edge_t = torch.as_tensor(np.ascontiguousarray(edge_index), dtype=torch.long, device=dev)

    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    rng = np.random.default_rng(seed)

    Xtr, ytr = splits["X_train"], splits["y_train"]
    Xva, yva = splits["X_val"], splits["y_val"]
    Xte, yte = splits["X_test"], splits["y_test"]

    best_state, best_val, best_epoch = None, float("inf"), -1
    history = []
    t0 = time.time()

    for epoch in range(1, epochs + 1):
        model.train()
        epoch_loss = 0.0
        for bidx in _iterate(len(Xtr), batch_size, True, rng):
            xb = _to_t(Xtr[bidx], dev)
            yb = _to_t(ytr[bidx], dev)
            opt.zero_grad(set_to_none=True)
            gb = _slice_geo(geo_tr, bidx, dev)
            pred = model(xb, edge_t, gb)
            # ★ 形状守卫。pred 必须是 (B,N)。若模型返回 (B,N,1)，mse_loss 会
            #   去广播 (B,N,1)×(1,B,N)——运气不好就报维度错，运气好就**静默**
            #   算出 (B,N,N) 的错误 loss，训练曲线依然好看。宁可早失败。
            #   Shape guard: a trailing singleton dim turns F.mse_loss into a
            #   silent (B,N,N) broadcast. Fail loudly instead.
            if pred.shape != yb.shape:
                raise ValueError(
                    f"{type(model).__name__} returned {tuple(pred.shape)} but targets "
                    f"are {tuple(yb.shape)}; expected (B, N). Strip the trailing "
                    f"singleton dim — see AUDIT_LOG D-36.")
            loss = F.mse_loss(pred, yb)
            if lambda_phys > 0:
                loss = loss + lambda_phys * _physics_penalty(pred, gb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            epoch_loss += float(loss.item()) * len(bidx)
        epoch_loss /= max(1, len(Xtr))

        val_rmse_norm = _eval_rmse(model, Xva, yva, edge_t, geo_va, dev)
        val_rmse = val_rmse_norm * y_std        # 报 °C，方便和基线比
        history.append({"epoch": epoch, "train_loss": epoch_loss,
                        "val_rmse": val_rmse, "val_rmse_norm": val_rmse_norm})

        if verbose and (epoch % 20 == 0 or epoch == 1):
            print(f"    epoch {epoch:3d}  loss={epoch_loss:.5f}  val_rmse={val_rmse:.5f}")

        if val_rmse < best_val - 1e-6:
            best_val, best_epoch = val_rmse, epoch
            best_state = copy.deepcopy(model.state_dict())
        elif epoch - best_epoch >= patience:
            if verbose:
                print(f"    early stop at epoch {epoch} (best={best_epoch})")
            break

    if best_state is not None:
        model.load_state_dict(best_state)

    pred = _predict(model, Xte, edge_t, geo_te, dev)

    # ★ 指标必须在**原始单位**下计算（°C），否则会和 persistence 之类的基线
    #   单位错位，得出"模型更好"的假结论——这正是 R3-3 的类型。
    # Metrics MUST be in original units. Otherwise comparing against a
    # physical baseline is apples-to-oranges — the exact R3-3 failure mode.
    pred_raw = pred * y_std + y_mean
    true_raw = np.asarray(yte, dtype=np.float64) * y_std + y_mean

    result = {
        "metrics": summarize(pred_raw, true_raw),
        "metrics_normalised": summarize(pred, yte),
        "pred": pred_raw.astype(np.float32),
        "true": true_raw.astype(np.float32),
        "units": "physical (inverse-transformed)", 
        "best_epoch": best_epoch,
        "best_val_rmse": best_val,
        "epochs_run": len(history),
        "seconds": round(time.time() - t0, 1),
        "seed": seed,
        "lambda_phys": float(lambda_phys),
        "seeding": applied,
        "history": history,
    }
    return result


@torch.no_grad()
def _predict(model, X, edge_t, geo_t, dev) -> np.ndarray:
    model.eval()
    out = []
    for s in range(0, len(X), 8):
        xb = _to_t(X[s:s + 8], dev)
        out.append(model(xb, edge_t, _slice_geo(geo_t, np.arange(s, min(s + 8, len(X))), dev)).cpu().numpy())
    return np.concatenate(out, axis=0)


def _slice_geo(geo_t, idx, dev):
    """geo 支持 (N,G) 全场共用，或 (W,N,G) 逐窗口。

    逐窗口是 origin 一致性的必要条件：每个窗口必须用"自己那个时刻"的描述子，
    否则又回到"所有窗口统一看 2010"的老毛病（D-08）。
    Per-window descriptors are what origin consistency requires: each window
    must use the descriptors available at its own origin.
    """
    if geo_t is None or geo_t.dim() == 2:
        return geo_t
    return geo_t[torch.as_tensor(np.asarray(idx), dtype=torch.long, device=dev)]


@torch.no_grad()
def _eval_rmse(model, X, y, edge_t, geo_t, dev) -> float:
    p = _predict(model, X, edge_t, geo_t, dev)
    return float(np.sqrt(np.mean((p - np.asarray(y)) ** 2)))


def _physics_penalty(pred, geo_t):
    """Stefan 约束的软惩罚：预测值不应超过 k_s · ALT 的物理上界。

    这里只做一个温和的越界惩罚，别把它当成"物理保证"——
    审稿人 R3-2 已经说了：没有任何机制能保证测试性能。
    A mild out-of-bound penalty only. Do NOT call this a physical guarantee;
    R3-2 is right that nothing here guarantees test-time behaviour.

    geo_t 可能是 (N,G) 或 (B,N,G)，两种都要能算。
    """
    if geo_t is None:
        return torch.zeros((), device=pred.device)
    it = geo_t[..., 2] if geo_t.dim() == 3 else geo_t[:, 2]
    it = torch.clamp(it, min=0.0)
    bound = torch.sqrt(2.0 * 1.2 * it * 86400.0 / 3.34e8)
    return torch.relu(pred - bound).mean()
