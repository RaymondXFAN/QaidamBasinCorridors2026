#!/usr/bin/env python3
"""E1 — 信息匹配对照：到底是 FiLM 机制，还是多拿了三个描述子？

E1 — Information-matched control: is it the FiLM mechanism, or simply the
three extra descriptors?

审稿人 R1-3 的原话是：no-FiLM comparator 应该通过**非 FiLM 通路**拿到
完全相同的三个条件变量。这里就用 `conditioning="concat"` 实现：
同样 3 个描述子、直接拼到输入通道、不给任何调制。

同时补一个参数匹配的 `none_wider`：把 standard 模型加宽到与 full FiLM
参数量相当——容量控制住了，信息没给，两者一减，才是"机制"的净效应。

作者 / Author: Raymond Xiaohu Fan

用法 / Usage:
    python experiments/e1_info_matched.py \
        --data <ROOT>/datasets_v2/real_magt_data_v2_clean.npz \
        --out  <ROOT>/runs/e1 \
        --n-sub 500 --seeds 5 --epochs 200
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from filmstgat.experiments.common import (  # noqa: E402
    load_v2, pick_pixels, make_splits, save_run, aggregate,
)
from filmstgat.models.factory import build_model  # noqa: E402
from filmstgat.models.gat import round_up_to_heads  # noqa: E402
from filmstgat.models.stgat import STGAT  # noqa: E402
from filmstgat.train.trainer import train_stgat  # noqa: E402


def match_width(base_kwargs: dict, target_params: int, heads: int = 4,
                lo: int = 48, hi: int = 320) -> int:
    """Brute-force scan over legal widths to match parameter counts. 扫描合法宽度匹配参数量。

    为什么不用二分：原版就是二分 + 没取整，才 assert 崩掉的（R1-7）。
    扫描范围才几十个点，代价可以忽略，换来"绝不会崩"。
    Why not binary search: the original binary search without rounding is
    exactly what asserted (R1-7). Scanning a few dozen legal widths costs
    nothing and cannot crash.
    """
    kwargs = {k: v for k, v in base_kwargs.items() if k != "hidden_dim"}
    best, best_gap = None, float("inf")
    for w in range(round_up_to_heads(lo, heads), hi + 1, heads):
        m = STGAT(hidden_dim=w, **kwargs)
        gap = abs(m.num_params - target_params)
        if gap < best_gap:
            best, best_gap = w, gap
    return int(best)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--n-sub", type=int, default=500)
    ap.add_argument("--selection", choices=["stratified", "random"], default="stratified",
                    help="像素选择方式；默认与论文一致的分层抽样")
    ap.add_argument("--layers", type=int, default=2, help="空间层数")
    ap.add_argument("--no-residual", action="store_true",
                    help="关闭输出残差与空间自连接（不建议，仅供消融）")
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--configs", default="",
                    help="逗号分隔的配置名，只跑其中几个（默认全跑）；用于上限/泄漏这类小实验")
    ap.add_argument("--epochs", type=int, default=200)
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--lambda-phys", type=float, default=0.0,
                    help="物理项权重；默认 0 表示强制纯 MSE，和代码实际一致")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    code_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    data = load_v2(args.data)
    pix = pick_pixels(data, args.n_sub, seed=42, mode=args.selection)
    splits = make_splits(data, pix)
    F = splits["X_train"].shape[-1]
    G = splits["geo_train"].shape[-1]
    N = splits["X_train"].shape[1]

    print("=" * 74)
    print(f"E1 信息匹配对照   pixels={len(pix)}  windows={len(splits['X_train'])}/"
          f"{len(splits['X_val'])}/{len(splits['X_test'])}  F={F} G={G}")
    print("=" * 74)

    # Residual parameterisation and spatial self-connection are on by default / 默认启用：
    # 前面的诊断证明，没有这两条通路时模型连 persistence 都追不上。
    # shared by every configuration, so the comparison stays fair / 所有配置共用，公平性不受影响。
    base = dict(input_dim=F, geo_dim=G, hidden_dim=64, num_heads=4,
                num_spatial_layers=args.layers, dropout=0.1,
                residual_output=not args.no_residual,
                spatial_residual=not args.no_residual)

    # 以 full FiLM 为容量基准，给 standard 配一个同参数量版本
    film_full = STGAT(conditioning="film", film_mode="full", **base)
    target = film_full.num_params
    wide = match_width(base | {"conditioning": "none"}, target)
    print(f"  参数匹配：full FiLM={target:,}  →  none_wider 的 hidden_dim={wide}")

    configs = [
        ("standard",       dict(conditioning="none",  hidden_dim=64)),
        ("standard_wider", dict(conditioning="none",  hidden_dim=wide)),
        ("concat_info",    dict(conditioning="concat", hidden_dim=64)),
        ("film_add",       dict(conditioning="film", film_mode="add_only", hidden_dim=64)),
        ("film_full",      dict(conditioning="film", film_mode="full",     hidden_dim=64)),
    ]

    if args.configs:
        keep = {c.strip() for c in args.configs.split(",") if c.strip()}
        configs = [c for c in configs if c[0] in keep]
        if not configs:
            raise SystemExit(f"--configs 没有匹配到任何配置: {keep}")


    rows = []
    t_all = time.time()
    for seed in range(42, 42 + args.seeds):
        print(f"\n--- seed {seed} ---")
        for name, override in configs:
            kw = {**base, **override}
            model = build_model(seed, **kw)
            res = train_stgat(
                model, splits, splits["edge_index"], None,
                seed=seed, epochs=args.epochs, lr=1e-3, batch_size=8,
                patience=40, lambda_phys=args.lambda_phys, device=args.device,
                y_mean=splits["mean"], y_std=splits["std"],
            )
            run_id = f"{name}_seed{seed}"
            # 注意：test 用 geo_test，train/val 用 geo_train —— 逐窗口描述子
            save_run(args.out, run_id, res,
                     config={"model": name, **{k: v for k, v in kw.items()}},
                     dataset_path=args.data, code_root=code_root,
                     extra={"params": model.num_params,
                            "conditioning": kw.get("conditioning"),
                            "film_mode": kw.get("film_mode")})
            m = res["metrics"]
            rows.append({"model": name, "seed": seed, "rmse": m["rmse"],
                         "mae": m["mae"], "r2": m["r2"],
                         "params": model.num_params})
            print(f"  {name:16} RMSE={m['rmse']:.4f}  R²={m['r2']:.4f} "
                  f"params={model.num_params:,}  ({res['seconds']}s)")

    # Aggregate / 汇总
    summary = aggregate(rows)
    order = [c[0] for c in configs]
    with open(os.path.join(args.out, "summary_e1.json"), "w", encoding="utf-8") as fh:
        json.dump(summary, fh, indent=2, ensure_ascii=False)
    with open(os.path.join(args.out, "runs_e1.jsonl"), "w", encoding="utf-8") as fh:
        for r in rows:
            fh.write(json.dumps(r) + "\n")

    print("\n" + "=" * 74)
    print(f"{'model':18}{'RMSE (mean±std)':>24}{'R²':>12}{'params':>12}")
    print("-" * 74)
    for name in order:
        s = summary[name]
        print(f"{name:18}{s['rmse_mean']:.4f} ± {s['rmse_std']:.4f}"
              f"{s['r2_mean']:>16.4f}{s['params']:>12,}")
    print("=" * 74)
    print(f"总耗时 {time.time()-t_all:.0f}s  → {args.out}")
    print("\n怎么读这张表：")
    print("  film_full vs concat_info → 同为 3 个描述子，差的就是'机制'本身")
    print("  concat_info vs standard  → 多给的描述子本身值多少")
    print("  standard_wider vs film_full → 参数量相同时的净差异")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
