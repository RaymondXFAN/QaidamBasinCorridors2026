"""Shared experiment plumbing: tensor assembly, batching, result persistence. 实验公共件。

Shared plumbing: assemble tensors, slice windows, persist results.

三条铁律 / Three rules
----------------------
1. 所有模型吃**同一批测试窗口**（否则又是 R3-3）。
2. 每个 run 必须落 `predictions.npz` + `metrics.json` + `run_manifest.json`。
3. 归一化只用训练期统计量。
"""

from __future__ import annotations

import json
import os

import numpy as np

from ..data.real import knn_edges
from ..eval.metrics import summarize
from ..utils.provenance import write_run_manifest

__all__ = ["load_v2", "pick_pixels", "make_splits", "save_run", "aggregate"]


def load_v2(path: str) -> dict:
    d = np.load(path, allow_pickle=True)
    return {k: d[k] for k in d.files}


def pick_pixels(data: dict, n: int | None, seed: int, mode: str = "stratified") -> np.ndarray:
    """Select a pixel subset. 选像素子集。

    mode="stratified"：按 1981–2010 均值分层（**与论文协议一致**，推荐）
    mode="random"    ：纯随机（仅用于快速冒烟）

    为什么默认分层：论文用的是分层抽样，随机抽样会改变像素的温度构成，
    RMSE 就不可比了——这正是"同一测试集"要求的一部分（R3-3 的教训）。
    """
    total = data["series"].shape[0]
    if n is None or n >= total:
        return np.arange(total)
    if mode == "random":
        rng = np.random.default_rng(seed)
        return np.sort(rng.choice(total, size=n, replace=False))
    if mode != "stratified":
        raise ValueError("mode 只能是 'stratified' 或 'random'")

    from ..data.real import stratified_sample, train_period_mask

    series = data["series"]
    ok = train_period_mask(series)
    cand = np.where(ok)[0]
    mean = np.nanmean(series[:, :30], axis=1)
    return stratified_sample(cand, mean, n, n_bins=10, seed=seed)


def make_splits(data: dict, pix: np.ndarray, k: int = 8,
                pixel_size_m: float = 1000.0) -> dict:
    """装配 train/val/test 张量，并重建子图。

    关键：三个集合引自 `split_*` 的**窗口索引**，因此 flat/graph 天然同源。
    """
    Xw = data["X_windows"][pix]                    # (n,W,T,F)
    yw = data["y_windows"][pix]                    # (n,W,1)
    desc = data["descriptors"][:, pix, :]          # (W,n,G)

    X = Xw.transpose(1, 0, 2, 3)                   # (W,n,T,F)
    y = yw[:, :, 0].transpose(1, 0)                # (W,n)

    mean, std = float(data["ts_mean"]), float(data["ts_std"])
    X = ((X - mean) / (std + 1e-8)).astype(np.float32)
    y = ((y - mean) / (std + 1e-8)).astype(np.float32)

    # 描述子按训练窗口标准化，避免量纲把 FiLM 压死
    tr = data["split_train"]
    d_mean = desc[tr].mean(axis=(0, 1), keepdims=True)
    d_std = desc[tr].std(axis=(0, 1), keepdims=True) + 1e-8
    desc = ((desc - d_mean) / d_std).astype(np.float32)

    edge, _ = knn_edges(data["pixel_indices"][pix], k=k, pixel_size_m=pixel_size_m)

    out = {"edge_index": edge, "mean": mean, "std": std,
           "d_mean": d_mean.reshape(-1), "d_std": d_std.reshape(-1)}
    for name in ("train", "val", "test"):
        idx = data[f"split_{name}"]
        out[f"X_{name}"] = X[idx]
        out[f"y_{name}"] = y[idx]
        out[f"geo_{name}"] = desc[idx]
    out["target_years"] = data["target_idx"] + 1981
    return out


def save_run(out_dir: str, run_id: str, result: dict, *, config: dict,
             dataset_path: str, code_root: str, extra: dict | None = None) -> str:
    """落盘一个 run 的三件套。"""
    d = os.path.join(out_dir, run_id)
    os.makedirs(d, exist_ok=True)

    np.savez_compressed(
        os.path.join(d, "predictions.npz"),
        pred=result["pred"], true=result["true"],
    )
    with open(os.path.join(d, "metrics.json"), "w", encoding="utf-8") as fh:
        # ★ 一定要把 `units` 落盘：没有它，下游无法区分"物理单位"和"归一化单位"，
        #   而后者看起来完全合理（RMSE≈1.0），是最危险的一类陈旧结果。
        #   `units` must be persisted, otherwise downstream cannot tell physical
        #   from normalised metrics — and normalised ones look plausible.
        payload = {k: result[k] for k in
                   ("metrics", "best_epoch", "best_val_rmse", "epochs_run",
                    "seconds", "seed", "lambda_phys", "seeding")}
        payload["units"] = result.get("units", "unknown")
        if "metrics_normalised" in result:
            payload["metrics_normalised"] = result["metrics_normalised"]
        json.dump(payload, fh, indent=2, ensure_ascii=False)

    write_run_manifest(
        d, run_id=run_id, code_root=code_root, data_paths=[dataset_path],
        config=config, seeds={"global": result["seed"]},
        extra={"metrics": result["metrics"], **(extra or {})},
    )
    return d


def aggregate(rows: list) -> dict:
    """把多 seed 结果汇总成 mean±std，并检查指标自洽（R3-3）。"""
    by_model: dict = {}
    for r in rows:
        by_model.setdefault(r["model"], []).append(r)

    summary = {}
    for model, rs in by_model.items():
        rmse = np.array([x["rmse"] for x in rs], dtype=float)
        r2 = np.array([x["r2"] for x in rs], dtype=float)
        summary[model] = {
            "n_seeds": len(rs),
            "rmse_mean": float(rmse.mean()), "rmse_std": float(rmse.std(ddof=1)) if len(rs) > 1 else 0.0,
            "r2_mean": float(r2.mean()), "r2_std": float(r2.std(ddof=1)) if len(rs) > 1 else 0.0,
            "params": rs[0].get("params"),
        }
    return summary


def summarize_predictions(pred, true) -> dict:
    return summarize(pred, true)
