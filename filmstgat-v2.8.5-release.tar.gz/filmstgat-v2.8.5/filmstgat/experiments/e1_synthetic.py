#!/usr/bin/env python3
"""E1（合成数据）：条件化配置对照 + 朴素基线，同协议、同测试窗口。

E1 on synthetic: conditioning ablations against naive baselines, one protocol.

三个必须说清楚的设计决定 / Three decisions that must be stated, not buried
----------------------------------------------------------------------------
1. **滞后目标通道**（`--lags 1`，默认开）
   生成器的 12 个特征里**不含沉降本身**。模型看不到近期沉降，就永远打不过
   persistence——那不是模型弱，是输入缺了必要信息。所以把 y(t-1) 作为第 13
   通道接进去（预测 t 时 t-1 已知，不构成泄漏）。
   The 12 generated features do not include settlement itself. Without the
   lagged target the task is not comparable to persistence, so we append y(t-1)
   as an extra channel (known at forecast time, no leakage).

2. **残差基底指向滞后通道**
   在真实数据里通道 0 就是目标序列，`ŷ = x_last + Δ` 天然合法；合成数据里通道 0
   是形变速率，直接套会把输出钉死在错的量级。正确做法不是**关掉**残差，而是把
   基底指向我们加进来的滞后通道（索引 = 原始特征数）：`ŷ = y(t−1) + f(·)`。
   所有配置共用同一条捷径，公平性不受影响。
   原本我关掉了残差，结果模型必须从零学出绝对水平，而 persistence 只是复制上期值，
   于是模型以 4 倍劣势落败——那不是模型弱，是协议缺了一条人人都该有的通路。
   In the real data channel 0 *is* the target series, so the residual shortcut is
   natural. In synthetic data channel 0 is deformation velocity, so instead of
   disabling the shortcut we point it at the lagged target channel:
   `y_hat = y(t-1) + f(.)`. Shared by all configurations, so the comparison stays
   fair. Disabling it (my first attempt) made the models compete with one hand
   tied behind their back.

3. **合成数据的描述子是外生的**
   geo = [ALT, k_s, I_t] 来自 Stefan 方程与气候参数，**不是**从输入序列算出来的，
   所以 overlap 天生就低。这正是它与真实数据互补的地方：
   真实数据里描述子由输入派生（R3-5 的混杂），合成数据里没有。
   The synthetic priors are exogenous, so overlap is low by construction —
   the mirror image of the real-data confounding R3-5 raised.

作者 / Author: Raymond Xiaohu Fan
"""

from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__)))))

from scipy import stats                                              # noqa: E402

from filmstgat.eval.metrics import summarize, rmse as rmse_fn          # noqa: E402
from filmstgat.experiments.common import save_run                      # noqa: E402

# 同 e2：训练才需要 torch，基线/装配部分要能在无 GPU 环境自检。
try:                                                                    # noqa: E402
    from filmstgat.models.factory import build_model
    from filmstgat.train.trainer import train_stgat
    HAS_TORCH = True
except ImportError:                                                     # pragma: no cover
    build_model = None
    train_stgat = None
    HAS_TORCH = False

CONFIGS = {
    "standard":        {"conditioning": "none"},
    "standard_wider":  {"conditioning": "none", "hidden_wider": True},
    "concat_info":     {"conditioning": "concat"},
    "film_add":        {"conditioning": "film", "film_mode": "add_only"},
    "film_full":       {"conditioning": "film", "film_mode": "full"},
}


def load_synth(path: str, lags: int = 1):
    """装配张量；切分索引直接取自 dataset（绝不重新推导）。"""
    d = np.load(path, allow_pickle=True)
    Xw = np.asarray(d["X_windows"], dtype=np.float32)        # (N,W,T,F)
    yw = np.asarray(d["y_windows"], dtype=np.float32)[:, :, 0]   # (N,W)
    y_series = np.asarray(d["y_series"], dtype=np.float32)   # (N,T)
    target_idx = np.asarray(d["target_idx"], dtype=np.int64)
    geo = np.asarray(d["descriptors"], dtype=np.float32)     # (W,N,3)
    x_mean = np.asarray(d["x_mean"], dtype=np.float32)
    x_std = np.asarray(d["x_std"], dtype=np.float32)
    y_mean, y_std = float(d["y_mean"]), float(d["y_std"])

    N, W, T, F = Xw.shape

    # ---- Lagged target channel / 滞后目标通道 ----
    if lags > 0:
        lag_ch = np.zeros((N, W, T, lags), dtype=np.float32)
        for k in range(lags):
            for w in range(W):
                end = target_idx[w] - 1 - k        # 目标前 k+1 个时刻
                for j in range(T):
                    src = end - (T - 1 - j)
                    lag_ch[:, w, j, k] = y_series[:, src] if src >= 0 else 0.0
        Xw = np.concatenate([Xw, lag_ch], axis=-1)
        # 滞后通道用 y 的统计量归一化（量纲与 y 一致）
        x_mean = np.concatenate([x_mean, np.full(lags, y_mean, dtype=np.float32)])
        x_std = np.concatenate([x_std, np.full(lags, y_std, dtype=np.float32)])

    X = Xw.transpose(1, 0, 2, 3)                              # (W,N,T,F')
    Y = yw.transpose(1, 0)                                    # (W,N)
    Xn = ((X - x_mean) / x_std).astype(np.float32)
    Yn = ((Y - y_mean) / y_std).astype(np.float32)

    tr = np.asarray(d["split_train"])
    g_mean = geo[tr].mean(axis=(0, 1), keepdims=True)
    g_std = geo[tr].std(axis=(0, 1), keepdims=True) + 1e-8
    geo_n = ((geo - g_mean) / g_std).astype(np.float32)

    splits = {"edge_index": np.asarray(d["edge_index"])}
    for name in ("train", "val", "test"):
        idx = np.asarray(d[f"split_{name}"])
        splits[f"X_{name}"] = Xn[idx]
        splits[f"y_{name}"] = Yn[idx]
        splits[f"geo_{name}"] = geo_n[idx]

    # 滞后通道的起始索引：残差基底必须指向它，而不是通道 0
    # Index of the first lag channel; the residual base must point here, not at 0.
    lag_channel = (F if lags > 0 else None)
    return {"splits": splits, "Y_raw": Y, "y_series": y_series,
            "target_idx": target_idx, "y_mean": y_mean, "y_std": y_std,
            "input_dim": Xn.shape[-1], "geo_dim": geo_n.shape[-1],
            "lag_channel": lag_channel,
            "test_idx": np.asarray(d["split_test"]), "n_nodes": N}


def naive_baselines(d: dict) -> dict:
    """persistence / climatology(逐节点逐月) / trend(末 6 期线性外推一步)。

    三个基线都在**原始单位**下算，和模型走同一套逆标准化后的指标，
    否则又会重演"基线单位不同 → 模型显得更好"的老坑。
    """
    y_series, target_idx = d["y_series"], d["target_idx"]
    test_idx, y_mean, y_std = d["test_idx"], d["y_mean"], d["y_std"]
    Y_raw = d["Y_raw"]

    split_idx = int(target_idx[test_idx].min())      # 96：测试期起点

    # 逐节点 × 日历月 的气候态（只用训练期 < split_idx 的月份）
    clim = np.zeros_like(y_series)
    for m in range(12):
        cols = [t for t in range(split_idx) if t % 12 == m]
        if cols:
            clim[:, m::12] = y_series[:, cols].mean(axis=1, keepdims=True)

    preds = {"persistence": [], "climatology": [], "trend": []}
    for w in test_idx:
        t = int(target_idx[w])
        preds["persistence"].append(y_series[:, t - 1])
        preds["climatology"].append(clim[:, t])

        # 用 t-k … t-1 拟合直线，外推一步到 t
        k = min(6, t)
        x = np.arange(k, dtype=np.float64)
        xbar = x.mean()
        ys = y_series[:, t - k:t].astype(np.float64)
        denom = float(np.sum((x - xbar) ** 2)) or 1.0
        slope = ((ys - ys.mean(axis=1, keepdims=True)) @ (x - xbar)) / denom
        preds["trend"].append(ys.mean(axis=1) + slope * (k - xbar))

    out = {}
    for name, pl in preds.items():
        p = np.stack(pl, axis=0)                     # (W_test, N)
        m = summarize(p, Y_raw[test_idx])
        m["rmse_norm"] = float(rmse_fn((p - y_mean) / y_std,
                                       (Y_raw[test_idx] - y_mean) / y_std))
        out[name] = m
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--epochs", type=int, default=800,
                    help="150 was not enough: 66 windows x batch 16 = 5 steps/epoch")
    ap.add_argument("--patience", type=int, default=120)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--batch-size", type=int, default=16)
    ap.add_argument("--hidden", type=int, default=64)
    ap.add_argument("--lags", type=int, default=1)
    ap.add_argument("--no-residual", action="store_true",
                    help="disable the residual base on the lag channel (diagnostic only)")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--configs", default="standard,standard_wider,concat_info,film_add,film_full")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    code_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    d = load_synth(args.data, lags=args.lags)
    sp = d["splits"]
    edge = sp["edge_index"]

    print("=" * 88)
    print("E1（合成）条件化对照 + 朴素基线")
    print(f"  nodes={d['n_nodes']}  windows train/val/test = "
          f"{len(sp['X_train'])}/{len(sp['X_val'])}/{len(sp['X_test'])}")
    print(f"  input_dim={d['input_dim']} (含 {args.lags} 个滞后目标通道)  geo_dim={d['geo_dim']}")
    print(f"  residual base: lag channel = {d['lag_channel']} "
          f"（ŷ = y(t−1) + f(·)，所有配置共用）" if d["lag_channel"] is not None
          else "  residual base: DISABLED (--no-residual)")
    print("=" * 88)

    results = {"naive": naive_baselines(d), "configs": {}}
    for name in results["naive"]:
        print(f"  [baseline] {name:12s} RMSE={results['naive'][name]['rmse']:.4f}  "
              f"R²={results['naive'][name]['r2']:+.3f}")

    print()
    for cfg_name in [c.strip() for c in args.configs.split(",") if c.strip()]:
        spec = dict(CONFIGS[cfg_name])
        wider = spec.pop("hidden_wider", False)
        hidden = 96 if wider else args.hidden
        rmses, r2s, best_epochs, epochs_run = [], [], [], []
        for k in range(args.seeds):
            seed = 42 + k
            use_res = (not args.no_residual) and (d["lag_channel"] is not None)
            model = build_model(
                seed, input_dim=d["input_dim"], geo_dim=d["geo_dim"],
                hidden_dim=hidden,
                residual_output=use_res,
                residual_channel=(d["lag_channel"] or 0),
                spatial_residual=False, **spec)
            res = train_stgat(model, sp, edge, None, seed=seed, epochs=args.epochs,
                              lr=args.lr, batch_size=args.batch_size,
                              patience=args.patience, device=args.device,
                              y_mean=d["y_mean"], y_std=d["y_std"])
            rmses.append(res["metrics"]["rmse"])
            r2s.append(res["metrics"]["r2"])
            best_epochs.append(int(res["best_epoch"]))
            epochs_run.append(int(res["epochs_run"]))
            # ★ 每次训练都落三件套（predictions / metrics / run_manifest）。
            #   上一版只存了 predictions.npz，溯源链在这里断了——R1-9 问起来就是缺口。
            #   Every run must write the full triple; a bare predictions.npz breaks
            #   the provenance chain exactly where R1-9 is pointed.
            save_run(
                args.out, f"{cfg_name}_seed{seed}", res,
                config={"experiment": "e1_synthetic", "config": cfg_name,
                        "epochs": args.epochs, "patience": args.patience,
                        "lr": args.lr, "batch_size": args.batch_size,
                        "hidden_dim": hidden, "lags": args.lags,
                        "residual_output": bool(use_res),
                        "residual_channel": int(d["lag_channel"] or 0),
                        "seed": seed, **spec},
                dataset_path=args.data, code_root=code_root,
                extra={"params": int(model.num_params),
                       "best_epoch": int(res["best_epoch"]),
                       "early_stopped": bool(res["epochs_run"] < args.epochs)},
            )
        pers = float(results["naive"]["persistence"]["rmse"])
        d_pers = np.asarray(rmses, dtype=float) - pers      # >0 表示不如 persistence
        if len(d_pers) > 1 and d_pers.std(ddof=1) > 1e-12:
            t_p, p_p = stats.ttest_1samp(d_pers, 0.0)
            p_p = float(p_p)
        else:
            p_p = None
        results["configs"][cfg_name] = {
            "rmse_mean": float(np.mean(rmses)),
            "rmse_std": float(np.std(rmses, ddof=1)) if len(rmses) > 1 else 0.0,
            "r2_mean": float(np.mean(r2s)), "n_seeds": len(rmses),
            "hidden": hidden, "params": int(model.num_params),
            "rmse_per_seed": [float(x) for x in rmses],
            # 收敛诊断：best_epoch 顶到上限 = 没学完，不能解读成"没有信号"
            # Convergence diagnostic: best_epoch at the cap means undertrained,
            # which must not be reported as "no signal".
            "best_epoch_mean": float(np.mean(best_epochs)),
            "best_epoch_max": int(np.max(best_epochs)),
            "epochs_run_mean": float(np.mean(epochs_run)),
            "any_early_stopped": bool(any(e < args.epochs for e in epochs_run)),
            "delta_vs_persistence": float(d_pers.mean()),
            "delta_vs_persistence_pct": float(100.0 * d_pers.mean() / pers),
            "p_vs_persistence": p_p,
        }
        r = results["configs"][cfg_name]
        flag = "early-stopped" if r["any_early_stopped"] else "HIT EPOCH CAP"
        print(f"  {cfg_name:16s} RMSE={r['rmse_mean']:.4f} ± {r['rmse_std']:.4f}  "
              f"R²={r['r2_mean']:+.3f}  Δvs_pers={r['delta_vs_persistence']:+.4f} "
              f"({r['delta_vs_persistence_pct']:+.2f}%)  best_epoch={r['best_epoch_mean']:.0f} [{flag}]")

    with open(os.path.join(args.out, "e1_synth_summary.json"), "w", encoding="utf-8") as fh:
        json.dump(results, fh, indent=2, ensure_ascii=False)

    best_naive = min(v["rmse"] for v in results["naive"].values())
    with open(os.path.join(args.out, "table_e1_synth.md"), "w", encoding="utf-8") as fh:
        fh.write("| model | RMSE (°C) | R² | Δ vs persistence | p | best epoch | params |\n")
        fh.write("|:--|--:|--:|--:|--:|--:|--:|\n")
        for name, v in results["naive"].items():
            fh.write(f"| {name} (baseline) | {v['rmse']:.4f} | {v['r2']:+.3f} | "
                     f"— | — | — | 0 |\n")
        for name, v in results["configs"].items():
            pp = "—" if v["p_vs_persistence"] is None else f"{v['p_vs_persistence']:.3f}"
            fh.write(f"| {name} | {v['rmse_mean']:.4f} ± {v['rmse_std']:.4f} | "
                     f"{v['r2_mean']:+.3f} | {v['delta_vs_persistence']:+.4f} "
                     f"({v['delta_vs_persistence_pct']:+.2f}%) | {pp} | "
                     f"{v['best_epoch_mean']:.0f}/{'early' if v['any_early_stopped'] else 'CAP'} | "
                     f"{v['params']} |\n")
        fh.write(f"\n> 最强朴素基线 RMSE = {best_naive:.4f} °C\n")

    print(f"\n最强朴素基线 = {best_naive:.4f} °C")
    print(f"结果 → {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
