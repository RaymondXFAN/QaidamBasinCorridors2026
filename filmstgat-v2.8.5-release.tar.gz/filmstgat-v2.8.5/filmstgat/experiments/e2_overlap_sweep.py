#!/usr/bin/env python3
"""E2 — 受控 overlap 扫描：同一任务、同一数据，只改条件场与输入的重叠度。

E2 — Controlled overlap sweep: same task, same data, only the overlap between
the conditioning field and the input field varies.

问题 / Question
---------------
论文原来说"ρ 高就用 additive，ρ 低就用 full"。审稿人 R1-1 指出这句话在
代码里根本没实现，R3-5 指出描述子与输入并不独立。所以我们要在**同一个任务、
同一份数据、同一批测试窗口**上把 overlap 当成一个可控变量，看 Δ(ρ) 到底
有没有方向。
The paper claimed "high rho -> additive, low rho -> full". R1-1 showed it was
never implemented; R3-5 showed the descriptors are not independent of the input.
So we make overlap a *controlled* variable within one task, one dataset, one set
of test windows.

受控做法 / The controlled manipulation
--------------------------------------
对每个窗口，条件场 g 由两部分线性混合：
    g(α) = α · g_true + (1 − α) · g_perm
  · g_true：该像素真实历史算出的描述子（与输入几乎完全重叠）
  · g_perm ：把同一批描述子在像素间**随机置换**——边缘分布一点没变，
             只是"这组描述子被安到了错误的像素上"
  · α ∈ {0, .25, .5, .75, 1}

这个设计的要义：**信息量守恒，只动空间对应关系**。
所以如果 Δ 随 α（也就是 ρ）单调变化，那就是 overlap 在起作用，不是
"信息多寡"在起作用。这一点必须写进论文，否则 Reviewer 会说我们还是
没把 confound 分开。
The point: marginal information is held constant; only spatial correspondence
moves. If Delta tracks alpha, it is overlap doing the work — not information.

作者 / Author: Raymond Xiaohu Fan

用法 / Usage:
    python experiments/e2_overlap_sweep.py \
        --data <ROOT>/datasets_v2_h1/real_magt_data_v2_clean.npz \
        --out  <ROOT>/runs/e2 \
        --n-sub 500 --seeds 5 --epochs 250
"""

from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np
from scipy import stats
from scipy.interpolate import griddata

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__)))))

from filmstgat.eval.metrics import rmse as rmse_fn                      # noqa: E402
from filmstgat.eval.overlap import overlap_degree                       # noqa: E402
from filmstgat.experiments.common import load_v2, pick_pixels, make_splits, save_run  # noqa: E402

# torch 只在真正训练时需要。设计自检（置换/ρ/桩跑）要在无 GPU、甚至无 torch
# ... on a torch-free machine, otherwise "verify the manipulation first" never happens / 无 torch 也能跑
# torch is only needed for actual training; the design checks must run anywhere.
try:                                                                     # noqa: E402
    from filmstgat.models.factory import build_model
    from filmstgat.train.trainer import train_stgat
    HAS_TORCH = True
except ImportError:                                                      # pragma: no cover
    build_model = None
    train_stgat = None
    HAS_TORCH = False

ALPHAS = (0.0, 0.25, 0.5, 0.75, 1.0)


def to_grid(pix: np.ndarray, vals: np.ndarray, bins: int = 96) -> np.ndarray:
    """Rasterise scattered pixels onto a regular grid. 把散点插值到规则网格。

    ρ 的定义基于二维空间梯度，所以必须先铺成网格。用线性插值，空位用最近邻补，
    保证没有 NaN 污染 np.gradient。
    rho is defined on 2-D spatial gradients, so we rasterise first; empty cells
    are filled nearest-neighbour so np.gradient never sees NaN.
    """
    r = pix[:, 0].astype(float)
    c = pix[:, 1].astype(float)
    r = (r - r.min()) / max(r.max() - r.min(), 1e-9)
    c = (c - c.min()) / max(c.max() - c.min(), 1e-9)
    g = np.linspace(0.0, 1.0, bins)
    XX, YY = np.meshgrid(g, g)

    v = np.asarray(vals, dtype=float)
    if not np.isfinite(v).any() or np.nanstd(v) < 1e-12:
        return np.zeros((bins, bins), dtype=float)

    pts = np.stack([c, r], axis=1)
    grid = griddata(pts, v, (XX, YY), method="linear")
    if np.isnan(grid).any():
        near = griddata(pts, v, (XX, YY), method="nearest")
        grid = np.where(np.isnan(grid), near, grid)
    return grid


def mix_conditioning(geo_true: np.ndarray, alpha: float, seed: int) -> np.ndarray:
    """g(α) = α·真实 + (1−α)·像素置换（通道共用同一置换，保持像素内自洽）。"""
    rng = np.random.default_rng(seed)
    W, N, G = geo_true.shape
    out = np.empty_like(geo_true)
    for w in range(W):
        perm = rng.permutation(N)
        noise = geo_true[w, perm]
        out[w] = alpha * geo_true[w] + (1.0 - alpha) * noise
    return out.astype(np.float32)


def measure_rho(desc: np.ndarray, input_fields: np.ndarray, pix: np.ndarray,
                test_idx: np.ndarray) -> float:
    """实测 ρ：条件场（描述子第 0 通道）与输入场（origin 那一年的观测）。

    注意用 `input_fields`（来自 X_windows 的最后一帧）而不是 series[origin]，
    这样不依赖 gap 参数，也不会因为 gap 设错而算错年份。
    We read the origin-year field straight off the last input frame, so the
    measurement cannot drift when the gap argument changes.
    """
    vals = []
    for w in test_idx:
        cond = to_grid(pix, desc[w][:, 0])
        inp = to_grid(pix, input_fields[w])
        vals.append(overlap_degree(cond, inp))
    return float(np.mean(vals)) if vals else float("nan")


def spatial_blocks(pix: np.ndarray, n_bins: int = 5) -> np.ndarray:
    """把像素按坐标分块（n_bins×n_bins），给块自助法用。

    逐像素自助会低估不确定性，因为相邻像素的残差高度相关。按空间块重采样
    保守一些，也更接近"换一片区域还会不会成立"这个问题。
    Per-pixel bootstrap understates uncertainty because neighbouring residuals are
    correlated; resampling spatial blocks is the conservative choice.
    """
    q = np.linspace(0, 1, n_bins + 1)[1:-1]
    r = np.digitize(pix[:, 0], np.quantile(pix[:, 0], q))
    c = np.digitize(pix[:, 1], np.quantile(pix[:, 1], q))
    return (r * n_bins + c).astype(np.int64)


def block_bootstrap_delta(err2_add: np.ndarray, err2_full: np.ndarray,
                          blocks: np.ndarray, n_boot: int = 2000,
                          seed: int = 0) -> tuple:
    """ΔRMSE = RMSE_full − RMSE_add 的 95% 块自助区间。"""
    rng = np.random.default_rng(seed)
    uniq = np.unique(blocks)
    idx_by_block = [np.where(blocks == b)[0] for b in uniq]
    deltas = np.empty(n_boot)
    for i in range(n_boot):
        pick = rng.integers(0, len(uniq), size=len(uniq))
        idx = np.concatenate([idx_by_block[j] for j in pick])
        deltas[i] = (np.sqrt(err2_full[idx].mean()) - np.sqrt(err2_add[idx].mean()))
    return float(np.percentile(deltas, 2.5)), float(np.percentile(deltas, 97.5))


def build_verdict(rows: list) -> tuple:
    """把"这份结果能不能支撑 C6"写成**可测试的判定**，而不是一段顺口的话。

    上一版只看 Spearman 的符号：n=5 时符号几乎等于抛硬币（p≈0.6），
    真按那条规则跑，纯噪声会被判成"方向一致、C6 保留"。
    现在的要求是：至少一档在配对检验或块自助区间上显著，否则一律判「无证据」。
    The previous rule keyed on the SIGN of Spearman. At n=5 that is a coin flip,
    so pure noise would have been promoted to a design rule. Now a level must
    actually be significant, or the answer is "no evidence".

    Returns
    -------
    (verdict: list[str], stats: dict)
    """
    rhos = np.array([r["rho"] for r in rows], dtype=float)
    deltas = np.array([r["delta_full_minus_add"] for r in rows], dtype=float)
    spread = float(deltas.max() - deltas.min()) if len(deltas) else 0.0
    rho_range = float(rhos.max() - rhos.min()) if len(rhos) else 0.0
    ps = [r["p_value"] for r in rows if r["p_value"] is not None]

    can_correlate = rho_range > 1e-9 and np.ptp(deltas) > 1e-12 and len(rhos) > 3
    sp = stats.spearmanr(rhos, deltas) if can_correlate else None
    rho_delta = float(sp.statistic) if sp is not None else 0.0
    rho_delta_p = float(sp.pvalue) if sp is not None else 1.0

    verdict = []
    floor = float(rhos.min()) if len(rhos) else float("nan")
    # Validate the tool before reading the result: the lowest alpha must sit near chance level 0.5 / 先验工具再读结论
    if not (0.40 <= floor <= 0.68):
        verdict.append(f"⚠ α 最低档的实测 ρ={floor:.3f}，偏离随机水平 0.5 过多，"
                       f"先怀疑置换或栅格化，别急着解读 Δ。")
    if len(rows):
        rho_star = 2.0 * rhos - 1.0
        verdict.append(f"实测 ρ 区间 [{rhos.min():.3f}, {rhos.max():.3f}]，"
                       f"对应校正后 ρ* ∈ [{rho_star.min():+.3f}, {rho_star.max():+.3f}]；"
                       f"注意 ρ* = 0 才是「与随机无异」。")
    if rho_range < 0.15:
        verdict.append("ρ 的变动幅度过小（<0.15），这一轮没能真正扫开 overlap，需调整置换强度。")

    # Two sources of significance, never to be conflated / 两种显著性来源：
    #   seed_sig —— 换一批初始化还成不成立（对"方法级"结论负责）
    #   ci_sig   —— 在这批像素上差异是否确定（对"这块地"负责）
    # 两者冲突时以种子级为准，并把冲突显式写出来（D-24）。
    # Two sources of uncertainty. Seed-level answers "does it hold across
    # initialisations"; the block bootstrap answers "is it certain on these
    # pixels". When they disagree, seed-level wins and the conflict is printed.
    seed_sig = [r["alpha"] for r in rows if r["p_value"] is not None and r["p_value"] < 0.05]
    ci_sig = [r["alpha"] for r in rows
              if r.get("delta_ci95") and not (r["delta_ci95"][0] <= 0.0 <= r["delta_ci95"][1])]
    ci_only = [a for a in ci_sig if a not in seed_sig]
    sig_levels = seed_sig
    if ci_only:
        verdict.append(f"⚠ α ∈ {ci_only} 的块自助区间不含 0，但种子级检验不显著："
                       f"只反映这批像素上的确定差异，**不得**当作方法级结论引用。")

    if spread < 0.005:
        verdict.append("Δ 在各档之间几乎不变（<0.005 °C）——没有证据支持 overlap 决定 FiLM 形式。")
    elif sig_levels:
        if len(rows) < 4:
            # 两个端点之间没有"趋势"可言：Spearman 在 n=2 时无定义，
            # 硬算会打出 +0.00 这种看着像结论、其实无意义的数字（D-25）。
            verdict.append(f"显著档位 α ∈ {sig_levels}；本次只有 {len(rows)} 档，"
                           f"**不做趋势推断**（两点之间没有单调性可言），"
                           f"只能陈述端点差异。")
        else:
            verdict.append(f"显著档位 α ∈ {sig_levels}；Δ 极差 {spread:.4f} °C，"
                           f"Spearman(ρ,Δ)={rho_delta:+.2f}（p={rho_delta_p:.2f}）。")
            if rho_delta_p < 0.05 and rho_delta > 0:
                verdict.append("单档显著且趋势显著、方向与假设一致 —— 可以陈述为"
                               "『overlap 越高，full 相对 add 越不利』，但仍不给阈值。")
            else:
                verdict.append("有档位显著，但趋势不显著：只能陈述该档事实，不得外推成规则。")
    else:
        verdict.append(f"Δ 极差 {spread:.4f} °C 看似不小，但没有任何单档达到显著"
                       f"（最小 p={min(ps) if ps else float('nan'):.3f}），"
                       f"Spearman p={rho_delta_p:.2f}。")
        verdict.append("→ 判为「无证据」：C6 不得作为设计规则保留，只能写成"
                       "『在本数据上没有检出 FiLM 形式差异』。")

    stats_out = {"rho_range": rho_range, "delta_spread": spread,
                 "spearman": rho_delta, "spearman_p": rho_delta_p,
                 "sig_levels": sig_levels,
                 "ci_only_levels": ci_only,
                 "n_levels": len(rows),
                 "min_p": float(min(ps)) if ps else float("nan")}
    return verdict, stats_out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--n-sub", type=int, default=500)
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--epochs", type=int, default=250)
    ap.add_argument("--patience", type=int, default=60)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--selection", default="stratified")
    ap.add_argument("--alphas", default="0,0.25,0.5,0.75,1",
                    help="逗号分隔的 α 档位；端点检验用 '0,1' 即可")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    # 判据用"有没有可用的训练实现"，而不是"装没装 torch"——
    # so the stub test (whole chain with stand-in functions) is not blocked by the env guard / 桩测试不被误伤
    if not (callable(build_model) and callable(train_stgat)):
        raise RuntimeError(
            "E2 需要 PyTorch 才能训练；但置换/ρ 的自检可以在无 torch 环境跑：\n"
            "E2 needs PyTorch to train. The manipulation checks still run headless:\n"
            "    python -m pytest tests/test_e2_design.py -v"
        )
    code_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    data = load_v2(args.data)
    pix = pick_pixels(data, args.n_sub, seed=42, mode=args.selection)
    pix_xy = data["pixel_indices"][pix]
    tr, va, te = data["split_train"], data["split_val"], data["split_test"]

    # 输入场：X_windows 的最后一帧就是 origin 那一年的观测（F=1）
    input_fields = data["X_windows"][pix][:, :, -1, 0].T.astype(np.float64)  # (W,N)
    geo_true = data["descriptors"][:, pix, :].astype(np.float32)             # (W,N,3)

    base = make_splits(data, pix, k=8)
    mean, std = base["mean"], base["std"]
    edge = base["edge_index"]
    y_te_raw = base["y_test"] * std + mean
    T_in = base["X_train"].shape[2]
    F_in = base["X_train"].shape[3]

    print("=" * 88)
    print("E2 受控 overlap 扫描 / Controlled overlap sweep")
    print(f"  data   : {os.path.basename(args.data)}")
    print(f"  pixels : {len(pix)}   windows train/val/test = "
          f"{len(tr)}/{len(va)}/{len(te)}")
    print(f"  T_in={T_in}  F={F_in}  seeds={args.seeds}  epochs={args.epochs}")
    print("=" * 88)

    rows = []
    alphas = tuple(float(x) for x in args.alphas.split(",") if x.strip())
    blk = spatial_blocks(pix_xy, n_bins=5)
    blocks_all = np.tile(blk, len(te))          # 与 (W_test, N) 展平顺序一致
    for alpha in alphas:
        g = mix_conditioning(geo_true, alpha, seed=42)
        rho = measure_rho(g, input_fields, pix_xy, te)

        sp = dict(base)
        for name in ("train", "val", "test"):
            dd = g[data[f"split_{name}"]]
            m = g[tr].mean(axis=(0, 1), keepdims=True)
            s = g[tr].std(axis=(0, 1), keepdims=True) + 1e-8
            # 标准化统计量一律取自训练窗口，测试期绝不参与（R1-5 的教训）
            sp[f"geo_{name}"] = ((dd - m) / s).astype(np.float32)

        print(f"\n--- α={alpha:.2f}   实测 ρ={rho:.3f}   "
              f"校正 ρ*={2.0 * rho - 1.0:+.3f} ---")
        # ρ=(cos+1)/2 的"随机水平"是 0.5 而不是 0：两个无关的平滑场，梯度方向
        # 期望正交（cos≈0），于是 ρ≈0.5。所以 ρ*=2ρ−1 才是"好于随机多少"，
        # range [-1,1]; 0 = indistinguishable from chance. Restate the 0.3/0.5 thresholds on this scale / 口径重述
        # The chance level of (cos+1)/2 is 0.5, not 0 — two unrelated smooth
        # fields have expected cos≈0. So rho* = 2*rho-1 is the chance-corrected
        # version, 0 meaning "indistinguishable from chance".
        level = {"alpha": alpha, "rho": rho, "rho_chance_corrected": 2.0 * rho - 1.0,
                 "runs": {}, "per_seed": {}}

        for mode in ("add_only", "full"):
            rmses, r2s, preds = [], [], []
            for k in range(args.seeds):
                seed = 42 + k
                model = build_model(
                    seed, input_dim=F_in, geo_dim=g.shape[-1], hidden_dim=64,
                    conditioning="film", film_mode=mode,
                    residual_output=True, spatial_residual=True,
                )
                res = train_stgat(
                    model, sp, edge, None, seed=seed, epochs=args.epochs,
                    lr=args.lr, batch_size=args.batch_size,
                    patience=args.patience, device=args.device,
                    y_mean=mean, y_std=std,
                )
                rmses.append(float(res["metrics"]["rmse"]))
                r2s.append(float(res["metrics"]["r2"]))
                preds.append(res["pred"])
                save_run(
                    args.out, f"a{alpha:.2f}_{mode}_seed{seed}", res,
                    config={"alpha": alpha, "rho": rho, "mode": mode,
                            "epochs": args.epochs, "lr": args.lr,
                            "batch_size": args.batch_size,
                            "patience": args.patience, "hidden_dim": 64,
                            "residual_output": True, "spatial_residual": True},
                    dataset_path=args.data, code_root=code_root,
                    extra={"params": model.num_params, "measured_rho": rho},
                )

            pred_ens = np.mean(np.stack(preds, axis=0), axis=0)
            level["per_seed"][mode] = rmses
            level.setdefault("_pred_ens", {})[mode] = pred_ens
            level["runs"][mode] = {
                "rmse_mean": float(np.mean(rmses)),
                "rmse_std": float(np.std(rmses, ddof=1)) if len(rmses) > 1 else 0.0,
                "r2_mean": float(np.mean(r2s)),
                "rmse_ensemble": float(rmse_fn(pred_ens, res["true"])),
                "params": int(model.num_params),
            }
            print(f"  {mode:9s} RMSE={np.mean(rmses):.4f} ± "
                  f"{np.std(rmses, ddof=1) if len(rmses) > 1 else 0:.4f}   "
                  f"R²={np.mean(r2s):.4f}   ensemble={rmse_fn(pred_ens, res['true']):.4f}")

        a_r = np.array(level["per_seed"]["add_only"])
        f_r = np.array(level["per_seed"]["full"])
        d = f_r - a_r                      # >0 表示 add 更好
        level["delta_full_minus_add"] = float(d.mean())
        level["delta_std"] = float(d.std(ddof=1)) if len(d) > 1 else 0.0
        if len(d) > 1 and d.std(ddof=1) > 0:
            t, p = stats.ttest_rel(f_r, a_r)
            level["p_value"] = float(p)
        else:
            level["p_value"] = None
        print(f"  Δ(full−add) = {d.mean():+.4f} ± "
              f"{d.std(ddof=1) if len(d) > 1 else 0:.4f}   "
              f"p={level['p_value'] if level['p_value'] is None else round(level['p_value'], 4)}")

        # 集成预测上的块自助区间：种子间的 t 检验只反映"训练随机性"，
        # Only the block bootstrap speaks to spatial generalisation. Report both; never cherry-pick / 两个都报
        # The seed-level t-test only reflects training randomness; the block
        # bootstrap reflects spatial generalisation. Report both.
        ens = level.pop("_pred_ens", None)
        if ens is not None:
            true_vec = np.asarray(res["true"], dtype=np.float64)
            e_add = ((np.asarray(ens["add_only"], dtype=np.float64) - true_vec) ** 2).reshape(-1)
            e_full = ((np.asarray(ens["full"], dtype=np.float64) - true_vec) ** 2).reshape(-1)
            if e_add.size == blocks_all.size:
                lo, hi = block_bootstrap_delta(e_add, e_full, blocks_all)
                level["delta_ci95"] = [lo, hi]
                tag = "含 0 → 不显著" if lo <= 0 <= hi else "不含 0 → 显著"
                print(f"  95% 块自助区间 = [{lo:+.4f}, {hi:+.4f}]  {tag}")
        rows.append(level)

    with open(os.path.join(args.out, "e2_summary.json"), "w", encoding="utf-8") as fh:
        json.dump(rows, fh, indent=2, ensure_ascii=False)

    with open(os.path.join(args.out, "rho_vs_delta.csv"), "w", encoding="utf-8") as fh:
        fh.write("alpha,rho,rho_chance_corrected,rmse_add,rmse_add_sd,rmse_full,"
                 "rmse_full_sd,delta_full_minus_add,delta_sd,delta_ci_low,"
                 "delta_ci_high,p_value\n")
        for r in rows:
            ci = r.get("delta_ci95", [float("nan"), float("nan")])
            fh.write(f"{r['alpha']:.2f},{r['rho']:.4f},{r['rho_chance_corrected']:+.4f},"
                     f"{r['runs']['add_only']['rmse_mean']:.5f},"
                     f"{r['runs']['add_only']['rmse_std']:.5f},"
                     f"{r['runs']['full']['rmse_mean']:.5f},"
                     f"{r['runs']['full']['rmse_std']:.5f},"
                     f"{r['delta_full_minus_add']:+.5f},{r['delta_std']:.5f},"
                     f"{ci[0]:+.5f},{ci[1]:+.5f},"
                     f"{'' if r['p_value'] is None else round(r['p_value'], 5)}\n")

    with open(os.path.join(args.out, "table_e2.md"), "w", encoding="utf-8") as fh:
        fh.write("| α | measured ρ | chance-corrected ρ* | RMSE add_only (°C) | "
                 "RMSE full (°C) | Δ (full−add) | 95% CI (block boot) | p |\n")
        fh.write("|--:|--:|--:|--:|--:|--:|--:|--:|\n")
        for r in rows:
            a = r["runs"]["add_only"]
            f = r["runs"]["full"]
            p = "—" if r["p_value"] is None else f"{r['p_value']:.3f}"
            ci = r.get("delta_ci95")
            cis = "—" if not ci else f"[{ci[0]:+.3f}, {ci[1]:+.3f}]"
            fh.write(f"| {r['alpha']:.2f} | {r['rho']:.3f} | "
                     f"{r['rho_chance_corrected']:+.3f} | "
                     f"{a['rmse_mean']:.4f} ± {a['rmse_std']:.4f} | "
                     f"{f['rmse_mean']:.4f} ± {f['rmse_std']:.4f} | "
                     f"{r['delta_full_minus_add']:+.4f} | {cis} | {p} |\n")
        fh.write("\n> ρ* = 2ρ−1：ρ=(cos+1)/2 的随机水平是 0.5 而非 0，"
                 "故 ρ*=0 等价于「与随机场无法区分」，ρ*=1 为完全重合。\n")

    # ---- 自动判读（判定规则已抽成 build_verdict，可被单测钉住） ----
    verdict, vstats = build_verdict(rows)
    rho_range = vstats["rho_range"]
    spread = vstats["delta_spread"]
    rho_delta = vstats["spearman"]
    rho_delta_p = vstats["spearman_p"]

    print("\n" + "=" * 88)
    print("自动判读 / Automatic read-out")
    for v in verdict:
        print(f"  · {v}")
    print(f"\n结果目录 / output: {args.out}")

    with open(os.path.join(args.out, "verdict.txt"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(verdict) + "\n")
        fh.write(f"rho_range={rho_range:.4f}\ndelta_spread={spread:.4f}\n"
                 f"spearman={rho_delta:+.4f}\nspearman_p={rho_delta_p:.4f}\n"
                 f"min_level_p={vstats['min_p']:.4f}\n"
                 f"significant_levels={vstats['sig_levels']}\n"
                 f"ci_only_levels={vstats['ci_only_levels']}\n"
                 f"n_levels={vstats['n_levels']}\n"
                 f"verdict={'supported' if vstats['sig_levels'] else 'no-evidence'}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
