#!/usr/bin/env python3
"""E4 — 不确定性：块自助法 + 非劣性检验。

E4 — Uncertainty: block bootstrap and a non-inferiority test.

为什么需要这个 / Why this exists
------------------------------
R1-8：五个 seed 的 t 检验不成立——它们是对**同一批重叠子样本**重复预测，
不是独立重复实验。正确做法是按时间块 / 空间块重采样，给出 ΔRMSE 的置信区间。
R3-2：合成数据上 5.0% 的恶化必须做**非劣性检验**，而不是"看起来还行"。

作者 / Author: Raymond Xiaohu Fan

用法 / Usage:
    python experiments/e4_uncertainty.py \
        --a  runs/e1/film_add_seed42 \
        --b  runs/e1/standard_seed42 \
        --out runs/e4 --margin 0.02
"""

from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


def _load(run_dir: str):
    p = os.path.join(run_dir, "predictions.npz")
    if not os.path.isfile(p):
        raise FileNotFoundError(f"找不到 {p}")
    d = np.load(p)
    return np.asarray(d["pred"], dtype=np.float64), np.asarray(d["true"], dtype=np.float64)


def _rmse(p, y) -> float:
    return float(np.sqrt(np.mean((p - y) ** 2)))


def block_bootstrap_delta(pa, pb, y, n_boot: int = 2000, seed: int = 0,
                          block: str = "window") -> np.ndarray:
    """ΔRMSE = RMSE(a) − RMSE(b) 的自助分布。

    block="window"：按时间窗口重采样（保时间结构）
    block="pixel" ：按空间像素重采样（保空间结构）
    负值代表 a 更好。
    """
    if pa.shape != pb.shape or pa.shape != y.shape:
        raise ValueError(f"形状不一致 {pa.shape} {pb.shape} {y.shape}")
    rng = np.random.default_rng(seed)
    W, N = y.shape
    out = np.empty(n_boot, dtype=float)

    for b in range(n_boot):
        if block == "window":
            idx = rng.integers(0, W, size=W)
            yy, aa, bb = y[idx], pa[idx], pb[idx]
        elif block == "pixel":
            idx = rng.integers(0, N, size=N)
            yy, aa, bb = y[:, idx], pa[:, idx], pb[:, idx]
        else:
            raise ValueError("block 只能是 'window' 或 'pixel'")
        out[b] = _rmse(aa, yy) - _rmse(bb, yy)
    return out


def summarize_delta(deltas: np.ndarray, margin: float) -> dict:
    """给 CI、p 值与非劣性结论。

    margin 是"允许差多少"的绝对阈值（与 RMSE 同单位）。
    非劣性：单侧 95% 上界 < margin 才算通过。
    """
    lo, hi = np.percentile(deltas, [2.5, 97.5])
    up95 = float(np.percentile(deltas, 95))
    return {
        "delta_mean": float(deltas.mean()),
        "delta_median": float(np.median(deltas)),
        "ci95": [float(lo), float(hi)],
        "upper95_one_sided": up95,
        "p_two_sided": float(2 * min(np.mean(deltas <= 0), np.mean(deltas >= 0))),
        "margin": float(margin),
        "non_inferior": bool(up95 < margin),
        "significant_better": bool(hi < 0),
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--a", required=True, help="主方法 run 目录")
    ap.add_argument("--b", required=True, help="对照 run 目录")
    ap.add_argument("--out", required=True)
    ap.add_argument("--n-boot", type=int, default=2000)
    ap.add_argument("--margin", type=float, default=0.02,
                    help="非劣性阈值（RMSE 绝对单位，默认 0.02 °C）")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    pa, y = _load(args.a)
    pb, _ = _load(args.b)
    os.makedirs(args.out, exist_ok=True)

    res = {"run_a": os.path.abspath(args.a), "run_b": os.path.abspath(args.b)}
    for block in ("window", "pixel"):
        d = block_bootstrap_delta(pa, pb, y, args.n_boot, args.seed, block)
        np.save(os.path.join(args.out, f"deltas_{block}.npy"), d)
        res[block] = summarize_delta(d, args.margin)
        s = res[block]
        print(f"[{block:6}] ΔRMSE = {s['delta_mean']:+.4f}  "
              f"95%CI [{s['ci95'][0]:+.4f}, {s['ci95'][1]:+.4f}]  "
              f"非劣={'✅' if s['non_inferior'] else '❌'}")

    with open(os.path.join(args.out, "e4_summary.json"), "w", encoding="utf-8") as fh:
        json.dump(res, fh, indent=2, ensure_ascii=False)

    print("\n怎么读：")
    print("  CI 完全 < 0        → a 显著更好")
    print("  CI 跨 0 但上界<margin → 不能说更好，但可说'不劣于'")
    print("  上界 > margin      → 不能声称非劣，请如实写")
    print(f"\n结果 → {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
