#!/usr/bin/env python3
"""E5 — 外部基线对照：STGCN / DCRNN / PINN，同一验证方案、同一测试集。

E5 — External baselines under one protocol: STGCN, DCRNN, PINN.

审稿人 R3-3 的要求是"基线必须在**同一验证方案**下重跑"，而不是从别的论文里
抄一个数字过来。这个脚本就是把三家基线塞进 v2 的训练器，用与我们完全相同的：
  · 像素子集（分层抽样，同 seed）
  · 窗口切分（同 target_idx / gap / T_in）
  · 归一化统计量（只用训练期）
  · 早停（同 patience）与随机种子

⚠️ 一个必须写进论文的事实 / A fact that must go into the manuscript
---------------------------------------------------------------
探针（`scripts/probe_baselines.py`）实测：STGCN / DCRNN / PINN 三个模型的
`forward` **都不消费地质描述子**——旧代码里描述子只进 `compute_physical_loss`，
而我们把 `lambda_phys` 设为 0。也就是说这三家在本文协议下是**无条件模型**
（unconditioned），与我们的 `standard` 同属一类，不能标成"条件化基线"。

这不是缺陷，是定位问题：Table 5 里必须逐行标 `priors: no`。若把它们说成
"也用了地质先验"，那就是 R3-3 想抓的那种不老实。

作者 / Author: Raymond Xiaohu Fan

用法 / Usage:
    python filmstgat/experiments/e5_baselines.py \
        --data <ROOT>/datasets_v2/real_magt_data_v2_clean.npz \
        --out  <ROOT>/runs/e5 --n-sub 500 --seeds 5 --epochs 250 --T-in 10 --gap 4
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
import traceback

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from filmstgat.eval.metrics import summarize  # noqa: E402
from filmstgat.experiments.common import (  # noqa: E402
    aggregate, load_v2, make_splits, pick_pixels, save_run,
)
from filmstgat.experiments.e3_naive_baselines import _windows_for  # noqa: E402
from filmstgat.models.baselines import BASELINE_NAMES, build_baseline  # noqa: E402
from filmstgat.train.trainer import train_stgat  # noqa: E402


def test_fingerprint(y_test: np.ndarray) -> str:
    """测试集的指纹：换过测试集就必须在结果里露馅。  A test-set fingerprint.

    为什么要：R3-3 的根源就是"每个模型的测试集其实不一样"。把 (w,N) 的目标值
    做哈希存进 metrics，两个结果文件一比就知道是不是同一批样本。
    """
    b = np.ascontiguousarray(np.asarray(y_test, dtype=np.float32)).tobytes()
    return hashlib.sha1(b).hexdigest()[:16]


def check_model_uses_priors(model, xb, edge_index, gb) -> bool:
    """实测一个模型的前向是否消费描述子。  Does the forward consume the priors?

    用同一输入、两组不同描述子各跑一次：输出一致 ⇒ 无条件。
    不靠读源码——旧代码的描述子可能藏在某个分支里，读注释是靠不住的。
    """
    import torch

    # ⚠️ 必须在 eval() 下比：train 模式有 dropout，两组描述子一定给出不同输出，
    #    会把"无条件模型"误判成"用了先验"——结论正好反了。
    # Must run in eval(): under train mode dropout makes any two passes differ,
    # which would label an UNconditioned model as conditioned.
    was_training = model.training
    model.eval()
    try:
        with torch.no_grad():
            y1 = model(xb, edge_index, gb)
            y2 = model(xb, edge_index, torch.randn_like(gb))
        return not bool(torch.allclose(y1, y2, atol=1e-6))
    finally:
        model.train(was_training)


def pixel_errors(pred: np.ndarray, true: np.ndarray) -> np.ndarray:
    """(w, N) → (N,) 每个像素跨窗口的平均绝对误差。

    为什么不用 2000 个 (窗口,像素) 格子直接做检验：4 个测试窗口同属一个时段，
    格子之间高度相关，把它们当独立样本会让 p 值虚低好几个量级——那正是
    审稿人会拿来质疑"显著性"的地方。以**像素**为独立单元（n=500）是同一位
    空间自相关下更保守、也更站得住的取法。
    Why not 2000 cells: the cells cluster in 4 windows, so treating them as
    independent deflates p by orders of magnitude. Pixel-level aggregation
    (n=500) is the more conservative, defensible unit.
    """
    e = np.abs(np.asarray(pred, dtype=np.float64) - np.asarray(true, dtype=np.float64))
    return e.mean(axis=0) if e.ndim == 2 else e.ravel()


def wilcoxon_p(a_err: np.ndarray, b_err: np.ndarray) -> float:
    """配对 Wilcoxon 符号秩检验：逐样本绝对误差。  Paired Wilcoxon on |error|.

    为什么用逐样本而不是逐 seed：5 个 seed 做不了检验（n=5 的最小 p 是 0.0625），
    这一点在 E4 里已经算过 MDE 了。逐样本检验回答的是"误差分布是否整体偏移"。
    """
    try:
        from scipy.stats import wilcoxon

        a = np.asarray(a_err, dtype=np.float64).ravel()
        b = np.asarray(b_err, dtype=np.float64).ravel()
        if np.allclose(a, b):
            return 1.0
        return float(wilcoxon(a, b, zero_method="zsplit").pvalue)
    except Exception:
        return float("nan")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--n-sub", type=int, default=500)
    ap.add_argument("--selection", choices=["stratified", "random"], default="stratified")
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--seed0", type=int, default=42)
    ap.add_argument("--epochs", type=int, default=250)
    ap.add_argument("--patience", type=int, default=40)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--hidden", type=int, default=64)
    ap.add_argument("--T-in", type=int, default=10)
    ap.add_argument("--gap", type=int, default=4)
    ap.add_argument("--models", default=",".join(BASELINE_NAMES))
    ap.add_argument("--sweep", action="store_true",
                    help="给基线做小网格搜索，按验证集 RMSE 选最优（应对'你没调参'）")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--tag", default="e5", help="输出文件名前缀（e5 / e5h1）")
    args = ap.parse_args()

    import torch

    os.makedirs(args.out, exist_ok=True)
    code_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    device = args.device if (args.device != "cuda" or torch.cuda.is_available()) else "cpu"
    models = [m.strip() for m in args.models.split(",") if m.strip()]

    # ---------------- 数据：与 E1/E3 完全相同的选点与切分 ----------------
    # Same pixel subset and same splits as E1/E3 — otherwise Table 5 is not a
    # comparison, it is three separate experiments printed next to each other.
    data = load_v2(args.data)
    pix = pick_pixels(data, args.n_sub, seed=args.seed0, mode=args.selection)
    splits = make_splits(data, pix)
    fp = test_fingerprint(splits["y_test"])
    n_nodes = splits["X_train"].shape[1]
    input_dim = splits["X_train"].shape[-1]
    geo_dim = splits["geo_train"].shape[-1]

    print("=" * 78)
    print(f"E5 外部基线 / external baselines   device={device}")
    print(f"  data   : {args.data}")
    print(f"  pixels : {len(pix)} (n_sub={args.n_sub}, {args.selection}, seed={args.seed0})")
    print(f"  shapes : X_train={splits['X_train'].shape}  geo={splits['geo_train'].shape}")
    print(f"  test   : {splits['y_test'].shape}   fingerprint={fp}")
    print(f"  models : {', '.join(models)}   seeds={args.seeds}   epochs={args.epochs}")
    print("=" * 78)

    # ---------------- 朴素基线：同测试集上先算一遍 ----------------
    series = data["series"][pix]
    pers, trend = _windows_for(series, data["target_idx"], data["split_test"],
                               args.T_in, args.gap, 1)
    truth = data["y_windows"][pix][:, data["split_test"], 0].transpose(1, 0)
    m_pers = summarize(pers, truth)
    m_trend = summarize(trend, truth)
    print(f"  [reference] persistence  RMSE={m_pers['rmse']:.3f}  "
          f"trend RMSE={m_trend['rmse']:.3f}  (n={m_pers['n_samples']})")

    # 扫参网格：只扫两个最影响收敛的轴。基线享有**不低于**我们模型的调参待遇，
    # 这是对"you tuned the baselines poorly"最直接的回答。
    # A deliberately generous grid for the baselines — they get at least as much
    # tuning as our own model, which is the standard defence against that review.
    grid = ([(args.lr, args.hidden)]
            if not args.sweep else
            [(lr, h) for lr in (1e-3, 3e-4) for h in (64, 128)])

    rows: list = []
    failures: list = []
    priors_flag: dict = {}

    for name in models:
        for k in range(args.seeds):
            seed = args.seed0 + k
            t0 = time.time()
            try:
                model = build_baseline(
                    name, n_nodes=n_nodes, input_dim=input_dim, geo_dim=geo_dim,
                    seed=seed,
                    config={"hidden_dim": args.hidden, "lambda_phys": 0.0,
                            "use_phys_loss": False},
                )
                # 训练前实测一次：这个模型到底吃不吃描述子（写给论文用）
                if name not in priors_flag:
                    xb = torch.as_tensor(splits["X_test"][:2], dtype=torch.float32)
                    gb = torch.as_tensor(splits["geo_test"][:2], dtype=torch.float32)
                    priors_flag[name] = check_model_uses_priors(
                        model, xb, splits["edge_index"], gb)
                    print(f"  [{name}] uses_priors="
                          f"{'YES' if priors_flag[name] else 'NO (unconditioned)'}")

                # 网格：每次重新造模型（否则权重会从上一次接着跑）
                best = None
                for (lr_i, hid_i) in grid:
                    m_i = build_baseline(
                        name, n_nodes=n_nodes, input_dim=input_dim,
                        geo_dim=geo_dim, seed=seed,
                        config={"hidden_dim": hid_i, "lambda_phys": 0.0,
                                "use_phys_loss": False})
                    r_i = train_stgat(
                        m_i, splits, splits["edge_index"], None,
                        seed=seed, epochs=args.epochs, lr=lr_i,
                        batch_size=args.batch_size, patience=args.patience,
                        lambda_phys=0.0, device=device,
                        y_mean=splits["mean"], y_std=splits["std"],
                    )
                    # ★ 只按**验证集**选，测试集一次都不看——否则就是拿测试集调参。
                    #   Selection uses the validation split only; the test set is
                    #   touched exactly once, for the reported number.
                    key = float(r_i["best_val_rmse"])
                    if best is None or key < best[0]:
                        best = (key, r_i, m_i, lr_i, hid_i)
                    if len(grid) > 1:
                        print(f"      {name} seed={seed} lr={lr_i:g} h={hid_i} "
                              f"val={key:.4f} test={r_i['metrics']['rmse']:.3f}")
                _, res, model, lr_used, hid_used = best
                run_id = f"{name}_seed{seed}"
                save_run(args.out, run_id, res,
                         config={"model": name, "hidden_dim": hid_used,
                                 "lr": lr_used, "sweep": bool(args.sweep),
                                 "T_in": args.T_in, "gap": args.gap,
                                 "n_sub": args.n_sub, "uses_priors": priors_flag[name]},
                         dataset_path=args.data, code_root=code_root,
                         extra={"params": model.num_params,
                                "test_fingerprint": fp,
                                "uses_priors": priors_flag[name]})
                m = res["metrics"]
                err_pix = pixel_errors(res["pred"], res["true"])
                pers_err_pix = pixel_errors(pers, truth)
                err_cell = np.abs(np.asarray(res["pred"]).ravel()
                                  - np.asarray(res["true"]).ravel())
                rows.append({
                    "model": name, "seed": seed, "params": model.num_params,
                    "rmse": m["rmse"], "mae": m["mae"], "r2": m["r2"],
                    "n_samples": m["n_samples"], "units": res.get("units", "unknown"),
                    "uses_priors": priors_flag[name],
                    "lr": lr_used, "hidden": hid_used,
                    "best_val_rmse": res["best_val_rmse"],
                    "seconds": round(time.time() - t0, 1),
                    "p_vs_persistence": wilcoxon_p(err_pix, pers_err_pix),
                    "p_vs_persistence_cell": wilcoxon_p(
                        err_cell, np.abs(pers.ravel() - truth.ravel())),
                    "n_units": int(err_pix.size),
                })
                print(f"  [{name:5}] seed={seed}  RMSE={m['rmse']:.3f}  "
                      f"MAE={m['mae']:.3f}  R2={m['r2']:+.4f}  "
                      f"params={model.num_params:,}  {time.time()-t0:.0f}s")
            except Exception as exc:  # 一家崩了不该拖垮整张表
                failures.append({"model": name, "seed": seed,
                                 "error": f"{type(exc).__name__}: {exc}",
                                 "traceback": traceback.format_exc()[-1500:]})
                print(f"  [{name:5}] seed={seed}  FAILED: {type(exc).__name__}: {exc}")

    if failures:
        with open(os.path.join(args.out, "failures.json"), "w", encoding="utf-8") as fh:
            json.dump(failures, fh, indent=2, ensure_ascii=False)

    summary = aggregate(rows) if rows else {}

    # ---------------- Table 5 ----------------
    table_rows = []
    for name, s in summary.items():
        delta = 100.0 * (s["rmse_mean"] - m_pers["rmse"]) / m_pers["rmse"]
        ps = [r["p_vs_persistence"] for r in rows
              if r["model"] == name and np.isfinite(r.get("p_vs_persistence", np.nan))]
        table_rows.append({
            "model": name, "priors": "no" if not priors_flag.get(name, False) else "yes",
            "params": s["params"], "rmse_mean": s["rmse_mean"], "rmse_std": s["rmse_std"],
            "r2_mean": s["r2_mean"], "delta_vs_persistence_pct": delta,
            "p_vs_persistence": float(np.median(ps)) if ps else float("nan"),
            "n_seeds": s["n_seeds"],
            "n_samples": rows[0]["n_samples"] if rows else 0,
        })
    # 把两个朴素基线也放进同一张表：它们才是"零成本"的参照系
    for nm, mm in (("persistence", m_pers), ("trend_extrapolation", m_trend)):
        table_rows.append({
            "model": nm, "priors": "no", "params": 0,
            "rmse_mean": mm["rmse"], "rmse_std": 0.0, "r2_mean": mm["r2"],
            "delta_vs_persistence_pct": 100.0 * (mm["rmse"] - m_pers["rmse"]) / m_pers["rmse"],
            "p_vs_persistence": 1.0 if nm == "persistence" else float("nan"),
            "n_seeds": 1, "n_samples": mm["n_samples"],
        })

    order = {"persistence": 0, "trend_extrapolation": 1, "pinn": 2, "stgcn": 3, "dcrnn": 4}
    table_rows.sort(key=lambda r: (order.get(r["model"], 9), r["rmse_mean"]))

    payload = {"protocol": {"n_sub": args.n_sub, "selection": args.selection,
                            "T_in": args.T_in, "gap": args.gap, "seeds": args.seeds,
                            "epochs": args.epochs, "device": device,
                            "test_fingerprint": fp},
               "uses_priors": priors_flag,
               "reference": {"persistence": m_pers, "trend": m_trend},
               "per_seed": rows, "table": table_rows, "failures": failures}
    with open(os.path.join(args.out, f"metrics_{args.tag}.json"), "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2, ensure_ascii=False)
    with open(os.path.join(args.out, f"runs_{args.tag}.jsonl"), "w", encoding="utf-8") as fh:
        for r in rows:
            fh.write(json.dumps(r) + "\n")

    md = ["| Model | priors | params | RMSE (°C) | R² | Δ vs persistence | p | seeds |",
          "|---|---|---|---|---|---|---|---|"]
    for r in table_rows:
        pv = r["p_vs_persistence"]
        p_txt = "—" if not np.isfinite(pv) else f"{pv:.2e}"
        md.append(
            f"| {r['model']} | {r['priors']} | {r['params']:,} | "
            f"{r['rmse_mean']:.3f} ± {r['rmse_std']:.3f} | {r['r2_mean']:+.4f} | "
            f"{r['delta_vs_persistence_pct']:+.1f}% | {p_txt} | {r['n_seeds']} |")
    with open(os.path.join(args.out, f"table_{args.tag}.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(md) + "\n")

    print("\n" + "=" * 78)
    print(f"{'model':20}{'priors':>8}{'params':>10}{'RMSE':>18}{'Δ%':>9}{'p':>11}")
    print("-" * 78)
    for r in table_rows:
        # ⚠️ 不要把 `A if cond else B` 直接接在 f-string 拼接后面：Python 会让
        #    条件表达式接管**整个**拼接结果，前面所有字段被静默丢弃。
        #    Never append `A if cond else B` to a concatenated f-string: the
        #    conditional captures the WHOLE concatenation and drops every field.
        p = r["p_vs_persistence"]
        p_txt = f"{'—':>11}" if not np.isfinite(p) else f"{p:>11.2e}"
        print(f"{r['model']:20}{r['priors']:>8}{r['params']:>10,}"
              f"{r['rmse_mean']:>12.3f} ± {r['rmse_std']:.3f}"
              f"{r['delta_vs_persistence_pct']:>+8.1f}%{p_txt}")
    print("=" * 78)
    if failures:
        print(f"[warn] {len(failures)} run(s) failed — see {args.out}/failures.json")
    print(f"\n产物 → {args.out}")
    print("⚠️ 写表时必须标注：三个 legacy 基线在本协议下为 unconditioned（priors=no）。")
    print(f"⚠️ p 的独立单元 = 像素 (n={int(pixel_errors(pers, truth).size)})，"
          f"不是 {pers.size} 个 (窗口,像素) 格子。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
