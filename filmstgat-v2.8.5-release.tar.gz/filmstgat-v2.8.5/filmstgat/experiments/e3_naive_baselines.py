#!/usr/bin/env python3
"""E3 — 朴素基线：历史均值（persistence）与趋势外推。

E3 — Naive baselines: persistence and trend extrapolation.

审稿人 R3-5 明确要求："information-matched baselines—including direct
descriptor concatenation, historical-mean prediction, and trend extrapolation"。
concat 在 E1 里做了，这里补后两个。

这两个基线存在的意义：如果 FiLM 模型连"拿最后一年当预测"都打不过，
那所谓的地质先验就没有说服力。反过来，如果模型明显更好，这个对比就是
最便宜的加分项。

作者 / Author: Raymond Xiaohu Fan

用法 / Usage:
    python experiments/e3_naive_baselines.py \
        --data <ROOT>/datasets_v2/real_magt_data_v2_clean.npz \
        --out  <ROOT>/runs/e3 --n-sub 500
"""

from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from filmstgat.eval.metrics import summarize  # noqa: E402
from filmstgat.utils.provenance import write_run_manifest  # noqa: E402

START_YEAR = 1981


def _windows_for(series: np.ndarray, target_idx: np.ndarray, test_w: np.ndarray,
                 T_in: int, gap: int, T_out: int):
    """Return persistence and trend-extrapolation predictions. 持久化与趋势外推基线。"""
    N = series.shape[0]
    pers = np.zeros((len(test_w), N), dtype=np.float32)
    trend = np.zeros_like(pers)

    for i, w in enumerate(test_w):
        t_target_end = int(target_idx[w])
        t_target_start = t_target_end - T_out + 1
        t_in_end = t_target_start - gap - 1
        t_in_start = t_in_end - T_in + 1

        # persistence：拿输入窗最后一个观测当预测
        pers[i] = series[:, t_in_end]

        # trend：输入窗线性拟合，外推到目标年
        seg = series[:, t_in_start:t_in_end + 1].astype(np.float64)
        # ⚠️ 先记住中心点再中心化。之前把 t 原地减均值后又用 t.mean()（此时=0），
        #    预测就整体偏移了 4.5×斜率。这种"看着对、其实差一截"的 bug 最要命。
        # Remember the centre BEFORE centring: calling t.mean() afterwards returns
        # 0 and silently shifts every prediction by 4.5×slope.
        t_raw = np.arange(seg.shape[1], dtype=np.float64)
        t_center = float(t_raw.mean())
        t = t_raw - t_center
        denom = float(np.sum(t ** 2)) or 1.0
        slope = (seg - seg.mean(axis=1, keepdims=True)) @ t / denom
        intercept = seg.mean(axis=1)
        horizon = t_target_start - t_in_start      # 目标在输入坐标系中的位置
        trend[i] = intercept + slope * (horizon - t_center)
    return pers, trend


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--n-sub", type=int, default=500)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--selection", choices=["stratified", "random"], default="stratified")
    ap.add_argument("--T-in", type=int, default=10)
    ap.add_argument("--gap", type=int, default=4)
    ap.add_argument("--T-out", type=int, default=1)
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    code_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    d = np.load(args.data, allow_pickle=True)
    series = d["series"]
    target_idx = d["target_idx"]
    test_w = d["split_test"]

    # 与 E1 用同一套选点规则，否则两个表的 RMSE 不可比（R3-3 的老教训）。
    from filmstgat.experiments.common import pick_pixels
    pix = pick_pixels({"series": series}, args.n_sub, seed=args.seed,
                      mode=getattr(args, "selection", "stratified"))

    s = series[pix]
    pers, trend = _windows_for(s, target_idx, test_w, args.T_in, args.gap, args.T_out)
    truth = d["y_windows"][pix][:, test_w, 0].transpose(1, 0)   # (w,n)

    rows = []
    for name, pred in (("persistence", pers), ("trend_extrapolation", trend)):
        m = summarize(pred, truth)
        np.savez_compressed(os.path.join(args.out, f"predictions_{name}.npz"),
                            pred=pred, true=truth)
        rows.append({"model": name, **m})
        print(f"  {name:22} RMSE={m['rmse']:.4f}  MAE={m['mae']:.4f}  R²={m['r2']:.4f}")

    with open(os.path.join(args.out, "metrics_e3.json"), "w", encoding="utf-8") as fh:
        json.dump(rows, fh, indent=2, ensure_ascii=False)

    write_run_manifest(
        os.path.join(args.out, "persistence"), run_id="e3_naive",
        code_root=code_root, data_paths=[args.data],
        config={"n_sub": args.n_sub, "T_in": args.T_in, "gap": args.gap,
                "T_out": args.T_out, "models": ["persistence", "trend_extrapolation"]},
        seeds={"global": args.seed}, extra={"results": rows},
    )

    # Paper-ready table / 论文用小表
    with open(os.path.join(args.out, "table_e3.md"), "w", encoding="utf-8") as fh:
        fh.write("| Model | RMSE (°C) | MAE (°C) | R² | n |\n|---|---|---|---|---|\n")
        for r in rows:
            fh.write(f"| {r['model']} | {r['rmse']:.3f} | {r['mae']:.3f} | "
                     f"{r['r2']:.4f} | {r['n_samples']} |\n")

    print(f"\n结果 → {args.out}")
    print("注意：这两个基线必须和模型用**同一批测试窗口**，否则又回到 R3-3。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
