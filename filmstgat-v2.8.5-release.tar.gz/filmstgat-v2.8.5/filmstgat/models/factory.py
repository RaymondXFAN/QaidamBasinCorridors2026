"""Model factory: seed first, build second. 先定种子，再造模型。

Model factory: seed first, build second.

为什么要这个文件：R1-8 的坑就在这里——如果先 `STGAT(...)` 再 `train(seed=7)`，
权重初始化早已用掉了上一次的全局随机状态，同 seed 也复现不了。
审稿人说的"model initialization is not explicitly seeded"，指的就是这种顺序问题。
Why this file exists: this is exactly the R1-8 trap. If you build the model
first and pass the seed to the trainer later, the weight init has already
consumed whatever global RNG state was lying around — and no seed will save
you. That is precisely "model initialization is not explicitly seeded".
"""

from __future__ import annotations

from ..train.seeding import set_all_seeds
from .stgat import STGAT

__all__ = ["build_model"]


def build_model(seed: int, **kwargs) -> STGAT:
    """Fix every RNG, then construct the model. 先固定随机源再构造模型。

    用法 / Usage::

        model = build_model(42, input_dim=12, geo_dim=3, hidden_dim=64,
                            conditioning="film", film_mode="full")
        result = train_stgat(model, splits, edge_index, geo, seed=42)

    注意：`train_stgat` 内部还会再 seed 一次（覆盖 shuffle/dropout），
    但**初始化必须在这里完成**，否则两次同 seed 仍然不同。
    Note: train_stgat seeds again for shuffling/dropout, but the INIT must
    happen here; otherwise two runs with the same seed still diverge.
    """
    set_all_seeds(seed)
    return STGAT(**kwargs)
