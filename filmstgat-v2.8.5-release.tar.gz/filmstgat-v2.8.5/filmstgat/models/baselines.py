"""Adapters that let the legacy baselines run inside the v2 harness.

把旧仓库的基线模型接进 v2 训练器的适配层。

为什么需要适配 / Why adapters
-----------------------------
The three external baselines use **three different calling conventions**:

| model  | input shape            | graph            | output      |
|--------|------------------------|------------------|-------------|
| STGCN  | (B, N, T, F)           | dense adj (N,N)  | (B, N, 1)   |
| DCRNN  | (B, N, T, F)           | dense adj (N,N)  | (B, N, 1)   |
| PINN   | **(N, T, F)** — no B   | none             | (N, 1)      |

The v2 trainer calls `model(X, edge_index, geo)` with X of shape (B, N, T, F).
Getting these wrong does not raise a helpful error — it silently produces a model
that trains on the wrong axis. That is precisely the class of bug that cost us a
day on the GRU (`_flatten_nodes`). So every adapter declares its expected shape
and `scripts/probe_baselines.py` runs one forward pass per model before any
training starts.

三个基线三种调用约定，写错不会报错、只会让模型在错的轴上训练。
所以这里显式声明形状，并用探针脚本先跑一遍前向。

作者 / Author: Raymond Xiaohu Fan
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn

from .legacy.dcrnn import DCRNNNet, compute_diffusion_matrices
from .legacy.pinn_permafrost import PINNPermafrostNet
from .legacy.stgcn import STGCNNet, compute_scaled_laplacian

__all__ = [
    "edge_index_to_adj",
    "STGCNAdapter",
    "DCRNNAdapter",
    "PINNAdapter",
    "build_baseline",
    "BASELINE_NAMES",
]

BASELINE_NAMES = ("stgcn", "dcrnn", "pinn")


def edge_index_to_adj(edge_index: np.ndarray | torch.Tensor, n_nodes: int) -> torch.Tensor:
    """(2, E) 稀疏边索引 → (N, N) 稠密 0/1 邻接（对称化，含自环）。

    The legacy models expect a dense adjacency; v2 stores an edge list. We
    symmetrise and add self-loops so that every node keeps its own signal —
    the same reason `spatial_residual` exists for our own model.
    """
    ei = torch.as_tensor(edge_index, dtype=torch.long)
    adj = torch.zeros(n_nodes, n_nodes, dtype=torch.float32)
    adj[ei[0], ei[1]] = 1.0
    adj = torch.maximum(adj, adj.t())
    adj.fill_diagonal_(1.0)
    return adj


class _Base(nn.Module):
    """Shared plumbing: dense adjacency cache + parameter counting."""

    expected_input = "(B, N, T, F)"

    def __init__(self, n_nodes: int):
        super().__init__()
        self.n_nodes = int(n_nodes)
        self._adj_cache = None

    def _adj(self, edge_index):
        if self._adj_cache is None or self._adj_cache.shape[0] != self.n_nodes:
            self._adj_cache = edge_index_to_adj(edge_index, self.n_nodes)
        return self._adj_cache

    def _adj_np(self, edge_index):
        return self._adj(edge_index).detach().cpu().numpy()

    @staticmethod
    def _to_target(y):
        """(B,N,1) → (B,N)，与 v2 训练器的目标形状对齐。

        v2 的 yb 是 (B,N)。如果返回 (B,N,1)，`F.mse_loss` 会尝试把两边广播成
        (B,N,N)：有时直接报"dim 1 上 500 vs 8"，有时**静默算出一个错误的
        loss**——后者更可怕，因为曲线看起来完全正常。
        The v2 trainer's targets are (B,N). A trailing singleton dim makes
        F.mse_loss broadcast into (B,N,N): it either raises a confusing
        dimension error or, worse, silently returns a wrong loss.
        """
        return y.squeeze(-1) if y.dim() == 3 and y.shape[-1] == 1 else y

    @property
    def num_params(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


class STGCNAdapter(_Base):
    """STGCN: (B,N,T,F) + dense adj → (B,N,1)."""

    def __init__(self, n_nodes: int, input_dim: int, geo_dim: int, config: dict):
        super().__init__(n_nodes)
        self.net = STGCNNet(config)
        self.net._build_model(input_dim, geo_dim)
        self.net.L_scaled = None      # 必须在拿到邻接后自己算，见 _ensure_graph

    def _ensure_graph(self, edge_index, device):
        """The legacy `fit()` precomputes L_scaled; we are bypassing fit(), so we
        must do it ourselves. Skipping it leaves L_scaled = None and the forward
        pass dies with an unhelpful AttributeError (which the probe caught).
        旧代码在 fit() 里预计算 L_scaled，我们绕过了 fit，就必须自己算。
        """
        if self.net.L_scaled is None or self.net.L_scaled.device != device:
            L = compute_scaled_laplacian(self._adj_np(edge_index))
            if not np.isfinite(L).all():
                raise ValueError("scaled Laplacian contains non-finite values; "
                                 "check the adjacency (isolated nodes?)")
            self.net.L_scaled = torch.as_tensor(L, dtype=torch.float32, device=device)

    def forward(self, x, edge_index, geo=None):
        if x.dim() != 4:
            raise ValueError(f"STGCNAdapter expects {self.expected_input}, got {tuple(x.shape)}")
        self._ensure_graph(edge_index, x.device)
        adj = self._adj(edge_index).to(x.device)
        # STGCN's forward takes the WHOLE batch: (B,N,T,F) + (N,N) → (B,N,1).
        # Its `geo_features` argument is unused inside forward — the priors only
        # enter `compute_physical_loss`, which we disable (lambda_phys = 0).
        # So this baseline is UNCONDITIONED in our protocol, and the probe
        # verifies that empirically rather than by reading the source.
        # 该基线在前向中不使用描述子，属于"无条件"对照；探针会实测这一点。
        g = None if geo is None else (geo[0] if geo.dim() == 3 else geo)
        return self._to_target(self.net(x, adj, g))


class DCRNNAdapter(_Base):
    """DCRNN: (B,N,T,F) + dense adj → (B,N,1)."""

    def __init__(self, n_nodes: int, input_dim: int, geo_dim: int, config: dict):
        super().__init__(n_nodes)
        self.net = DCRNNNet(config)
        self.net._build_model(input_dim, geo_dim)
        self.net.P_fwd_list = None    # computed lazily in _ensure_graph
        self.net.P_bwd_list = None
        self.K = int(config.get("diffusion_K", 2))

    def _ensure_graph(self, edge_index, device):
        if (self.net.P_fwd_list is None
                or self.net.P_fwd_list[0].device != device):
            fwd, bwd = compute_diffusion_matrices(self._adj_np(edge_index), self.K)
            self.net.P_fwd_list = [p.to(device) for p in fwd]
            self.net.P_bwd_list = [p.to(device) for p in bwd]

    def forward(self, x, edge_index, geo=None):
        if x.dim() != 4:
            raise ValueError(f"DCRNNAdapter expects {self.expected_input}, got {tuple(x.shape)}")
        self._ensure_graph(edge_index, x.device)
        adj = self._adj(edge_index).to(x.device)
        # Same convention as STGCN: whole batch in, priors unused in forward.
        g = None if geo is None else (geo[0] if geo.dim() == 3 else geo)
        return self._to_target(self.net(x, adj, g))


class PINNAdapter(_Base):
    """PINN: no graph, and **no batch dimension** in the legacy forward.

    We loop over the batch here rather than reshaping, because the legacy
    forward flattens (T,F) per node and a reshape would silently mix nodes.
    """
    expected_input = "(B, N, T, F), internally unbatched to (N, T, F)"

    def __init__(self, n_nodes: int, input_dim: int, geo_dim: int, config: dict):
        super().__init__(n_nodes)
        self.net = PINNPermafrostNet(config)
        self.net._build_model(input_dim, geo_dim)

    def forward(self, x, edge_index, geo=None):
        if x.dim() != 4:
            raise ValueError(f"PINNAdapter expects {self.expected_input}, got {tuple(x.shape)}")
        B, N, T, F = x.shape
        outs = []
        for b in range(B):
            g = None if geo is None else (geo[b] if geo.dim() == 3 else geo)
            outs.append(self.net(x[b], g))  # (N,1)
        return self._to_target(torch.stack(outs, dim=0))   # (B,N,1) → (B,N)


_ADAPTERS = {"stgcn": STGCNAdapter, "dcrnn": DCRNNAdapter, "pinn": PINNAdapter}

_DEFAULT_CONFIG = {
    "hidden_dim": 64, "num_heads": 4, "num_spatial_layers": 2, "dropout": 0.1,
    "lambda_phys": 0.0, "use_phys_loss": False, "K": 3, "num_layers": 3,
    "output_dim": 1,
}


def build_baseline(name: str, *, n_nodes: int, input_dim: int, geo_dim: int,
                   seed: int = 42, config: dict | None = None) -> nn.Module:
    """构造一个基线；种子必须先固定（与 `factory.build_model` 同一约定）。"""
    if name not in _ADAPTERS:
        raise ValueError(f"unknown baseline '{name}'; choose from {BASELINE_NAMES}")
    from ..train.seeding import set_all_seeds

    cfg = dict(_DEFAULT_CONFIG)
    cfg.update(config or {})
    set_all_seeds(seed)
    return _ADAPTERS[name](n_nodes=n_nodes, input_dim=input_dim, geo_dim=geo_dim,
                           config=cfg)
