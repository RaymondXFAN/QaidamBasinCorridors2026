"""统一的 ST-GAT 模型：一个类，覆盖论文里所有对照配置。

One model class that covers every ablation in the paper.

    conditioning="film"  + film_mode="full"     → Full FiLM (γ·h + gate·β)
    conditioning="film"  + film_mode="mul_only" → γ·h
    conditioning="film"  + film_mode="add_only" → h + gate·β
    conditioning="none"                         → Standard ST-GAT
    conditioning="concat"                       → 信息匹配对照（R1-3）
                                                  把同样 3 个描述子直接拼到输入，
                                                  不给 FiLM，只给信息。

最后一种就是审稿人要的 "no-FiLM comparator should receive exactly the same
three conditioning variables through a non-FiLM route"。以前没有它，
所以"FiLM 更好"到底是因为机制还是因为多拿了信息，说不清。
That last mode is exactly what the reviewer asked for. Without it, we cannot
tell whether FiLM helped because of the mechanism or because it simply got
more information.
"""

from __future__ import annotations

import torch
import torch.nn as nn

from .film import FiLMGenerator, apply_film
from .gat import SparseGATLayer

__all__ = ["STGAT", "CONDITIONING_MODES", "_flatten_nodes"]

CONDITIONING_MODES = ("film", "concat", "none")


def _flatten_nodes(h: torch.Tensor) -> torch.Tensor:
    """(B,N,T,H) → (B*N,T,H)，行序为 b*N+n。

    单独抽出来是为了能被单元测试钉死：这一行错了，模型会"能跑、不报错、
    但永远学不会"，是最难查的一类 bug。
    Extracted so a unit test can pin it down: get this wrong and the model
    still runs, never errors, and simply never learns — the worst kind of bug.
    """
    B, N, T, H = h.shape
    return h.reshape(B * N, T, H)


class STGAT(nn.Module):
    def __init__(self, input_dim: int, geo_dim: int = 3, hidden_dim: int = 64,
                 num_heads: int = 4, num_spatial_layers: int = 2,
                 dropout: float = 0.1, conditioning: str = "film",
                 film_mode: str = "add_only", beta_max: float = 5.0,
                 film_init: float = -1.5, num_hidden_layers: int = 1,
                 residual_output: bool = False, residual_channel: int = 0,
                 spatial_residual: bool = False):
        super().__init__()
        if conditioning not in CONDITIONING_MODES:
            raise ValueError(f"conditioning 必须是 {CONDITIONING_MODES}")
        if conditioning == "film" and film_mode == "none":
            raise ValueError("film_mode 不能是 'none'，用 conditioning='none'")

        self.conditioning = conditioning
        self.film_mode = film_mode
        self.geo_dim = geo_dim
        # 残差参数化：ŷ = x_last + f(·)。
        # 纯绝对值回归很难学出"复述去年"，而 persistence 天生就有这条通路，
        # 所以模型再努力也打不过一个 trivial 基线。加上这条捷径（所有配置
        # shared by all configurations so fairness is unaffected; the model only learns the increment / 只学变化量
        # Residual parameterisation: y_hat = x_last + f(.). Absolute regression
        # struggles to merely repeat last year's value, which is exactly what
        # persistence does for free. Shared by all configurations, so the
        # comparison stays fair — the model only has to learn the increment.
        self.residual_output = bool(residual_output)
        self.residual_channel = int(residual_channel)
        # 空间残差：h ← h + GAT(h)。
        # Without it, two attention layers wash each node's own level into a neighbour average / 会洗成邻居平均
        # 实测 RMSE 3.46 → 去掉图后 1.32。加回自连接即可保住自身信号。
        # Without it, two attention layers wash each node's own level into a
        # neighbourhood average (RMSE 3.46 vs 1.32 with no graph at all).
        self.spatial_residual = bool(spatial_residual)

        proj_in = input_dim + (geo_dim if conditioning == "concat" else 0)
        self.input_proj = nn.Sequential(
            nn.Linear(proj_in, hidden_dim), nn.ReLU(), nn.Dropout(dropout)
        )

        self.spatial_layers = nn.ModuleList([
            SparseGATLayer(hidden_dim, hidden_dim, num_heads, dropout)
            for _ in range(num_spatial_layers)
        ])

        self.film = None
        if conditioning == "film":
            self.film = FiLMGenerator(
                geo_dim, hidden_dim, mode=film_mode, beta_max=beta_max,
                init_scale=film_init, num_hidden_layers=num_hidden_layers,
            )

        self.temporal_gru = nn.GRU(hidden_dim, hidden_dim, num_layers=1, batch_first=True)
        self.output_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2), nn.ReLU(),
            nn.Dropout(dropout), nn.Linear(hidden_dim // 2, 1),
        )

    def forward(self, X: torch.Tensor, edge_index: torch.Tensor,
                geo: torch.Tensor | None = None) -> torch.Tensor:
        """X: (B,N,T,F) → (B,N)。geo: (N,G) 或 (B,N,G)。"""
        B, N, T, Fdim = X.shape

        # 先记下"最后一个观测"，残差通路要用（必须在 concat 之前取）
        base = None
        if self.residual_output:
            base = X[:, :, -1, self.residual_channel].unsqueeze(-1)   # (B,N,1)

        if self.conditioning == "concat":
            if geo is None:
                raise ValueError("conditioning='concat' 需要 geo 输入")
            # geo 可能是 (N,G) 或 (B,N,G)，都要扩成 (B,N,T,G) 才能和 X 拼。
            # 之前只处理了 2D，3D（逐窗口描述子）直接炸——冒烟测试抓到的就是这个。
            # geo can be (N,G) or (B,N,G); both must become (B,N,T,G). The first
            # version only handled 2D and crashed on per-window descriptors.
            if geo.dim() == 2:
                g = geo.view(1, N, 1, -1).expand(B, N, T, -1)
            elif geo.dim() == 3:
                g = geo.unsqueeze(2).expand(B, N, T, geo.shape[-1])
            else:
                raise ValueError(f"geo 维度不支持: {tuple(geo.shape)}")
            X = torch.cat([X, g], dim=-1)

        h = self.input_proj(X)                              # (B,N,T,H)

        # 空间：把时间维并进 batch，逐时刻做 GAT
        h = h.permute(0, 2, 1, 3).reshape(B * T, N, -1)
        for layer in self.spatial_layers:
            out = layer(h, edge_index)
            h = h + out if self.spatial_residual else out
        h = h.view(B, T, N, -1).permute(0, 2, 1, 3)          # (B,N,T,H)

        # 条件化：只在空间之后、时序之前作用一次（与 Perez et al. 一致）
        # Conditioning: applied once, after spatial encoding, before temporal.
        # geo 支持 (N,G)（全场共用）与 (B,N,G)（逐窗口 origin 描述子）。
        # geo may be (N,G) shared across the batch, or (B,N,G) per window.
        if self.film is not None and geo is not None:
            gamma, beta, gate = self.film(geo)
            if gamma is not None:
                if gamma.dim() == 2:
                    gamma = gamma.view(1, N, 1, -1)
                else:                                   # (B,N,H) → (B,N,1,H)
                    gamma = gamma.view(B, N, 1, -1)
            if beta is not None:
                if beta.dim() == 2:
                    beta = beta.view(1, N, 1, -1)
                else:
                    beta = beta.view(B, N, 1, -1)
            h = apply_film(h, gamma, beta, gate, self.film_mode)

        # 时序：每个节点独立跑 GRU，取最后时刻。
        # h 已是 (B,N,T,H)，直接 reshape 成 (B*N,T,H) 即可。
        # ⚠️ 千万别先 permute 成 (B,T,N,H) 再 reshape —— 那会把时间和节点
        #    搅在一起，GRU 读到的序列是乱码，训练出来永远约等于预测均值。
        #    （我重构时就犯过这个错，R² 卡在 0.07 查了半天。）
        # h is already (B,N,T,H); reshape directly. Permuting to (B,T,N,H)
        # first and then reshaping scrambles time into the node axis — the GRU
        # then reads garbage and the model collapses to the mean (R²≈0.07).
        hn = _flatten_nodes(h)
        out, _ = self.temporal_gru(hn)
        last = out[:, -1, :].view(B, N, -1)

        out = self.output_head(last)                          # (B,N,1)
        if base is not None:
            out = out + base                                  # 残差：只学增量
        return out.squeeze(-1)                                # (B,N)

    @property
    def num_params(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


def stefan_alt(geo_raw: torch.Tensor, k_thaw: float = 1.2, latent: float = 3.34e8):
    """Stefan 方程算 ALT（物理约束 loss 用）。

    ALT = sqrt(2 * k * I_t * 86400 / L)
    geo_raw 的第 2 列约定为解冻指数 I_t（单位 °C·day，见数据说明）。
    约定必须写死在代码里，别靠"我记得第三列是啥"。
    """
    if geo_raw.dim() != 2 or geo_raw.shape[1] < 3:
        raise ValueError("geo_raw 需要形如 (N, >=3)，第 3 列为解冻指数")
    it = torch.clamp(geo_raw[:, 2], min=0.0)
    return torch.sqrt(2.0 * k_thaw * it * 86400.0 / latent)
