"""唯一的稀疏 GAT 层 —— 全仓库只此一份。

The one and only sparse GAT layer.

实现沿用原版已验证可跑的 `scatter_reduce_` 版本（真实数据 N=500、K=8 跑过），
只做两处收敛：
  1. 删除重复的两份拷贝（原 `run_fair_film_experiment.py` 与
     `run_real_magt_experiment.py` 各写了一遍）；
  2. 不要再用裸 assert 崩掉整个实验 —— 宽度不整除时给出可操作的报错，
     并且提供一个"向上取整到合法宽度"的工具函数（R1-7 的直接修复）。
Kept the proven scatter_reduce_ implementation (it ran on real data, N=500,
K=8). Two changes only: remove the duplicated copies, and replace the bare
assert with an actionable error plus a round-up helper (the R1-7 fix).
"""

from __future__ import annotations

import torch
import torch.nn as nn

__all__ = ["SparseGATLayer", "round_up_to_heads"]


def round_up_to_heads(dim: int, num_heads: int) -> int:
    """把 hidden_dim 向上取整到 num_heads 的倍数。

    R1-7 的根因：二分搜索返回任意 int（比如 71），直接喂给 4 头的 GAT 就
    assert 崩了。这里先取整，再建模型——顺序反了就会炸。
    Root cause of R1-7: binary search returned an arbitrary int (e.g. 71) and
    fed it straight to a 4-head GAT, which asserted. Round first, build second.
    """
    if num_heads <= 0:
        raise ValueError("num_heads 必须为正 / must be positive")
    return int(((dim + num_heads - 1) // num_heads) * num_heads)


class SparseGATLayer(nn.Module):
    """基于 edge_index 的多头图注意力（只算 KNN 边）。

    h: (M, N, in_dim) → (M, N, out_dim)，M = batch × timesteps。
    edge_index: (2, E)，第 0 行 src、第 1 行 dst。
    """

    def __init__(self, in_dim: int, out_dim: int, num_heads: int = 4,
                 dropout: float = 0.1, strict: bool = True):
        super().__init__()
        if out_dim % num_heads != 0:
            msg = (f"out_dim={out_dim} 不能被 num_heads={num_heads} 整除。\n"
                   f"out_dim is not divisible by num_heads.\n"
                   f"→ 用 round_up_to_heads({out_dim}, {num_heads}) = "
                   f"{round_up_to_heads(out_dim, num_heads)}，别硬塞。")
            if strict:
                raise ValueError(msg)
            out_dim = round_up_to_heads(out_dim, num_heads)

        self.num_heads = num_heads
        self.out_dim = out_dim
        self.head_dim = out_dim // num_heads

        self.W_src = nn.Linear(in_dim, out_dim, bias=False)
        self.W_dst = nn.Linear(in_dim, out_dim, bias=False)
        self.attn = nn.Parameter(torch.zeros(1, num_heads, 2 * self.head_dim))
        nn.init.xavier_uniform_(self.attn)

        self.dropout = nn.Dropout(dropout)
        self.leaky_relu = nn.LeakyReLU(0.2)
        self.out_proj = nn.Linear(out_dim, out_dim)

    def forward(self, h: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        M, N, _ = h.shape
        src_idx, dst_idx = edge_index[0], edge_index[1]
        E = int(src_idx.numel())

        h_src = self.W_src(h).view(M, N, self.num_heads, self.head_dim)
        h_dst = self.W_dst(h).view(M, N, self.num_heads, self.head_dim)

        src_feat = h_src[:, src_idx]                       # (M,E,H,Dh)
        dst_feat = h_dst[:, dst_idx]
        edge_feat = torch.cat([src_feat, dst_feat], dim=-1)
        e = self.leaky_relu((edge_feat * self.attn.unsqueeze(0)).sum(-1))   # (M,E,H)

        dst_expand = dst_idx.view(1, -1, 1).expand(M, -1, self.num_heads)

        # 数值稳定：减去每个目标节点的最大分数 / subtract per-destination max
        e_max = torch.full((M, N, self.num_heads), -1e9, device=e.device, dtype=e.dtype)
        e_max.scatter_reduce_(1, dst_expand, e, reduce="amax", include_self=True)
        e_exp = torch.exp(e - e_max[:, dst_idx])

        e_sum = torch.zeros(M, N, self.num_heads, device=h.device, dtype=e.dtype)
        e_sum.scatter_add_(1, dst_expand, e_exp)
        alpha = self.dropout(e_exp / (e_sum[:, dst_idx] + 1e-8))

        weighted = (alpha.unsqueeze(-1) * src_feat).reshape(M, E, self.out_dim)
        h_agg = torch.zeros(M, N, self.out_dim, device=h.device, dtype=h.dtype)
        h_agg.scatter_add_(1, dst_idx.view(1, -1, 1).expand(M, -1, self.out_dim), weighted)
        return self.out_proj(h_agg)
