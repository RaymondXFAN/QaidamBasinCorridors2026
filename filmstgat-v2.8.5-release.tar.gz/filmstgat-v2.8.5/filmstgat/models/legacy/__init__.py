"""Byte-identical vendored copies of the legacy baselines.

Do not edit these files: they are kept verbatim so that the baselines we report
are exactly the code that produced the published numbers.

逐字节复制，勿改。
"""
