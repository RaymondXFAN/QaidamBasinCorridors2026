"""唯一的 FiLM 实现 —— 全仓库只此一份。

The one and only FiLM implementation in this repository.

为什么重写：原版把 FiLM 写了 4 遍（主模型 1 份、真实实验 1 份、公平消融 3 份），
而且主模型里的 gamma 被算出来后**根本没参与运算**（注释还写着"for paper
narrative"）。审稿人一眼就看穿了。现在：一份代码，三种模式，gamma 必须真的乘上去。
Why rewrite: the old repo had four copies of FiLM, and in the main model gamma
was computed but never applied (the comment literally said "for paper
narrative"). One implementation, three modes, gamma is genuinely multiplied.
"""

from __future__ import annotations

import torch
import torch.nn as nn

__all__ = ["FiLMGenerator", "apply_film", "VALID_MODES"]

VALID_MODES = ("full", "mul_only", "add_only")


class FiLMGenerator(nn.Module):
    """从地质描述子生成 (gamma, beta, gate)。

    Parameters
    ----------
    geo_dim : int
    hidden_dim : int
    mode : {"full", "mul_only", "add_only"}
    beta_max : float
        soft-clamp 上界。beta = beta_max * x / (beta_max + |x|)，|beta| < beta_max，
        梯度处处平滑（不像 hard clamp 那样在边界死掉）。
        Soft clamp keeps |beta| < beta_max with a smooth gradient everywhere —
        unlike a hard clamp, which kills gradients at the boundary.
    init_scale : float
        gate 的初值（logit）。-1.5 → sigmoid≈0.18；论文正文必须与此一致。
        Gate logit at init. -1.5 → sigmoid≈0.18. The manuscript MUST match this.
        （原稿写 -2.2，代码是 -1.5 —— R1-2 抓的就是这个。）
    num_hidden_layers : int
        默认 1：geo_dim → hidden_dim → output。论文若写"two hidden layers"，
        要么改代码要么改论文，**二选一，不能两头不一样**。
        Default 1 hidden layer. If the paper claims two, change the paper or
        the code — but never leave them disagreeing.
    """

    def __init__(self, geo_dim: int, hidden_dim: int, mode: str = "full",
                 beta_max: float = 5.0, init_scale: float = -1.5,
                 num_hidden_layers: int = 1, dropout: float = 0.0):
        super().__init__()
        if mode not in VALID_MODES:
            raise ValueError(f"mode 必须是 {VALID_MODES}，收到 {mode!r}")

        self.mode = mode
        self.beta_max = float(beta_max)

        n_out = 2 * hidden_dim if mode == "full" else hidden_dim

        layers = [nn.Linear(geo_dim, hidden_dim), nn.ReLU()]
        if dropout > 0:
            layers.append(nn.Dropout(dropout))
        for _ in range(max(0, num_hidden_layers - 1)):
            layers += [nn.Linear(hidden_dim, hidden_dim), nn.ReLU()]
        layers.append(nn.Linear(hidden_dim, n_out))
        self.mlp = nn.Sequential(*layers)

        # 零初始化最后一层：训练开始时 gamma=1, beta=0，模型等价于无 FiLM。
        # Zero-init the last layer: at step 0, gamma=1 and beta=0, i.e. FiLM is
        # an identity map. That is the ONLY thing "identity init" guarantees.
        nn.init.zeros_(self.mlp[-1].weight)
        nn.init.zeros_(self.mlp[-1].bias)

        self.film_scale_raw = nn.Parameter(torch.tensor(float(init_scale)))
        self.hidden_dim = hidden_dim

    def forward(self, geo: torch.Tensor):
        """geo: (N, G) 或 (B, N, G) → gamma/beta 形状 (..., H)，gate 为标量。"""
        params = self.mlp(geo)

        if self.mode == "full":
            gamma_raw, beta_raw = params.chunk(2, dim=-1)
        elif self.mode == "mul_only":
            gamma_raw, beta_raw = params, None
        else:  # add_only
            gamma_raw, beta_raw = None, params

        gamma = None if gamma_raw is None else 1.0 + gamma_raw

        beta = None
        if beta_raw is not None:
            # soft clamp：|beta| < beta_max，且梯度不会在边界消失
            beta = self.beta_max * beta_raw / (self.beta_max + beta_raw.abs() + 1e-8)

        gate = torch.sigmoid(self.film_scale_raw)
        return gamma, beta, gate


def apply_film(h: torch.Tensor, gamma, beta, gate, mode: str) -> torch.Tensor:
    """Apply the modulation to the features. 把调制作用到特征上。

    h : (B, N, T, H) 或 (N, H)
    注意 gate 只作用于 beta 通路；gamma 通路不再额外乘 gate，
    否则乘性项会被压到几乎无效（这是原版一个隐性的设计偏差）。
    Gate applies to the beta path only. Multiplying gamma by the gate as well
    would nearly nullify the multiplicative term — a subtle flaw in the old code.
    """
    if mode == "add_only":
        if beta is None:
            return h
        return h + gate * beta
    if mode == "mul_only":
        return h if gamma is None else h * gamma
    if mode == "full":
        out = h
        if gamma is not None:
            out = out * gamma
        if beta is not None:
            out = out + gate * beta
        return out
    raise ValueError(f"未知 mode {mode!r}")
