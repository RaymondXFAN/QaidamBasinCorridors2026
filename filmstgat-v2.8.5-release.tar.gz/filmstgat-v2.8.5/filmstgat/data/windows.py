"""Data pipeline: sliding windows, temporal split, scaling, window manifest. 数据管线。

Data pipeline: sliding windows, temporal split, scaling, window manifest.

这个模块存在的唯一理由：**把"切分"和"展平"这两件事彻底钉死**。
原版把 (N, W) 按 node-major 展平后又按时间切片，导致 77.5%~79% 的
"测试样本"其实是训练期窗口（审稿人 R1-5 抓到的就是这个）。
This module exists for one reason: nail down splitting and flattening.
The old code flattened (N, W) node-major and then sliced it as if it were
time-major, so 77.5-79% of "test" samples were training-period windows.
"""

from __future__ import annotations

import numpy as np

__all__ = [
    "sliding_windows",
    "temporal_split",
    "to_graph",
    "to_flat",
    "Standardizer",
    "window_manifest",
]


# --------------------------------------------------------------------------- #
# 1. 滑窗 / Sliding windows
# --------------------------------------------------------------------------- #
def sliding_windows(X: np.ndarray, y: np.ndarray, T_in: int, T_out: int,
                    stride: int = 1, gap: int = 0):
    """把 (N, T, F) 与 (N, T) 切成滑窗。

    Parameters
    ----------
    gap : int
        输入窗结束到目标窗开始的间隔（年）。原版 `T_out_step=5` 等价于
        "预测输入结束后第 5 年"，即 gap=4, T_out=1。
        Number of steps between the end of the input window and the start of
        the target window. The old `T_out_step=5` means "predict the 5th year
        after the input ends", i.e. gap=4, T_out=1.

    Returns
    -------
    Xw : (N, W, T_in, F)
    yw : (N, W, T_out)
    target_idx : (W,) 每个窗口"目标末时刻"在原始时间轴上的索引

    为什么把 gap 显式化：原版把它藏在变量名里，导致没人说得清
    "到底是提前几年"。审稿人 R3-1 要的就是这个确定性。
    Why make gap explicit: the old code buried it in a variable name, so
    nobody could state the actual forecast lead time. This is exactly the
    determinism R3-1 asks for.
    """
    X = np.asarray(X)
    y = np.asarray(y)
    if X.ndim != 3:
        raise ValueError(f"X 必须是 (N,T,F)，收到 {X.shape} / X must be (N,T,F)")
    N, T, F = X.shape
    if y.ndim != 2 or y.shape[0] != N:
        raise ValueError(f"y 必须是 (N,T)，收到 {y.shape} / y must be (N,T)")
    if gap < 0:
        raise ValueError("gap 不能为负 / gap must be >= 0")

    starts = np.arange(0, T - T_in - gap - T_out + 1, stride, dtype=int)
    if starts.size == 0:
        raise ValueError(
            f"时间步不足：T={T}, T_in={T_in}, gap={gap}, T_out={T_out} / "
            f"not enough timesteps"
        )

    Xw = np.stack([X[:, s:s + T_in, :] for s in starts], axis=1)
    yw = np.stack([y[:, s + T_in + gap:s + T_in + gap + T_out] for s in starts], axis=1)
    target_idx = starts + T_in + gap + T_out - 1
    return Xw.astype(np.float32), yw.astype(np.float32), target_idx


# --------------------------------------------------------------------------- #
# 2. 时间切分 / Temporal split
# --------------------------------------------------------------------------- #
def temporal_split(n_windows: int, train_ratio: float = 0.8,
                   val_ratio: float = 0.0) -> dict:
    """Split by **window index** (= chronological order), never by flattened row number. 按窗口序号切分。

    Split by window index (= chronological order). Never by flattened row index,
    which is exactly the bug that mixed nodes and timesteps.
    """
    if not (0 < train_ratio < 1):
        raise ValueError("train_ratio 必须在 (0,1) / must be in (0,1)")
    n_train = int(n_windows * train_ratio)
    n_val = int(n_windows * val_ratio)
    n_train = max(1, min(n_train, n_windows - 2))
    idx = {
        "train": np.arange(0, n_train),
        "val": np.arange(n_train, n_train + n_val),
        "test": np.arange(n_train + n_val, n_windows),
    }
    if idx["test"].size == 0:
        raise ValueError("测试集为空，检查 train_ratio / empty test split")
    return idx


def to_graph(Xw: np.ndarray, idx: np.ndarray) -> np.ndarray:
    """(N,W,T,F) + 窗口索引 → (w,N,T,F)，图模型格式。"""
    return Xw[:, idx, :, :].transpose(1, 0, 2, 3)


def to_flat(Xw: np.ndarray, idx: np.ndarray) -> np.ndarray:
    """(N,W,T,F) + 窗口索引 → (N*w,T,F)，表格模型格式。

    关键：**先按 idx 取窗口，再展平**。这样 flat 与 graph 的样本集合
    逐条对应，只是轴的顺序不同——这是修掉 R1-5 / R3-3 的核心。
    Key: select windows by idx FIRST, then flatten. Flat and graph formats
    then hold exactly the same samples, only axis order differs. This single
    change kills both R1-5 and R3-3.
    """
    sub = Xw[:, idx, :, :]
    return sub.transpose(1, 0, 2, 3).reshape(-1, sub.shape[2], sub.shape[3])


# --------------------------------------------------------------------------- #
# 3. 标准化 / Standardization (fit on TRAIN ONLY)
# --------------------------------------------------------------------------- #
class Standardizer:
    """A scaler fitted on training statistics only. 只用训练集统计量。

    Fit on training statistics ONLY. 原版在全序列上 fit 之后再切分，
    等于让未来信息参与缩放（R1-5 第一条）。
    """

    def __init__(self, eps: float = 1e-8):
        self.eps = eps
        self.mean = None
        self.std = None

    def fit(self, array: np.ndarray) -> "Standardizer":
        a = np.asarray(array, dtype=np.float64)
        self.mean = float(np.nanmean(a))
        self.std = float(np.nanstd(a))
        if self.std < self.eps:
            # 常数序列：std 设 1，避免除零后全变 inf。
            self.std = 1.0
        return self

    def transform(self, array: np.ndarray) -> np.ndarray:
        if self.mean is None:
            raise RuntimeError("先调 fit() / call fit() first")
        return ((np.asarray(array, dtype=np.float32) - self.mean) /
                (self.std + self.eps)).astype(np.float32)

    def inverse(self, array: np.ndarray) -> np.ndarray:
        if self.mean is None:
            raise RuntimeError("先调 fit() / call fit() first")
        return (np.asarray(array, dtype=np.float32) * (self.std + self.eps) +
                self.mean).astype(np.float32)


# --------------------------------------------------------------------------- #
# 4. 窗口清单 / Window manifest
# --------------------------------------------------------------------------- #
def window_manifest(target_idx: np.ndarray, T_in: int, T_out: int, gap: int = 0,
                    split: dict | None = None,
                    start_year: int = 1981) -> list:
    """逐窗口记录 origin / 输入年段 / 目标年段 / 提前量 / 所属划分。

    审稿人 R3-1 要的 "complete window manifest" 就是这张表。
    没有它，谁也说不清你到底在预测哪一年、提前几年。
    Without this, nobody can state which year a window predicts, or how far
    ahead. That ambiguity is precisely R3-1.
    """
    split_of = {}
    if split is not None:
        for name, ids in split.items():
            for i in ids:
                split_of[int(i)] = name

    rows = []
    for w, t_last in enumerate(np.asarray(target_idx).tolist()):
        t_start = t_last - T_out + 1
        in_end = t_start - gap - 1
        in_start = in_end - T_in + 1
        if in_start < 0:
            raise ValueError(
                f"窗口 {w} 的输入起点早于数据起点 / window {w} starts before data"
            )
        rows.append({
            "window": w,
            "input_years": f"{start_year + in_start}-{start_year + in_end}",
            "target_years": f"{start_year + t_start}-{start_year + t_last}",
            "origin_year": start_year + in_end,
            "gap_years": gap,
            "horizon_years": t_last - in_end,   # 1-based：提前几年
            "split": split_of.get(w, "unassigned"),
        })
    return rows
