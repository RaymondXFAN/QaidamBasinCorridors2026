"""真实数据重建：从旧 npz 重建一份"可复现"的 v2 数据集。

Rebuild the real dataset from the legacy npz into a reproducible v2 artefact.

为什么能在不碰 tif 的情况下重建 / Why this works without the GeoTIFFs
---------------------------------------------------------------------
旧 npz 里其实存了**全部 45,041 个有效像素**的 38 年原始序列：
    X_train_raw (N,30) + y_val_raw (N,5) + y_test_raw (N,3) = (N,38)
所以像素筛选、描述子、开窗全都能在内存里重做，不必再读 45 GB 的栅格。
The legacy npz already contains all 45,041 valid pixels with their full
38-year series, so pixel selection, descriptors and windowing can all be
redone in memory — no need to touch the rasters again.

修掉的三件事 / Three defects fixed here
---------------------------------------
1. **D-07**：像素合格性与分层抽样只用训练期（1981–2010），不再看 2011–2018。
2. **D-08**：描述子按每个窗口的 forecast origin 现算（扩展窗），不再统一用 2010。
3. **D-12**：提前量 gap 显式化，并输出完整 window manifest。

作者 / Author: Raymond Xiaohu Fan
"""

from __future__ import annotations

import json
import os

import numpy as np

__all__ = [
    "load_legacy", "train_period_mask", "stratified_sample",
    "origin_descriptors", "knn_edges", "build_windows_v2", "build_dataset_v2",
]

N_TRAIN_YEARS = 30          # 1981–2010
START_YEAR = 1981


def load_legacy(path: str) -> dict:
    """读取旧 npz，拼出完整 38 年序列。

    注意：旧文件里 `y_train` 只是 `y_val` 的别名（注释写着 "use val for
    early stopping"），`X_train/X_val/X_test` 也是同一份输入。这些字段
    **一律不用**，只用 `*_raw` 重新拼。留着它们就是给下游埋雷（D-13）。
    Legacy `y_train` is just an alias of `y_val`, and the three X arrays are
    identical. We ignore all of them and rebuild from `*_raw` only.
    """
    d = np.load(path, allow_pickle=True)
    required = ["X_train_raw", "y_val_raw", "y_test_raw", "geo_raw", "pixel_indices"]
    missing = [k for k in required if k not in d.files]
    if missing:
        raise KeyError(f"旧 npz 缺少字段 {missing} / missing fields")
    if "years" in d.files:
        years = np.asarray(d["years"]).astype(int)
    else:
        years = np.arange(START_YEAR, START_YEAR + 38)

    series = np.concatenate(
        [np.asarray(d["X_train_raw"], np.float32),
         np.asarray(d["y_val_raw"], np.float32),
         np.asarray(d["y_test_raw"], np.float32)], axis=1)
    if series.shape[1] != len(years):
        raise ValueError(f"序列长度 {series.shape[1]} ≠ 年份数 {len(years)}")

    return {
        "series": series,                       # (N, 38)
        "geo_raw": np.asarray(d["geo_raw"], np.float32),
        "pixel_indices": np.asarray(d["pixel_indices"], np.int64),
        "years": years,
    }


def train_period_mask(series: np.ndarray, n_train: int = N_TRAIN_YEARS,
                      min_valid: int = N_TRAIN_YEARS) -> np.ndarray:
    """只用训练期判断像素是否合格（D-07）。

    原版 `find_valid_pixels(magt_all)` 把 2011–2018 也算进去了——等于让
    测试期的目标信息参与"这个像素要不要"的决定。现在只看前 30 年。
    """
    head = series[:, :n_train]
    return np.isfinite(head).sum(axis=1) >= min_valid


def stratified_sample(candidate_idx: np.ndarray, values: np.ndarray,
                      n_samples: int, n_bins: int = 10, seed: int = 42) -> np.ndarray:
    """按训练期均值分层抽样（D-07 的另一半）。"""
    rng = np.random.default_rng(seed)
    vals = values[candidate_idx]
    lo, hi = np.nanmin(vals), np.nanmax(vals)
    if not np.isfinite(lo) or not np.isfinite(hi) or hi - lo < 1e-6:
        edges = np.array([lo, hi])
    else:
        edges = np.linspace(lo, hi, n_bins + 1)

    bins = np.clip(np.digitize(vals, edges[1:-1]), 0, n_bins - 1)
    per_bin = max(1, n_samples // n_bins)

    picked = []
    for b in range(n_bins):
        in_bin = candidate_idx[bins == b]
        if in_bin.size == 0:
            continue
        take = min(per_bin, in_bin.size)
        picked.append(rng.choice(in_bin, size=take, replace=False))
    out = np.concatenate(picked) if picked else np.array([], dtype=int)

    # 补齐 / top up to the requested size
    if out.size < n_samples:
        rest = np.setdiff1d(candidate_idx, out, assume_unique=False)
        extra = min(n_samples - out.size, rest.size)
        if extra > 0:
            out = np.concatenate([out, rng.choice(rest, size=extra, replace=False)])
    return np.sort(out.astype(int))


def origin_descriptors(series: np.ndarray, origins: np.ndarray,
                       n_min: int = 5) -> np.ndarray:
    """按每个窗口的 origin 现算描述子（D-08）。

    对 origin=t0 的窗口，只用 series[:, :t0+1] 计算：
        [均值, 线性趋势(°C/yr), 标准差]
    这样任何窗口的描述子都不可能看到目标期——审稿人 R3-1 抓的就是原版
    统一用 1981–2010 算、却拿去预测 1995 的样本。
    For a window whose input ends at t0, descriptors use series[:, :t0+1] only.
    """
    N = series.shape[0]
    out = np.zeros((len(origins), N, 3), dtype=np.float32)
    for w, t0 in enumerate(np.asarray(origins, dtype=int)):
        window = series[:, :t0 + 1]
        out[w, :, 0] = np.nanmean(window, axis=1)
        out[w, :, 2] = np.nanstd(window, axis=1)

        t = np.arange(window.shape[1], dtype=np.float64)
        t = t - t.mean()
        denom = float(np.sum(t ** 2)) or 1.0
        centred = window - np.nanmean(window, axis=1, keepdims=True)
        out[w, :, 1] = (centred @ t) / denom

    if n_min > 0:
        bad = ~np.isfinite(out)
        out[bad] = 0.0
    return out


def knn_edges(pixel_indices: np.ndarray, k: int = 8,
              pixel_size_m: float = 1000.0):
    """按像素坐标建 KNN 边（假设 1 km 等面积网格）。

    旧代码用 rasterio 的 affine transform 换算距离；这里没有 tif，就用
    像素索引 × 1 km 近似。**这个假设必须写进论文与 README**，不能默默用。
    The old code used the raster transform. Without the raster we approximate
    with pixel index × 1 km — and this assumption MUST be stated in the paper.
    """
    from scipy.spatial import cKDTree

    xy = np.asarray(pixel_indices, dtype=np.float64) * pixel_size_m
    tree = cKDTree(xy)
    dist, idx = tree.query(xy, k=k + 1)
    dist, idx = dist[:, 1:], idx[:, 1:]

    N = xy.shape[0]
    src = np.repeat(np.arange(N), k)
    dst = idx.reshape(-1)
    w = 1.0 / (dist.reshape(-1) + 1.0)
    w = (w / w.max()).astype(np.float32)
    return np.stack([src, dst]).astype(np.int64), w


def build_windows_v2(series: np.ndarray, T_in: int = 10, gap: int = 4,
                     T_out: int = 1):
    """开窗 + 目标年份 + 划分（train≤2010 / val 2011–2014 / test≥2015）。"""
    from .windows import sliding_windows

    N, T = series.shape
    X = series.reshape(N, T, 1)
    Xw, yw, target_idx = sliding_windows(X, series, T_in=T_in, T_out=T_out, gap=gap)

    years = START_YEAR + target_idx
    split = {
        "train": np.where(years <= 2010)[0],
        "val": np.where((years >= 2011) & (years <= 2014))[0],
        "test": np.where(years >= 2015)[0],
    }
    return Xw, yw, target_idx, split


def build_dataset_v2(legacy_npz: str, out_dir: str, n_samples: int = 45041,
                     k: int = 8, seed: int = 42, T_in: int = 10,
                     gap: int = 4, T_out: int = 1) -> dict:
    """完整重建流程，落盘 npz + manifest + 描述文件。"""
    os.makedirs(out_dir, exist_ok=True)
    legacy = load_legacy(legacy_npz)
    series, geo_raw, pix = legacy["series"], legacy["geo_raw"], legacy["pixel_indices"]

    # 1) 训练期合格性（D-07）
    ok = train_period_mask(series)
    cand = np.where(ok)[0]

    # 2) 训练期均值分层（D-07）
    train_mean = np.nanmean(series[:, :N_TRAIN_YEARS], axis=1)
    n_take = min(n_samples, cand.size)
    sel = stratified_sample(cand, train_mean, n_take, n_bins=10, seed=seed)

    series_s, geo_s, pix_s = series[sel], geo_raw[sel], pix[sel]

    # 3) Sliding windows + temporal split / 开窗 + 划分
    Xw, yw, target_idx, split = build_windows_v2(series_s, T_in, gap, T_out)

    # 4) 逐 origin 描述子（D-08）
    origins = target_idx - gap - T_out
    desc = origin_descriptors(series_s, origins)

    # 5) Graph construction / 建图
    edge_index, edge_weight = knn_edges(pix_s, k=k)

    # 6) 标准化：只用训练期（D-06）
    head = series_s[:, :N_TRAIN_YEARS]
    ts_mean, ts_std = float(np.nanmean(head)), float(np.nanstd(head))

    path = os.path.join(out_dir, "real_magt_data_v2_clean.npz")
    np.savez_compressed(
        path,
        series=series_s.astype(np.float32),
        X_windows=Xw.astype(np.float32),
        y_windows=yw.astype(np.float32),
        target_idx=target_idx.astype(np.int64),
        descriptors=desc.astype(np.float32),
        geo_raw=geo_s.astype(np.float32),
        pixel_indices=pix_s.astype(np.int64),
        edge_index=edge_index,
        edge_weight=edge_weight,
        split_train=split["train"], split_val=split["val"], split_test=split["test"],
        ts_mean=np.float32(ts_mean), ts_std=np.float32(ts_std),
        years=legacy["years"].astype(np.int64),
    )

    # 7) window manifest（R3-1）
    from .windows import window_manifest
    rows = window_manifest(target_idx, T_in=T_in, T_out=T_out, gap=gap, split=split)
    manifest_csv = os.path.join(out_dir, "window_manifest_v2.csv")
    with open(manifest_csv, "w", encoding="utf-8") as fh:
        cols = ["window", "input_years", "target_years", "origin_year",
                "gap_years", "horizon_years", "split"]
        fh.write(",".join(cols) + "\n")
        for r in rows:
            fh.write(",".join(str(r[c]) for c in cols) + "\n")

    # 8) Dataset card, written for reviewers / 数据集说明
    meta = {
        "source_npz": os.path.abspath(legacy_npz),
        "n_pixels_total": int(series.shape[0]),
        "n_pixels_selected": int(series_s.shape[0]),
        "selection_rule": "valid in all 1981-2010 years; stratified by 1981-2010 mean",
        "n_windows": int(Xw.shape[1]),
        "T_in": T_in, "gap": gap, "T_out": T_out,
        "split_sizes": {k: int(v.size) for k, v in split.items()},
        "target_years": [int(y) for y in (START_YEAR + target_idx)],
        "descriptor_definition": "[mean, linear trend (degC/yr), std] over years up to each origin",
        "graph": {"k": k, "pixel_size_m": 1000.0,
                  "note": "distance approximated as pixel index x 1 km (equal-area grid)"},
        "normalisation": {"fitted_on": "1981-2010 only", "mean": ts_mean, "std": ts_std},
    }
    with open(os.path.join(out_dir, "dataset_manifest_v2.json"), "w", encoding="utf-8") as fh:
        json.dump(meta, fh, indent=2, ensure_ascii=False)

    meta["npz_path"] = path
    meta["manifest_csv"] = manifest_csv
    return meta
