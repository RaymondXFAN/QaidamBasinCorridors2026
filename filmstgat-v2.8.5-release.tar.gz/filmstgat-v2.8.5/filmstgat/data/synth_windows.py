#!/usr/bin/env python3
"""合成数据 → v2 数据集（滑窗 / 时域切分 / 邻接转边 / 逐特征标准化统计）。

Synthetic → v2 dataset: windows, temporal split, adjacency-to-edges, per-feature stats.

为什么不能直接复用真实数据的装配代码 / Why not reuse the real-data assembler
--------------------------------------------------------------------------
真实数据 F=1（年均地温），用一个标量 mean/std 归一化就够；
合成数据 F=12，混着形变速率(mm/yr)、相干性(0-1)、地温(°C)、高程(m)、
冻结指数(°C·day)…… **一个标量归一化会把 ViT 直接压成 0**。
所以这里按特征各自标准化，统计量只取训练期。
Real data has F=1, so a scalar scaler is fine. Synthetic has F=12 with wildly
different units; a scalar scaler would flatten half the features to zero.

切分 / Split
------------
原协议：`split_idx = int(T * 0.8) = 96`（前 96 个月训练、后 24 个月测试）。
本实现沿用这条边界，并从训练段尾部切 6 个月做验证集：
    train: target_idx ≤ 89
    val  : 90 ≤ target_idx ≤ 95
    test : target_idx ≥ 96

作者 / Author: Raymond Xiaohu Fan
"""

from __future__ import annotations

import json
import os

import numpy as np

from .windows import sliding_windows

__all__ = ["adj_to_edge_index", "build_synth_v2", "per_feature_stats"]


def adj_to_edge_index(adj: np.ndarray, drop_self: bool = True):
    """邻接矩阵 → (2, E) 边索引。邻接本身是 0/1 阈值图，权重一律记 1。"""
    a = np.asarray(adj, dtype=float)
    n = a.shape[0]
    if a.shape != (n, n):
        raise ValueError(f"邻接矩阵必须是方阵，收到 {a.shape}")
    src, dst = np.where(a > 0)
    if drop_self:
        keep = src != dst
        src, dst = src[keep], dst[keep]
    w = np.ones(src.size, dtype=np.float32)
    return np.stack([src, dst]).astype(np.int64), w


def per_feature_stats(X: np.ndarray, n_train: int):
    """只用前 n_train 个时间步算每特征的 mean/std（逐特征，不是标量）。"""
    head = np.asarray(X[:, :n_train, :], dtype=np.float64)
    mean = np.nanmean(head, axis=(0, 1))
    std = np.nanstd(head, axis=(0, 1))
    std = np.where(std < 1e-8, 1.0, std)
    return mean.astype(np.float32), std.astype(np.float32)


def build_synth_v2(raw_npz: str, out_dir: str, T_in: int = 24, T_out: int = 1,
                   val_months: int = 6, split_ratio: float = 0.8) -> dict:
    """把生成器的原始 npz 转成带窗口与切分的 v2 数据集。"""
    os.makedirs(out_dir, exist_ok=True)
    d = np.load(raw_npz, allow_pickle=True)

    X = np.asarray(d["X"], dtype=np.float32)          # (N,T,F)
    y = np.asarray(d["y"], dtype=np.float32)          # (N,T)
    adj = np.asarray(d["adj_matrix"], dtype=np.float32)
    geo = np.asarray(d["geo_features"], dtype=np.float32)   # (N,3) 外生先验
    coords = np.asarray(d["coords"], dtype=np.float64)
    N, T, F = X.shape

    split_idx = int(T * split_ratio)                  # 96 for T=120
    if "split_idx" in d.files:
        split_idx = int(np.asarray(d["split_idx"]).reshape(-1)[0])

    # ---- 1) Sliding windows / 滑窗 ----
    Xw, yw, target_idx = sliding_windows(X, y, T_in=T_in, T_out=T_out, gap=0)
    W = Xw.shape[1]

    # ---- 2) Temporal split by target index, never by flattened position / 按目标索引切分 ----
    train_end = split_idx - 1                          # 95
    val_start = train_end - val_months + 1             # 90
    split = {
        "train": np.where(target_idx <= val_start - 1)[0],
        "val": np.where((target_idx >= val_start) & (target_idx <= train_end))[0],
        "test": np.where(target_idx >= split_idx)[0],
    }
    # Completeness check: the three splits must tile all windows and never overlap / 完备性检查
    union = np.sort(np.concatenate([split["train"], split["val"], split["test"]]))
    if union.size != W or not np.array_equal(union, np.arange(W)):
        raise ValueError(f"切分不完备或重叠：union={union.size}, W={W}")

    # ---- 3) 描述子：合成数据的 geo 是外生先验，逐窗口复制即可 ----
    desc = np.repeat(geo[None, :, :], W, axis=0)       # (W,N,3)

    # ---- 4) Graph / 建图 ----
    edge_index, edge_weight = adj_to_edge_index(adj, drop_self=True)

    # ---- 5) Per-feature scaling stats, fitted on the training period only / 只用训练期 ----
    x_mean, x_std = per_feature_stats(X, split_idx)
    y_mean = float(np.mean(y[:, :split_idx]))
    y_std = float(np.std(y[:, :split_idx])) or 1.0

    path = os.path.join(out_dir, "synth_v2.npz")
    np.savez_compressed(
        path,
        X_windows=Xw.astype(np.float32),
        y_windows=yw.astype(np.float32),
        y_series=np.asarray(y, dtype=np.float32),
        target_idx=target_idx.astype(np.int64),
        descriptors=desc.astype(np.float32),
        geo_raw=geo.astype(np.float32),
        node_coords=coords.astype(np.float64),
        edge_index=edge_index, edge_weight=edge_weight,
        split_train=split["train"], split_val=split["val"], split_test=split["test"],
        x_mean=x_mean, x_std=x_std,
        y_mean=np.float32(y_mean), y_std=np.float32(y_std),
        T_in=np.int64(T_in), T_out=np.int64(T_out), split_idx=np.int64(split_idx),
        feature_names=np.asarray(d["feature_names"]) if "feature_names" in d.files else np.array([]),
    )

    meta = {
        "source_raw": os.path.abspath(raw_npz),
        "N": int(N), "T": int(T), "F": int(F), "G": int(geo.shape[1]),
        "T_in": int(T_in), "T_out": int(T_out),
        "n_windows": int(W),
        "split_idx": int(split_idx),
        "split_sizes": {k: int(v.size) for k, v in split.items()},
        "target_range": [int(target_idx.min()), int(target_idx.max())],
        "n_edges": int(edge_index.shape[1]),
        "normalisation": {
            "x": "per-feature, fitted on months < split_idx only",
            "y": "scalar, fitted on months < split_idx only",
            "x_mean": x_mean.tolist(), "x_std": x_std.tolist(),
            "y_mean": y_mean, "y_std": y_std,
        },
        "descriptor_note": "synthetic geo priors [ALT, k_s, I_t] are EXOGENOUS "
                           "(not derived from the input series), so overlap with "
                           "the input is low by construction",
        "split_rule": f"train target<={val_start - 1}, val {val_start}-{train_end}, "
                      f"test>={split_idx}",
    }
    with open(os.path.join(out_dir, "synth_manifest_v2.json"), "w", encoding="utf-8") as fh:
        json.dump(meta, fh, indent=2, ensure_ascii=False)

    meta["npz_path"] = path
    return meta
