"""可追溯性：版本指纹与 run manifest。

Provenance: version fingerprint and run manifest.

R1-9 说我们"数字追不到源头"。这里给每个 run 钉三样东西：
代码树 hash、数据文件 hash、环境版本。少一样都别想在论文里出现。
Reviewer 1 said our numbers weren't traceable. Every run now pins three
things: code tree hash, dataset hash, environment. Miss one -> the number
does not go into the paper.
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import subprocess
from datetime import datetime

__all__ = ["sha256_file", "tree_hash", "env_info", "write_run_manifest"]

_CODE_EXT = {".py", ".yaml", ".yml", ".sh", ".md", ".txt", ".json"}
_SKIP_DIRS = {".git", "__pycache__", ".ipynb_checkpoints", "runs", "logs"}


def sha256_file(path: str, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


def tree_hash(root: str, exts=None) -> str:
    """整仓指纹：所有代码文件 (相对路径, sha256) 排序后再哈希。

    为什么不是简单的 `git rev-parse`？因为交付给审稿人的可能是 zip 包，
    不一定带 .git。这个函数对"解压出来的一个目录"同样有效。
    Why not just git rev-parse? The reviewer may get a plain zip without .git.
    This works on any extracted directory.
    """
    exts = _CODE_EXT if exts is None else set(exts)
    entries = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS]
        for name in filenames:
            if os.path.splitext(name)[1].lower() not in exts:
                continue
            full = os.path.join(dirpath, name)
            rel = os.path.relpath(full, root)
            entries.append((rel, sha256_file(full)))
    entries.sort()
    h = hashlib.sha256()
    for rel, digest in entries:
        h.update(f"{rel}\t{digest}\n".encode("utf-8"))
    return h.hexdigest()


def _git_commit(root: str) -> str:
    try:
        return subprocess.check_output(
            ["git", "-C", root, "rev-parse", "HEAD"],
            stderr=subprocess.DEVNULL, text=True,
        ).strip()
    except Exception:
        return "no-git"


def env_info() -> dict:
    info = {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "hostname": platform.node(),
    }
    try:
        import numpy
        info["numpy"] = numpy.__version__
    except Exception:
        pass
    try:
        import torch
        info["torch"] = torch.__version__
        info["cuda"] = torch.version.cuda
        info["cuda_available"] = bool(torch.cuda.is_available())
        if torch.cuda.is_available():
            info["gpu"] = torch.cuda.get_device_name(0)
            info["gpu_memory_gb"] = round(
                torch.cuda.get_device_properties(0).total_memory / 1024 ** 3, 1)
    except Exception:
        info["torch"] = "not-installed"
    return info


def write_run_manifest(out_dir: str, *, run_id: str, code_root: str,
                       data_paths, config: dict, seeds: dict,
                       extra: dict | None = None) -> str:
    """写 run_manifest.json，返回文件路径。

    宁可多记，也别到时候翻聊天记录找"当时用的哪个种子"。
    Record too much rather than dig through chat logs later asking
    "which seed was that again?".
    """
    os.makedirs(out_dir, exist_ok=True)
    data = []
    for p in data_paths:
        data.append({"path": os.path.abspath(p),
                     "sha256": sha256_file(p) if os.path.exists(p) else None})

    manifest = {
        "run_id": run_id,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "code": {
            "root": os.path.abspath(code_root),
            "tree_hash": tree_hash(code_root),
            "git_commit": _git_commit(code_root),
        },
        "data": data,
        "config": config,
        "seeds": seeds,
        "env": env_info(),
    }
    if extra:
        manifest["extra"] = extra

    path = os.path.join(out_dir, "run_manifest.json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=2, ensure_ascii=False, default=str)
    return path
