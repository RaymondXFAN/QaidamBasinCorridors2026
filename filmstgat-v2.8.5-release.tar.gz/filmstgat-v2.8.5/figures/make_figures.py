#!/usr/bin/env python3
"""Figure generation — reads result files only, never accepts hard-coded numbers.

作图脚本：只读结果文件，**不接受任何手写数字**。

Why this file exists / 为什么要重写
-----------------------------------
The previous figure script contained literal numbers:

    rmse_means = [1.716, 2.592]

and zero calls to np.load / json.load. The figures were therefore never verified
against the results — which is exactly how a table and its text drift apart.
Here every number comes from a result file; if a file is missing the figure is
skipped with a loud message, and if nothing at all is found the script exits
non-zero rather than producing empty axes.

原作图脚本把 RMSE 直接写在代码里，从不读结果文件，所以图与正文脱节是必然的。
本脚本的规则很简单：**要么从 JSON 读，要么不画**。

作者 / Author: Raymond Xiaohu Fan

用法 / Usage:
    python figures/make_figures.py --root <ROOT> [--only overlap]
"""

from __future__ import annotations

import argparse
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt          # noqa: E402
import numpy as np                       # noqa: E402

# ---- publication style (deterministic, no seaborn) ----
plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["DejaVu Serif", "Times New Roman"],
    "mathtext.fontset": "dejavuserif",
    "axes.unicode_minus": False,
    "font.size": 11,
    "axes.titlesize": 11,
    "axes.labelsize": 11,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
    "legend.fontsize": 9,
    "figure.dpi": 120,
    "savefig.dpi": 300,
    "savefig.bbox": "tight",
    "axes.spines.top": False,
    "axes.spines.right": False,
})

# colour-blind safe palette
C = {
    "base": "#6B8E9B",
    "cond": "#C4918A",
    "ref": "#444444",
    "ok": "#8BAF8E",
    "warn": "#C4A882",
}

FIG_DIR = None
MADE, MISSING = [], []


def _load(path):
    if not os.path.exists(path):
        MISSING.append(path)
        return None
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def _save(fig, name):
    out = os.path.join(FIG_DIR, name)
    fig.savefig(out + ".pdf")
    fig.savefig(out + ".png")
    plt.close(fig)
    MADE.append(out)
    print(f"  wrote {out}.pdf /.png")


# --------------------------------------------------------------------------- #
def fig_synthetic(root):
    """Synthetic benchmark: configurations and naive baselines in one frame."""
    d = _load(os.path.join(root, "runs/e1synth/e1_synth_summary.json"))
    if d is None:
        return
    naive, cfgs = d["naive"], d["configs"]
    names = list(cfgs)
    means = [cfgs[k]["rmse_mean"] for k in names]
    stds = [cfgs[k]["rmse_std"] for k in names]
    pers = float(naive["persistence"]["rmse"])

    fig, ax = plt.subplots(figsize=(6.4, 3.4))
    x = np.arange(len(names))
    ax.bar(x, means, yerr=stds, capsize=3, color=C["cond"], width=0.62,
           label="conditioned / baseline ST-GAT")
    ax.axhline(pers, color=C["ref"], ls="--", lw=1.2,
               label=f"persistence ({pers:.4f} °C)")
    ax.set_xticks(x)
    ax.set_xticklabels(names, rotation=20, ha="right")
    ax.set_ylabel("RMSE (°C)")
    # 留白按数据跨度取比例，不写死任何数值 / padding relative to the data range
    lo_v, hi_v = min(means + [pers]), max(means + [pers])
    rng = max(hi_v - lo_v, 1e-3)
    # 顶部留白专门给图例，底部只留一点——比把图例丢到画布外更稳
    # Reserve headroom at the top for the legend; far more robust than anchors.
    ax.set_ylim(lo_v - 0.15 * rng, hi_v + 0.75 * rng)
    ax.set_title("Synthetic benchmark: no configuration improves on persistence")
    # 纵轴区间窄时柱子几乎顶满画布，图例必须移到画布外，否则会压住柱子
    # With a narrow y-range the bars fill the canvas; keep the legend outside.
    ax.legend(loc="upper center", ncol=2, frameon=False)
    _save(fig, "fig_synthetic_benchmark")


def fig_conditioning_real(root):
    """Real-data conditioning ablations (E1), with persistence if available."""
    d = _load(os.path.join(root, "runs/e1/summary_e1.json"))
    if d is None:
        return
    names = list(d)
    means = [d[k]["rmse_mean"] for k in names]
    stds = [d[k]["rmse_std"] for k in names]

    pers = None
    e3 = _load(os.path.join(root, "runs/e3/metrics_e3.json"))
    if isinstance(e3, list):
        for row in e3:
            if row.get("model") == "persistence":
                pers = float(row["rmse"])
                break

    fig, ax = plt.subplots(figsize=(6.4, 3.4))
    x = np.arange(len(names))
    ax.bar(x, means, yerr=stds, capsize=3, color=C["base"], width=0.6)
    if pers is not None:
        ax.axhline(pers, color=C["ref"], ls="--", lw=1.2,
                   label=f"persistence ({pers:.4f} °C)")
        ax.legend(loc="upper center", ncol=2, frameon=False)
    ax.set_xticks(x)
    ax.set_xticklabels(names, rotation=20, ha="right")
    ax.set_ylabel("RMSE (°C)")
    ax.set_title("Real MAGT: conditioning ablations")
    _save(fig, "fig_conditioning_real")


def fig_overlap(root):
    """Two panels: the rho sweep (E2) and the endpoint contrast (E2b)."""
    sweep = _load(os.path.join(root, "runs/e2/e2_summary.json"))
    endpoints = _load(os.path.join(root, "runs/e2b/analysis/analysis.json"))
    if sweep is None and endpoints is None:
        return

    fig, axes = plt.subplots(1, 2, figsize=(9.6, 3.5))

    if sweep is not None:
        ax = axes[0]
        rho = [r["rho_chance_corrected"] for r in sweep]
        delta = [r["delta_full_minus_add"] for r in sweep]
        err = [r.get("delta_std", 0.0) for r in sweep]
        ax.errorbar(rho, delta, yerr=err, marker="o", ms=5, lw=1.4,
                    capsize=3, color=C["cond"])
        ax.axhline(0.0, color=C["ref"], ls=":", lw=1.0)
        ax.set_xlabel(r"chance-corrected overlap $\rho^\ast$")
        ax.set_ylabel(r"$\Delta$ RMSE (full $-$ add), °C")
        ax.set_title("Five-level sweep (exploratory, n=5)")
    else:
        axes[0].axis("off")

    if endpoints is not None:
        ax = axes[1]
        lv = endpoints["levels"]
        rho = [L["rho_star"] for L in lv]
        delta = [L["delta"] for L in lv]
        lo = [L["delta"] - L["ci95"][0] for L in lv]
        hi = [L["ci95"][1] - L["delta"] for L in lv]
        ax.errorbar(rho, delta, yerr=[lo, hi], fmt="o", ms=7, lw=1.4,
                    capsize=4, color=C["cond"])
        ax.axhline(0.0, color=C["ref"], ls=":", lw=1.0)
        for x, y, L in zip(rho, delta, lv):
            star = "*" if L["p"] < 0.05 else ""
            ax.annotate(f"{y:+.4f}{star}", (x, y), textcoords="offset points",
                        xytext=(0, 9), ha="center", fontsize=9)
        ax.set_xlabel(r"chance-corrected overlap $\rho^\ast$")
        ax.set_ylabel(r"$\Delta$ RMSE (full $-$ add), °C")
        ax.set_title("Endpoint contrast (n=24 seeds, 95% CI)")
    else:
        axes[1].axis("off")

    fig.suptitle("Multiplicative modulation only costs more when overlap is high",
                 fontsize=11)
    _save(fig, "fig_overlap_contrast")


def fig_split_timeline(root):
    """Window/split design: the one picture that answers 'what leaked?'."""
    csv = os.path.join(root, "datasets_v2/window_manifest_v2.csv")
    if not os.path.exists(csv):
        MISSING.append(csv)
        return
    rows = [ln.strip().split(",") for ln in open(csv, encoding="utf-8")][1:]
    if not rows:
        return
    years_in = [int(r[1].split("-")[0]) for r in rows]
    years_tg = [int(r[2].split("-")[0]) for r in rows]
    split = [r[6] for r in rows]
    n = len(rows)
    color = {"train": C["base"], "val": C["warn"], "test": C["cond"]}

    fig, ax = plt.subplots(figsize=(7.2, 2.9))
    for i, (yi, yt, s) in enumerate(zip(years_in, years_tg, split)):
        ax.plot([yi, yt], [i, i], color=color.get(s, C["ref"]), lw=2.2)
        ax.plot(yt, i, marker="o", ms=3, color=color.get(s, C["ref"]))
    handles = [plt.Line2D([], [], color=color[k], lw=2.4, label=k)
               for k in ("train", "val", "test")]
    ax.legend(handles=handles, frameon=False, ncol=3, loc="upper left")
    ax.set_ylabel("window index")
    ax.set_xlabel("year")
    ax.set_title(f"Temporal split of {n} forecast windows (input start → target)")
    _save(fig, "fig_split_timeline")




# --------------------------------------------------------------------------- #
#  v3 图（§3–§6）：实现在 figures/v3_figures.py，这里只做汇总
# --------------------------------------------------------------------------- #
def _v3(name):
    def runner(root):
        import v3_figures as v3
        fn = {"floors": v3.plot_floors, "collapse": v3.plot_collapse,
              "effects": v3.plot_effects, "dose": v3.plot_dose}[name]
        written, missing = fn(root, FIG_DIR)
        MADE.extend(written)
        MISSING.extend(missing)
    return runner

def main() -> int:
    global FIG_DIR
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=os.environ.get("ROOT", "/root/autodl-tmp/revision_v2"))
    ap.add_argument("--out", default=None)
    ap.add_argument("--only", default=None,
                    help="synthetic|real|overlap|split|floors|collapse|effects|dose")
    args = ap.parse_args()

    FIG_DIR = args.out or os.path.join(args.root, "figures")
    os.makedirs(FIG_DIR, exist_ok=True)
    print(f"figures → {FIG_DIR}")

    jobs = {"synthetic": fig_synthetic, "real": fig_conditioning_real,
            "overlap": fig_overlap, "split": fig_split_timeline,
            "floors": _v3("floors"), "collapse": _v3("collapse"),
            "effects": _v3("effects"), "dose": _v3("dose")}
    todo = jobs if args.only is None else {args.only: jobs[args.only]}
    for name, fn in todo.items():
        print(f"[{name}]")
        fn(args.root)

    print(f"\nmade {len(MADE)} figure(s)")
    if MISSING:
        print("missing inputs (skipped, NOT fabricated):")
        for m in MISSING:
            print(f"  {m}")
    if not MADE:
        print("\n[fatal] no figure produced — run the experiments first.")
        print("        bash run_all.sh e1 / e2 / e2b / synth")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
