#!/usr/bin/env python3
"""v3 figures — floors / collapse / effects / dose-response.

新稿 §3–§6 的四张图。规矩和 make_figures.py 一致：**只读结果文件，读不到就跳过**，
绝不把数字写进代码。返回 (written, missing) 由调用方汇总。

作者 / Author: Raymond Xiaohu Fan
"""

from __future__ import annotations

import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt          # noqa: E402
import numpy as np                       # noqa: E402

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["DejaVu Serif", "Times New Roman"],
    "mathtext.fontset": "dejavuserif",
    "axes.unicode_minus": False,
    "font.size": 11,
    "axes.titlesize": 11,
    "axes.labelsize": 11,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
    "legend.fontsize": 9,
    "figure.dpi": 120,
    "savefig.dpi": 300,
    "savefig.bbox": "tight",
    "axes.spines.top": False,
    "axes.spines.right": False,
})

C = {"base": "#6B8E9B", "cond": "#C4918A", "ref": "#444444",
     "ok": "#8BAF8E", "warn": "#C4A882"}


def _read_json(path):
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def _write(fig, out_dir, name):
    out = os.path.join(out_dir, name)
    fig.savefig(out + ".pdf")
    fig.savefig(out + ".png")
    plt.close(fig)
    print(f"  wrote {out}.pdf /.png")
    return out


def plot_floors(root, out_dir):
    """F1 — 零建模地板 + 滞后剖面（§3.1–3.2）。"""
    written, missing = [], []
    path = os.path.join(root, "datasets_v2", "signal_diagnosis.json")
    d = _read_json(path)
    if d is None:
        return written, [path]

    floors = {f["floor"]: f for f in d.get("floors", [])}
    keys = ["persistence (t-1 observation)", "pixel train-period mean",
            "pixel mean + linear trend", "ORACLE pixel level (uses test yrs)"]
    keys = [k for k in keys if k in floors]
    labels = {"persistence (t-1 observation)": "Persistence",
              "pixel train-period mean": "Climatology",
              "pixel mean + linear trend": "Clim. + trend",
              "ORACLE pixel level (uses test yrs)": "Oracle level\n(not a forecast)"}

    fig, axes = plt.subplots(1, 2, figsize=(9.4, 3.6))
    ax = axes[0]
    vals = [floors[k]["rmse"] for k in keys]
    cols = [C["ref"]] * (len(keys) - 1) + [C["warn"]]
    bars = ax.bar(range(len(keys)), vals, color=cols, width=0.62)
    for i, b in enumerate(bars):
        ax.text(b.get_x() + b.get_width() / 2, b.get_height() + 0.06,
                f"{vals[i]:.3f}", ha="center", fontsize=9)
    ax.set_xticks(range(len(keys)))
    ax.set_xticklabels([labels[k] for k in keys], fontsize=9)
    ax.set_ylabel("RMSE (°C)")
    ax.set_title("(a) Zero-modelling floors")
    ax.set_ylim(0, max(vals) * 1.20)

    prof = d.get("lag_profile", [])
    ax = axes[1]
    if prof:
        ks = [r["lag"] for r in prof]
        rs = [r["rmse"] for r in prof]
        ax.plot(ks, rs, "o-", color=C["base"], ms=4, lw=1.4, label="persistence at lag k")
        if "pixel train-period mean" in floors:
            ax.axhline(floors["pixel train-period mean"]["rmse"], ls="--", lw=1.1,
                       color=C["cond"], label="climatology")
        ax.axvline(5, ls=":", lw=1.0, color=C["ref"])
        ax.text(5.2, min(rs) + 0.04, "forecast gap", fontsize=8, color=C["ref"])
        ax.set_xlabel("lag k (years)")
        ax.set_ylabel("RMSE (°C)")
        ax.set_title("(b) Skill vs forecast lag")
        ax.legend(frameon=False, loc="lower right")
    written.append(_write(fig, out_dir, "F1_floors_and_lag"))
    return written, missing


def plot_collapse(root, out_dir):
    """F2 — 模型输出 vs persistence（§4.1）。r≈1 即塌缩的直接证据。"""
    written, missing = [], []
    data_path = os.path.join(root, "datasets_v2", "real_magt_data_v2_clean.npz")
    if not os.path.exists(data_path):
        return written, [data_path]

    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from filmstgat.experiments.common import pick_pixels

    d = np.load(data_path, allow_pickle=True)
    pix = pick_pixels({"series": d["series"]}, 500, seed=42, mode="stratified")
    test_w = d["split_test"]
    gap = 4
    pers = np.stack([d["series"][pix][:, int(t) - gap - 1] for t in d["target_idx"][test_w]],
                    axis=0)

    cfgs = [("standard", "Standard"), ("standard_wider", "Standard (wider)"),
            ("film_full", "FiLM (full)"), ("concat_info", "Concat")]
    fig, axes = plt.subplots(1, len(cfgs), figsize=(3.1 * len(cfgs), 3.3),
                             sharex=True, sharey=True)
    axes = np.atleast_1d(axes)
    for ax, (cfg, lab) in zip(axes, cfgs):
        p = os.path.join(root, "runs", "e1", f"{cfg}_seed42", "predictions.npz")
        if not os.path.exists(p):
            missing.append(p)
            ax.set_visible(False)
            continue
        z = np.load(p)
        pred = z["pred"]
        if pred.shape != pers.shape:
            missing.append(f"{p} (shape {pred.shape} != persistence {pers.shape})")
            ax.set_visible(False)
            continue
        r = float(np.corrcoef(pred.ravel(), pers.ravel())[0, 1])
        gap_rmse = float(np.sqrt(np.mean((pred - pers) ** 2)))
        ax.scatter(pers.ravel(), pred.ravel(), s=3, alpha=0.25, color=C["base"],
                   edgecolors="none")
        lim = [float(np.percentile(pers, 0.5)), float(np.percentile(pers, 99.5))]
        ax.plot(lim, lim, "--", lw=1.0, color=C["ref"])
        ax.set_title(f"{lab}\nr = {r:.4f},  gap RMSE = {gap_rmse:.2f}", fontsize=9)
        ax.set_xlabel("persistence (°C)")
    axes[0].set_ylabel("model prediction (°C)")
    written.append(_write(fig, out_dir, "F2_collapse_to_persistence"))
    return written, missing


def plot_effects(root, out_dir):
    """F3 — 逐 seed 效应森林图 + MDE 灰带（§5）。"""
    written, missing = [], []
    files = []
    for tag, lab in (("h5_ff_vs_std", "h = 5"), ("h1_ff_vs_std", "h = 1")):
        p = os.path.join(root, "runs", "e4", f"aggregate_{tag}.json")
        (files.append((p, lab)) if os.path.exists(p) else missing.append(p))
    if not files:
        return written, missing

    fig, axes = plt.subplots(1, len(files), figsize=(5.4 * len(files), 3.4))
    axes = np.atleast_1d(axes)
    for ax, (path, lab) in zip(axes, files):
        d = _read_json(path)
        if d is None:
            missing.append(path)
            ax.set_visible(False)
            continue
        per = d.get("per_seed", [])
        mde = d.get("mde", {}).get("mde", float("nan"))
        if np.isfinite(mde):
            # 灰带 = "分辨不出差异"的区域。图例文字要说明它的含义，
            # 只写 ±MDE 读者不知道那是什么。
            ax.axvspan(-mde, mde, color=C["warn"], alpha=0.22, lw=0,
                       label=f"resolution limit, |Δ| < {mde:.3f} °C")
        ax.axvline(0, color=C["ref"], lw=0.9)
        for i, r in enumerate(per):
            lo, hi = r.get("ci95", [np.nan, np.nan])
            ax.plot([lo, hi], [i, i], "-", color=C["base"], lw=1.6)
            ax.plot(r.get("delta_mean", np.nan), i, "o", color=C["base"], ms=5)
        sl = d.get("seed_level", {})
        mean, ci = sl.get("mean", np.nan), sl.get("ci95", [np.nan, np.nan])
        ybar = len(per) + 0.6
        ax.plot([ci[0], ci[1]], [ybar, ybar], "-", color=C["cond"], lw=2.4)
        ax.plot(mean, ybar, "D", color=C["cond"], ms=6)
        # 数值直接写进 y 轴刻度标签：之前放在坐标区里，无论放哪都会压到
        # 某一行误差棒。刻度标签天然不占绘图区。
        # Put the number in the y tick label — anywhere inside the axes it
        # collides with some error bar.
        ax.set_ylim(len(per) + 1.1, -0.7)
        ax.set_yticks(list(range(len(per))) + [ybar])
        ax.set_yticklabels([f"seed {r['seed']}" for r in per]
                           + [f"pooled {mean:+.3f}"], fontsize=8)
        ax.set_xlabel("Δ RMSE, full FiLM − standard (°C)")
        ax.set_title(f"{lab}  ({len(per)} seeds)")
        ax.legend(frameon=False, fontsize=8, loc="lower right")
        ax.invert_yaxis()
    written.append(_write(fig, out_dir, "F3_effect_vs_resolution"))
    return written, missing


def plot_dose(root, out_dir):
    """F4 — Δ 随描述子对齐度 α 的剂量-反应（§6）。"""
    written, missing = [], []
    path = os.path.join(root, "runs", "e2", "e2_summary.json")
    d = _read_json(path)
    if not d:
        return written, [path]
    rows = [r for r in d if r.get("delta_full_minus_add") is not None]
    if not rows:
        return written, [path + " (no delta rows)"]
    rows.sort(key=lambda r: r["alpha"])

    a = np.array([r["alpha"] for r in rows], dtype=float)
    dl = np.array([r["delta_full_minus_add"] for r in rows], dtype=float)

    fig, ax = plt.subplots(figsize=(4.9, 3.6))
    ax.axhline(0, color=C["ref"], lw=0.9)
    ax.plot(a, dl, "o-", color=C["cond"], ms=5, lw=1.4,
            label="per-seed mean Δ (full − additive)")
    # ⚠️ 不能把 delta_ci95 直接当 errorbar 的 yerr：它是对**集成预测**做的块自助区间，
    #    中心不一定等于逐 seed 均值，硬套会得到负的误差并报错（v2.5.0 就是这样崩的）。
    #    两个估计量就分开画：点=逐 seed 均值，竖线=集成预测的自助区间。
    #    Never pass delta_ci95 as yerr: it comes from an ensemble bootstrap whose
    #    centre need not equal the per-seed mean, which yields negative errors.
    for x, r in zip(a, rows):
        ci = r.get("delta_ci95")
        if ci and np.all(np.isfinite(ci)):
            ax.plot([x, x], [ci[0], ci[1]], lw=3.2, alpha=0.35,
                    color=C["base"], solid_capstyle="butt",
                    label="block-bootstrap CI (ensemble)" if x == a[0] else None)
    for r in rows:
        ax.annotate(f"$\\rho$={r.get('rho', float('nan')):.3f}",
                    (r["alpha"], r["delta_full_minus_add"]),
                    textcoords="offset points", xytext=(5, 8), fontsize=7,
                    color=C["ref"])
    ax.set_xlabel(r"descriptor–input overlap $\alpha$")
    ax.set_ylabel("Δ RMSE (°C)")
    ax.set_title("Overlap dose–response")
    ax.legend(frameon=False, fontsize=8)
    written.append(_write(fig, out_dir, "F4_overlap_dose_response"))
    return written, missing
