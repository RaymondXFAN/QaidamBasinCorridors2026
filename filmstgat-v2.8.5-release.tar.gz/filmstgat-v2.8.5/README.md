# filmstgat v2.8.5

**What a permafrost temperature benchmark can and cannot resolve — an audited,
leakage-free reference implementation.**

A reproducible study of whether geological-prior conditioning improves multi-year
permafrost ground-temperature forecasts. It rebuilds the full evaluation protocol,
removes three classes of window-overlap leakage, and reports four independent lines of
evidence that the standard benchmark cannot resolve the effect sizes usually claimed for
this task: zero-modelling floors that nearly coincide (persistence 1.361 °C vs per-pixel
climatology 1.395 °C), model collapse to persistence (r ≥ 0.9974 across 25 runs and three
external backbones), a minimum detectable effect of 6.7–9.0 % of RMSE that exceeds the
gains typically reported, and a competition probe showing that conditioning is used only
when no competing input path exists (9.000 °C without descriptors, 1.140 °C with a leaking
oracle descriptor, 1.340 °C once the input window is restored). The repository ships every
result file, a dataset contract, per-run provenance with code and data hashes, and a
self-audit that a reviewer can run in ten seconds without a GPU.

---

## For reviewers / 给审稿人

Three commands, in order. The first two need **no data and no GPU**.

```bash
python scripts/repro_audit.py     # structure / syntax / paths / secrets / data / integrity
bash run_all.sh check            # offline logic tests, ~10 s
ROOT=results bash run_all.sh figures   # rebuild every figure from shipped result files
```

`results/` contains each run's `metrics.json`, `predictions.npz` and
`run_manifest.json` (with per-file SHA-256 in `results/MANIFEST.json`), so every
number in the manuscript can be traced and every figure regenerated without
retraining.

* Installation, the three reproduction levels, and a table of error messages we
  actually hit: **`docs/DEPLOY.md`**
* Data provenance, the file contract, and the two construction rules that prevent
  leakage: **`docs/DATA.md`**
* What is bit-exact and what is only statistically reproducible: `docs/DEPLOY.md` §4


---

## What this repository is / 这是什么

A single-source-of-truth reimplementation of every experiment reported in the
manuscript. The original submission had two trainer stacks, three FiLM
implementations and a data pipeline in which 77.5–79% of "test" samples were in
fact training-period windows. Those defects are addressed here, and the evidence
for each fix is reproducible from this directory alone.

本仓库是论文全部实验的**单一真相源**实现。原稿有三套 FiLM 实现、两套训练循环，
且 77.5–79% 的"测试样本"实际来自训练期；这里逐条修复，且每条修复都能被复现。

**Design rule / 设计原则**: one implementation per concept, one training loop, one
evaluator, one split. If two copies of anything exist, that is a bug.

---

## Quickstart / 快速开始

```bash
# 1) environment
pip install -r requirements.txt

# 2) offline self-checks (no GPU needed, ~10 s)
bash run_all.sh check

# 3) rebuild datasets (real MAGT + synthetic)
bash run_all.sh data

# 4) main experiments (each launches under nohup and prints how to follow it)
bash run_all.sh e1        # conditioning ablations, real data
bash run_all.sh e2        # controlled overlap sweep
bash run_all.sh e2b       # endpoint contrast, 24 seeds
bash run_all.sh e3        # naive baselines
bash run_all.sh e4        # uncertainty / non-inferiority
bash run_all.sh synth     # synthetic benchmark + naive baselines
bash run_all.sh analyze   # paired DiD analysis of e2b
```

---

## Layout / 目录结构

```
filmstgat/
├── data/
│   ├── windows.py         sliding windows, temporal split, scaler, manifest
│   ├── real.py            rebuild the real MAGT dataset from the legacy npz
│   ├── synthetic.py       vendored synthetic generator (byte-identical, seeded)
│   └── synth_windows.py   synthetic → windows, adjacency → edges, per-feature stats
├── eval/
│   ├── metrics.py         the one evaluator (rmse/mae/r2 + consistency checks)
│   └── overlap.py         overlap degree rho and chance-corrected rho*
├── models/
│   ├── film.py            the ONE FiLM implementation
│   ├── gat.py             sparse GAT layer
│   ├── stgat.py           one class covering every ablation
│   └── factory.py         seed first, build second
├── train/
│   ├── seeding.py         deterministic RNG setup
│   └── trainer.py         the ONE training loop
├── experiments/           e1, e1_synthetic, e2, e3, e4
└── utils/provenance.py    hashes, environment capture, run manifests

scripts/                   dataset builders, probes, diagnostics, analyses
tests/                     offline suites (no torch) + GPU suite
docs/REPRODUCE.md          exact commands, expected hashes, runtimes
```

---

## One protocol decision worth knowing / 一个必须知道的协议决定

In the synthetic benchmark the target (settlement) is **not** among the 12
generated features, so the residual shortcut `y_hat = x_last + f(.)` cannot use
channel 0. We therefore append the lagged target as channel 13 and point the
shortcut at it: `y_hat = y(t-1) + f(.)`, shared by every configuration.
Disabling the shortcut instead (`--no-residual`) leaves the models without a
persistence path and they lose by roughly 4x — that variant exists only as a
diagnostic and must not be used for the main table.

合成数据的目标（沉降）不在 12 个生成特征里，所以残差捷径必须指向新增的滞后通道，
而不是通道 0。关掉捷径会人为让模型失去 persistence 通路，只能作为诊断变体。

## Three invariants / 三条不变量

1. **No leakage by construction.** Pixel eligibility is decided on 1981–2010 only;
   descriptors are computed per forecast origin; scalers are fitted on the
   training period; splits are taken on window index, never on a flattened row.
2. **Every number is traceable.** Each run writes `predictions.npz`,
   `metrics.json` and `run_manifest.json` (code tree hash + dataset sha256 +
   environment + seeds).
3. **Metrics are in physical units.** RMSE is always computed after the inverse
   transform, and `assert_metric_consistency()` refuses to compare runs that did
   not share a test set.

---

## Tests / 测试

| suite | needs GPU | what it pins down |
|:--|:--|:--|
| `tests/test_core.py` | no | windows, split, FiLM algebra, rho, metrics |
| `tests/test_data_rebuild.py` | no | dataset rebuild counts and hashes |
| `tests/test_e2_design.py` | no | the overlap manipulation; and the **decision rule** (a monotone-looking but non-significant result must be judged "no evidence") |
| `tests/test_synth.py` | no | generator determinism, split completeness, lag channel does not leak `y(t)` |
| `tests/test_torch.py` | yes | tensor-order regressions, determinism, parameter counts |

Run them all offline with `bash run_all.sh check`.

---

## Reproducibility notes / 复现说明

- The synthetic dataset is **bit-reproducible** from `scripts/regen_synthetic.py`:
  the generator is vendored byte-for-byte and consumes a single seeded RNG.
- The real dataset is rebuilt from the legacy `npz` (all 45,041 pixels × 38 years
  are stored there), so no GeoTIFF access is required to reproduce the splits.
- Expected hashes are listed in `docs/REPRODUCE.md`; they are produced, not
  asserted, so a mismatch is visible rather than silently tolerated.

---

## Known limitations of the code / 已知局限

- Neighbour graphs use pixel-index distances with an assumed 1 km grid, not
  geodesic distance.
- The synthetic generator is legacy research code: it is vendored unchanged to
  preserve the RNG stream, so its style does not match the rest of the package.
- No GPU is required for the offline suites, but every experiment needs one.

---

*Raymond Xiaohu Fan*
